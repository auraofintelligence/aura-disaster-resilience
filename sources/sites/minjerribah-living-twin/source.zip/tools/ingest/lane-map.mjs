// The map lane. A KML or KMZ of the island becomes candidate records, screened, bounds-checked and
// reconciled against what the packs already hold.
//
//   node tools/ingest/lane-map.mjs --extract ingest-inbox/mymaps/north-stradbroke-island.kml \
//        --batch mymaps-nsi-2026-08 --contributor "Luke Hayes" \
//        --source "Google MyMaps mid=..." --fetched 2026-08-10
//
//   node tools/ingest/lane-map.mjs --extract <file> --dry     parse, screen and report, write nothing
//
// It writes to tools/ingest/candidates/ and never to data/. Promotion is tools/ingest/promote.mjs,
// which runs the whole gate and rolls back if anything blocks.
//
// WHY THIS LANE IS DIFFERENT FROM THE OTHERS
//
// A document lane reads a publisher's words. A map lane reads somebody's hand. The first map through
// here is the owner's own Google MyMaps of the island he lives on, and it is the highest-trust
// contribution this project has received, because he put every pin there himself. It also carries
// his own confidence statement, which is the pack's dataStatus and is not overridden anywhere in
// this file:
//
//   "UNDER CONSTRUCTION. I don't know what information on this map is up to date or accurate so just
//    use this as a starting point to do your own research."
//
// So the confidence is split rather than averaged. High on the fact that a thing exists and is
// roughly where the pin is, because he stood there. Lower on whether it still trades, under that
// name, with that operator, because he says so himself. Averaging those two into one number would
// throw away the most useful thing the source told us about itself, which is the same reading
// docs/SOURCES.md takes of the events engine's own dataStatus.
//
// FOUR THINGS THIS LANE WILL NOT DO
//
//   It does not overwrite a sourced record. Every pin lands in its own contribution pack carrying a
//   reconciliation verdict against what already exists. Applying a CORRECTS into data/places.json or
//   data/businesses.json is a person's decision and a separate commit, and the note on the corrected
//   record has to say whose pin it came from.
//
//   It does not swap coordinates. KML is lon,lat,alt. Everything that turns a KML triple into a lat
//   and a lon goes through toLatLon in tools/ingest/kml.mjs, and every point is checked against the
//   island's bounding box. A point outside it is reported, not dropped: a placemark in the wrong
//   ocean is a fact about the file that somebody needs to know.
//
//   It does not carry a contact detail. tools/ingest/checks-screens.mjs strips them here and fails
//   the gate if one ever reaches a contribution pack. Nothing in this tool ever prints the value.
//
//   It does not decide a cultural question. A placemark whose text touches ceremony, or names a
//   place as sacred or restricted, is held: no record, no coordinate, no name in the interface. So
//   is any other placemark drawn over the same ground, because the site is the thing that would be
//   published, not the wording. Held items go to docs/CULTURAL-REVIEW.md as questions for QYAC, and
//   this file names none of them in anything it writes.

import fs from 'node:fs';
import path from 'node:path';
import { ROOT, today, shortHash, readJSON, exists } from './lib.mjs';
import { readMapFile, placemarks, toLatLon } from './kml.mjs';
import { findContactDetails, stripContactDetails, tokenFamily } from './checks-screens.mjs';
import { coarsen } from './lane-contribution.mjs';

export const EXTRACTOR = { id: 'lane-map', version: '1.0' };

// ------------------------------------------------------------------------------------------------
// The island
// ------------------------------------------------------------------------------------------------

/**
 * Minjerribah's bounding box, generously drawn.
 *
 * A pin outside this is not necessarily wrong; it may be the mainland ferry terminal at Cleveland,
 * which is a real part of how this island works. It is reported either way, because the alternative
 * is a tool that quietly drops a placemark and a person who never finds out.
 */
export const ISLAND_BOUNDS = { minLat: -27.75, maxLat: -27.35, minLon: 153.35, maxLon: 153.55 };

const EARTH_R = 6371008.8;

/** Metres between two lat/lon pairs. Equirectangular, which is exact enough over 30 km. */
export function metresBetween(a, b) {
  const rad = Math.PI / 180;
  const x = (b.lon - a.lon) * rad * Math.cos(((a.lat + b.lat) / 2) * rad);
  const y = (b.lat - a.lat) * rad;
  return Math.sqrt(x * x + y * y) * EARTH_R;
}

/** The representative point of a geometry: the point itself, or the mean of a ring's vertices. */
export function representativePoint(geometry) {
  if (!geometry || !geometry.outer || !geometry.outer.length) return null;
  if (geometry.type === 'Point') return toLatLon(geometry.outer[0]);
  // A closed ring repeats its first vertex last. Counting it twice pulls the mean toward it.
  const ring = geometry.outer.slice();
  if (ring.length > 2) {
    const first = ring[0];
    const last = ring[ring.length - 1];
    if (first[0] === last[0] && first[1] === last[1]) ring.pop();
  }
  let lat = 0;
  let lon = 0;
  for (const t of ring) { const p = toLatLon(t); lat += p.lat; lon += p.lon; }
  return { lat: lat / ring.length, lon: lon / ring.length, alt: 0 };
}

// ------------------------------------------------------------------------------------------------
// Names
// ------------------------------------------------------------------------------------------------

const NAME_NOISE = new Set(['the', 'a', 'an', 'of', 'and', 'at', 'on', 'in', 'inc', 'pty', 'ltd', 'co', 'qld']);

/** Two spellings of the same word across the packs and the map. Declared, and deliberately short. */
const NAME_SYNONYMS = [
  [/\bcampgrounds?\b/g, 'camping ground'],
  [/\bcar ?parks?\b/g, 'car park'],
  [/\btoilets?\b/g, 'toilet'],
  [/\bfoodworks\b/g, 'foodworks']
];

/** A name reduced to comparable tokens. Deterministic, and it never drops a word that carries a place. */
export function nameTokens(name) {
  let s = String(name)
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[‘’']/g, '')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
  for (const [rx, to] of NAME_SYNONYMS) s = s.replace(rx, to);
  // One plural rule, applied to both sides, so "Gold Cat Flyer" and "Gold Cats" are the same boat.
  // Anything more than this is a stemmer, and a stemmer inside a matcher is a source of confident
  // wrong pairings that nobody can debug.
  return s.split(' ')
    .filter((t) => t && !NAME_NOISE.has(t))
    .map((t) => (t.length > 3 && t.endsWith('s') && !t.endsWith('ss') ? t.slice(0, -1) : t));
}

/**
 * The part of a placemark name that says what the thing is.
 *
 * This author uses a semicolon the way a signpost does: the thing, then where it is. "Bus Stop;
 * Manta Lodge YHA" is a bus stop, not a lodge, and matching on the whole string paired it with
 * `businesses/manta-lodge-scuba-centre` at a containment score of 0.85 and then offered to move the
 * lodge to the bus stop. "Brown Lake; Picnic Area and Park" is Brown Lake. Taking the leading
 * segment is the author's own convention read back, and the full name is kept on the record.
 */
export function matchName(name) {
  const head = String(name).split(/\s*;\s*/)[0].trim();
  return head.length >= 3 ? head : String(name).trim();
}

/**
 * How alike two names are, from 0 to 1.
 *
 * Jaccard over the token sets, lifted when one name contains the other whole. The lift is the part
 * that needs guarding: a single shared token is contained in everything. "Dunwich" is inside
 * "Dunwich RSL", "Dunwich Post Office" and "Dunwich Police Station", and an unguarded containment
 * score of 0.85 had this lane offering to move the township of Dunwich to the post office. So the
 * lift only applies when the shorter name is at least two words long.
 */
export function nameScore(a, b) {
  const A = new Set(nameTokens(a));
  const B = new Set(nameTokens(b));
  if (!A.size || !B.size) return 0;
  let shared = 0;
  let sharedDistinct = 0;
  for (const t of A) {
    if (!B.has(t)) continue;
    shared++;
    if (!PLACE_WORDS.has(t)) sharedDistinct++;
  }
  const jaccard = shared / (A.size + B.size - shared);
  const smaller = Math.min(A.size, B.size);
  // Two names that share only the township they sit in have nothing in common. "Point Lookout Public
  // Toilet Block" and "Point Lookout Pharmacy" share two words out of three and scored 0.57, which
  // was enough to offer to move the pharmacy to the toilet block.
  const containment = (smaller >= 2 && sharedDistinct > 0) ? (shared / smaller) * 0.85 : 0;
  return Math.max(jaccard, containment);
}

/** Township and island words. They locate a name; they never distinguish one. */
const PLACE_WORDS = new Set([
  'point', 'lookout', 'dunwich', 'amity', 'stradbroke', 'straddie', 'north', 'island', 'minjerribah',
  'nsi', 'goompi', 'gumpi', 'koompe', 'mulumba', 'mooloomba', 'pulan', 'bulan', 'queensland', 'qld'
]);

/**
 * Feature types whose recorded coordinate is a representative point rather than a doorway.
 *
 * A beach is 600 m long and a national park is 27 km. A pin 140 m along Main Beach does not correct
 * `places/main-beach`; it corroborates it. Getting this wrong turned twelve honest corroborations
 * into corrections, which is the sort of report that trains a reader to stop believing the column.
 */
const EXTENDED_TYPES = new Set([
  'township', 'beach', 'lake', 'national_park', 'conservation_park', 'headland', 'gorge', 'walk',
  'campground', 'beach_camping', 'spring', 'rock', 'park', 'hazard_zone', 'sports_field', 'cemetery',
  'historic_site', 'lighthouse', 'lookout', 'mine_rehabilitation_area', 'water_body'
]);

const STRONG_NAME = 0.55;
const WEAK_NAME = 0.30;
const SAME_SPOT_M = 75;
const SAME_EXTENDED_M = 600;
const NEAR_SPOT_M = 600;
const WEAK_CLOSE_M = 80;

/** The same idea, for packs whose `type` is a trade category rather than a shape of ground. */
const EXTENDED_WORDS = /\b(golf|course|oval|field|reserve|precinct|trail|walk|beach|lake|park|campground|camping|cemetery|foreshore|national)\b/i;

function sameSpotTolerance(record) {
  if (EXTENDED_TYPES.has(String(record.type || '').toLowerCase())) return SAME_EXTENDED_M;
  if (EXTENDED_WORDS.test(`${record.name} ${record.type}`)) return SAME_EXTENDED_M;
  return SAME_SPOT_M;
}

// ------------------------------------------------------------------------------------------------
// The screens
// ------------------------------------------------------------------------------------------------

/**
 * Accommodation that is a commercial premises rather than somebody's house.
 *
 * The distinction decides whether a coordinate is published as pinned or coarsened before commit.
 * docs/PARTICIPATION.md is specific: precise locations of private homes never enter the repository,
 * and the fuzzing happens before commit rather than at display time, because a runtime filter is one
 * bug away from publishing the thing it was hiding. A resort with a reception desk is a business
 * with a street frontage. A three bedroom house let out by its owners is a house, and the fact that
 * it is advertised does not make its exact position this project's to publish at full precision.
 */
const COMMERCIAL_PREMISES = /\b(resort|lodge|hotel|motel|apartments?|units|camping|campground|caravan|cabins|hostel|camp|scuba|bed and breakfast|holiday park|marina|pavilion)\b/i;

const DWELLING_FOLDERS = /holiday (rental|accommodation)|holiday rentals/i;
const ACCOMMODATION_FOLDER = DWELLING_FOLDERS;

/**
 * Natural features, and the folders in which a pin is definitely not one.
 *
 * "Amity Beach House" and "Amity Beach House on Birch" are two holiday houses. Both matched
 * `places/amity-beach` at 0.85 and were reported as corroborating the beach's position, which is how
 * a matcher ends up moving a beach to a driveway. A pin in a holiday rental folder is a place to
 * stay: it is named after the beach, it is not the beach.
 */
const NATURAL_TYPES = new Set([
  'beach', 'lake', 'headland', 'spring', 'rock', 'gorge', 'walk', 'township', 'national_park',
  'conservation_park', 'water_body', 'hazard_zone', 'lighthouse', 'lookout', 'jetty'
]);

/** A body with no address is not a point, and a pin never supplies one. */
const NOT_A_POINT = /island[- ]wide|mainland/i;

/** Placemarks that propose renaming a real place. Held, and asked about, never applied. */
const RENAMING = /\bre-?nam(e|es|ed|ing)\b/i;

function culturalTokens() {
  const lore = readJSON('data/lore.json');
  const rules = ((lore.prohibitions && lore.prohibitions.rules) || [])
    .filter((r) => r.id === 'no-invented-ceremony' || r.id === 'no-sacred-or-restricted-sites');
  return [...new Set(rules.flatMap((r) => (r.check && r.check.tokens) || []))].sort();
}

function hitsCulturalToken(text, tokens) {
  for (const token of tokens) {
    const rx = new RegExp('(^|[^A-Za-z0-9_])(' + tokenFamily(token) + ')(?![A-Za-z0-9_])', 'i');
    if (rx.test(text)) return token;
  }
  return null;
}

/** Is a lat/lon inside a KML ring? Ray casting, in lon/lat space, which is fine at this scale. */
export function pointInRing(point, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i][0];
    const yi = ring[i][1];
    const xj = ring[j][0];
    const yj = ring[j][1];
    const crosses = (yi > point.lat) !== (yj > point.lat)
      && point.lon < ((xj - xi) * (point.lat - yi)) / (yj - yi) + xi;
    if (crosses) inside = !inside;
  }
  return inside;
}

/** How close two placemarks have to be before they are drawings of the same thing. */
const SAME_GROUND_M = 25;

/**
 * What is held, and why.
 *
 * Two passes, because the second is the one that matters. The first finds the wording. The second
 * finds every other placemark drawn over the same ground and holds that too: the harm the
 * sacred-sites prohibition names is publishing a location, and a polygon outlining the clearing a
 * held pin sits in publishes exactly that location under a different label.
 *
 * "The same ground" is deliberately tight. Twenty five metres is about a hand's width on a web map
 * at the zoom people draw at, and a point falling inside a held polygon is the same thing said
 * geometrically. Anything looser starts holding the neighbours: an earlier draft used 150 m and held
 * the whole waste transfer station, four real public facilities, because a proposal pinned nearby
 * happened to contain a word. A screen that quietly swallows the street around it is not protecting
 * anybody; it is just refusing more.
 */
export function screenCulture(items, tokens) {
  const held = new Map(); // index -> { reason, token }
  for (const it of items) {
    const text = [it.name, it.description].filter(Boolean).join('\n');
    const token = hitsCulturalToken(text, tokens);
    if (token) {
      // The token is recorded on the hold so the lane can reason about it, and it is never written
      // into the candidates file or the report. Naming the word beside the folder is halfway to
      // naming the placemark, and docs/CULTURAL-REVIEW.md is the one file where this gets described.
      held.set(it.index, {
        reason: 'cultural-token',
        token,
        detail: 'its own text uses one of the tokens the two cultural prohibitions in data/lore.json '
          + 'declare, which is a stop and ask'
      });
      continue;
    }
    if (RENAMING.test(text)) {
      held.set(it.index, {
        reason: 'renaming-proposal',
        token: null,
        detail: 'the placemark proposes renaming a real place, and place naming on Minjerribah is an '
          + 'open question with QYAC in docs/CULTURAL-REVIEW.md A3'
      });
    }
  }
  let grew = true;
  while (grew) {
    grew = false;
    for (const it of items) {
      if (held.has(it.index)) continue;
      const p = representativePoint(it.geometry);
      if (!p) continue;
      for (const other of items) {
        if (!held.has(other.index)) continue;
        const q = representativePoint(other.geometry);
        if (!q) continue;
        const close = metresBetween(p, q) <= SAME_GROUND_M;
        const inside = other.geometry && other.geometry.type === 'Polygon' && pointInRing(p, other.geometry.outer);
        if (close || inside) {
          held.set(it.index, {
            reason: 'same-ground',
            token: null,
            detail: inside
              ? 'its position falls inside a placemark held above, so publishing it would publish that '
                + 'location under a different label'
              : 'it marks the same ground as a placemark held above, within '
                + `${SAME_GROUND_M} m, so publishing it would publish that location under a different label`
          });
          grew = true;
          break;
        }
      }
    }
  }
  return held;
}

/** Strip contact details out of a placemark and say how many came out, never what they were. */
export function screenPersonalData(item) {
  const before = findContactDetails([item.name, item.description].join('\n'));
  const name = stripContactDetails(item.name);
  const description = stripContactDetails(item.description);
  return {
    name: name.text,
    description: description.text,
    removed: name.removed + description.removed,
    kinds: [...new Set(before.map((h) => h.label))].sort()
  };
}

// ------------------------------------------------------------------------------------------------
// What the packs already hold
// ------------------------------------------------------------------------------------------------

/**
 * Every record in the committed packs that a map pin could plausibly be about, flattened into one
 * comparable shape. Read straight off disk, so the reconciliation is against the packs as they are
 * rather than against anybody's memory of them.
 */
export function existingRecords() {
  const out = [];
  const push = (pack, collection, r, lat, lon, extra) => {
    out.push({
      pack,
      collection,
      id: r.id,
      name: r.name || r.label || r.id,
      aliases: []
        .concat((r.alt_names || []).map((a) => a.name))
        .concat(r.also_known_as || [])
        .concat(r.name_quandamooka ? [r.name_quandamooka] : [])
        .filter(Boolean),
      type: r.type || '',
      township: r.township || '',
      status: r.status || '',
      lat: typeof lat === 'number' ? lat : null,
      lon: typeof lon === 'number' ? lon : null,
      ...extra
    });
  };

  if (exists('data/places.json')) {
    for (const r of readJSON('data/places.json').places || []) push('places', 'places', r, r.lat, r.lon);
  }
  if (exists('data/businesses.json')) {
    for (const r of readJSON('data/businesses.json').businesses || []) push('businesses', 'businesses', r, r.lat, r.lon);
  }
  if (exists('data/transport.json')) {
    const t = readJSON('data/transport.json');
    for (const r of t.terminals || []) push('transport', 'terminals', r, r.lat, r.lon);
  }
  if (exists('data/geography.json')) {
    const g = readJSON('data/geography.json');
    // The geography pack states its own coordinate order and it is lon,lat. Reading a centroid the
    // other way round would put every mine on the wrong side of the island and the numbers would
    // still look plausible, which is the failure mode worth writing a line of code against.
    const lonFirst = !/lat/i.test(String(g.coordinate_order || '').split(',')[0] || 'lon');
    const centroid = (c) => (Array.isArray(c) && c.length >= 2
      ? (lonFirst ? { lat: c[1], lon: c[0] } : { lat: c[0], lon: c[1] })
      : { lat: null, lon: null });
    for (const r of g.rehabilitation_areas || []) {
      const c = centroid(r.centroid);
      push('geography', 'rehabilitation_areas', r, c.lat, c.lon, { area_ha: r.area_ha });
    }
    for (const r of g.water_bodies || []) {
      const c = centroid(r.centroid);
      push('geography', 'water_bodies', r, c.lat, c.lon, {});
    }
  }
  return out;
}

// ------------------------------------------------------------------------------------------------
// Reconciliation
// ------------------------------------------------------------------------------------------------

/** Statuses in the committed packs that mean the sourced record and a live pin do not agree. */
const DISPUTED_STATUS = new Set(['closed', 'closed-unconfirmed', 'trading-unconfirmed', 'proposed']);

/**
 * The four-way split, with the reason recorded on every one of them.
 *
 *   NEW       nothing in the packs looks like this
 *   CONFIRMS  an existing record, and his pin corroborates its position
 *   CORRECTS  an existing record has a different position, or none at all, and his is first hand
 *   CONFLICTS they disagree about something his own dataStatus says he is unsure of. The existing
 *             sourced record wins on status; his pin wins on position.
 *
 * The order matters. Position is decided first, because a pin is evidence about position and about
 * nothing else. Then status is checked, and a status disagreement promotes the verdict to CONFLICTS
 * whatever the position said, because that is the thing a reader most needs to see.
 */
/**
 * Is this placemark a proposal rather than an observation?
 *
 * The author marks his own proposals: every one of them is named "Dream Space" something, or is
 * written in the first person about what a place could become. A proposal is not evidence about
 * where anything is, so it never corrects and never conflicts with a sourced record. It names what
 * it is about and stays marked proposed, forever, wherever it is rendered.
 */
export function isProposal(pin) {
  return /^dream space/i.test(pin.name)
    || /\bwould you like to\b|\bI imagine\b|\bI envision\b|\bcharacter overlay\b|\bI dream\b/i.test(pin.description || '');
}

export function reconcileOne(pin, records) {
  const p = pin.point;
  const subject = matchName(pin.name);
  const scored = records.map((r) => {
    let score = nameScore(subject, r.name);
    for (const alias of r.aliases) score = Math.max(score, nameScore(subject, alias));
    // A township is the one type where a containing name means the opposite of a match: everything
    // in Dunwich has Dunwich in its name. Nothing pairs with a township unless the names are the
    // same words.
    if (ACCOMMODATION_FOLDER.test(pin.folder) && NATURAL_TYPES.has(String(r.type).toLowerCase())) {
      const A = nameTokens(subject).sort().join(' ');
      const B = nameTokens(r.name).sort().join(' ');
      if (A !== B) score = 0;
    }
    if (String(r.type).toLowerCase() === 'township') {
      const A = nameTokens(subject).sort().join(' ');
      const B = nameTokens(r.name).sort().join(' ');
      score = A === B ? 1 : 0;
    }
    const dist = (p && r.lat !== null && r.lon !== null) ? metresBetween(p, { lat: r.lat, lon: r.lon }) : null;
    return { record: r, score, dist };
  });

  // Best by name, then by distance among equally good names.
  const byName = scored
    .filter((s) => s.score >= WEAK_NAME)
    .sort((a, b) => (b.score - a.score) || ((a.dist === null ? 1e9 : a.dist) - (b.dist === null ? 1e9 : b.dist)));
  const nearest = scored
    .filter((s) => s.dist !== null)
    .sort((a, b) => a.dist - b.dist)[0] || null;

  let verdict = 'NEW';
  let against = null;
  let reason = '';
  let sameNameFarApart = null;
  const winsOn = [];

  const best = byName[0] || null;
  // A weak name match standing on the same doorstep is the same thing under different wording.
  // "FoodWorks Dunwich" against "Stradbroke Island FoodWorks", 15 m apart, is one shop.
  const weakAndClose = byName
    .filter((s) => s.dist !== null && s.dist <= WEAK_CLOSE_M)
    .sort((a, b) => a.dist - b.dist)[0] || null;

  if (best && best.score >= STRONG_NAME) {
    const tolerance = sameSpotTolerance(best.record);
    against = best;
    if (best.dist === null && NOT_A_POINT.test(String(best.record.township || ''))) {
      // Redland City Council is not at its depot, and the depot is not the council. A record whose
      // own township field says island-wide has no position for a pin to supply.
      verdict = 'NEW';
      against = null;
      reason = `The name matches ${best.record.pack}/${best.record.id}, but that record's own township `
        + `is "${best.record.township}": it is a body, not a building, and it has no position for a pin `
        + 'to supply. This pin is a facility of that body and is a new record, not a correction to it.';
    } else if (best.dist === null) {
      verdict = 'CORRECTS';
      winsOn.push('position');
      reason = `The name matches ${best.record.pack}/${best.record.id}, which carries no coordinate at all. `
        + 'His pin supplies the position that record has been missing.';
    } else if (best.dist <= tolerance) {
      verdict = 'CONFIRMS';
      reason = `The name matches ${best.record.pack}/${best.record.id} and his pin is ${Math.round(best.dist)} m from it`
        + (tolerance > SAME_SPOT_M
          ? ', which is inside the extent of a feature whose recorded coordinate is one representative point.'
          : ', which is inside the precision either source claims.');
    } else if (best.dist <= NEAR_SPOT_M) {
      verdict = 'CORRECTS';
      winsOn.push('position');
      reason = `The name matches ${best.record.pack}/${best.record.id} and his pin is ${Math.round(best.dist)} m away. `
        + 'He put the pin there himself, so his position is the first-hand one.';
    } else {
      verdict = 'NEW';
      against = null;
      sameNameFarApart = { id: `${best.record.pack}/${best.record.id}`, distance_m: Math.round(best.dist) };
      reason = `The nearest record sharing this name, ${best.record.pack}/${best.record.id}, is `
        + `${Math.round(best.dist)} m away. Either these are two different things whose names repeat `
        + 'between townships, which happens here, or one of the two positions is wrong. A machine cannot '
        + 'tell which, and a person who has been there can tell in a second. Treated as new until then.';
    }
  } else if (weakAndClose) {
    verdict = 'CONFIRMS';
    against = weakAndClose;
    reason = `A partial name match to ${weakAndClose.record.pack}/${weakAndClose.record.id} and `
      + `${Math.round(weakAndClose.dist)} m from it. Same spot, different wording for the same thing.`;
  } else {
    reason = nearest && nearest.dist !== null
      ? `Nothing in the packs matches this name. The nearest record of any kind is ${nearest.record.pack}/${nearest.record.id}, `
        + `${Math.round(nearest.dist)} m away, and nothing in either name says whether it is the same thing. `
        + 'On a street where the shops are ten metres apart, that is a question for somebody who has been there.'
      : 'Nothing in the packs matches this name and nothing is near it.';
  }

  // A proposal is about a place; it is not evidence about where that place is. Whatever the names
  // and the distances said above, the verdict is NEW and the match is recorded as what it is about.
  if (isProposal(pin)) {
    const about = against || (best && best.score >= WEAK_NAME ? best : nearest);
    return {
      verdict: 'NEW',
      against: null,
      about: about
        ? { pack: about.record.pack, collection: about.record.collection, id: about.record.id, name: about.record.name }
        : null,
      distance_m: about && about.dist !== null && about.dist !== undefined ? Math.round(about.dist) : null,
      wins_on: [],
      reason: 'A proposal by the contributor, not an observation. It does not correct or contradict '
        + (about ? `${about.record.pack}/${about.record.id}, which it is about. ` : 'anything in the packs. ')
        + 'A plan never becomes a fact by being modelled, so it carries the Proposed marker wherever it '
        + 'is rendered and nothing is applied anywhere from it.'
    };
  }

  // The mine folder. His categories are evidence: a pin filed under "Private Mine Leases" asserts a
  // live private lease, and the geography pack holds five mined polygons it explicitly declines to
  // name because nobody had verified which mine is which. Proximity alone is enough to pair them,
  // and the pairing is worth more than the verdict, because it closes a gap the pack names itself.
  if (/mine lease/i.test(pin.folder) && (!against || against.record.pack !== 'geography')) {
    const near = scored
      .filter((s) => s.record.collection === 'rehabilitation_areas' && s.dist !== null && s.dist <= 2000)
      .sort((a, b) => a.dist - b.dist);
    const rehab = near[0];
    if (rehab) {
      against = rehab;
      verdict = 'CONFLICTS';
      winsOn.push('position', 'the name of the matched polygon');
      reason = `His pin sits ${Math.round(rehab.dist)} m from ${rehab.record.pack}/${rehab.record.id}, which `
        + 'data/geography.json records as a sand mining rehabilitation area and deliberately leaves unnamed, '
        + 'because which of the three mine names belongs to which polygon had not been verified. His folder '
        + 'files it as a current private lease. The sourced record wins on status, mining having ended; his '
        + 'pin wins on position and, subject to a person checking it, supplies the name.'
        + (near.length > 1
          ? ` ${near.length - 1} other rehabilitation polygon(s) sit within 2 km: `
            + near.slice(1).map((s) => `${s.record.id} at ${Math.round(s.dist)} m`).join(', ')
            + '. Which polygon carries which mine name is exactly the question the pack says is open, so this '
            + 'pairing is a lead for a person and not a fact.'
          : '');
    }
  }

  if (against && DISPUTED_STATUS.has(String(against.record.status).toLowerCase()) && verdict !== 'CONFLICTS') {
    verdict = 'CONFLICTS';
    if (!winsOn.includes('position')) winsOn.push('position');
    reason = `${reason} The existing record is marked "${against.record.status}", and his map lists it as a `
      + 'going concern. His own note says he does not know what is current, so the sourced record wins on '
      + 'status and his pin wins on position.';
  }

  return {
    verdict,
    against: against
      ? {
        pack: against.record.pack,
        collection: against.record.collection,
        id: against.record.id,
        name: against.record.name,
        status: against.record.status || null,
        name_score: Math.round(against.score * 100) / 100
      }
      : null,
    distance_m: against && against.dist !== null ? Math.round(against.dist) : null,
    wins_on: [...new Set(winsOn)],
    same_name_far_apart: sameNameFarApart,
    reason
  };
}

// ------------------------------------------------------------------------------------------------
// Records
// ------------------------------------------------------------------------------------------------

const EM_DASH = String.fromCharCode(0x2014);

/** The house rule is about this project's prose, not about what a contributor wrote. Declare it. */
function quoteText(parts) {
  const joined = parts.filter(Boolean).join('\n');
  const substituted = joined.includes(EM_DASH);
  return { text: joined.split(EM_DASH).join('-'), substituted };
}

function slug(s) {
  return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60) || 'unnamed';
}

/**
 * Status confidence by folder, which is the author's own categorisation and therefore the honest
 * place to take it from. A shopfront's status is exactly what his note says he is unsure about. A
 * beach's is not.
 */
function statusConfidenceFor(folder) {
  if (/business|rental|accommodation|mine lease/i.test(folder)) return 'low';
  return 'medium';
}

// ------------------------------------------------------------------------------------------------
// What a player may see
// ------------------------------------------------------------------------------------------------

/**
 * WHY THIS SECTION EXISTS
 *
 * The first pass through this lane marked every one of the 133 records `player_facing: false` and
 * wrote "nothing in this pack is player-facing" into the pack header. That was the right default and
 * the wrong rule, and a critic driving the running build found out exactly how wrong: the pack was
 * fetched on every boot, 325 kB of it, and changed nothing on screen. Twenty bus stops with a
 * first-hand position each, on two routes the twin already models with not one coordinate between
 * their eleven timing points; three water treatment plants; the tip; the ambulance station; two
 * toilet blocks; the fishing jetty; the shark-proof swimming enclosure at Amity Point. All of it in
 * a file, drawn nowhere.
 *
 * The blanket rule was holding back records that have nothing to hold back for. So the rule is now
 * narrow, and it is five questions rather than one, every one of them answerable from the record:
 *
 *   1. Which folder did the contributor file it under? Only the four public ones. A shopfront, a
 *      holiday let and a mine lease are the three things his own data_status says he cannot vouch
 *      for, and a dwelling's position is coarsened before it is committed anyway.
 *   2. Is the verdict NEW? A NEW record contradicts nothing and overwrites nothing, so showing it
 *      cannot put a contribution over the top of a sourced record. CONFIRMS, CORRECTS and CONFLICTS
 *      all name an existing record, and what to do about that is still a person's decision.
 *   3. Is it an observation rather than a proposal? Proposed stays proposed, and this world has no
 *      register for proposals yet, so a proposal is held out of it rather than blended into it.
 *   4. Is the position the one he pinned, uncoarsened?
 *   5. Does anything shown assert a current status? Nothing here does. A marker says the thing is
 *      there. It never says it is open, running, staffed or serviced, because that is precisely what
 *      `status_confidence` says nobody has checked.
 *
 * What comes through: 42 public features. What does not: every business, every rental, every lease,
 * every record with an existing record behind it, and the two proposals.
 */
const PUBLIC_FOLDERS = /^(natural beauty|active community spaces|getting around|public services and utilities)/i;

/**
 * What kind of thing a marker is, so the world can draw a bus stop as a bus stop and a tip as a tip.
 *
 * Read off the contributor's own name for the pin and nothing else. Ordered, first match wins. The
 * fallback is a plain marker rather than a guess: a kind this table does not know is not a reason to
 * invent one.
 */
const FACILITY_KINDS = [
  [/^bus.?\s*stop/i, 'bus_stop'],
  [/aero club|airfield|airstrip/i, 'airfield'],
  [/water treatment/i, 'water_treatment'],
  [/refuse tip|waste transfer|\btip\b/i, 'waste_transfer'],
  [/metal waste|green waste|plant\/green/i, 'waste_bay'],
  [/depot/i, 'depot'],
  [/ambulance/i, 'ambulance'],
  [/public phone|pay ?phone/i, 'public_phone'],
  [/toilet/i, 'toilet_block'],
  [/jetty|boat ramp/i, 'jetty'],
  [/skate/i, 'skate_park'],
  [/bmx/i, 'bmx_track'],
  [/court/i, 'court'],
  [/cricket|tennis|bowls|oval/i, 'sports_ground'],
  [/swimming enclosure/i, 'swimming_enclosure'],
  [/spring/i, 'spring'],
  [/park|playground/i, 'park'],
  [/beach/i, 'beach']
];

export function facilityKind(name) {
  for (const [rx, kind] of FACILITY_KINDS) if (rx.test(name)) return kind;
  return 'facility';
}

/**
 * The only wording this project changes, and it changes it in a separate field with the original
 * kept. One of the twenty bus stops is typed "Bust Stop". Showing that to a player as the name of a
 * place would be repeating a slip of the finger as a fact about the island; silently rewriting the
 * `name` field would be editing somebody's contribution. So both are on the record and the note says
 * which is which.
 */
const DISPLAY_FIXES = [
  { rx: /^Bust Stop$/, to: 'Bus Stop', why: 'The contributed name reads "Bust Stop". Shown as "Bus Stop": a typing slip, not a place name. The contributed spelling is kept in `name`.' }
];

export function displayNameFor(name) {
  for (const f of DISPLAY_FIXES) if (f.rx.test(name)) return { display: name.replace(f.rx, f.to), why: f.why };
  return null;
}

/** Decide clause by clause, and record the clause that decided it either way. */
export function playerFacingDecision({ folder, verdict, proposal, coarsened, geometry }) {
  if (!PUBLIC_FOLDERS.test(folder)) {
    return { ok: false, basis: `Filed by the contributor under "${folder}", which is a folder of businesses, rentals or leases. His own data status says current trading and tenure is exactly what he cannot vouch for, so nothing from these folders is drawn.` };
  }
  if (verdict !== 'NEW') {
    return { ok: false, basis: `The verdict is ${verdict}, so this record names an existing sourced record. What to do about that is a person's decision and a separate commit, and until it is made the sourced record is the one the world uses.` };
  }
  if (proposal) {
    return { ok: false, basis: 'A proposal by the contributor rather than an observation. Proposed stays proposed, and this world has no register for proposals to sit in, so it is held out of the world rather than blended into it.' };
  }
  if (coarsened) {
    return { ok: false, basis: 'The committed position is coarsened, so it is not a position to draw a marker at.' };
  }
  return {
    ok: true,
    basis: 'A public feature the contributor stood in front of, in one of his four public folders, with '
      + 'no existing record behind it to reconcile and no proposal in it. Drawn at the position he '
      + `pinned${geometry === 'polygon' ? ', which for a hand-drawn outline is the centre of the outline and not its edge' : ''}. `
      + 'Nothing about its current state is shown, because that is what nobody has checked.'
  };
}

// ------------------------------------------------------------------------------------------------
// Joining a bus stop to the routes that already exist
// ------------------------------------------------------------------------------------------------

/**
 * `data/transport.json` models Route 880 and Route 881 in full: operator, capacity, the whole
 * published timetable, the roads used. Between them their eleven waypoints carry not one coordinate.
 * Four resolve through a `ref` into `terminals`; the other seven are a name and nothing else, so
 * nothing in the twin could put a bus stop on the ground.
 *
 * This map supplies a position and a name for twenty of them. Joining the two up is the whole reason
 * the slice brief says to join rather than to add a second parallel truth, so the join is computed
 * here, at ingest, with its evidence on the record, rather than guessed at runtime.
 *
 * Two kinds of evidence are accepted and no others:
 *
 *   name      the contributor's own name for the stop contains the words that distinguish that
 *             timing point. "Bus Stop; Adder Rock" against "Point Lookout, Adder Rock".
 *   distance  the timing point resolves through its `ref` to a terminal that carries a coordinate,
 *             and the pin is within 150 m of it.
 *
 * Where there is neither, the join is null and says so. A bus stop that is not a published timing
 * point is the normal case: a Translink timetable publishes times at a handful of timing points and
 * the bus stops at every stop in between, and saying otherwise would invent a departure time.
 */
/**
 * One row per published timing point, written out rather than matched by a clever general rule.
 *
 * A general matcher was tried first and it put the Amity Point general store stop onto the "Amity
 * Point turnoff" waypoint, which is the Beehive Road junction four and a half kilometres away on the
 * other side of the island, because both strings contain the word Amity. On an island where "Point
 * Lookout" prefixes four of the six waypoints on one route and every township name repeats inside
 * the names of the things in it, a matcher clever enough to be right is a matcher nobody can audit.
 * Eleven rows is the whole problem. Here they are.
 *
 *   ref        the waypoint resolves to a terminal that carries a coordinate: match within 150 m
 *   word       a word in the contributed name that identifies this stop and no other
 *   township   the stop must also stand in this township, so a word cannot travel
 *   unmatched  a note saying why nothing can join to it, which is a finding, not a gap
 */
const TIMING_POINTS = [
  { route: 'svc-bus-880', waypoint: 'Junner Street Ferry Terminal', ref: 'terminal-junner-street' },
  { route: 'svc-bus-880', waypoint: 'One Mile Ferry Terminal', ref: 'terminal-one-mile' },
  { route: 'svc-bus-880', waypoint: 'Amity Point turnoff', unmatched: 'The Beehive Road junction on East Coast Road, which stands in no township. The nearest contributed pin, "Bus Stop and Exchange", is 393 m from where data/geography.json puts that junction: close enough to be a lead for somebody who knows the road and too far to assert.' },
  { route: 'svc-bus-880', waypoint: 'Point Lookout, Adder Rock', word: /\badder rock\b/i, township: 'point-lookout' },
  { route: 'svc-bus-880', waypoint: 'Point Lookout, Cylinder Beach', word: /\bcylinder\b/i, township: 'point-lookout' },
  { route: 'svc-bus-880', waypoint: 'Point Lookout, Gorge Walk', word: /\bgorge\b/i, township: 'point-lookout', unmatched: 'No contributed pin names the Gorge Walk. "Bus Stop and Turnaround" is the last stop on Mooloomba Road and may be it, and only somebody who catches that bus can say.' },
  { route: 'svc-bus-881', waypoint: 'One Mile Ferry Terminal', ref: 'terminal-one-mile' },
  { route: 'svc-bus-881', waypoint: 'Junner Street Ferry Terminal', ref: 'terminal-junner-street' },
  { route: 'svc-bus-881', waypoint: 'QUAMPI', word: /\bquampi\b/i, township: 'dunwich', unmatched: 'Added as a timing point in the 1 December 2025 timetable change. No contributed pin names it.' },
  { route: 'svc-bus-881', waypoint: 'Amity Point turnoff', unmatched: 'The same Beehive Road junction as on Route 880.' },
  { route: 'svc-bus-881', waypoint: 'Amity Point (Pulan)', word: /\bamity\b/i, township: 'amity-point' }
];

/** Which routes serve the township a stop stands in, read off the routes' own waypoint lists. */
function routesForTownship(township) {
  if (township === 'point-lookout') return ['svc-bus-880'];
  if (township === 'amity-point') return ['svc-bus-881'];
  return ['svc-bus-880', 'svc-bus-881'];
}

/** Which township a lat/lon is in, by nearest of the three, and only within 3.5 km of one. */
const TOWNSHIP_POINTS = [
  { id: 'dunwich', lat: -27.4989, lon: 153.4017 },
  { id: 'amity-point', lat: -27.3997, lon: 153.4390 },
  { id: 'point-lookout', lat: -27.4295, lon: 153.5330 }
];
export function townshipOf(point) {
  let best = null;
  for (const t of TOWNSHIP_POINTS) {
    const d = metresBetween(point, t);
    if (!best || d < best.d) best = { id: t.id, d };
  }
  return best && best.d <= 3500 ? best.id : null;
}

export function transportJoin(pin, kind) {
  if (kind !== 'bus_stop') return null;
  let transport = null;
  try { transport = readJSON('data/transport.json'); } catch { return null; }
  const terminals = new Map((transport.terminals || []).map((t) => [t.id, t]));
  const services = new Map((transport.services || []).map((s) => [s.id, s]));
  const township = townshipOf(pin.point);

  // Junner Street and One Mile are timing points on both routes, so a stop can join more than one.
  const matches = [];
  for (const row of TIMING_POINTS) {
    const svc = services.get(row.route);
    if (!svc || !(svc.waypoints || []).some((w) => w.name === row.waypoint)) continue;
    const term = row.ref ? terminals.get(row.ref) : null;
    const dist = term && Number.isFinite(term.lat)
      ? Math.round(metresBetween(pin.point, { lat: term.lat, lon: term.lon }))
      : null;
    const byDistance = dist !== null && dist <= 150;
    const byName = !!row.word && row.word.test(pin.name) && (!row.township || row.township === township);
    if (!byDistance && !byName) continue;
    matches.push({
      route: svc.id,
      route_name: svc.name,
      timing_point: row.waypoint,
      basis: byDistance
        ? `The waypoint refers to ${row.ref}, which carries a coordinate, and the pin is ${dist} m from it.`
        : `The contributed name carries the word that identifies this timing point and no other on this route, and the pin stands in ${row.township}.`,
      distance_m: dist
    });
  }

  return {
    township,
    serves_routes: routesForTownship(township),
    serves_routes_basis: 'Inferred from the routes\' own waypoint lists in data/transport.json: Route 880 '
      + 'runs Dunwich to Point Lookout and Route 881 runs Dunwich to Amity Point. It is an inference from '
      + 'that pack, not something the contributor wrote and not something Translink published per stop.',
    timing_points: matches,
    timing_point_note: matches.length
      ? 'This stop is one of the timing points the published timetable prints a time against, so a '
        + 'departure from this stop is a published time and not an estimate.'
      : 'Not one of the published timing points. A Translink timetable prints times at a handful of them '
        + 'and the bus stops at every stop in between, so no departure time is published for this stop and '
        + 'none is shown for it.'
  };
}

export function toRecord(pin, batch, reconciliation) {
  const commercial = COMMERCIAL_PREMISES.test(pin.name);
  const dwelling = DWELLING_FOLDERS.test(pin.folder) && !commercial;
  const published = dwelling
    ? coarsen({ lat: pin.point.lat, lon: pin.point.lon, precision_m: 250 })
    : { lat: pin.point.lat, lon: pin.point.lon, precision_m: 0, coarsened: false };

  const q = quoteText([pin.folder, pin.name, pin.description]);
  const proposal = isProposal(pin);

  const record = {
    id: `map-${slug(pin.folder)}-${slug(pin.name)}-${shortHash(`${pin.folder}|${pin.name}|${pin.index}`, 6)}`,
    name: pin.name,
    folder: pin.folder,
    geometry: pin.geometry ? pin.geometry.type.toLowerCase() : 'none',
    lat: Math.round(published.lat * 1e7) / 1e7,
    lon: Math.round(published.lon * 1e7) / 1e7,
    position_precision_m: published.coarsened ? published.precision_m : 0,
    position_basis: published.coarsened
      ? 'Coarsened to 250 m before commit because this is a dwelling let as a holiday rental, not a '
        + 'commercial premises. docs/PARTICIPATION.md: fuzzing happens before commit, never at display time.'
      : 'As pinned by the contributor.',
    source: `contribution:${batch.id}`,
    locator: `folder "${pin.folder}", placemark ${pin.index + 1} of ${batch.placemark_count}`,
    quote: q.text,
    quote_note: 'The verbatim text of the placemark: its folder name, its own name and its description as '
      + 'the KML nests them, joined with line breaks and otherwise unchanged.'
      + (q.substituted ? ' One em dash in the contributor\'s own wording is rendered as a hyphen, which is the '
        + 'only substitution made, on the same footing as the document lane.' : '')
      + (pin.contact_removed ? ` ${pin.contact_removed} contact detail(s) were removed at ingest and are not `
        + 'recorded anywhere in this repository.' : ''),
    asserts: 'real_world',
    claim: `The contributor's own map of the island places ${pin.name} here.`,
    status: proposal ? 'proposed' : 'contributed',
    confidence: 'high',
    existence_confidence: 'high',
    position_confidence: pin.geometry && pin.geometry.type === 'Polygon' ? 'low' : 'high',
    status_confidence: statusConfidenceFor(pin.folder),
    extracted_at: today(),
    extractor: `${EXTRACTOR.id}/${EXTRACTOR.version}`,
    contributed_by: batch.contributor,
    role: batch.role,
    method: 'map',
    visibility: 'public_twin',
    consent: batch.consent,
    facility_kind: facilityKind(pin.name),
    player_facing: false,
    reconciliation,
    note: proposal
      ? 'A proposal by the contributor, not a description of anything that exists. It stays marked '
        + 'proposed wherever it is rendered, forever.'
      : 'Contributed and not verified by a second source. Nothing here has been applied to '
        + 'data/places.json or data/businesses.json; that is a person\'s decision and a separate commit.'
  };

  if (published.coarsened) {
    record.reconciliation = { ...reconciliation };
    if (record.reconciliation.distance_m !== null && record.reconciliation.distance_m !== undefined) {
      const d = record.reconciliation.distance_m;
      record.reconciliation.distance_m = null;
      record.reconciliation.distance_band = d < 100 ? 'under 100 m' : d <= 500 ? '100 to 500 m' : 'over 500 m';
      record.reconciliation.distance_note = 'The exact distance is withheld because this position is '
        + 'coarsened, and a distance to a known record would undo the coarsening.';
    }
  }

  if (pin.geometry && pin.geometry.type === 'Polygon') {
    record.outline = pin.geometry.outer.map((t) => {
      const ll = toLatLon(t);
      return [Math.round(ll.lat * 1e7) / 1e7, Math.round(ll.lon * 1e7) / 1e7];
    });
    record.outline_note = 'Drawn by hand by the contributor on a web map. Treat it as an indication of '
      + 'extent, never as a boundary. Nothing draws it: the world puts a marker at the centre of it and '
      + 'says the thing is here, which is what a hand-drawn outline actually supports.';
  }

  // May a player see it, and if so what is it and what does it join to. The decision and its reason
  // are both on the record, so a reader who disagrees can see which clause they are arguing with.
  const decision = playerFacingDecision({
    folder: pin.folder,
    verdict: reconciliation.verdict,
    proposal,
    coarsened: published.coarsened,
    geometry: record.geometry
  });
  record.player_facing = decision.ok;
  record.player_facing_basis = decision.basis;
  if (decision.ok) {
    const display = displayNameFor(pin.name);
    if (display) {
      record.display_name = display.display;
      record.display_name_note = display.why;
    }
    const township = townshipOf(pin.point);
    if (township) record.township = township;
    const join = transportJoin(pin, record.facility_kind);
    if (join) {
      delete join.township;
      record.transport = join;
    }
    record.shown_as = 'A marker at the pinned position, its name, who contributed it and when, and the '
      + 'verbatim text of the placemark. No opening hours, no operating status, no service level: the '
      + 'record does not carry them and nobody has checked them.';
  }
  return record;
}

// ------------------------------------------------------------------------------------------------
// The run
// ------------------------------------------------------------------------------------------------

export function runLane(file, opts = {}) {
  const read = readMapFile(file);
  if (read.kind === 'network-link-stub') {
    return { stub: true, networkLink: read.networkLink, note: read.note };
  }

  const parsed = placemarks(read.text);
  const tokens = culturalTokens();
  const held = screenCulture(parsed.placemarks, tokens);
  const records = existingRecords();

  const batch = {
    id: opts.batch || `map-${slug(parsed.documentName)}-${today()}`,
    contributor: opts.contributor || 'unattributed',
    role: opts.role || 'player',
    source: opts.source || '',
    fetched: opts.fetched || today(),
    placemark_count: parsed.placemarks.length,
    consent: {
      given: true,
      wording: opts.consent || '',
      recorded_by: opts.contributor || 'unattributed'
    }
  };

  const out = {
    document: parsed.documentName,
    folders: parsed.folders,
    total: parsed.placemarks.length,
    candidates: [],
    heldItems: [],
    outOfBounds: [],
    noGeometry: [],
    stripped: [],
    mediaDropped: [],
    counts: { NEW: 0, CONFIRMS: 0, CORRECTS: 0, CONFLICTS: 0 }
  };

  // The document description is screened too. The owner's map carries a contact number in it, and a
  // tool that screened the pins and copied the header verbatim would have published the thing.
  const docFound = findContactDetails(parsed.documentDescription);
  const docScreen = stripContactDetails(parsed.documentDescription);
  out.documentDescription = docScreen.text;
  if (docScreen.removed) {
    out.stripped.push({
      where: 'the map description',
      kinds: [...new Set(docFound.map((h) => h.label))].sort(),
      count: docScreen.removed
    });
  }

  for (const item of parsed.placemarks) {
    if (held.has(item.index)) {
      const h = held.get(item.index);
      const carried = findContactDetails([item.name, item.description].join('\n'));
      const heldId = `held-${shortHash(`${item.folder}|${item.name}|${item.index}`, 8)}`;
      if (carried.length) {
        out.stripped.push({
          where: `held placemark ${heldId}`,
          kinds: [...new Set(carried.map((x) => x.label))].sort(),
          count: carried.length
        });
      }
      out.heldItems.push({
        // No name and no coordinate. A held item is held; a file that recorded what it was called and
        // where it was would be publishing the thing the hold exists to prevent.
        id: heldId,
        folder: item.folder,
        geometry: item.geometry ? item.geometry.type : 'none',
        reason: h.reason,
        detail: h.detail
      });
      continue;
    }

    const screened = screenPersonalData(item);
    if (screened.removed) {
      out.stripped.push({
        where: `folder "${item.folder}", placemark ${item.index + 1}`,
        kinds: screened.kinds,
        count: screened.removed
      });
    }
    if (item.media && item.media.length) {
      out.mediaDropped.push({ where: `folder "${item.folder}", placemark ${item.index + 1}`, count: item.media.length });
    }

    const point = representativePoint(item.geometry);
    if (!point) {
      out.noGeometry.push({ folder: item.folder, name: screened.name });
      continue;
    }
    const inBounds = point.lat >= ISLAND_BOUNDS.minLat && point.lat <= ISLAND_BOUNDS.maxLat
      && point.lon >= ISLAND_BOUNDS.minLon && point.lon <= ISLAND_BOUNDS.maxLon;
    if (!inBounds) {
      out.outOfBounds.push({
        folder: item.folder,
        name: screened.name,
        lat: point.lat,
        lon: point.lon,
        note: 'Outside the island bounding box. Reported, not dropped: it may be the mainland terminal, '
          + 'or it may be a pin somebody moved by accident, and only a person can tell.'
      });
      continue;
    }

    const pin = {
      index: item.index,
      folder: item.folder,
      name: screened.name,
      description: screened.description,
      contact_removed: screened.removed,
      geometry: item.geometry,
      point
    };
    const reconciliation = reconcileOne(pin, records);
    out.counts[reconciliation.verdict]++;
    out.candidates.push(toRecord(pin, batch, reconciliation));
  }

  out.batch = batch;
  return out;
}

// ------------------------------------------------------------------------------------------------
// The report
// ------------------------------------------------------------------------------------------------

/**
 * The top-level fields the pack has to carry, so a reader who opens the file alone knows who made
 * it, what its author said about it, what came out of it before it was written, and what its four
 * verdicts mean. tools/ingest/promote.mjs merges this when it creates the pack.
 */
export function packHeader(result) {
  const b = result.batch;
  const strippedKinds = [...new Set(result.stripped.flatMap((s) => s.kinds))].sort();
  const drawn = result.candidates.filter((c) => c.player_facing);
  const stops = drawn.filter((c) => c.facility_kind === 'bus_stop');
  const timingPoints = stops.filter((c) => c.transport && c.transport.timing_points.length);
  return {
    version: '0.2.0',
    about: `Pins from ${b.contributor}'s own map of Minjerribah, screened, bounds-checked and `
      + 'reconciled against the packs that already exist. This pack is the record of what the map says '
      + 'and how it lines up. Nothing in it has been applied to data/places.json or data/businesses.json: '
      + 'applying a correction to a sourced record is a person\'s decision and a separate commit, and the '
      + `corrected record has to say whose pin it came from. ${drawn.length} of the ${result.candidates.length} `
      + 'records are drawn in the world, and `player_facing_basis` on every record says in a sentence why '
      + 'it is or is not one of them.',
    crs: 'EPSG:4326',
    coordinate_order: 'lat then lon in every record. The KML this came from is lon,lat,alt, and '
      + 'tools/ingest/kml.mjs toLatLon is the single place that turns one into the other.',
    contribution: {
      contributed_by: b.contributor,
      role: b.role,
      method: 'map',
      source: b.source,
      fetched: b.fetched,
      fetch_note: 'The KMZ that Google MyMaps hands back from Download KMZ was a NetworkLink stub: about '
        + 'two kilobytes, one link, no map data. The data came from following that link once and saving '
        + 'the KML. The next person exporting this map will hit the same thing, so: three dot menu, Export '
        + 'to KML/KMZ, tick "Export as KML instead of KMZ". Fetching is an offline step; the running twin '
        + 'never touches any of it.',
      data_status: 'UNDER CONSTRUCTION. I don\'t know what information on this map is up to date or '
        + 'accurate so just use this as a starting point to do your own research.',
      data_status_note: 'The author\'s own words about his own map, carried through as this pack\'s '
        + 'dataStatus and not overridden anywhere. docs/SOURCES.md takes the same reading of the events '
        + 'engine: when a source tells you how far to trust it, that is the confidence, and a twin that '
        + 'computes a more flattering one is overstating.',
      attribution: `Credit is a name in a manifest, and this is it: ${b.contributor}. `
        + 'docs/PARTICIPATION.md applies to the owner exactly as it applies to anybody else, which is the '
        + 'point of there being one spine.',
      consent: b.consent,
      withdrawal: 'Withdrawal is honoured at the next release through a tombstone that keeps the id with '
        + 'a withdrawn marker. A public git history persists, so revocation after publication is '
        + 'best-effort, and docs/PARTICIPATION.md says so rather than promising otherwise.'
    },
    confidence_scale: {
      high: 'The contributor put the pin there himself and the thing is there. Existence and position.',
      medium: 'A physical public feature whose current state nobody has checked. It can be closed, '
        + 'removed or renamed, but it does not change month to month the way a shopfront does.',
      low: 'A hand-drawn extent, or a current trading status the contributor says himself he cannot '
        + 'vouch for. Not to be shown to a player as fact.'
    },
    confidence_split: 'Every pin carries two ratings rather than one average. `existence_confidence` '
      + 'is high because he stood there. `status_confidence` is low for a shop, a rental or a lease, '
      + 'because his own note says that is exactly what he does not know, and medium for a beach, a boat '
      + 'ramp or a water treatment plant, because those do not open and shut. Averaging the two into one '
      + 'number would throw away the most useful thing the source said about itself.',
    honesty: [
      'This is one person\'s map. It is the highest-trust contribution this project has had, and it is '
        + 'still one person\'s map.',
      'A reconciliation verdict is a lead, not an edit. CORRECTS means somebody should look, not that '
        + 'anything has changed.',
      `${drawn.length} of these records are drawn in the world and ${result.candidates.length - drawn.length} `
        + 'are not. The line is drawn by the five clauses in `player_facing_basis`, not by taste: a public '
        + 'feature in one of the contributor\'s four public folders, with a NEW verdict so there is no '
        + 'sourced record behind it, no proposal in it and an uncoarsened position. Held is a normal state, '
        + 'and unreviewed is invisible rather than caveated.',
      'A marker in the world says a thing is there. It never says the thing is open, running, staffed or '
        + 'serviced, because `status_confidence` is the contributor saying that is exactly what he has not '
        + 'checked.',
      `${stops.length} of the drawn records are bus stops, and ${timingPoints.length} of those join to a `
        + 'timing point the Translink timetable in data/transport.json prints a time against. The other '
        + `${stops.length - timingPoints.length} are stops between timing points, which is the ordinary case, `
        + 'and no departure time is shown for them because none is published.',
      'Positions of dwellings let as holiday rentals are coarsened to 250 m before commit, not filtered '
        + 'at display time, because a runtime filter is one bug away from publishing what it was hiding.',
      'The four verdicts are computed by name and by distance. Names on this island repeat between '
        + 'townships and shops sit ten metres apart, so a machine gets some of these wrong and the report '
        + 'beside this pack says which ones it is least sure of.'
    ],
    screens: {
      personal_data: {
        rule: 'No contact detail and no residential address enters this repository through a '
          + 'contribution, under any consent. tools/ingest/checks-screens.mjs runs this on every gate.',
        removed: result.stripped.reduce((n, s) => n + s.count, 0),
        kinds: strippedKinds,
        where: result.stripped.map((s) => s.where),
        note: 'The values are not recorded anywhere in this repository, including in this note and in '
          + 'the gate log.'
      },
      cultural: {
        rule: 'The two cultural prohibitions in data/lore.json are read out of the pack and applied to '
          + 'every placemark before anything is written. A placemark either of them touches does not '
          + 'enter the world, is not rendered, is not named in the interface and does not become a place '
          + 'record, and neither does any other placemark drawn over the same ground. The rules are not '
          + 'restated here, because a copy of a rule is a copy that goes stale.',
        held: result.heldItems.length,
        held_ids: result.heldItems.map((h) => h.id),
        note: 'Held items are not named here and carry no coordinate here. They are described in '
          + 'docs/CULTURAL-REVIEW.md section M, as questions for QYAC. This is not a refusal of the '
          + 'contributor\'s idea; the twin is not the place it gets decided.'
      },
      external_media: {
        rule: 'No external image and no network reference. The twin is offline at runtime.',
        dropped: result.mediaDropped.reduce((n, m) => n + m.count, 0)
      },
      bounds: {
        rule: `Every point is checked against lat ${ISLAND_BOUNDS.minLat} to ${ISLAND_BOUNDS.maxLat}, `
          + `lon ${ISLAND_BOUNDS.minLon} to ${ISLAND_BOUNDS.maxLon}. A point outside it is reported, `
          + 'never dropped.',
        outside: result.outOfBounds.length,
        no_geometry: result.noGeometry.length
      }
    },
    reconciliation: {
      counts: result.counts,
      total_placemarks: result.total,
      carried: result.candidates.length,
      verdicts: {
        NEW: 'Nothing in the packs looks like this.',
        CONFIRMS: 'An existing record, and his pin corroborates its position.',
        CORRECTS: 'An existing record carries a different position, or none at all, and his is first '
          + 'hand, so his wins on position.',
        CONFLICTS: 'They disagree about something his own data_status says he is unsure of, such as '
          + 'whether a business still trades. The existing sourced record wins on status and his pin '
          + 'wins on position.'
      },
      applied: 'none',
      note: 'Read the reconciliation report the lane wrote beside the candidates file. Every CORRECTS '
        + 'and every CONFLICTS is listed there by name with its reason.'
    }
  };
}

export function reportMarkdown(result) {
  const L = [];
  const w = (s = '') => L.push(s);
  const c = result.counts;

  w(`# Map reconciliation: ${result.document}`);
  w('');
  w(`Run on ${today()} by ${EXTRACTOR.id}/${EXTRACTOR.version}. Nothing in data/ was written by this run.`);
  w('');
  w(`**${result.total} placemarks** in ${result.folders.length} folders. `
    + `${result.candidates.length} became candidates, ${result.heldItems.length} were held, `
    + `${result.outOfBounds.length} fell outside the island, ${result.noGeometry.length} had no geometry.`);
  w('');
  w('## The four-way split');
  w('');
  w('| Verdict | Count | What it means |');
  w('| --- | --- | --- |');
  w(`| NEW | ${c.NEW} | Nothing in the packs looks like this. |`);
  w(`| CONFIRMS | ${c.CONFIRMS} | An existing record, and his pin corroborates its position. |`);
  w(`| CORRECTS | ${c.CORRECTS} | The existing record has a different position, or none. His is first hand. |`);
  w(`| CONFLICTS | ${c.CONFLICTS} | They disagree on status. The sourced record wins on status, his pin on position. |`);
  w('');

  for (const verdict of ['CORRECTS', 'CONFLICTS']) {
    const rows = result.candidates.filter((r) => r.reconciliation.verdict === verdict);
    w(`## Every ${verdict} (${rows.length})`);
    w('');
    w('These are the ones to look at. Nothing has been applied.');
    w('');
    for (const r of rows) {
      const a = r.reconciliation.against;
      const d = r.reconciliation.distance_m !== null && r.reconciliation.distance_m !== undefined
        ? `${r.reconciliation.distance_m} m`
        : (r.reconciliation.distance_band || 'no position on the existing record');
      w(`- **${r.name}** (${r.folder}) against \`${a ? a.pack + '/' + a.id : 'nothing'}\`, ${d}.`);
      w(`  ${r.reconciliation.reason}`);
    }
    w('');
  }

  const farApart = result.candidates.filter((r) => r.reconciliation.same_name_far_apart);
  if (farApart.length) {
    w(`## Same name, far apart (${farApart.length})`);
    w('');
    w('Neither a confirmation nor a correction. The name matches a record in the packs and the two '
      + 'positions are too far apart to be the same thing. Either the names repeat, which they do here, '
      + 'or one of the two positions is wrong. Somebody who has been there settles each of these in a '
      + 'sentence.');
    w('');
    for (const r of farApart) {
      const s = r.reconciliation.same_name_far_apart;
      w(`- **${r.name}** (${r.folder}) against \`${s.id}\`, ${s.distance_m} m apart.`);
    }
    w('');
  }

  /* ------------------------------------------------------------ what a player sees */

  const drawn = result.candidates.filter((r) => r.player_facing);
  const stops = drawn.filter((r) => r.facility_kind === 'bus_stop');
  const joined = stops.filter((r) => r.transport && r.transport.timing_points.length);

  w('## What is drawn in the world');
  w('');
  w(`**${drawn.length} of ${result.candidates.length}.** Every other record is in the pack and out of the `
    + 'world, and its own `player_facing_basis` says which clause held it back. The five clauses, in order: '
    + 'the contributor filed it under one of his four public folders; the verdict is NEW so there is no '
    + 'sourced record behind it to overwrite or contradict; it is an observation and not a proposal; the '
    + 'position is the one he pinned rather than a coarsened one; and nothing shown asserts a current '
    + 'status, because that is exactly what his own data status says nobody has checked.');
  w('');
  const byKind = new Map();
  for (const r of drawn) byKind.set(r.facility_kind, (byKind.get(r.facility_kind) || 0) + 1);
  w('| What | How many |');
  w('| --- | --- |');
  for (const [k, n] of [...byKind.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1))) {
    w(`| ${k.replace(/_/g, ' ')} | ${n} |`);
  }
  w('');
  w('### Held out of the world although the verdict is NEW');
  w('');
  const heldBack = result.candidates.filter((r) => !r.player_facing && r.reconciliation.verdict === 'NEW'
    && PUBLIC_FOLDERS.test(r.folder));
  if (!heldBack.length) w('None.');
  for (const r of heldBack) w(`- **${r.name}** (${r.folder}). ${r.player_facing_basis}`);
  w('');

  w('## Bus stops against the published timetable');
  w('');
  w(`Route 880 and Route 881 in \`data/transport.json\` carry eleven waypoints between them and not one `
    + `coordinate on any of them. This map supplies ${stops.length} bus stops with a first-hand position, `
    + `and ${joined.length} of them join to a published timing point on the evidence shown below. The rest `
    + 'are stops between timing points, which is the ordinary case: a Translink timetable prints times at a '
    + 'handful of points and the bus stops at every stop in between, so no departure time is published for '
    + 'them and none is shown for them.');
  w('');
  w('| Stop, as contributed | Township | Routes through | Timing point | On what evidence |');
  w('| --- | --- | --- | --- | --- |');
  for (const r of stops) {
    const t = r.transport;
    const tp = t.timing_points.length
      ? t.timing_points.map((x) => `${x.route.replace('svc-bus-', '')} ${x.timing_point}`).join('; ')
      : '';
    w(`| ${r.name} | ${r.township || 'between the townships'} | ${t.serves_routes.map((s) => s.replace('svc-bus-', '')).join(', ')} `
      + `| ${tp} | ${t.timing_points.length ? t.timing_points[0].basis : ''} |`);
  }
  w('');
  w('### Timing points nothing joined to');
  w('');
  for (const row of TIMING_POINTS) {
    if (!row.unmatched) continue;
    w(`- **${row.waypoint}** on ${row.route.replace('svc-bus-', 'Route ')}. ${row.unmatched}`);
  }
  w('');

  w('## Held');
  w('');
  w('Held items are not named here, do not carry a coordinate here, and are not in the pack. They are '
    + 'described in docs/CULTURAL-REVIEW.md, which is the queue, and the decision is not this project\'s '
    + 'to make.');
  w('');
  for (const h of result.heldItems) {
    w(`- \`${h.id}\`, a ${h.geometry.toLowerCase()} in "${h.folder}": ${h.detail}.`);
  }
  w('');

  w('## Screened out');
  w('');
  if (!result.stripped.length) w('Nothing was stripped.');
  for (const s of result.stripped) {
    w(`- ${s.where}: ${s.count} contact detail(s) removed (${s.kinds.join(', ')}). The value is not recorded anywhere.`);
  }
  for (const m of result.mediaDropped) {
    w(`- ${m.where}: ${m.count} external image link(s) dropped. The twin makes no network request and carries no external image.`);
  }
  w('');

  if (result.outOfBounds.length) {
    w('## Outside the island bounding box');
    w('');
    for (const o of result.outOfBounds) w(`- ${o.name} (${o.folder}) at ${o.lat}, ${o.lon}. ${o.note}`);
    w('');
  }
  if (result.noGeometry.length) {
    w('## No geometry');
    w('');
    for (const o of result.noGeometry) w(`- ${o.name} (${o.folder})`);
    w('');
  }

  w('## Every verdict, by folder');
  w('');
  for (const f of result.folders) {
    const rows = result.candidates.filter((r) => r.folder === f.name);
    if (!rows.length) { w(`### ${f.name} (${f.placemarks} placemarks, none carried)`); w(''); continue; }
    w(`### ${f.name} (${rows.length} of ${f.placemarks})`);
    w('');
    w('| Placemark | Verdict | Against | Distance |');
    w('| --- | --- | --- | --- |');
    for (const r of rows) {
      const rec = r.reconciliation;
      const a = rec.against || rec.about || (rec.same_name_far_apart ? { pack: '', id: rec.same_name_far_apart.id } : null);
      const label = a ? (a.pack ? `${a.pack}/${a.id}` : a.id) + (rec.against ? '' : ' (about)') : '';
      const d = rec.distance_m !== null && rec.distance_m !== undefined
        ? `${rec.distance_m} m`
        : (rec.distance_band || (rec.same_name_far_apart ? `${rec.same_name_far_apart.distance_m} m` : ''));
      w(`| ${r.name} | ${rec.verdict} | ${label} | ${d} |`);
    }
    w('');
  }
  return L.join('\n') + '\n';
}

// ------------------------------------------------------------------------------------------------
// CLI
// ------------------------------------------------------------------------------------------------

const RAN_DIRECTLY = process.argv[1] && process.argv[1].replace(/\\/g, '/').endsWith('tools/ingest/lane-map.mjs');
if (RAN_DIRECTLY) {
  const args = process.argv.slice(2);
  const val = (f, d = null) => (args.indexOf(f) >= 0 ? args[args.indexOf(f) + 1] : d);
  const file = val('--extract');
  if (!file) {
    console.log(fs.readFileSync(new URL(import.meta.url), 'utf8').split('\n').slice(0, 20).join('\n'));
    process.exit(1);
  }
  const result = runLane(file, {
    batch: val('--batch'),
    contributor: val('--contributor'),
    role: val('--role', 'player'),
    source: val('--source'),
    fetched: val('--fetched'),
    consent: val('--consent')
  });

  if (result.stub) {
    console.error('\nREFUSED: this file carries no map data.\n');
    console.error(result.note);
    if (result.networkLink) console.error(`\nThe NetworkLink in it points at: ${result.networkLink}`);
    process.exit(1);
  }

  const dir = path.join(ROOT, 'tools/ingest/candidates');
  fs.mkdirSync(dir, { recursive: true });
  const stem = `map-${result.batch.id}`;
  const candidatesFile = path.join(dir, `${stem}.json`);
  const reportFile = path.join(dir, `${stem}-reconciliation.md`);

  if (!args.includes('--dry')) {
    fs.writeFileSync(candidatesFile, JSON.stringify({
      kind: 'ingest-candidates',
      lane: 'map',
      schema: 'minjerribah-candidates/1',
      batch: result.batch.id,
      contributed_by: result.batch.contributor,
      extractor: EXTRACTOR,
      document: { id: result.batch.id, title: result.document, source: result.batch.source, fetched: result.batch.fetched },
      pack_header: packHeader(result),
      note: 'Screened, bounds-checked and reconciled. Not promoted. A person reads the reconciliation '
        + 'report beside this file, and tools/ingest/promote.mjs runs the whole gate before anything '
        + 'reaches data/.',
      candidates: result.candidates
    }, null, 2) + '\n', 'utf8');
    fs.writeFileSync(reportFile, reportMarkdown(result), 'utf8');
  }

  const c = result.counts;
  console.log(`${result.document}: ${result.total} placemarks in ${result.folders.length} folders.`);
  console.log(`  NEW ${c.NEW}   CONFIRMS ${c.CONFIRMS}   CORRECTS ${c.CORRECTS}   CONFLICTS ${c.CONFLICTS}`);
  console.log(`  held ${result.heldItems.length}, outside the island ${result.outOfBounds.length}, no geometry ${result.noGeometry.length}`);
  console.log(`  ${result.stripped.reduce((n, s) => n + s.count, 0)} contact detail(s) stripped, `
    + `${result.mediaDropped.reduce((n, m) => n + m.count, 0)} external image link(s) dropped`);
  if (!args.includes('--dry')) {
    console.log(`\nWrote ${path.relative(ROOT, candidatesFile).split(path.sep).join('/')}`);
    console.log(`Wrote ${path.relative(ROOT, reportFile).split(path.sep).join('/')}`);
  }
  console.log('\nNothing has been added to data/.');
}
