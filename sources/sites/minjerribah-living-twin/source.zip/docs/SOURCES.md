# Sources

Where the source material is, what is in it, and what to do with it. Read this before dispatching a
wave that needs facts.

Until now every wave has built from the data packs in this repo and nothing else, because the owner's
document corpus lives outside it. That corpus is 661 markdown files plus several hundred PDFs and
DOCX, and it contains the design ancestors of this twin, the island's real civic instruments, and the
plans the twin is meant to rehearse. This document is the map. It commands no build.

## Read these first, and do not redo their work

Three documents in this folder already carry the distilled direction. Go to source for detail, not
for direction.

- `docs/DIRECTION.md`: what the twin is for, the founding brief, build order, the economic layer.
- `docs/PARTICIPATION.md`: how the island contributes to its twin, and what is not a lane.
- `docs/CAPTURE-CONTRACT.md`: how scanned real-world assets arrive.

If a wave finds itself deriving one of those from source again, stop and read the doc instead.

## The curated set

Thirty three documents the owner handed over directly, all paths verified present. Grouped by the
part of the twin they serve. Two roots, abbreviated below:

- `SORT` = `C:\Users\sbt41\OneDrive\Documents\Sorting_Files\02_Processed_MD\PDFs_to_Sort`
- `DL` = `C:\Users\sbt41\Downloads`

**This twin's design ancestors.** Closest existing thinking to what you are building.
`SORT\Virtual_Minjerribah_Design_Document.md` (rollout order, world-as-UI, GIS to engine pipeline,
NPC and transport simulation), `SORT\Virtual_Minjerribah__Time_Simulations_&_Data.md` (the historical
layer, archival sources, the future sandbox),
`SORT\Generative_Simulation_Engine_&_Asset_Pipeline_for_Quandamooka_Country.md` (the asset pipeline
and the expert-guild processing story, plus a worked bowls-club example end to end).

**Participation and contribution.** `SORT\Sovereign_Space_Builder__Full_System_Specification_(2).md`
(roles, sharing levels, the object family, the low-tech inclusion floor),
`SORT\Memory_Mapping_App_for_Aura_of_Intelligence.md` (place-anchored memory, capture modes,
accessibility floor), `SORT\Web3_Sensorium_for_Science_Debate.md` (the claims board pattern:
labels plus a named settling test).

**The economic layer.** `DL\C-Hour Legislation and National Security.md`,
`DL\Legislative Research AI C-Hour.md`, `DL\Global Civic Tech Legislative Analysis.md` (what the
record is and is not, international precedent, the wage-drift failure mode),
`DL\Architectural Blueprint for Oceania_ Integrating Decentralized Governance, Customary Law, and Sovereign Economics.md`
and `DL\03 The Constitutional Matrix of Participation.docx.md` (decision shapes, fractal aggregation),
`DL\Straddie Insurance Branch Research Proposal.md` (the mutual pool, its layers and its legal
boundaries), `DL\Decentralised Compute For Australian Communities.md` (compute as a utility, with
committed power envelopes).

**Scenario drivers.** `DL\Oceania Health and AI Surge Plan.md`,
`DL\Queenslands Heart-First Ai Surge Plan (1).md`, `DL\Australia's Olympic Space Gambit.md` (crisis
fiscal benchmarks, the 2032 horizon, decision latency, cooperative finance arithmetic),
`SORT\Integrated_Food_System_AI_Expansion.md` and `SORT\AI_Kitchen_Food_Waste_Solution.md` (food
loops and waste benchmarks).

**Civic dogfooding.** `SORT\Dual-Track_Aura_Strategy_&_Civic_Infrastructure.md`, sections 4.3 and 4.4
only: using the twin to plan a real community event at a real venue. The rest of that document is
strategy outside this repo's scope; do not read it across.

**How a swarm should work.** The owner designed agent-guild methods years before the tools existed,
and they read as a description of what you are: `DL\early 2024 Aura\13 MoE Extended.md`,
`DL\early 2024 Aura\12 Mixture of Experts, Function Callers and AutoGen Agents.md` (task agents, a
supervisor that rejects substandard work, human-in-the-loop function definition),
`DL\early 2024 Aura\11 Build an Aura in Blender then in Unity XR .md`,
`SORT\04_Sentient_Communications_Engine.md`, `SORT\03_Innovation_Engine.md`,
`SORT\AI_Agent_Growth_and_Human_Cognition.md`.

**Read selectively.** `SORT\AURA_OF_INTELLIGENCE_&_THE_SOVEREIGN-COSMIC_FRAMEW....md` is the umbrella
architecture and does contain twin-relevant patterns, but large parts of it sit outside this
repository's scope entirely. Extract only what bears on the island simulation; see the exclusions
below.

**Out of scope for this twin**, listed so nobody spends a wave on them:
`SORT\Super-Computers_of_North_Straddie.md`, `SORT\1-page_Building_AGI_On_The_Record.md`,
`SORT\Space_Weather_Hub_Pseudo_Code.md`, `SORT\Space_Weather_Data_IFTTT.md`,
`SORT\Modular_Unity_Development_&_Deployment_Plan_for___SpaceWeather_News_Hub__.md`,
`SORT\image fail md\VR_Space_Weather_News.md`.

**Do not open** `DL\in-home farm and microbiome.md` in a session running Fable. Its biological content
has twice tripped a model switch mid-flight. Its one genuinely reusable idea is already extracted:
crops indexed by which failure mode each survives (drought, flood, heat, poor soil, supply collapse),
so the design metric becomes what fails last.

## The wider corpus

`C:\Users\sbt41\OneDrive\Documents\Sorting_Files`, roughly 661 markdown files plus PDFs and DOCX.
Region by region, with what a wave should expect.

**`RCC`, 38 PDFs. The single richest block of real civic material in the corpus, and this twin has
never read it.** It is Redland City Council and Queensland statutory instruments, all text
extractable, no scans, roughly 2,000 pages in total. It is ground truth for exactly what the twin
models. Highest value:

- `RCC_redland_city_plan_version_13.pdf`: the 484-page statutory planning scheme, zones, precincts,
  overlays. It names Stradbroke, Minjerribah, Dunwich, Amity or Point Lookout on 84 lines, so
  extract the island lines rather than reading the whole thing.
- `RCC_20241216_local_disaster_management_plan__control_copy_.pdf`: 128 pages, activation levels,
  hazards, evacuation and recovery, agency roles. The best single source for a disaster scenario.
- `RCC_coastal_hazard_adaptation_strategy.pdf`, `RCC_final_wildlife_connections_plan_2018_2028__a2528412_.pdf`,
  `RCC_koala_conservation_plan_2021_v47.pdf`, `RCC_redlands_coast_biosecurity_plan_2025_2030.pdf`:
  the ecological stewardship spine, including a real species and threat list.
- `RCC_financial_strategy_2025_2035.pdf`, `RCC_strategic_asset_management_plan_2019_2029.pdf`: the
  numbers behind a council budget mechanic.
- `RCC_community_engagement_framework_2025.pdf` and
  `RCC_fact_sheet_-_making_a_properly_made_submission.pdf`: a ready-made rule set for the twin's
  consultation loop and submission mechanic.
- `RCC_redlands_coast_events_strategy_2024_2029.pdf`, `RCC_transport_strategy_final_low_res__a4378995_.pdf`,
  `RCC_waste_reduction_and_recycling_plan_2021_2030_a4__6th_draft_low_res_2.pdf`: events, transport
  and waste layers.
- `RCC_shapingseq-2023-Low.pdf` and `QLD-ministers-guidelines-and-rules-book2020.pdf`: the state
  instruments above the city plan, including the statutory process for amending a scheme.

**Read RCC with its counterpart, because the pair is the civic layer's spine.** RCC is the system as
it exists: how funding, planning and decisions actually work today. Its counterpart is
`SORT\Local_Government_Funding_Inquiry_Submission.md`, which is where the owner's plan diverges from
that system and introduces the C-hour. It opens by diagnosing local government's structural deficit
as an incomplete ledger, then proposes the community sovereign wealth fund, a regenerative asset
carve-out, sovereign digital twins of council assets, and the L0 to L2 governance topology. Read
alone, RCC teaches the twin how councils work. Read alone, the submission is a proposal with no
ground under it. Read together, they give the civic layer both halves: the existing constraint and
the specific point where the proposed alternative enters. That divergence point is the thing worth
simulating, and `docs/DIRECTION.md` §The economic layer is where its mechanics are already written
down.

**The tool that would read RCC properly does not exist yet.** Two plans for a legal retrieval system
over these statutes sit in the corpus, `SORT\Legal_RAG_LLM_Plan_AUS-QLD-Redlands.md` and
`SORT\Building_an_Australian_Legal_RAG_System.md`, and neither has been built. Do not cite either as
though a working system stands behind it. For this twin the honest use of RCC is direct extraction
into fact-checked data packs, the same as every other pack: pull the island lines, cite the document
and page, carry a confidence rating. A retrieval system is a separate project, not a prerequisite.

**`02_Processed_MD\PDFs_to_Sort`, 262 to 300 markdown files.** The main body: island entity
ecosystems, the everything-app blueprints, subterranean and sand works, island clubs and events,
council engagement, narrative and micro-drama engines, the braided economy. This is where most of
the curated set above came from, and there is a great deal more of it.

**This directory has not finished being cleaned, so keep a wave's diet narrow.** Conversion quality
varies, some documents are duplicated under near-identical names, tables arrive flattened, and
several files restate each other at different stages of the owner's thinking. Point a wave at named
documents for a named purpose. Do not point one at the full architecture and ask it to synthesise:
it will produce something confident and wrong, because the corpus contradicts itself in places by
design, being years of thinking rather than a settled specification. The curated set above and the
RCC directory are the clean paths in. When in doubt, ask the owner which document is current rather
than inferring it from a file date.

**`02_Processed_MD\PDFs_to_Sort_styled_claude`. Skip it.** Every one of its 86 top-level files is a
duplicate of a file in `PDFs_to_Sort`, with zero unique content, plus a `_changes` folder of diffs.
Worse, the styling pass lost content: one file dropped from 39 KB to 4 KB, another from 88 KB to
58 KB. The originals in `PDFs_to_Sort` are canonical. Never cite the styled copy.

**`01_Maps_As_Markdown`, 68 files, 8,757 lines.** The cheapest directory in the corpus and the
fastest way to absorb the project's vocabulary and structure: indented mind-map outlines, one
heading each. Despite the name it holds no geographic data.

**`02_Processed_MD\Powerpoint_PDFs`, 120 files.** Presentation decks converted to markdown: short,
pitch-shaped, often restating documents that exist as prose elsewhere.

**`DOCX_drive`, 355 .docx.** Extracts fine. About a third have a same-named twin in `PDFs_to_Sort`;
read one, not both.

**`Powerpoints_as_PNGs`. Do not send a wave here.** It is 520 page images with no text layer, around
4 MB each, and most decks restate documents that exist as text elsewhere. Sample a page or two only
when a specific deck's subject has no text equivalent.

**`TAFE_Courses`.** Thirty nine of its 40 files are ordinary national qualification guides with no
island content. The exception is a misfiled feasibility dossier on an island wealth fund and
eco-power. Otherwise skip the directory.

**There is no GIS anywhere in the corpus.** No coordinates, no shapefiles, no elevation data. The
island's geometry came from elsewhere and must keep coming from elsewhere; do not send a wave
looking for it here.

## Handling rules

These are not negotiable and they matter more than coverage.

1. **Do not index or quote private material.** A survey of the corpus flagged roughly 200 files as
   out of scope for this repository: personal journalling and health material, third-party personal
   information, clinical and therapeutic protocols, private property and partnership negotiations,
   relationship and sexuality material, and hardware internals. If a file's title suggests any of
   those, do not open it, do not name it in a commit, and do not summarise it. This repository is
   semi-public and its git history is permanent.
2. **Cultural material is not a source lane.** The prohibitions in `data/lore.json` are blocking, and
   they apply to the corpus exactly as they apply to everything else. Aboriginal language, story,
   ceremony, art and site knowledge do not enter this repo from a document, however that document is
   framed. `docs/CULTURAL-REVIEW.md` is the queue, QYAC holds the decision, and the first question
   there stands over this file too.
3. **The corpus is not ground truth by itself.** Many of these documents are research-agent outputs
   in a confident register, and several carry dated legislative claims that cannot be verified from
   here. Anything entering a data pack needs an independent source, a confidence rating, and A$ with
   the conversion noted. Cite figures as "per that document, as at its stated date", never as fact.
   Scenario inputs are labelled scenario inputs, never benchmarks.
4. **Take the pattern, leave the register.** The corpus runs hot in places, and some documents wrap
   real engineering in visionary framing. That framing is deliberate and is not an error, but it is
   not this repo's voice. Name the reusable mechanism, drop the adjectives, and keep the smaller
   true claim.
5. **Regulated territory carries its label.** Anything touching insurance, superannuation, funds or
   income floors is proposed, not offered, in every doc and on every screen.
6. **Real places, real businesses, no fabrication.** A corpus document proposing something is a
   proposal, and it stays marked proposed in the twin. Never let a plan become a fact by being
   modelled.

## What to do first

If a wave is choosing where to start, the highest return in the corpus is not more theory. It is
`RCC`, because it converts the civic layer from plausible to sourced: real zones, a real disaster
plan, a real species list, real budget structure, and a real submission process. Most of the rest
here is design direction. That directory is evidence.

Then read `SORT\Local_Government_Funding_Inquiry_Submission.md` against it, because that is the
single point where the owner's plan diverges from the system RCC describes. A civic simulation that
models only the existing rules is an accurate museum. One that models only the proposal is a
daydream. The twin's job is the join: show how the island runs under the rules as they are, then let
a player run the divergence and watch what changes. That is the whole argument for building this
thing, and both halves are now on disk.

Take one narrow slice, source it properly, and let it be right. The corpus will still be there for
the wave after.

## The Quandamooka Country Events Engine, and how to connect to it

Added 10 August 2026, after the owner pointed out that this repository is refreshed often. It is, and
that changes how a connector should treat it. Read this before writing `tools/connectors/events-engine.mjs`.

**Where it is:** `C:\Users\sbt41\githublocal\quandamooka-country-events-engine`

**It is a live-ish feed, not a static pack.** The git history carries repeated `Refresh public event
atlas sources` commits: six between 12 June and 3 July 2026, so roughly weekly. The local working copy
lags the remote. A connector must pull before it syncs, and must record which commit it read, not just
the date it ran.

**It carries its own freshness and its own honesty flag, so do not invent replacements.**
The data lives in `assets/site-data.js` as `window.QCEE_DATA` (plus `noticeboard-data.js` and
`place-data-extra.js`), and the project object already publishes:

- `lastPublicSearch`, currently "3 July 2026"
- `dataStatus`, currently "Draft event atlas. Confirm dates, permissions and contacts..."

Carry both straight through into the record envelope as the freshness and the confidence. A twin that
computes its own confidence for this source, while the source is already telling you it is a draft, is
overstating. If `dataStatus` says draft, every record from that sync is draft, and the interface says so.

**`docs/PUBLIC_BOUNDARY.md` in that repository is a BLOCKING rule for this connector**, on the same
footing as `data/lore.json`. It is the owner's own publication contract for this material and it is
better written than anything we would have invented. Its keep-private list includes sensitive cultural
material, protected places, unapproved images or names, and incident details that identify people.
Nothing on that list enters the twin through this connector, whatever the data file happens to contain.

Its "required wording stance" is worth reading in full because four of its five lines are rules this
project already holds under different names:

- do not imply official authority unless it has been granted
- **do not treat guessed catalogue data as consent**
- do not frame one person as director of the ecosystem
- **do not describe a proposed capability as if it already exists**
- use clear source status when dates, permissions or listings need confirmation

The second and fourth are exactly our no-fabrication and proposed-stays-proposed rules, arrived at
independently. Where that document and ours differ on this material, that one wins: it is closer to the
source and closer to the people the material is about.

## Correction from the owner, 10 August 2026: the mine leases are former mine sites

His Google MyMaps carries a folder named "Private Mine Leases" with four placemarks. His correction,
in his own words: the leases were closed in 2019 but they are still the old mine sites.

That distinction matters and the folder name alone would have got it wrong. Sand mining on Minjerribah
ended in 2019 under the North Stradbroke Island Protection and Sustainability Act, and the Economic
Transition Strategy is the state's response to that ending. So those four placemarks are the FORMER
mine sites: the ground the mining happened on, which is still there, still recognisable, and in various
states of rehabilitation. They are not current leases and nothing in this twin may present them as
operating, or imply that anyone holds a right to mine there now.

For any agent importing that folder:

- status is `former`, never `active`, and the label a player sees says former mine site
- they join the rehabilitation the twin already models rather than becoming a second parallel truth.
  `src/systems/ecology/vegetation.js` already tracks the even-aged replanted areas and
  `data/geography.json` carries the rehabilitation zones. Reconcile against those.
- the end date is 2019 and it is sourced: the Act and the Economic Transition Strategy are both in
  `data/civic.json`. Cite one of them rather than the map, because the map is a pin and the Act is the
  reason.
- the rehabilitated ground is one of the more interesting things about this island and reads as a real
  landscape story rather than a footnote: an even-aged forest with a straight edge is visible from the
  air, and the twin can already show it.

## The 2012 stack: the owner's own reading, and where this project came from

Staged 10 August 2026 at `ingest-inbox/law-2012/`, 61 files, 91 MB, gitignored. All PDFs are
text-extractable with pdftotext: sampled the Constitution, Magna Carta and the TransLink Act and each
returned clean text.

**This is primary material and it outranks anything an agent researches from scratch.** In 2012 the
owner went through his own filing cabinet, took every document with fine print naming a legislative
act, downloaded the Act, and read it. Then followed the chain up and out. Sixty instruments. This is
that stack, with his own relevance judgement in the folder name.

He has said what it did to him: after reading it he wanted to remove himself from Australia. A couple
of years later, in 2015, he started game design to gamify democracy and to build Aura of Intelligence.
So this twin's civic layer is not a feature that happened to get built. It is the thing that reading
produced, thirteen years downstream, and the reason the civic board says you are not the mayor and
models persuading, applying and waiting rather than deciding.

### Why the selection matters more than the count

It is not a library, it is a paper trail, and the method is visible in what sits beside what:

- The fine-print documents he started from are still in the stack: `TFN Application Form`,
  `nat3346 Statement by a Supplier`, `Westpac Personal Accounts PDS`, `QSuper Accumulation Acc PDS`.
- Beside each is the Act it cites. The bank PDS next to the `Banking Act 1959` and the
  `Bills of Exchange Act 1909`. The super PDS next to four Superannuation Acts and two volumes of the
  SIS Regulations. The TFN form next to `Taxation Administration Act 1953` and PAYG.
- Then the chain outward: `The Magna Carta`, `UN - Universal Declaration of Human Rights`,
  `UN Treaties with Australia as Signatory`, and a `UCC-1 Form`.

An agent building the corpus should follow that structure, because the edge from a personal document to
the Act that governs it is the most useful edge in the entire graph and it is the one nobody draws.

### Three findings in the stack itself

**1. He collected both halves of the UCC question and probably did not know it.**
The `UCC-1 Form` is the financing statement under the United States Uniform Commercial Code, Article 9,
which is the law of US states and has no operation in Australia. Sitting in the same folder is the
`Personal Property Securities Act 2009`, twice. The PPSA is Australia's answer to UCC Article 9: it is
what actually creates and perfects a security interest over personal property here, and it has its own
register. So the honest edges are: `UCC-1` to an Australian, `foreign-domestic`, no operation; and
`UCC Article 9` to `PPSA 2009`, `functionally-equivalent`, different instrument, same job, this one
binds. That pair is a better teaching object than either document alone.

**2. The treaty spreadsheet already carries the in-force distinction.**
`UN Treaties with Australia as Signatory.xls` is not a spreadsheet: it is an HTML table saved with an
xls extension, a United Nations Treaty Series export. Parse it as HTML. It holds 1,500 registration
rows and 1,253 distinct titles, with columns Registration Number, Title, Participants, Conclusion Date,
Entry into Force Date, Treaty Type.

The registration prefix is the thing to read: `I-` 1,116 registered, `A-` 351 subsequent actions such
as protocols and amendments, `NIF-` 5 **not in force**, plus `NEW-`, `II-`, `C-` and `CH-`.
The dataset distinguishes in force from not in force at the source. Use its own distinction rather than
asserting one, and remember that UN registration and entry into force are still not the same thing as
being part of Australian domestic law, which needs implementing legislation.

**3. He caught a transition in the maritime cluster.**
Both `Navigation Act 1912` and `Navigation Act 2012` are in the stack, with `Shipping Registration Act
1981` and `Limitation of Liability for Maritime Claims Act 1989`. On an island where everything arrives
by boat, that cluster is directly load-bearing and it is already researched.

And `QLD - Transport Operations (Translink Transit Authority) Act 2008` is in there, which is the
statutory basis for the TransLink correction he made on 10 August 2026. He had the source in 2012.

### A third publisher, added for the edges: Queensland Judgments

The edges of the corpus need judgments, and a judgment is the easiest thing in this project to get
wrong from memory. Half the case names a person is handed with one of these arguments are
misremembered, misattributed or from another country, and the pack will not carry one on anybody's
recall, including its own.

**Where.** `queenslandjudgments.com.au`, published by the Incorporated Council of Law Reporting for
the State of Queensland with the Supreme Court of Queensland Library Committee. It serves the case
page at `/caselaw/<court>/<year>/<number>` and the authorised PDF at that path plus `/pdf`. The
larger free database refuses automated readers in its terms, so this project goes elsewhere rather
than around it, and reads one page per judgment, offline afterwards.

**What is checked.** The case page has to carry the case name and the medium neutral citation. The
PDF has to carry the quote character for character and every party name in the case name. Both
retrievals are sha256'd into `ingest-inbox/legislation/judgments/`, which is gitignored, and the
hashes go on the record. Nothing is republished beyond the quoted sentence.

**What is in the pack.** Four Queensland judgments, all on chains a person may arrive holding:
Carnes v Essenberg [1999] QCA 339 on Magna Carta and the Bill of Rights, Kosteska v Magistrate
Manthey & Anor [2013] QCA 105 on the claim that the courts and the statutes are not validly
established, R v Sweet [2021] QDC 216 on the two legal persons argument and on documents drawing on
the United States Uniform Commercial Code, and Wells v Queensland Police Service [2024] QDC 38 on the
claim that a person who has not consented is not bound by the traffic law.

**How they are written.** In the pack's own words, kept to what the court decided. Judgments on these
arguments sometimes carry sharp words about the person who ran them. The pack quotes the legal
conclusion and not the rebuke, because a reader who arrives holding one of these is there to find out
where they stand, not to be told what somebody thought of a stranger.

**And the Act that answers the question the 2012 stack ended on.** Imperial Acts Application Act 1984
(Qld), on the Queensland register at `act-1984-070`. Section 7 terminates the application in
Queensland of the imperial enactments in force in England when the Australian Courts Act 1828 was
passed; section 5 preserves the sixteen listed in schedule 1, with the same force and effect they
had. Entry 1 in that schedule is `(1297) 25 Edward 1 ch 29 Magna Carta` and entry 9 is the Bill of
Rights. Anybody researching this corpus should start there rather than with the charter.
