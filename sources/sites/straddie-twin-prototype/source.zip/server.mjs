import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, dirname, extname, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.STRADDIE_PREVIEW_PORT || 8847);
const types = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.webp':'image/webp','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.gif':'image/gif','.wasm':'application/wasm','.woff2':'font/woff2'};
const server = createServer(async(req,res) => {
  try {
    if (!['GET','HEAD'].includes(req.method)) {res.writeHead(405); res.end(); return;}
    if (![ `127.0.0.1:${port}`, `localhost:${port}` ].includes(req.headers.host)) {res.writeHead(403); res.end(); return;}
    const path = decodeURIComponent(new URL(req.url, `http://127.0.0.1:${port}`).pathname);
    const relative = path === '/' ? 'index.html' : path.slice(1);
    const allowed = /^(index\.html|sources\.html|app\.css|(?:src|data|media|vendor)\/[^\0]+)$/.test(relative);
    const target = resolve(root, relative);
    if (!allowed || !target.startsWith(root + sep)) {res.writeHead(404); res.end(); return;}
    const info = await stat(target);
    if (!info.isFile()) {res.writeHead(404);res.end();return;}
    res.setHeader('Content-Type',types[extname(target)] || 'application/octet-stream');
    res.setHeader('X-Content-Type-Options','nosniff');
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Cache-Control',relative.startsWith('vendor/') || relative.startsWith('media/') ? 'public, max-age=3600' : 'no-cache');
    // Cesium's pinned local build uses runtime compilation and WebAssembly.
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self' blob: 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https://tiles.maps.eox.at https://spatial-img.information.qld.gov.au; connect-src 'self' https://tiles.maps.eox.at https://spatial-img.information.qld.gov.au; worker-src 'self' blob:; font-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'none'");
    res.writeHead(200);res.end(req.method==='HEAD' ? undefined : await readFile(target));
  } catch {res.writeHead(404); res.end('Not found');}
});
server.listen(port,'127.0.0.1',()=>console.log(`Straddie preview: http://127.0.0.1:${port} (this computer only)`));
