@echo off
cd /d "%~dp0"
echo Opening the local Straddie preview at http://127.0.0.1:8847
echo Keep this window open while using it. Close it to stop the preview.
start "" "http://127.0.0.1:8847"
node server.mjs
pause
