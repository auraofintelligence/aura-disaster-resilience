# Local preview validation

Checked on 5 September 2026 on this laptop. Browser checks use installed Microsoft Edge in an isolated headless profile. The finished page was also opened in the Codex browser. No frame-rate or AAA performance claim follows from these checks.

- Five simulation tests pass, including 486 boundary combinations for conservation and seat capacity, ordering, a final-minute arrival, repeatability and invalid inputs.
- Actual public satellite tiles returned successfully and rendered in the desktop preview. The test records the tile count in `qa/browser-results.json`.
- Both local 360 collections open interactively. Next-point navigation works.
- Search, layer controls, changed scenario inputs and comparison export work.
- A test observation and attached photo survive a page reload. Export preserves private status and the photo checksum. User text is displayed as text. The test record is deleted inside the isolated test browser; the user's browser notebook is untouched.
- The source page displays all five input-file provenance records.
- The 390-pixel layout fits without horizontal overflow. Imagery attribution spacing was checked visually.
- Blocking satellite requests shows the outage status while the independent scenario remains usable.
- The static server rejects parent-folder/source-code reads and POST requests. The region data endpoint remains readable. The server listens on loopback only.

The screenshots and machine-readable browser result are in `qa`. These checks prove the stated interactions and internal arithmetic, not the accuracy of the source geography, live service operation, demand forecasts, legal applicability, cultural permissions or engineering designs.

## Imagery and phone layout follow-up

The 390 x 844 phone check now measures a 732-pixel map, with the tab strip beginning at pixel 796. A 3x-density device uses a 780-pixel canvas across its 390 CSS pixels. Public Queensland aerial tiles rendered in both phone and desktop close-ups, and the satellite-only toggle passed. The existing browser checks also passed. Reproduce with npm run test:map; STRADDIE_TEST_URL can target the local or public edition.
