# Straddie twin prototype

A small working browser interface for inspecting existing island evidence and trying a transparent transport exercise. Prepared for Luke on 5 September 2026. This does not replace either existing twin repository.

## Open it

Public site: https://auraofintelligence.github.io/straddie-twin-prototype/

For the local edition:

Double-click **Start preview.cmd** in this folder. It opens http://127.0.0.1:8847. Keep the small terminal window open while you use the preview. If a preview is already running, use its browser address instead.

Node.js is required and is installed on this laptop. No account or paid imagery token is needed. Satellite tiles need internet access. The local photos, lists, simulation and notebook do not use an external AI service.

## What works

- A Cesium satellite map with roads, bus stops, lakes, and capture points.
- 77 existing local panorama records from the Dunwich and Ballow Road examples. Select a point and choose **Step inside this 360 photo**.
- **What if** compares two hypothetical shuttle boarding patterns, with adjustable demand, seats, interval and arrival delay, a queue chart, replay and JSON export.
- **My notes** saves observations and optional JPEG/PNG/WebP photos in browser storage. Photos get SHA-256 checksums. Records and photos can be exported separately and deleted locally.
- A separate data/source page with actual input file checksums and repository commits.

## Limits that matter

This is a satellite and panorama preview, not AAA reconstructed 3D. No live feed is connected. The map uses an ellipsoid, without elevation or buildings. The transport exercise is uncalibrated and does not model routes, vehicle cycles, staff, costs or a real timetable. The legal cabinet is a source-link starting point, without legal RAG or applicability decisions.

The notebook is private to this browser profile. It is not encrypted by the application, automatically backed up, synchronised, or protected from other users of the same browser profile. Clearing browser data removes it. Keep originals and export important records. Exported JSON contains attachment metadata and checksums, not image bytes.

The server binds only to 127.0.0.1 and allows only read access to the preview's public assets. It does not serve parent repositories, hidden files, or an upload endpoint. In the local edition, libraries and panorama derivatives are served locally. In the public edition they are served by GitHub Pages. Satellite requests go to EOX. The release includes the existing public panorama derivatives; it contains no private notebook records or newly attached user photos. Browser storage on GitHub Pages shares an origin with other pages under the same account, so the local edition is preferable for sensitive notes.

## Where the pieces came from

`tools/prepare-data.mjs` reads selected source files from four neighbouring repositories, preserves source file checksums and local commit IDs, and copies existing display images. It does not modify those repositories. Local-versus-remote reconciliation is still needed before treating them as maintained feeds.

Based on minjerribah-living-twin and second-island by Luke Nathan Hayes / Strange But True / Aura of Intelligence. Used under the Strange But True Public Source Licence. Existing capture material retains its existing owner and permissions. This folder is not a blanket open-source licence grant.

OSM-derived geometry retains ODbL obligations; Translink data retains CC BY 4.0. EOxCloudless 2025 imagery is under its non-commercial terms, with attribution. Paid/commercial/offline rights require separate assessment. CesiumJS 1.145.0 is Apache 2.0; Pannellum is MIT. Their bundled notices remain in vendor files. See **Data & sources** in the preview for linked records.

## Validation and development

`npm test` checks passenger conservation, seat capacity, ordering, time boundaries and repeatability. `node tools/browser-check.mjs` runs the local browser checks using the bundled Playwright runtime and installed Edge. A running preview server is required.

The region package is a first portable boundary for data and provenance. The small boarding exercise is an explicitly temporary demonstration module, not a wholesale replacement for the existing simulation kernels. The next build should reconcile those kernels and attach a verified observation feed and a bounded legal-retrieval service.

## GitHub Pages

The site is static and uses relative asset paths so it works beneath the repository URL. Pages publishes `main` from the repository root with `.nojekyll`. `.npm-cache`, dependency archives, local release helpers and QA outputs are excluded from Git. No private notebook is stored in repository files.

## Clearer close-ups and phone view

Close-up views automatically add Queensland public aerial imagery over the satellite base. A Dunwich identify sample returned the 2022 Redland 10 cm capture; dates and resolution vary elsewhere. The aerial layer can be turned off. Both providers retain their attribution and the Queensland acknowledgement is on the source page. Phones use almost the first screen for the map, with the scrollable tab strip visible below. Rendering uses screen pixel density, capped at 2x, instead of reducing canvas resolution on high-density screens.
