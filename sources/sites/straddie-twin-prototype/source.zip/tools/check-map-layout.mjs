import {createRequire} from 'node:module';import {readFile,writeFile} from 'node:fs/promises';
import {homedir} from 'node:os';import {join} from 'node:path';import assert from 'node:assert/strict';
const {chromium}=createRequire(import.meta.url)(join(homedir(),'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));
const base=process.env.STRADDIE_TEST_URL||'http://127.0.0.1:8847';
const browser=await chromium.launch({channel:'msedge',headless:true});
try{
 for(const size of [{name:'phone-detail',width:390,height:844,dpr:3},{name:'desktop-detail',width:1440,height:1000,dpr:1.5}]){
  const context=await browser.newContext({viewport:{width:size.width,height:size.height},deviceScaleFactor:size.dpr,reducedMotion:'reduce'});const p=await context.newPage();const errors=[];let aerialTiles=0;
  p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.url().includes('spatial-img.information.qld.gov.au')&&r.status()===200)aerialTiles++;});
  await p.goto(base);await p.waitForFunction(()=>document.querySelector('#map-message').textContent.startsWith('Satellite mosaic:'),{},{timeout:60000});
  if(size.width===390){const dimensions=await p.evaluate(()=>({height:document.querySelector('.map-panel').getBoundingClientRect().height,tabTop:document.querySelector('.tablist').getBoundingClientRect().top,scrollWidth:document.documentElement.scrollWidth,width:innerWidth,viewport:innerHeight,pixels:document.querySelector('#map canvas').width,cssPixels:document.querySelector('#map canvas').clientWidth}));assert.ok(dimensions.height>=dimensions.viewport*.85);assert.ok(dimensions.tabTop<dimensions.viewport&&dimensions.tabTop>dimensions.viewport-65);assert.equal(dimensions.scrollWidth,dimensions.width);assert.ok(dimensions.pixels>=dimensions.cssPixels*1.9);console.log('PASS phone map fills first screen with scroll strip; crisp 2x canvas',dimensions);}
  await p.getByRole('button',{name:'Dunwich ferry walk 33 capture points'}).click();if(size.width===390)await p.evaluate(()=>window.scrollTo(0,0));
  await p.waitForFunction(()=>document.querySelector('#map-message').textContent.startsWith('Queensland aerial imagery'),{},{timeout:60000});assert.ok(aerialTiles>0);await p.screenshot({path:`qa/${size.name}.png`});
  await p.getByRole('checkbox',{name:'Detailed aerial close-ups'}).uncheck();assert.ok((await p.locator('#imagery-label').innerText()).includes('Satellite'));await p.getByRole('checkbox',{name:'Detailed aerial close-ups'}).check();assert.ok((await p.locator('#imagery-label').innerText()).includes('Queensland'));
  assert.deepEqual(errors,[]);console.log(`PASS ${size.name}: ${aerialTiles} public aerial tiles, source switch and no application errors`);await context.close();
 }
}finally{await browser.close();}
