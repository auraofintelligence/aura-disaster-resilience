import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const workspace = resolve(root, '..');
const sources = [];
async function source(repo, file, publicUrl, licence) {
  const bytes = await readFile(resolve(workspace, repo, file));
  const item = { repo, file, publicUrl, licence, sha256: createHash('sha256').update(bytes).digest('hex'), commit: execFileSync('git', ['-C', resolve(workspace, repo), 'rev-parse', 'HEAD'], {encoding:'utf8'}).trim() };
  sources.push(item);
  return bytes.toString('utf8');
}
await mkdir(resolve(root, 'data'), {recursive:true});
const captures = [];
for (const config of [
  {key:'dunwich', repo:'dunwich-gumpi-ferry-terminal-open-data-lab', file:'assets/photo-data.js', collection:'Dunwich ferry walk'},
  {key:'ballow', repo:'ballow-road-sand-screen-hub', file:'assets/js/site-360-data.js', collection:'Ballow Road walk'}
]) {
  const url = `https://auraofintelligence.github.io/${config.repo}/evidence-map.html`;
  const content = await source(config.repo, config.file, url, 'Luke Nathan Hayes / Aura of Intelligence; existing local display derivatives. No new publication or training rights granted.');
  const array = content.match(/=\s*(\[[\s\S]*?\r?\n\]);/);
  if (!array) throw new Error(`Cannot read the capture array in ${config.file}`);
  const points = JSON.parse(array[1]);
  await mkdir(resolve(root, 'media', config.key), {recursive:true});
  for (const p of points) {
    const media = {};
    for (const [kind, input] of Object.entries({pano:p.viewerPano || p.pano, thumb:p.thumb})) {
      const target = `media/${config.key}/${p.id}-${kind}.webp`;
      const bytes = await readFile(resolve(workspace, config.repo, input));
      await writeFile(resolve(root, target), bytes);
      media[kind] = target;
      media[`${kind}Sha256`] = createHash('sha256').update(bytes).digest('hex');
    }
    captures.push({id:`${config.key}-${p.id}`, collection:config.collection, group:config.key, sequence:p.sequence, title:p.publicName || p.title, lat:p.lat, lon:p.lon, captured:p.captureLabel, notes:p.notes, source:url, sourceFile:config.file, sourceRepo:config.repo, placement:'Source GPS position. Not survey control; panorama heading and altitude are unverified.', ...media});
  }
}
const geo = JSON.parse(await source('minjerribah-living-twin','data/geography.json','https://github.com/auraofintelligence/minjerribah-living-twin/blob/main/data/geography.json','OSM-derived geometry: ODbL 1.0. Project annotations: Strange But True Public Source Licence.'));
const transit = JSON.parse(await source('second-island','data/transport-gtfs.json','https://github.com/auraofintelligence/second-island/blob/main/data/transport-gtfs.json','Translink CC BY 4.0; project annotations retain Strange But True Public Source Licence.'));
const crossings = JSON.parse(await source('second-island','data/crossings.json','https://github.com/auraofintelligence/second-island/blob/main/data/crossings.json','Strange But True Public Source Licence; underlying sources remain attached.'));
const data = {schema:'straddie-preview-region/1', preparedAt:new Date().toISOString(), title:'Minjerribah and surrounding waters', coordinates:'EPSG:4326; longitude, latitude', bounds:geo.island.bbox, geographyDate:geo.generated, coastline:geo.coastline, roads:geo.roads, water:geo.water_bodies, captures, stops:transit.stops, terminals:transit.terminals, routes:transit.routes, crossings:crossings.services, sources};
await writeFile(resolve(root, 'data/region.json'), JSON.stringify(data, null, 2));
await mkdir(resolve(root, 'vendor/pannellum'), {recursive:true});
for (const file of ['pannellum.js','pannellum.css']) await copyFile(resolve(workspace,'ballow-road-sand-screen-hub/assets/vendor/pannellum',file),resolve(root,'vendor/pannellum',file));
console.log(`Prepared ${captures.length} captures, ${data.roads.length} roads, ${data.stops.length} bus stops. Originals unchanged.`);
