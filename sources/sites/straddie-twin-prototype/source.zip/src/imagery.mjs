export function addDetailedImagery(viewer, notify) {
  const C=window.Cesium;
  const provider=new C.UrlTemplateImageryProvider({
    url:'https://spatial-img.information.qld.gov.au/arcgis/rest/services/Basemaps/LatestStateProgram_AllUsers/ImageServer/tile/{z}/{y}/{x}',
    minimumLevel:8,maximumLevel:20,
    rectangle:C.Rectangle.fromDegrees(153.2,-27.8,153.65,-27.32),
    credit:new C.Credit('Includes material © State of Queensland (Department of Natural Resources and Mines, Manufacturing and Regional and Rural Development); © Planet Labs Netherlands B.V. reproduced under licence from Planet and Geoplex, all rights reserved, 2026. <a href="https://spatial-img.information.qld.gov.au/arcgis/rest/services/Basemaps/LatestStateProgram_AllUsers/ImageServer/info/iteminfo">Queensland imagery terms</a>',false)
  });
  const layer=viewer.imageryLayers.addImageryProvider(provider);
  let failed=false;
  const toggle=document.getElementById('aerial-detail');
  const label=document.getElementById('imagery-label');
  const update=()=>{
    layer.show=toggle.checked&&!failed&&viewer.camera.positionCartographic.height<16000;
    label.textContent=layer.show?'Queensland aerial · dated imagery':'Satellite 2025 · 10 m context';
    viewer.scene.requestRender();
  };
  provider.errorEvent.addEventListener(()=>{failed=true;update();notify('Detailed aerial unavailable. Showing the lower-resolution satellite view.');});
  toggle.addEventListener('change',()=>{failed=false;update();});
  viewer.camera.changed.addEventListener(update);
  update();
  return {isActive:()=>layer.show,hasFailed:()=>failed};
}
