export const MODEL_VERSION = 'boarding-exercise/1.0.0';
export const HORIZON = 180;
function integer(value,min,max,name) {
  if(!Number.isInteger(value) || value < min || value > max) throw new Error(`${name} must be a whole number from ${min} to ${max}.`);
  return value;
}
export function simulate({demand=80,seats=16,interval=20,delay=0}={}) {
  integer(demand,0,300,'Demand');integer(seats,1,40,'Seats');integer(interval,5,60,'Interval');integer(delay,0,90,'Delay');
  const people = Array.from({length:demand}, (_,i)=>({id:`synthetic-${i+1}`,arrival:Math.floor(i*4/Math.max(demand,1))*30+delay,boarded:null}));
  const queue=[]; const timeline=[]; const departures=[];
  for(let minute=0;minute<=HORIZON;minute++) {
    queue.push(...people.filter(p=>p.arrival===minute));
    if(minute>=10 && (minute-10)%interval===0) {
      const riders=queue.splice(0,seats);
      riders.forEach(p=>p.boarded=minute);
      departures.push({minute,boarded:riders.length,seats,ids:riders.map(p=>p.id)});
    }
    timeline.push({minute,waiting:queue.length,boarded:people.filter(p=>p.boarded!==null).length});
  }
  const boarded=people.filter(p=>p.boarded!==null);
  return {model:MODEL_VERSION,inputs:{demand,seats,interval,delay},horizon:HORIZON,people,departures,timeline,metrics:{arrived:people.length,boarded:boarded.length,waiting:queue.length,meanServedWait:boarded.length ? boarded.reduce((s,p)=>s+p.boarded-p.arrival,0)/boarded.length : null,longestWaitSoFar:people.length ? Math.max(...people.map(p=>(p.boarded ?? HORIZON)-p.arrival)) : 0,seatDepartures:departures.reduce((s,d)=>s+d.seats,0)}};
}
export function compare(input) {
  return {reference:simulate({...input,seats:12,interval:30}),proposal:simulate(input)};
}
