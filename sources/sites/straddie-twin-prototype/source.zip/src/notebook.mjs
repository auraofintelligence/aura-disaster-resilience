const DB='straddie-preview-private-notebook';
function openDB(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('notes',{keyPath:'id'});r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}
async function transact(mode,action){const db=await openDB();return new Promise((resolve,reject)=>{const tx=db.transaction('notes',mode);const request=action(tx.objectStore('notes'));tx.oncomplete=()=>{resolve(request.result);db.close();};tx.onerror=()=>{reject(tx.error);db.close();};tx.onabort=()=>{reject(tx.error||new Error('Storage cancelled'));db.close();};});}
export const listNotes=()=>transact('readonly',s=>s.getAll());
export const saveNote=note=>transact('readwrite',s=>s.put(note));
export const deleteNote=id=>transact('readwrite',s=>s.delete(id));
export async function hashFile(file){const hash=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());return Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('');}
export function receipt(note){const {file,...metadata}=note;return {schema:'straddie-local-observation/1',...metadata,attachmentIncluded:false};}
