import {test} from 'node:test';
import assert from 'node:assert/strict';
import {simulate,compare,HORIZON} from '../src/simulation.mjs';
test('boarding conserves people and never exceeds seats across boundary cases',()=>{
  for(const demand of [0,1,7,80,299,300])for(const seats of [1,12,40])for(const interval of [5,30,60])for(const delay of [0,35,90]){
    const r=simulate({demand,seats,interval,delay});assert.equal(r.metrics.boarded+r.metrics.waiting,demand);assert.equal(r.metrics.arrived,demand);
    const ids=r.departures.flatMap(d=>d.ids);assert.equal(new Set(ids).size,ids.length);assert.ok(r.departures.every(d=>d.boarded<=seats));
    assert.ok(r.people.every(p=>p.boarded===null||(p.boarded>=p.arrival&&p.boarded<=HORIZON)));
    for(const t of r.timeline)assert.equal(t.waiting+t.boarded,r.people.filter(p=>p.arrival<=t.minute).length);
  }
});
test('people arriving at the horizon are still accounted for',()=>{const r=simulate({demand:4,seats:1,interval:60,delay:90});assert.equal(r.people.at(-1).arrival,HORIZON);assert.equal(r.people.at(-1).boarded,null);assert.equal(r.metrics.waiting,3);});
test('a known small queue boards in arrival order',()=>{const r=simulate({demand:8,seats:1,interval:30,delay:0});assert.deepEqual(r.people.map(p=>p.boarded),[10,40,70,100,130,160,null,null]);assert.equal(r.metrics.longestWaitSoFar,100);});
test('identical designs produce identical results and can be replayed',()=>{const input={demand:80,seats:12,interval:30,delay:20};const c=compare(input);assert.deepEqual(c.reference,c.proposal);assert.deepEqual(c,compare(input));});
test('invalid and fractional inputs are rejected',()=>{for(const input of [{demand:-1},{seats:0},{interval:0},{delay:91},{demand:3.5},{seats:NaN}])assert.throws(()=>simulate(input));});
