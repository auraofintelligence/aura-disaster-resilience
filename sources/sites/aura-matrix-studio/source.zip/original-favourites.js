import {framePoint} from './frame-display.js?v=0.4.26';
import {favouriteGroups} from './favourite-groups.js?v=0.4.26';
import {pageIcon,favouriteIcon} from './page-icons.js?v=0.4.26';
import {blankProject,validateProject} from './core.js?v=0.4.26';
import {updateFavourite} from './favourites-data.js?v=0.4.26';
import {mapPages,pageTitle} from './original-sitemap.js?v=0.4.26';
import {exportShortcutMenu,reviewShortcutMap,importShortcutMap} from './favourites-sharing.js?v=0.4.26';
export const FAVOURITES='B47A9839-38E6-49D8-B255-0D9E428E521C';
const KEY='aura-matrix-studio:v4:project';
export function mountFavourites({page,screen,pages,go}){
 const make=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls||'';if(text!==undefined)n.textContent=text;return n;};
 const button=(label,fn)=>{const b=make('button','',label);b.type='button';b.onclick=fn;return b;};
 const all=[...pages.values()],icons=new Map(all.map(p=>[pageIcon(p.id),pageTitle(p)]).filter(([file])=>file)),pageIcons=new Map(all.map(p=>[p.id,pageIcon(p.id)]));
 const groups=favouriteGroups(all,mapPages(all,'all')),browse=groups.flatMap(g=>g.pages);let bookIndex=0,turning=false,turnAnimation=null,groupId='people';
 let project,editing=false,slotIndex=0,menuId='',chosenPage='',chosenIcon='',stage='pages',query='',resultPage=0,disposed=false;
 function read(){const raw=[KEY,'aura-matrix-studio:v3:project','aura-matrix-studio:v2:project','aura-matrix-studio:v1:project'].map(k=>localStorage.getItem(k)).find(Boolean);project=raw?validateProject(JSON.parse(raw)):blankProject();}
 function change(fn){read();const next=validateProject(fn(structuredClone(project)));localStorage.setItem(KEY,JSON.stringify(next));project=next;draw();}
 const active=()=>project.favourites.menus.find(m=>m.id===project.favourites.activeId);
 read();const sourceSlots=page.controls.filter(c=>c.controlTypeID==='Icon'&&!c.properties.URL&&+c.w===24&&+c.h===24).sort((a,b)=>+a.y-+b.y||+a.x-+b.x);
 if(sourceSlots.length!==25)throw Error('The original favourite slots could not be located.');
 for(const c of page.controls)if(c.controlTypeID==='CoverFlow'||sourceSlots.includes(c)||+c.y===20&&c.controlTypeID==='Icon'||c.controlTypeID==='Image'&&+c.y===426||c.controlTypeID==='Label'&&+c.y===56)screen.querySelector(`[data-source-control="${c.controlID}"]`).hidden=true;
 for(const c of page.controls)if(c.controlTypeID==='Label'&&+c.y===374)screen.querySelector(`[data-source-control="${c.controlID}"] .original-text`).textContent='Browse pages · tap ☆ to add';
 const title=button('Favourite pages',()=>openMenu(false));title.className='favourites-title';const edit=button('Edit',()=>{editing=!editing;draw();});edit.className='favourites-edit';screen.append(title,edit);
 const hint=make('p','favourites-hint');screen.append(hint);
 const slotButtons=sourceSlots.map((c,i)=>{const b=button('',()=>{read();const slot=active().slots[i];if(slot&&!editing&&pages.has(slot.pageId))go(slot.pageId);else openSlot(i);});b.className='favourite-slot';Object.assign(b.style,{left:(+c.x-16)+'px',top:(+c.y-10)+'px'});screen.append(b);return b;});
 const menuBook=button('',()=>{if(!swiped&&!turning)go(browse[bookIndex].id);});menuBook.className='favourite-menu-book';
 const prev=button('‹',()=>cycle(-1)),next=button('›',()=>cycle(1));prev.className='favourite-menu-prev';next.className='favourite-menu-next';prev.setAttribute('aria-label','Previous page');next.setAttribute('aria-label','Next page');
 const add=button('☆',()=>{const free=active().slots.findIndex(s=>!s);if(free<0){editing=true;draw();return;}openSlot(free);chosenPage=browse[bookIndex].id;chosenIcon=pageIcon(chosenPage);stage='details';renderPicker();});add.className='favourite-book-add';add.title='Add this page to favourites';add.setAttribute('aria-label',add.title);screen.append(menuBook,prev,next,add);
 let start=null,swiped=false;
 menuBook.addEventListener('pointerdown',e=>{start={...framePoint(screen,e)};swiped=false;});
 menuBook.addEventListener('pointermove',e=>{if(start&&Math.abs(framePoint(screen,e).x-start.x)>10)menuBook.setPointerCapture(e.pointerId);});
 menuBook.addEventListener('pointerup',e=>{if(start&&Math.abs(framePoint(screen,e).x-start.x)>30&&Math.abs(framePoint(screen,e).x-start.x)>Math.abs(framePoint(screen,e).y-start.y)){swiped=true;cycle(framePoint(screen,e).x<start.x?1:-1);}start=null;});menuBook.addEventListener('pointercancel',()=>start=null);
 menuBook.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();cycle(e.key==='ArrowRight'?1:-1);}});
 const dialog=make('dialog','favourite-dialog'),head=make('header'),heading=make('h2'),close=button('Done',()=>dialog.close()),body=make('div','favourite-dialog-body'),status=make('p','favourite-status');status.setAttribute('role','status');head.append(heading,close);dialog.append(head,body,status);document.body.append(dialog);
 let refreshChoices=null;const resizePicker=()=>{if(dialog.open)refreshChoices?.();};window.addEventListener('resize',resizePicker);
 const safe=fn=>{try{fn();}catch(e){status.textContent=e.message;}};
 function sharing(){
  refreshChoices=null;body.classList.remove('is-browsing');heading.textContent='Share favourite pages';body.replaceChildren();status.textContent='';
  body.append(make('p','','Share the selected shortcut menu: its name, page references, icons and positions. Answers, tables, media, encryption keys and access permissions are excluded. Importing adds a new menu; its pages open your own Aura data.'));
  body.append(button('Export this shortcut menu',()=>safe(()=>{read();const data=exportShortcutMenu(project.favourites,active().id),blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=make('a');a.href=url;a.download='aura-shortcut-map.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='Shortcut map exported. Review menu names before sharing.';})));
  const file=make('input');file.type='file';file.accept='.json,application/json';file.setAttribute('aria-label','Import shortcut map');body.append(field('Import a shared shortcut map',file));
  const preview=make('div');body.append(preview);
  let revision=0;file.onchange=async()=>{const current=++revision;preview.replaceChildren();status.textContent='';try{const f=file.files[0];if(!f)return;if(f.size>250000)throw Error('Choose a shortcut map under 250 KB.');const text=await f.text();if(current!==revision||!dialog.open||disposed)return;const reviewed=reviewShortcutMap(JSON.parse(text),new Set(pages.keys()),new Set(icons.keys()));preview.append(make('p','','Review before importing. Existing menus and answers will be kept.'));
   for(const menu of reviewed){preview.append(make('h3','',menu.name));const list=make('ol');for(const [i,slot]of menu.slots.entries())if(slot)list.append(make('li','',`Position ${i+1}: ${pageTitle(pages.get(slot.pageId))}`));preview.append(list);}
   preview.append(button('Add imported shortcut menus',()=>safe(()=>{change(p=>{p.favourites=importShortcutMap(p.favourites,reviewed);return p;});dialog.close();})));status.textContent=`${reviewed.length} menu(s) ready for review. No personal answers are included.`;
  }catch(e){if(current===revision)status.textContent=e.message;}};
  if(!dialog.open)dialog.showModal();
 }
 const image=(file,alt='')=>{const img=make('img');img.src='assets/mockplus/'+file;img.alt=alt;return img;};
 function draw(){
  const menu=active();title.textContent=menu.name;edit.textContent=editing?'Done':'Edit';edit.setAttribute('aria-pressed',String(editing));hint.textContent=editing?'Tap an icon to replace, move or clear it.':'Tap a square to add a favourite.';
  slotButtons.forEach((b,i)=>{const slot=menu.slots[i],target=slot&&pages.get(slot.pageId);b.replaceChildren();b.classList.remove('icon-only');b.classList.toggle('is-filled',!!target);b.classList.toggle('is-editing',editing);b.title=target?pageTitle(target):'Add favourite '+(i+1);b.setAttribute('aria-label',(target?(editing?'Edit ':'Open ')+pageTitle(target):'Add favourite')+' · slot '+(i+1));if(target){const file=favouriteIcon(slot);if(file)b.append(image(file));else b.append(make('span','',pageTitle(target).slice(0,1)));const label=make('small','',pageTitle(target));b.append(label);requestAnimationFrame(()=>{if(label.isConnected&&label.offsetHeight>22)b.classList.add('icon-only');});}else b.append(make('span','empty-favourite'));});
  drawBook();title.title='Switch or rename shortcut menus';title.setAttribute('aria-label','Manage shortcut menus');
 }
 function drawBook(){const p=browse[bookIndex],group=groups.find(g=>g.pages.includes(p));menuBook.replaceChildren(image(pageIcon(p.id)),make('strong','',pageTitle(p)),make('small','',group.label),make('small','',`${bookIndex+1} / ${browse.length} · Tap to open`));menuBook.setAttribute('aria-label','Open '+pageTitle(p));}
 function cycle(delta){if(turning)return;const old=menuBook.cloneNode(true);old.setAttribute('aria-hidden','true');old.removeAttribute('aria-label');old.tabIndex=-1;old.style.pointerEvents='none';bookIndex=(bookIndex+delta+browse.length)%browse.length;drawBook();if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;turning=true;screen.append(old);old.style.zIndex=delta>0?'43':'40';menuBook.style.zIndex='42';const sheet=delta>0?old:menuBook;turnAnimation=sheet.animate(delta>0?[{transform:'perspective(700px) rotateY(0deg)'},{transform:'perspective(700px) rotateY(-180deg)'}]:[{transform:'perspective(700px) rotateY(-180deg)'},{transform:'perspective(700px) rotateY(0deg)'}],{duration:650,easing:'ease-in-out'});turnAnimation.finished.catch(()=>{}).finally(()=>{old.remove();turning=false;});}
 function openSlot(i){safe(()=>{read();slotIndex=i;menuId=active().id;const slot=active().slots[i];chosenPage=slot?.pageId||'';chosenIcon=slot?favouriteIcon(slot):'';stage=chosenPage?'details':'pages';query='';resultPage=0;renderPicker();dialog.showModal();});}
 function field(label,n){const l=make('label');l.append(make('span','',label),n);return l;}
 function renderPicker(){
  refreshChoices=null;heading.textContent='Favourite '+(slotIndex+1);body.replaceChildren();status.textContent='';body.classList.toggle('is-browsing',stage!=='details');
  if(stage==='details'){
   const target=pages.get(chosenPage);if(!target){stage='pages';renderPicker();return;}
   const summary=make('div','favourite-choice');if(chosenIcon)summary.append(image(chosenIcon));summary.append(make('strong','',pageTitle(target)));body.append(summary);
   const actions=make('div','favourite-actions');actions.append(button('Change page',()=>{stage='pages';query='';resultPage=0;renderPicker();}),button('Choose icon',()=>{stage='icons';query='';resultPage=0;renderPicker();}));body.append(actions);
   const destination=make('select');destination.setAttribute('aria-label','Position');for(let i=0;i<25;i++){const o=make('option','',`Row ${Math.floor(i/5)+1}, position ${i%5+1}`);o.value=i;destination.append(o);}destination.value=slotIndex;body.append(field('Position (occupied slots swap)',destination));
   body.append(button('Save favourite',()=>safe(()=>{if(chosenIcon&&!icons.has(chosenIcon))throw Error('Choose an icon from the app.');change(p=>{p.favourites=updateFavourite(p.favourites,menuId,slotIndex,{pageId:chosenPage,icon:chosenIcon},+destination.value);return p;});dialog.close();})),button('Clear this slot',()=>safe(()=>{change(p=>{p.favourites=updateFavourite(p.favourites,menuId,slotIndex,null);return p;});dialog.close();})));return;
  }
  const search=make('input');search.type='search';search.placeholder=stage==='icons'?'Find an icon':'Find a page';search.setAttribute('aria-label',search.placeholder);search.value=query;body.append(search);
  const groupSelect=make('select');groupSelect.setAttribute('aria-label','Related favourite pages');for(const group of groups){const o=make('option','',`${group.label} (${group.pages.length})`);o.value=group.id;groupSelect.append(o);}groupSelect.value=groupId;if(stage==='pages')body.append(groupSelect);
  const grid=make('div',stage==='icons'?'favourite-icon-picker':'favourite-page-picker'),pager=make('div','favourite-actions');body.append(grid,pager);
  function results(){grid.replaceChildren();pager.replaceChildren();const source=query?browse.filter(p=>(pageTitle(p)+' '+p.name).toLowerCase().includes(query.toLowerCase())):groups.find(g=>g.id===groupId).pages;const items=stage==='icons'?[...icons].filter(([file,label])=>label.toLowerCase().includes(query.toLowerCase())):source.map(p=>[p.id,pageTitle(p)]),rows=Math.max(1,Math.floor((Math.min(740,window.innerHeight-12)-190)/78)),size=rows*(stage==='icons'?4:3);grid.style.gridTemplateRows=`repeat(${Math.min(rows,Math.max(1,Math.ceil(Math.min(size,items.length)/ (stage==='icons'?4:3))))},minmax(0,1fr))`;resultPage=Math.min(resultPage,Math.max(0,Math.ceil(items.length/size)-1));groupSelect.disabled=Boolean(query);
   for(const [id,label]of items.slice(resultPage*size,resultPage*size+size)){const b=button('',()=>{if(stage==='icons')chosenIcon=id;else{chosenPage=id;chosenIcon=pageIcons.get(id)||'';}stage='details';renderPicker();});b.setAttribute('aria-label',(stage==='icons'?'Use icon ':'Choose ')+label);const file=stage==='icons'?id:pageIcons.get(id);if(file)b.append(image(file));b.append(make('span','',label));grid.append(b);}
   if(!items.length)grid.append(make('p','','No matches.'));const back=button('←',()=>{resultPage--;results();}),forward=button('→',()=>{resultPage++;results();});back.disabled=resultPage===0;forward.disabled=(resultPage+1)*size>=items.length;back.setAttribute('aria-label','Previous choices');forward.setAttribute('aria-label','More choices');pager.append(back,make('span','',`${resultPage+1} / ${Math.max(1,Math.ceil(items.length/size))}`),forward);}
  refreshChoices=results;groupSelect.onchange=()=>{groupId=groupSelect.value;resultPage=0;results();};search.oninput=()=>{query=search.value;resultPage=0;results();};results();if(chosenPage)body.append(button('Back to favourite',()=>{stage='details';renderPicker();}));
 }
 function openMenu(isNew){safe(()=>{refreshChoices=null;body.classList.remove('is-browsing');read();menuId=active().id;heading.textContent=isNew?'New shortcut menu':'Your shortcut menus';body.replaceChildren();status.textContent='';const name=make('input');name.value=isNew?'':active().name;name.maxLength=80;name.setAttribute('aria-label','Menu name');body.append(field('Menu name',name),button(isNew?'Create menu':'Save name',()=>safe(()=>{if(!name.value.trim())throw Error('Enter a menu name.');change(p=>{if(isNew){const id=crypto.randomUUID();p.favourites.menus.push({id,name:name.value.trim(),slots:Array(25).fill(null)});p.favourites.activeId=id;}else p.favourites.menus.find(m=>m.id===menuId).name=name.value.trim();return p;});dialog.close();})));if(!isNew){const menus=make('select');menus.setAttribute('aria-label','Choose shortcut menu');for(const m of project.favourites.menus){const o=make('option','',m.name);o.value=m.id;menus.append(o);}menus.value=project.favourites.activeId;menus.onchange=()=>safe(()=>{change(p=>{p.favourites.activeId=menus.value;return p;});dialog.close();});body.prepend(field('Choose shortcut menu',menus));body.append(button('New menu',()=>openMenu(true)));}if(!dialog.open)dialog.showModal();});}
 const share=button('Import / export',sharing);share.className='favourites-sharing';screen.append(share);
 dialog.addEventListener('close',()=>{if(!disposed)safe(()=>{read();draw();});});draw();return {resize(){},dispose(){disposed=true;window.removeEventListener('resize',resizePicker);turnAnimation?.cancel();dialog.remove();}};
}
