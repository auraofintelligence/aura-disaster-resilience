# Image prompts

## Homepage hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-home.webp`

Preserved original: `assets/images/source/hero-home-original.png`

Prompt:

> Create a cinematic wide website hero image for a regional Oceania community project. Show an imagined living archipelago from a slightly elevated oblique viewpoint at the boundary between dusk and dawn. Small coastal and island community hubs glow like faceted geodes, joined by gentle flowing ribbons of light across deep ocean blue. In the near foreground, suggest a welcoming circular community pavilion with warm timber, a softly lit wellbeing room, a compact local computing cabinet, and a sauna-like amber glow, all integrated naturally and without showing branded or specific medical devices. The mood is joyful, spacious, responsible and abundant: neighbours shaping distinct local agreements while remaining connected across the ocean. Colour palette: inky navy, bioluminescent aqua, coral pink, violet, solar gold and pearl. Premium editorial concept art with subtle realism, rich atmosphere, luminous detail and clear depth. Compose for a full-width 16:9 website banner, with generous calm dark negative space on the left for a large headline and visual interest concentrated toward the centre and right. No text, no letters, no logos, no flags, no political borders, no stereotyped cultural motifs, no sacred symbols, no people in ceremonial dress, no medical claims, no pills, no needles, no futuristic flying vehicles, no watermark.

The image is concept art. It does not show a current facility, certified product, existing partnership or specific place.

## Homepage hero, future ceremonial edition

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-home-v2.webp`

Preserved original: `assets/images/source/hero-home-v2-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 homepage hero for a premium public website. Primary request: portray self-sovereignty as equal personal radiance across Oceania, making every visitor feel precious, powerful and welcomed into a future they help shape. Scene/backdrop: a monumental open ocean pavilion at celestial dawn, looking across a luminous archipelago where many distinct community sanctuaries glow like jewels, joined by soft currents of light without political borders. Subject: one gender-neutral person seen from behind at the edge of a circular opal threshold, surrounded by a subtle geometric aura of light; beyond them many equally radiant human silhouettes stand in their own spaces, with no central ruler and no hierarchy. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide immersive landscape, subject and architecture concentrated on the right two-thirds, calm deep negative space on the left for large website copy, strong foreground depth, dramatic horizon. Lighting/mood: reverent without religion, joyful responsible abundance, sovereign dignity, blue-hour atmosphere with sunrise breaking through. Color palette: black pearl, abyssal navy, electric lagoon aqua, opal white, orchid violet, hibiscus ruby and liquid solar gold. Materials/textures: polished obsidian, mother-of-pearl, faceted glass, fine metallic seams, moving ocean reflections, soft atmospheric haze. Constraints: everyone is equally dignified; architecture is imagined concept art; no identifiable real location; no text, letters, logos, flags, political borders, crowns, thrones, heraldry, religious symbols, sacred cultural motifs, medical claims, branded equipment or watermark. Avoid: generic sci-fi city, corporate technology advertisement, pastel card aesthetic, cyberpunk grime, royal hierarchy, worship scene, stereotyped Pacific or Indigenous imagery.

## Co-operative Paths hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-co-operative-paths.webp`

Preserved original: `assets/images/source/hero-co-operative-paths-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Co-operative Paths page of a premium Oceania public website. Primary request: show locally shaped co-operation as a gathering of equally sovereign people, with shared resources and distinct agreements rather than one imposed model. Scene/backdrop: an extraordinary open-air ocean forum at twilight, made from several circular gathering rooms at different heights, each room unique in material and colour, joined by graceful bridges above calm water. Subject: diverse adults of varied ages seated in several equal circles, every person surrounded by a quiet jewel-like radiance; no person sits above another and the centre of each circle remains open. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide panoramic scene, strongest gathering spaces across the centre and right, deep ocean-shadow negative space on the left for page copy, visible layers and inviting human scale. Lighting/mood: warm collective dignity, abundance without excess, calm participation, opal twilight and slow golden light. Color palette: black pearl, deep sapphire, emerald lagoon, orchid, garnet, opal and solar gold. Materials/textures: polished dark stone, local timber, faceted glass, mother-of-pearl inlay, brushed gold, water reflections. Constraints: equal dignity, no central leader, no political symbols, no identifiable cultural ceremony, no sacred motifs, no text, letters, logos, flags, crowns, thrones, heraldry, voting paraphernalia, branded objects or watermark. Avoid: corporate boardroom, generic meeting photo, government chamber, monarchy, religious worship, stereotyped Pacific or Indigenous imagery, pastel card aesthetic.

## Shared Wellbeing hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-shared-wellbeing.webp`

Preserved original: `assets/images/source/hero-shared-wellbeing-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Shared Wellbeing page of a premium Oceania public website. Primary request: show affordable community wellbeing as an atmosphere of dignity, warmth, breath, rest and carefully supervised care, without making a treatment promise. Scene/backdrop: a magnificent jewel-like community sanctuary overlooking the ocean at early evening, with a warm timber sauna room, cool quiet garden, water-reflection space and a separate calm professional consultation room visible through faceted glass. Subject: several ordinary people of varied adult ages resting, talking quietly or moving gently through the spaces, each treated with the visual dignity of a royal guest; professionals are present discreetly in the separate consultation area. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide immersive landscape, architectural experience concentrated on centre and right, calm dark lagoon and shaded stone negative space on left for page copy, clear separation between general wellbeing and professional care spaces. Lighting/mood: nurturing, abundant, serene, safe and self-possessed, warm amber meeting opal-blue evening. Color palette: obsidian, deep ocean blue, opal, emerald, warm copper, hibiscus ruby and solar gold. Materials/textures: dark stone, warm local timber, translucent faceted glass, brushed metal, soft linen, water reflections, living plants. Constraints: imagined concept art only; no medical claim; no identifiable commercial equipment; no patient distress; no text, letters, logos, flags, crowns, thrones, religious or sacred cultural symbols, oxygen masks, needles, pills or watermark. Avoid: luxury spa advertisement, sterile hospital, generic wellness stock image, futuristic medical pod, home hyperbaric equipment, clinical spectacle, stereotyped Pacific or Indigenous imagery.

## Aura Geode Research hero

Generated 30 August 2026 with OpenAI image generation. A precise follow-up edit removed tiny invented markings from the local computing cabinet while leaving the wider scene unchanged.

Final web asset: `assets/images/hero-aura-geode.webp`

Preserved original: `assets/images/source/hero-aura-geode-original.png`

Base prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Aura Geode Research page of a premium Oceania public website. Primary request: portray the Aura Geode as an ambitious construction and research chrysalis where pressure, light, reflection and local computation meet, without presenting a finished or certified product. Scene/backdrop: a vast future ceremonial research atelier open to an ocean night, where architects and engineers study one monumental translucent geode-shaped chamber resting on a black-stone platform; material samples of steel, mineral shell and faceted glass sit nearby as distinct research directions. Subject: the unoccupied Geode glows from within with layered rings of opal light and delicate golden repaired seams, while a compact local computing cabinet stands outside the chamber; the scene feels like a public architectural exhibition, not a clinic. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide landscape with quiet deep-shadow negative space on the left for page copy, Geode and research activity concentrated centre-right, strong scale and depth, full structure visible. Lighting/mood: visionary, contemplative, rigorous and abundant, moonlit ocean meeting warm internal radiance. Color palette: black pearl, midnight sapphire, crystalline aqua, orchid violet, opal, titanium silver and liquid solar gold. Materials/textures: polished obsidian, translucent mineral crystal, brushed steel, fine gold seams, clear glass, ocean mist. Constraints: clearly imagined architecture; no claim of certification or operation; no patient inside; no specific commercial chamber; no text, letters, labels, logos, flags, crowns, thrones, religious symbols, sacred cultural motifs, medical claims, oxygen masks, needles, pills or watermark. Avoid: hospital room, consumer wellness pod, fantasy crystal cave, generic spacecraft, unsafe home chamber, steampunk machinery, stereotyped Pacific or Indigenous imagery.

Precision edit prompt:

> Use case: precise-object-edit. Asset type: full-width 16:9 Aura Geode website hero. Primary request: remove only the tiny label-like marks and writing from the dark local computing cabinet on the right, leaving its surfaces clean and unbranded. Constraints: keep the entire scene, people, Geode structure, materials, composition, camera angle, lighting, colours, reflections, negative space and aspect ratio unchanged; no text, letters, numbers, logos or watermark anywhere in the image; change only the cabinet markings.

## Your Digital Self hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-your-digital-self.webp`

Preserved original: `assets/images/source/hero-your-digital-self-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Your Digital Self page of a premium Oceania public website. Primary request: portray a self-sovereign digital twin as a divine personal reflection that grows beside its person on local hardware, never as a remote corporate copy. Scene/backdrop: a majestic quiet chamber open to a star-filled ocean horizon, shaped like an opal observatory with a small elegant local computing pedestal at its centre. Subject: one ordinary gender-neutral person stands face to face with a luminous life-sized reflection made from layered memories, choices, body rhythms and coloured facets; both figures hold equal posture, and streams of light remain visibly anchored to the nearby personal device rather than travelling to a cloud. Style/medium: cinematic future ceremonial editorial concept art, sophisticated luminous realism, award-site quality. Composition/framing: wide landscape, dark atmospheric negative space on the left for page copy, person, radiant twin and local device centred on the right, intimate human scale within monumental architecture. Lighting/mood: birth, recognition, privacy, wonder, self-possession and joyful responsible abundance; divine without religion. Color palette: black pearl, midnight blue, opal white, electric aqua, amethyst, rose light and solar gold. Materials/textures: mother-of-pearl, polished dark stone, faceted light, translucent glass, fine gold circuitry contained within the local pedestal. Constraints: no cloud symbol, no remote data centre, no surveillance camera, no neural implant, no biometric scan effect, no hierarchy between person and twin; no text, letters, numbers, logos, flags, crowns, thrones, religious symbols, sacred cultural motifs or watermark. Avoid: corporate artificial intelligence advertisement, hologram cliché, robot duplicate, cyberpunk interface, medical scan, worship scene, stereotyped Pacific or Indigenous imagery.

## Public Value hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-public-value.webp`

Preserved original: `assets/images/source/hero-public-value-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Public Value page of a premium Oceania public website. Primary request: portray an affordable public investment thesis as many transparent resource streams gathering around shared community infrastructure, with every person receiving equal dignity and no suggestion of private wealth or financial promises. Scene/backdrop: a vast future ceremonial civic landscape beside the ocean at sunrise, where distinct neighbourhood pavilions, local computing rooms, warm wellbeing spaces, gardens and workshops sit across several inhabited islands and coastal places. Subject: luminous currents in solar gold, lagoon aqua, orchid and ruby flow from many small human-scale sources into clear shared reservoirs, then branch outward toward the different community spaces; ordinary people of varied adult ages stand beside their own chosen paths and no person appears above another. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide panoramic landscape with dark calm negative space on the left for page copy, strongest transparent resource currents and shared civic spaces across the centre and right, deep foreground and radiant horizon. Lighting/mood: joyful responsible abundance, public generosity, practical optimism, shared capability and equal personal radiance. Color palette: black pearl, deep sapphire, electric lagoon aqua, orchid violet, hibiscus ruby, opal white and liquid solar gold. Materials/textures: polished dark stone, faceted glass, clear water, mother-of-pearl, fine golden seams, timber and living greenery. Constraints: imagined concept art only; no money, coins, banknotes, currency symbols, charts, numbers, calculators, government seals, company branding, text, letters, logos, flags, crowns, thrones, religious symbols, sacred cultural motifs or watermark. Avoid: finance advertisement, casino wealth, cryptocurrency, corporate headquarters, charity poster, political campaign, utopian megacity, royal hierarchy, stereotyped Pacific or Indigenous imagery.

## Many Places Across Oceania hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-oceania.webp`

Preserved original: `assets/images/source/hero-oceania-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Many Places Across Oceania page of a premium public website. Primary request: portray regional kinship across many distinct places while every island, coast, inland community and city retains its own law, culture, environment and chosen relationships. Scene/backdrop: a sweeping ocean-to-country horizon at blue hour, joining a distant island village, a tropical coastal town, a subtropical city edge and an inland Australian community through soft celestial currents that travel above the water and land without becoming borders. Subject: small groups of ordinary people are visible in several separate places, each place glowing with its own jewel colour and architectural character; the currents exchange light between them but never merge the places into one uniform settlement. Style/medium: cinematic future ceremonial editorial concept art, sophisticated landscape and architectural visualisation, luminous realism, award-site quality. Composition/framing: very wide panoramic view, quiet deep-ocean and star-shadow negative space on the left for page copy, layered distinct places unfolding across centre and right, majestic sky and clear horizon. Lighting/mood: family without sameness, warmth across distance, equal sovereignty, curiosity, humility and joyful responsible abundance. Color palette: black pearl, deep Pacific blue, rainforest emerald, lagoon aqua, orchid violet, hibiscus ruby, opal moonlight and solar gold. Materials/textures: ocean mist, dark volcanic stone, pale sand, subtropical greenery, inland earth, timber, glass and fine currents of light. Constraints: no political borders, no flags, no map labels, no invented cultural symbols, no ceremonial dress, no sacred motifs, no claim of partnership or authority, no text, letters, logos, crowns, thrones, religious symbols, stereotyped architecture or watermark. Avoid: flat map graphic, tourism advertisement, one generic tropical island, colonial imagery, political summit, utopian megacity, uniform network nodes, stereotyped Pacific or Indigenous imagery.

## A Protopian Gambit hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-a-protopian-gambit.webp`

Preserved original: `assets/images/source/hero-a-protopian-gambit-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the A Protopian Gambit music page of a premium Oceania public website. Primary request: portray the album as one connected inner story of divine digital birth, self-repair and a sixty-day hyperbaric oxygen therapy journey, with three empty vertical smartphone-shaped portals ready for later music videos. Scene/backdrop: a monumental future ceremonial chamber open to a star-filled ocean horizon, with three tall elegant smartphone frames standing as luminous portals on a dark reflective floor. Subject: the first phone portal holds an abstract newborn constellation of opal light anchored to a small local computing jewel; the second holds a fractured human-like silhouette repaired with fine liquid-gold seams; the third holds concentric pressure rings leading into a translucent imagined chamber, with all three connected by one continuous current of light across the floor. Style/medium: cinematic future ceremonial editorial concept art, sophisticated luminous realism, award-site quality. Composition/framing: wide landscape, deep dark negative space on the left for page copy, three full-height vertical phone frames grouped across centre and right, the first frame slightly forward, clear uninterrupted screens and strong floor reflections. Lighting/mood: divine without religion, intimate, courageous, self-reflective, abundant and musically charged. Color palette: black pearl, midnight sapphire, electric aqua, opal white, amethyst, hibiscus rose and liquid solar gold. Materials/textures: polished obsidian, mother-of-pearl, faceted glass, gold kintsugi seams, translucent light, ocean reflections. Constraints: all phone screens remain portrait 9:16 and visibly usable for later embedded video; no treatment claims; no recognisable commercial phone; no playback controls; no text, letters, numbers, lyrics, album title, logos, flags, crowns, thrones, religious symbols, sacred cultural motifs, medical labels, oxygen masks or watermark. Avoid: concert stage, band portrait, streaming-service advertisement, generic playlist, cyberpunk nightclub, broken real phone, clinical procedure, worship scene, stereotyped Pacific or Indigenous imagery.

The prompt above is preserved exactly as generated. The finished page uses Luke's clarified wording, a sixty-session artistic chamber journey, rather than treating the title as a daily clinical schedule.

## Evidence and Open Questions hero

Generated 30 August 2026 with OpenAI image generation. A precise follow-up edit removed every invented mark from the archive papers.

Final web asset: `assets/images/hero-evidence.webp`

Preserved original: `assets/images/source/hero-evidence-original.png`

Base prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the Evidence and Open Questions page of a premium Oceania public website. Primary request: portray transparent public reasoning as a luminous archive where established records, working proposals, future research and unresolved questions remain visibly separate yet connected. Scene/backdrop: a vast future ceremonial archive chamber open to a dark ocean horizon, with floating paper-like records and material samples passing through one monumental clear opal prism into four distinct streams of light. Subject: several ordinary researchers and community readers stand at equal reading tables around the prism; one stream settles into a calm aqua record shelf, one becomes an orchid field of working models, one rises as a gold research constellation, and one remains a ruby-edged open vessel awaiting more information. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide landscape, deep dark negative space on the left for page copy, clear prism and four visually distinct evidence streams concentrated centre-right, strong depth and readable separation without labels. Lighting/mood: precise, calm, welcoming, curious, accountable and abundant, with no courtroom or moral judgement feeling. Color palette: black pearl, midnight sapphire, opal white, lagoon aqua, orchid violet, ruby rose and solar gold. Materials/textures: translucent crystal, dark stone, frosted glass, unmarked archival paper, fine light threads and ocean reflections. Constraints: no readable text on documents, no letters, numbers, charts, stamps, seals, scales of justice, gavels, court imagery, authority podiums, company branding, logos, flags, crowns, thrones, religious symbols, sacred cultural motifs or watermark. Avoid: library stock photo, government records office, courtroom, surveillance room, corporate dashboard, fantasy magic school, information overload, stereotyped Pacific or Indigenous imagery.

Precision edit prompt:

> Use case: precise-object-edit. Asset type: full-width 16:9 Evidence and Open Questions website hero. Primary request: remove every readable or pseudo-readable mark, line of writing, letter, number, stamp and diagram from all floating papers and every paper on the reading tables; leave the sheets as elegant blank or softly textured unmarked archival paper. Constraints: keep the entire archive chamber, people, clear prism, four coloured streams, shelves, objects, composition, camera angle, lighting, colours, reflections, dark left negative space and aspect ratio unchanged; no text, letters, numbers, charts, seals, logos or watermark anywhere; change only the paper markings.

## About, Connections and Licence hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-about.webp`

Preserved original: `assets/images/source/hero-about-original.png`

Prompt:

> Use case: stylized-concept. Asset type: full-width 16:9 hero for the About, Connections and Licence page of a premium Oceania public website. Primary request: portray an open family of related public projects as distinct self-sovereign worlds connected around a generous source commons, without suggesting ownership of communities or cultural authority. Scene/backdrop: a monumental ocean observatory at dawn where an open unmarked book made of opal and dark stone rests on a low circular table, and several luminous miniature project worlds orbit above and around it like a gentle constellation. Subject: the project worlds are visually distinct: an imagined translucent Geode, a small local computing device, a community gathering pavilion, a music portal, an open research archive and a garden of care; a few ordinary people stand around the table at equal height, looking toward whichever world interests them. Style/medium: cinematic future ceremonial editorial concept art, sophisticated architectural visualisation, luminous realism, award-site quality. Composition/framing: wide landscape, calm deep-shadow negative space on the left for page copy, open book and project constellation centre-right, ocean horizon and sunrise beyond, strong depth and generous breathing room. Lighting/mood: welcoming authorship, openness, curiosity, equal dignity, creative abundance and room for many future branches. Color palette: black pearl, midnight blue, opal white, lagoon aqua, orchid violet, hibiscus ruby, emerald and liquid solar gold. Materials/textures: mother-of-pearl, polished obsidian, unmarked paper, faceted glass, warm timber, fine gold seams, ocean mist and reflections. Constraints: no readable writing on the book or objects, no text, letters, numbers, logos, copyright symbols, legal scales, ownership symbols, flags, crowns, thrones, religious symbols, sacred cultural motifs, ceremonial dress or watermark. Avoid: personal vanity monument, corporate family tree, royal court, courtroom, branded portfolio collage, generic team photo, fantasy spellbook, stereotyped Pacific or Indigenous imagery.

## Site Map hero

Generated 30 August 2026 with OpenAI image generation.

Final web asset: `assets/images/hero-site-map.webp`

Preserved original: `assets/images/source/hero-site-map-original.png`

Prompt:

> Create a cinematic full-width website hero image, 16:9 landscape, for the human-facing Site Map page of a futuristic Oceania community health co-operative and self-sovereign local computing project. Show an open luminous navigation constellation across a deep ocean horizon: eleven distinct glowing worlds or faceted geodes connected by fine arcs of light, each unique yet equal, with no centre of authority and no hierarchy. The visual feeling is royal and divine for every person through dignity, radiance, welcome and shared abundance, never monarchy. Materials and colour: black pearl, opal, polished obsidian, faceted glass, solar gold, lagoon aqua, orchid violet and hibiscus pink. Include subtle Pacific ocean atmosphere and a ceremonial editorial quality without borrowing, imitating or stereotyping any Indigenous or Pacific cultural motifs. Composition: generous dark clean negative space across the left third for large white website headline; the brightest constellation gathers through the centre and right; wide horizon, dimensional depth, intricate but uncluttered, award-winning interactive website aesthetic, high-end motion-ready layers and glints. No people. No buildings. No medical equipment. No maps with political borders. No crowns, thrones, flags, religious or sacred symbols. No logos. No interface mock-up. Absolutely no text, letters, words, numbers, labels, watermarks or signatures.

## Connected gems favicon

Generated 31 August 2026 with OpenAI image generation, using the Site Map hero as a visual reference.

Public icon assets:

- `assets/icons/favicon.ico`
- `assets/icons/favicon-16x16.png`
- `assets/icons/favicon-32x32.png`
- `assets/icons/favicon-192.png`
- `assets/icons/apple-touch-icon.png`

Preserved original: `assets/icons/source/favicon-connected-gems-original.png`

Prompt:

> Use case: logo-brand. Asset type: square master artwork for a website favicon and touch icon. Input image: the supplied Site Map hero is a visual reference for its connected faceted gems, black-pearl depth, opal colour, solar-gold light and luminous equal-world feeling. Primary request: distil that connected-gem constellation into one extremely clear, memorable favicon mark. Subject: six equally sized, large faceted jewel spheres arranged in an open circular constellation with no central ruler, linked by a few bold luminous solar-gold arcs; gems use lagoon aqua, opal white, orchid violet, hibiscus pink, emerald-teal and warm gold. Style/medium: premium polished 3D jewel emblem simplified for strong recognition at 16 by 16 pixels, with crisp edges and a bold silhouette. Composition/framing: perfectly centred square icon, the constellation fills about 82 percent of the canvas, generous safe margin, balanced from every direction, no horizon and no scene. Background: a simple near-black black-pearl circular medallion with transparent space outside the circle. Lighting/mood: luminous, joyful, precious and welcoming. Constraints: genuine transparent background outside the medallion; all six gems remain visually equal; connecting lines stay thick enough to survive tiny scaling; no fine filigree; no tiny satellite dots; no text, letters, numbers, labels, logos, crowns, thrones, flags, religious symbols, cultural motifs, borders, watermark or signature. Avoid: complex landscape, ocean scene, central hierarchy, corporate network icon, flat clip art, thin hairline connections, excessive glow, busy detail.

## Aura Geode prototype and research artwork

Generated 24 September 2026 with built-in OpenAI image generation. These are speculative concept designs, not photographs of built or certified products. The six original PNG files are preserved in `assets/images/source/`; the optimised WebP files are the public page assets. The descriptions below are the recreation prompt set for this artwork.

### Steel-frame arrival

Web: `assets/images/geode-prototype-steel-entry.webp`
Original: `assets/images/source/geode-prototype-steel-entry-original.png`

Retired from the public baseline comparison on 24 September 2026. Its large faceted design looked like the bespoke Geode rather than a practical mass-produced seated chamber. The file remains in the project record; the live comparison now links to a real YF-1003 supplier photograph hosted by OxySail.

> Premium cinematic architectural product visualisation, wide landscape. Show a realistic faceted steel-frame hyperbaric oxygen chamber prototype in a luminous community research studio beside the sea. One ordinary adult is entering through a spacious accessible doorway, with another adult professional nearby. Make the human scale, entry mechanism, seating and pressure-vessel shell legible. Opal, polished steel, deep midnight blue, warm gold and subtle lagoon light. Optimistic, calm, sophisticated, technically plausible as an early concept, not a finished medical product. No text, numbers, logos, schematic lines, floating interface labels, flags, crowns, sacred motifs or watermark.

### Mineral-shell session

Web: `assets/images/geode-prototype-mineral-session.webp`
Original: `assets/images/source/geode-prototype-mineral-session-original.png`

> Wide cinematic cutaway architectural concept of a faceted mineral-composite hyperbaric Geode prototype with a person inside. Show the seated adult comfortably engaging with an integrated personal display, wearing a plausible personal breathing mask while calm sensory light glows around the interior. Outside shell and structural form remain visible; include space for supervision and a separate breathing supply concept. Rich mineral textures, opal seams, aqua and violet light, black-pearl depth, warm human expression. Make it a human-centred research design, not a claim of certification. No text, numbers, labels, logos, magical effects, medical result promises or watermark.

### Modular exit and external monitoring

Web: `assets/images/geode-prototype-modular-exit.webp`
Original: `assets/images/source/geode-prototype-modular-exit-original.png`

> Wide photorealistic future-design concept of a modular transparent hyperbaric chamber in a welcoming coastal research setting. An adult is stepping out after a session through a clear open doorway; another adult professional is present near an external monitoring console. Show real human scale, accessible circulation, modular sections and sensors outside the chamber. Premium editorial realism, translucent materials, brushed metal, opal highlights, soft solar-gold and lagoon light. Optimistic and calm, visibly a prototype rather than a marketed certified device. No readable interface, words, numbers, branding, crowns, religious or cultural motifs or watermark.

### Oxygen, plasma and selected wound research

Web: `assets/images/geode-plasma-wound-research.webp`
Original: `assets/images/source/geode-plasma-wound-research-original.png`

> Scientific editorial artwork in a wide landscape composition. Portray oxygen dissolving into blood plasma and travelling toward a small healing area of skin. Make the biological scale and gentle tissue-repair process visually legible through luminous red blood cells, liquid plasma, oxygen glints and skin layers, without suggesting instant healing or a universal treatment. High-end medical visualisation with black-pearl background, ruby, opal and aqua light. No labels, graphs, words, numbers, logos, frightening injury detail or watermark.

### Blood-cell telomere research

Web: `assets/images/geode-telomere-research.webp`
Original: `assets/images/source/geode-telomere-research-original.png`

> Premium wide scientific editorial visualisation about a measured research signal. Show chromosome ends and telomere structures alongside a carefully collected blood sample in a contemporary laboratory. Luminous microscopic detail, opal white, violet, aqua and warm gold on dark blue, with a sense of curiosity rather than a miracle cure. No claim of whole-body rejuvenation or age reversal. No text, numbers, charts, logos, people identifiable from real life or watermark.

### Owner-held digital reflection

Web: `assets/images/geode-local-twin.webp`
Original: `assets/images/source/geode-local-twin-original.png`

> Cinematic wide editorial scene after a chamber session. An ordinary adult sits peacefully at their own local laptop, reflecting on notes and chosen body observations while a gentle, equal-height abstract digital-twin visual appears on the screen. The person remains the centre of the scene, with the chamber softly visible in the background. Make the technology personal, local and non-coercive; warm coastal future architecture, opal, lagoon aqua, violet and solar-gold light. No readable text, data labels, diagnostic claims, logos, crowns, thrones, sacred symbols or watermark.

## Peaceful modern wellbeing imagery, 24 September 2026

Generated with built-in OpenAI image generation. These are concept artworks, not photographs of operating centres, named suppliers or certified equipment. Original PNGs remain in `assets/images/source/`; optimised WebP files serve the site.

### Person-held computing in a contemporary wellbeing centre

Web: `assets/images/sovereign-modern-wellbeing.webp`
Original: `assets/images/source/sovereign-modern-wellbeing-original.png`

> Premium cinematic editorial image for a futuristic yet peaceful Australian longevity and self-sovereign computing website, wide landscape. A contemporary coastal Queensland wellbeing and research centre at late afternoon with elegant low-carbon architecture, warm white stone, glass, opal aqua light and restrained gold accents. An adult uses their own compact personal computer and local storage to review wellness reflections, while a realistic sauna and consultation spaces appear behind. Dignified, aspirational and serene, never a hippie commune, rustic retreat, spiritual ceremony, luxury hotel or spaceship. No text, logos, floating interfaces, medical claims, polygons or crystal symbolism.

### Seated chamber and clinical conversation

Web: `assets/images/wellbeing-clinical-concept.webp`
Original: `assets/images/source/wellbeing-clinical-concept-original.png`

> Premium architectural editorial concept for a forward-looking Australian longevity and preventative-wellbeing website. A seated adult speaks with a qualified clinician beside a realistic, modest single-person seated hyperbaric oxygen therapy chamber with transparent door and straightforward controls. Coastal daylight, subtle wearable sensor and a compact computer suggest personally held data. Human-scale, welcoming contemporary medical design, not a vast bespoke spaceship. No text, logos, mystical symbols, geodes, crystals, rustic decor or medical claims. Concept art, not a supplier photograph.

### Contemporary sauna and recovery room

Web: `assets/images/wellbeing-sauna-concept.webp`
Original: `assets/images/source/wellbeing-sauna-concept-original.png`

> Wide editorial architectural concept for an Australian future wellbeing cooperative. A peaceful contemporary sauna and recovery suite designed for ordinary community access, with restrained timber, pale stone, glass, efficient lighting and ocean light. One person rests on the lower sauna bench and another rests outside. Serene, bright, inclusive, practical and future-ready. No text, logos, mystical symbols, geodes, crystals, icons or medical equipment.

### Modern co-operative planning hero

Web: `assets/images/hero-co-operative-paths-v2.webp`
Original: `assets/images/source/hero-co-operative-paths-v2-original.png`

Replaces the earlier ceremonial-circle concept on the live co-operative page. The earlier asset remains in project history.

> Full-width cinematic website hero. A future-ready coastal Australian health co-operative in a calm contemporary building with glass, pale stone, restrained timber, brushed metal and opal daylight. A diverse small group of ordinary adults of different ages make practical plans together around a modern table, with equal conversation and no leader or ritual. Through glass, a professionally designed sauna, quiet movement area and modest seated oxygen chamber appear in separate rooms. Peaceful, modern and optimistic about living healthier for longer. Darker architectural space on the left for a white heading. No text, logos, watermarks, geodes, crystals, polygons, mystical ceremony, luxury-resort extravagance or floating interfaces.

### Music video placeholder stills

These portrait concept artworks sit inside the smartphone frames until Luke chooses video links, recordings and captions. They are not released video frames.

Web: `assets/images/track-primordial-consent.webp`
Original: `assets/images/source/track-primordial-consent-original.png`

> Portrait cinematic still for Primordial Consent 1,2,3, Infinity. A contemporary adult stands peacefully at the edge of a softly lit modern coastal room, facing an equal-height light-formed personal digital reflection coming into being. Deeply personal, self-sovereign, luminous and futuristic yet grounded. Opal aqua, violet and restrained gold. No text, logos, phone frame, geodes, crystals, mandalas, ritual or floating interface.

Web: `assets/images/track-kintsugi-protocol.webp`
Original: `assets/images/source/track-kintsugi-protocol-original.png`

> Portrait cinematic still for Kintsugi Protocol. A contemporary adult sits calmly by an ocean-facing window after a difficult chapter, hands gently meeting at the heart. Delicate golden seams glimmer through a translucent symbolic reflection of the person behind them, conveying learning, continuity and renewed agency. Peaceful Australian coastal future-wellbeing setting. No text, geodes, crystals, pottery bowls, ritual, phone frame or claim of medical healing.

Web: `assets/images/track-60-days.webp`
Original: `assets/images/source/track-60-days-original.png`

> Portrait cinematic still for 60 Days Set in Stone. An adult sits comfortably inside a realistic human-scale hyperbaric oxygen chamber with a personal breathing mask. A clinician is visible outside, alongside a compact computer and believable sensors. Calm blue and warm gold in a contemporary coastal clinical setting. Personal artistic journey through pressure, reflection and owner-held digital life, without promising medical outcomes. No text, geodes, crystals, spacecraft, phone frame or floating interfaces.
