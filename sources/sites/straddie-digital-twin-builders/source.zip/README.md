# Straddie Digital Twin Builders

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 27 May 2026.
- GitHub repository: [straddie-digital-twin-builders](https://github.com/auraofintelligence/straddie-digital-twin-builders).
- Public site: [visit the public site](https://auraofintelligence.github.io/straddie-digital-twin-builders/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 10 relevant public connections.

### Aura Systems Image Atlas source projects

- [aura-systems-image-atlas](https://github.com/auraofintelligence/aura-systems-image-atlas) - [public page](https://auraofintelligence.github.io/aura-systems-image-atlas/) - source project represented in this visual atlas.

### Capsule, habitat and resilience simulation

- [Minjerribah-Resilience](https://github.com/auraofintelligence/Minjerribah-Resilience) - [public page](https://auraofintelligence.github.io/Minjerribah-Resilience/) - shared technical architecture.
- [SSB](https://github.com/auraofintelligence/SSB) - [public page](https://auraofintelligence.github.io/SSB/) - explicit cross-reference, shared technical architecture.
- [straddie-capsule-surge-lab](https://github.com/auraofintelligence/straddie-capsule-surge-lab) - [public page](https://auraofintelligence.github.io/straddie-capsule-surge-lab/) - explicit cross-reference, shared technical architecture.
- [straddie-disaster-kiosks](https://github.com/auraofintelligence/straddie-disaster-kiosks) - [public page](https://auraofintelligence.github.io/straddie-disaster-kiosks/) - shared technical architecture.
- [straddie-space-station-simulator](https://github.com/auraofintelligence/straddie-space-station-simulator) - [public page](https://auraofintelligence.github.io/straddie-space-station-simulator/) - explicit cross-reference, shared technical architecture.
- [straddie-vitality-network-builders](https://github.com/auraofintelligence/straddie-vitality-network-builders) - [public page](https://auraofintelligence.github.io/straddie-vitality-network-builders/) - shared technical architecture.

### Minjerribah digital-twin builds and explainers

- [minjerribah-living-twin](https://github.com/auraofintelligence/minjerribah-living-twin) - [public page](https://auraofintelligence.github.io/minjerribah-living-twin/) - explicit cross-reference, shared named build family.
- [second-island](https://github.com/auraofintelligence/second-island) - [public page](https://auraofintelligence.github.io/second-island/) - explicit cross-reference, shared named build family.
- [straddie-digital-twin-explainer](https://github.com/auraofintelligence/straddie-digital-twin-explainer) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-explainer/) - explicit cross-reference, shared named build family.

<!-- github-organisation:end -->

A Strange But True family static site for plain-English Markdown (`.md`) prompt-builder questionnaires that prepare accurate customisable scene prompts for external image generators, video models, three-dimensional (3D) and four-dimensional (4D) world builders and simulation tools, from Level 0 (L0) private spaces through Level 1 (L1) places to Level 2 (L2) bioregion prompts.

Public site target:

- https://auraofintelligence.github.io/straddie-digital-twin-builders/

Source repo target:

- https://github.com/auraofintelligence/straddie-digital-twin-builders

## Pages

- `index.html` - gateway
- `architecture.html` - Level 0 (L0), Level 1 (L1), Level 2 (L2) prompt architecture
- `l0.html` - private space prompts
- `l1.html` - place mesh and venue world prompts
- `dunwich-ferry-terminal.html` - Dunwich (Gumpi/Goompi) ferry terminal upgrade capture-to-prompt page
- `l2.html` - bioregion-scale prompt briefs using Moreton Bay, islands and watershed context
- `builders.html` - working Markdown prompt questionnaire
- `network.html` - related Strange But True family sites
- `boundaries.html` - self-sovereign sharing controls
- `sources.html` - source trail

## Sovereignty

This site turns plain choices into Markdown (`.md`) prompt files for outside visual and world-building tools. It helps people say what scene they want, what can be customised, what should stay local and what needs a source label.

## Related projects

- [Scan to Twin plain-English explainer](https://auraofintelligence.github.io/straddie-digital-twin-explainer/)
- [Second Island instrument-first twin](https://auraofintelligence.github.io/second-island/)
- [Minjerribah Living Twin reference build](https://auraofintelligence.github.io/minjerribah-living-twin/)
