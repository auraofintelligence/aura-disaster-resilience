# GAJRA Earth Build Log

## Build 0 - Reconnaissance - 27 July 2026

- Selected `GAJRA-earth-infinity` as a separate build repository so the established `GAJRA-earth` repository remains intact.
- Mapped the connected public projects, local-first builders and source trails.
- Separated visible facts, open questions and proposed work.

## Build 1 - The public spine - 27 July 2026

- Created a multi-page replacement while leaving `gajra.earth` unchanged during review.
- Kept the established `GAJRA-earth` repository separate.
- Added grouped desktop and mobile navigation, a sitemap, a reality layer and this public build log.
- Added the persistent 0-100 Motion Vibrancy control as a site-wide system.
- Kept the Strange But True Public Source Licence with all commercial rights reserved.
- Published early so later visual, interactive and research work will have a visible history.
- Published from a dedicated repository before moving the `gajra.earth` domain.

## Build 2 - Earth in view - 27 July 2026

- Added NASA SVS 31375 aurora footage and a locally optimised poster with direct source credit and no endorsement claim.
- Added original flower-force artwork made for the project, plus a 178 KB web delivery version.
- Connected video playback to Motion Vibrancy: motion 0 pauses it, while a visitor's own pause remains respected.
- Added source-specific captions that distinguish observed Earth imagery, symbolic artwork and future simulations.
- Removed the synthetic vector-like Earth treatment; real Earth now appears only through credited raster imagery.
- Restored the original Aura heart logo and browser icons from the supplied GAJRA build.
- Made the section seams span the full viewport and made the ticker loop without an empty interval.
- Reframed the site around new and seasoned explorers mapping infinity.
- Added a unique full-width hero image to every room.
- Added a punctuation check that rejects em dashes.
- Clarified the home diagram as our Sol system with Sol, eight named planets and a real NASA raster for Earth.
- Gave ticker words wider spacing and RGB accents, with slower counter-moving colour rails.
- Replaced the moving seam slug with colour flowing through the full kintsugi line.
- Added motion-aware pointer light and centre-balanced card tilt for mouse and touch, following the Right Place Right Time interaction.
- Removed permanent media credit panels. Full-width imagery now carries reusable hover, focus and tap acknowledgements behind small information icons.
- Moved the Earth aurora film directly below the ticker, removed the linear planet key and slightly quickened the labelled Sol model.
- Left `gajra.earth` unchanged while this dedicated Pages site remains the public build preview.

## Build 3 - The local Alignment Lab - 27 July 2026

- Turned the Alignment Lab spine into a working browser-local instrument.
- Connected four revisable parts: a JRA map, preference comparison, lived experiment and source card.
- Kept local saving explicit. Unsaved words stay only in the open tab, and saved words remain in that browser.
- Added readable Markdown, structured JSON and single-record JSONL downloads.
- Labelled downloads as personal records or raw contribution material, not automatically valid training datasets.
- Added keyboard-operable instrument tabs, visible focus, mobile layouts and a completion trace.
- Added an automated privacy guard that rejects network transmission APIs in the Lab script.
- Replaced the darker home film with NASA SVS 31281, a brighter Aurora Australis sequence that ends with Australia and Perth in view.
- Lifted the base reading size, card headings, labels and supporting text across the site.
- Added clearer screen-reader descriptions for the Sol model, media, local-save state and download controls.
- Strengthened heading and landmark structure so the site reads in a meaningful order without its visual layout.
- Reworked the header and footer at laptop widths so the full organisation name, navigation and page links no longer collide.
- Changed the grouped navigation into an accordion so opening one section closes the others.
- Replaced the plain diagram on the first concept hero with a rich original raster artwork.

## Build 4 - Borderless atlas foundation - 27 July 2026

- Replaced the static Ecosystem page hero with a working satellite atlas.
- Added sphere and flat view controls with no geolocation prompt.
- Used neutral Sentinel-2 cloudless imagery rather than OpenStreetMap tiles or a political boundary layer.
- Added a no national flags map policy in the public map data.
- Published one broad build-origin record and no joined-group claims.
- Added a screen-reader-accessible public records ledger below the map.
- Added guardrail checks for unwanted map tile sources, geolocation requests and forbidden flag-related map chrome.
- Vendored MapLibre GL JS assets and licence text so the map engine is visible in source and not loaded from a live CDN.

## Build 5 - Pruned public journey - 27 July 2026

- Reduced the main public navigation to eight useful doors: Home, Meeting Space, Alignment Lab, Gather, Bridge Atlas, Frontier Labs, Culture and Build With Us.
- Preserved old room URLs as lightweight redirect trails into the nearest useful room.
- Moved the JRA definition and small commitment loop into the Meeting Space.
- Moved Data Garden, Simulations and Live Experiments into the Alignment Lab as one source-and-edge-walk workbench.
- Added starter field-kit lanes to Gather: listening stations, tech help and festival host markers.
- Moved AI-builder hedge language and technical map-layer planning into Frontier Labs.
- Moved Earth-to-Sol stewardship and source trails into Culture.
- Moved atlas joining, status, archive and build utility paths into Build With Us.

## Build 6 - Plain core and public stakes - 27 July 2026

- Stated the front-page purpose in clear language: GAJRA Earth convenes a meeting of minds about self-alignment and AI alignment within Joyful Responsible Abundance.
- Added a plain-language explanation of self-alignment and AI alignment before the more poetic site layers.
- Added a source-backed homepage section on why this matters now: money, current AI safety rooms, frontier-industry coordination, AI-for-good spaces and the missing middle.
- Framed the stakes as practical and lived: work, education, health, media, culture, trust, ecology, security, agency and ordinary days.

## Build 7 - Meeting and field-kit handles - 27 July 2026

- Reworked the Meeting Space so it begins with a browser-local meeting-circle builder instead of only a metaphor.
- Added copy, Markdown download, calendar file, email draft and WhatsApp draft actions for meeting invitations.
- Reworked Gather so it begins with a practical starter field-kit builder for listening stations, tech-help tables, public circles and festival tables.
- Added the same local handoff actions for field-kit run sheets.
- Pointed the homepage primary action and cards at the new functional anchors.
- Kept the pattern browser-first: nothing is sent by the page, and the visitor chooses any email or messaging handoff.
- Added validation checks so the meeting builder, field-kit builder, local handoff script and no-network rule remain present after future builds.

## Build 8 - What is approaching - 28 July 2026

- Added a source-led future watch inside Gather for events people may attend, influence or watch.
- Kept the watch separate from the page hero and from reports about events that have already happened.
- Added filters for participation routes, plain search and a visible count of matching opportunities.
- Added calendar downloads that preserve the organiser's live page as the place to confirm current details.
- Seeded the first watch with official ITU, AI for Good and UN sources, with the date each record was checked.
- Added a question to carry into each room so an event listing can become preparation rather than passive promotion.
- Labelled listings as invitations to inspect, not GAJRA Earth endorsements.
- Added automated checks for source links, participation routes, calendar support and accidental network transmission.
- Replaced the long underlined section links with compact action tiles that keep each label and arrow together.
- Cut the Meeting Space from six explanatory sections to one invitation builder and two useful onward paths.
- Reduced the meeting form to the details required to invite people, hold the question and name the shared trace.
- Centred editorial sections in a calmer reading column and brought section numbers back beside their headings.
- Reduced Gather to one job: build a GAJRA Field Kit.
- Removed the future-events watch, explanatory sequence and secondary cards from the Field Kit journey.
- Unified the promise, builder, preview and exports around one Field Kit instead of mixing rooms, listening stations and run sheets.

## Build 9 - One door, one useful job - 28 July 2026

- Rebuilt the public journey around eight active doors: Home, Alignment Lab,
  Meeting Circle, Field Kit, Bridge Atlas, Future Watch, Culture Compass and
  Join or Build.
- Gave every door a private page contract naming its visitor, task and useful
  outcome.
- Removed automatic essays, repeated questions, generic sequence panels and
  unrelated onward cards from the active pages.
- Rebuilt the layout around one centred frame, one editorial width and one
  reading measure, with compact heroes and content-sized cards.
- Repaired the missing prompt grid, laptop header conflicts, mobile no-script
  navigation, anchor offsets and footer flow.
- Added the browser-local Culture Compass and contribution packet with copy,
  download and explicit message handoffs.
- Made the Alignment Lab instruments optional and changed its state summary
  from a completion percentage to an answered-field count.
- Strengthened Meeting Circle and Field Kit calendar exports with validation,
  end times and blank-recipient email drafts.
- Moved Future Watch into its own useful door and retained source, date,
  participation filters and calendar export.
- Rechecked all six Future Watch records against official organiser pages,
  added direct event links and removed calendar export where only a month is known.
- Replaced the weakest procedural hero fields with original cinematic raster
  scenes for Alignment Lab, Field Kit, Future Watch and Join or Build.
- Kept the home aurora immediately below the ticker and kept the functional
  Bridge Atlas separate from its Earth-view hero.

## Next builds

- Build 10: useful map layers for festivals, working groups, labs, data centres,
  grant labs, tender labs and starter field kits.
- Build 11: expand the static review workflow from local contribution packets
  into vetted Atlas records.
