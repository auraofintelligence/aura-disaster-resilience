# GAJRA Earth

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 27 July 2026.
- GitHub repository: [GAJRA-earth-infinity](https://github.com/auraofintelligence/GAJRA-earth-infinity).
- Public site: [visit the public site](https://auraofintelligence.github.io/GAJRA-earth-infinity/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 7 relevant public connections.

### Direct and other supported connections

- [fractal-aura](https://github.com/auraofintelligence/fractal-aura) - [public page](https://auraofintelligence.github.io/fractal-aura/) - explicit cross-reference.
- [global-group-marriages](https://github.com/auraofintelligence/global-group-marriages) - [public page](https://auraofintelligence.github.io/global-group-marriages/) - explicit cross-reference.
- [grain-by-grain-documentary](https://github.com/auraofintelligence/grain-by-grain-documentary) - [public page](https://auraofintelligence.github.io/grain-by-grain-documentary/) - explicit cross-reference.

### GAJRA Earth builds

- [GAJRA-earth](https://github.com/auraofintelligence/GAJRA-earth) - [public page](https://auraofintelligence.github.io/GAJRA-earth/) - later build; GAJRA-earth is earlier, explicit cross-reference, ordered build lineage, shared named build family.
- [gajra-earth-claude-build](https://github.com/auraofintelligence/gajra-earth-claude-build) - [public page](https://auraofintelligence.github.io/gajra-earth-claude-build/) - later build; gajra-earth-claude-build is earlier, explicit cross-reference, ordered build lineage, shared named build family.
- [gajra-earth-public-hub](https://github.com/auraofintelligence/gajra-earth-public-hub) - [public page](https://auraofintelligence.github.io/gajra-earth-public-hub/) - later build; gajra-earth-public-hub is earlier, explicit cross-reference, ordered build lineage, shared named build family.
- [GAJRA_Earth-Space-AI_Summit](https://github.com/auraofintelligence/GAJRA_Earth-Space-AI_Summit) - [public page](https://auraofintelligence.github.io/GAJRA_Earth-Space-AI_Summit/) - explicit cross-reference, shared named build family.

<!-- github-organisation:end -->

GAJRA Earth is the **Global Association for Joyful Responsible Abundance on Earth**: an evolving public concept, participatory alignment practice and local-first experimentation framework.

It is not currently a registered global association. The ICO, DAO and Live Aid 2025 plans did not launch and are retained only in the archive and reality layer.

## Live site

Staging and source-history site:

https://auraofintelligence.github.io/GAJRA-earth-infinity/

Planned public domain after DNS migration:

https://gajra.earth/

## Public build method

The site is being built in visible layers so the Git history and [public build log](BUILD_LOG.md) show how the work changes.

- Build 1: multi-page spine, grouped navigation, status boundaries and motion control.
- Build 2: cinematic media system and rights-safe visual language.
- Build 3: local-first Alignment Lab builders and exports.
- Build 4: borderless world map with satellite, flat and sphere views.
- Build 5: pruned the early 22-page spine into eight main visitor doors with old URLs preserved as redirects.
- Build 6: stated the core purpose and public stakes in plain language.
- Build 7: added working Meeting Circle and Field Kit builders.
- Build 8: added the source-led Future Watch.
- Build 9: rebuilt all eight doors around one visitor, one task and one useful outcome.

## Architecture

The site uses a small dependency-free Node generator:

- `src/site-data.mjs` contains the page map, navigation and public copy.
- `tools/build-site.mjs` renders the root HTML pages, sitemap and 404 page.
- `assets/site.css` owns the visual and responsive system.
- `assets/site.js` owns navigation and the persistent 0-100 Motion Vibrancy control.
- `assets/cosmos.js` owns the first canvas solar-system treatment.
- `assets/alignment-lab.js` owns the browser-local Alignment Lab, explicit local save and Markdown, JSON and JSONL exports.
- `assets/world-map.js` owns the borderless satellite atlas and `data/map-records.json` owns public map records.
- `assets/upcoming-watch.js` owns source-led event filtering and calendar exports.
- `assets/culture-tool.js` owns the browser-local Culture Compass.
- `assets/contribution-tool.js` owns the local contribution packet and explicit handoff choices.
- `tools/check-site.mjs` checks generated pages, local links and superseded launch language.
- `docs/RECONNAISSANCE.md` records the source decisions and public boundaries.
- `docs/ASSET_PROVENANCE.md` records media sources and rights treatment.
- `docs/VOICE_AND_TONE.md` keeps the public voice self-sovereign and explorer-facing.
- `docs/DESIGN.md` keeps visual and interaction notes out of public page copy.

Generated HTML is committed so GitHub Pages can serve the site without a server or build action.

## Build locally

```powershell
npm.cmd run build
npm.cmd run check
python -m http.server 4179
```

`npm.cmd run build:heroes` is not part of a normal release because it rebuilds
procedural art used only by utility and redirect pages.

Then open `http://localhost:4179/`.

## Privacy

The GitHub Pages phase is local-first. Personal reflections and builder drafts stay in the browser unless the visitor explicitly downloads or shares an export. No analytics or third-party tracking is added.

## Licence

[Strange But True Public Source Licence](LICENSE): personal and non-commercial use is allowed with attribution. All commercial and corporate rights are reserved to Luke Nathan Hayes.


<!-- mutual-futures-connection -->
## Mutual Futures: connected workbench

[Mutual Futures](https://auraofintelligence.github.io/mutual-futures/) connects this project with Luke Nathan Hayes's proposed mutual business succession, Try Everything Once, Intermittent Retirement, personal intelligence, legal reflection, resilience, travel and wider civilisational horizon. The connection does not merge the projects or imply outside endorsement.

[Source repository](https://github.com/auraofintelligence/mutual-futures) · [Project connections and sources](https://auraofintelligence.github.io/mutual-futures/sources.html)
