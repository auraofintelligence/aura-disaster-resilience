const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const dataCode = fs.readFileSync(path.join(root, 'data.js'), 'utf8');
const sandbox = { window: {} };
vm.runInNewContext(dataCode, sandbox);
const data = sandbox.window.NOTICEBOARD_DATA;

function slugify(value) {
  return value.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function escapeHtml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function pageHtml(entity, group, slug) {
  const description = `${entity.name} entity page for the Straddie Noticeboard Network, including public-source checklist and draft markdown files.`;
  return `<!doctype html>
<html lang="en-AU">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="${escapeHtml(description)}">
    <title>${escapeHtml(entity.name)} | Straddie Noticeboard Network</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&family=Nunito+Sans:wght@700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles.css">
  </head>
  <body data-entity="${slug}">
    <a class="skip-link" href="#main">Skip to content</a>
    <header class="site-header">
      <nav class="nav" aria-label="Main navigation">
        <a class="brand-mark" href="../index.html" aria-label="Straddie Noticeboard Network home"><span>Straddie</span><span>Noticeboard</span></a>
        <button class="nav-toggle" type="button" aria-label="Open menu" aria-expanded="false"><span></span><span></span><span></span></button>
        <div class="nav-links">
          <a href="../index.html">Home</a>
          <a href="../categories/index.html">Categories</a>
          <a href="../entities.html">Entities</a>
          <a href="../public-noticeboard-builder.html">Builder</a>
          <a href="../public-noticeboard.html">public_noticeboard.md</a>
        </div>
      </nav>
    </header>
    <main id="main">
      <section class="category-hero entity-hero">
        <nav class="breadcrumb" aria-label="Entity breadcrumb">
          <a href="../index.html">Island scope</a>
          <span>Data directory</span>
          <a data-entity-category href="../categories/${group.slug}.html">${escapeHtml(group.label)}</a>
        </nav>
        <p class="eyebrow" data-entity-eyebrow>${escapeHtml(group.label)}</p>
        <h1 data-entity-title>${escapeHtml(entity.name)}</h1>
        <p class="hero-lede" data-entity-lede>${escapeHtml(entity.share)}</p>
        <div class="hero-actions entity-actions">
          <a class="button secondary" data-entity-directory href="../entities.html">All entities</a>
          <a class="button secondary" data-entity-category href="../categories/${group.slug}.html#entity-${slug}">Category card</a>
          <a class="button secondary" href="#draft-files">Draft .md files</a>
        </div>
      </section>
      <section class="section entity-page-layout">
        <article class="source-panel" data-entity-summary></article>
        <article class="source-panel">
          <p class="eyebrow">Public-source checklist</p>
          <h2>Evidence before publishing.</h2>
          <div class="source-grid" data-entity-sources></div>
        </article>
      </section>
      <section class="section wide visual-band" id="draft-files">
        <div class="section-heading">
          <p class="eyebrow">Draft files</p>
          <h2>Notice and profile markdown.</h2>
          <p>These are drafts for conversation. Anything still marked TODO needs direct confirmation or a better public source.</p>
        </div>
        <div class="entity-md-layout">
          <article class="md-card">
            <h3>example public notice.md</h3>
            <pre><code data-notice-md></code></pre>
          </article>
          <article class="md-card">
            <h3>business_profile.md</h3>
            <pre><code data-profile-md></code></pre>
          </article>
        </div>
        <div class="entity-page-nav">
          <a class="card-link" data-prev-entity href="#">Previous entity</a>
          <a class="card-link" data-next-entity href="#">Next entity</a>
        </div>
      </section>
    </main>
    <footer class="site-footer"><div class="footer-copy"><p>Entity data page for the Straddie Noticeboard Network.</p><p class="footer-note">Public-source evidence first. Approval before publishing.</p></div></footer>
    <script src="../data.js"></script>
    <script src="../entity-page.js"></script>
    <script src="../app.js"></script>
  </body>
</html>
`;
}

const outDir = path.join(root, 'entities');
fs.mkdirSync(outDir, { recursive: true });

const seen = new Set();
for (const group of data.entityGroups) {
  for (const entity of group.entities) {
    const slug = slugify(entity.name);
    if (seen.has(slug)) throw new Error(`Duplicate entity slug: ${slug}`);
    seen.add(slug);
    fs.writeFileSync(path.join(outDir, `${slug}.html`), pageHtml(entity, group, slug));
  }
}

console.log(`Generated ${seen.size} entity pages in ${outDir}`);
