# Minjerribah Resilience

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 28 October 2025.
- GitHub repository: [Minjerribah-Resilience](https://github.com/auraofintelligence/Minjerribah-Resilience).
- Public site: [visit the public site](https://auraofintelligence.github.io/Minjerribah-Resilience/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 17 relevant public connections.

### Capsule, habitat and resilience simulation

- [SSB](https://github.com/auraofintelligence/SSB) - [public page](https://auraofintelligence.github.io/SSB/) - shared technical architecture.
- [straddie-capsule-surge-lab](https://github.com/auraofintelligence/straddie-capsule-surge-lab) - [public page](https://auraofintelligence.github.io/straddie-capsule-surge-lab/) - shared technical architecture.
- [straddie-digital-twin-builders](https://github.com/auraofintelligence/straddie-digital-twin-builders) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-builders/) - shared technical architecture.
- [straddie-disaster-kiosks](https://github.com/auraofintelligence/straddie-disaster-kiosks) - [public page](https://auraofintelligence.github.io/straddie-disaster-kiosks/) - shared technical architecture.
- [straddie-space-station-simulator](https://github.com/auraofintelligence/straddie-space-station-simulator) - [public page](https://auraofintelligence.github.io/straddie-space-station-simulator/) - shared technical architecture.
- [straddie-vitality-network-builders](https://github.com/auraofintelligence/straddie-vitality-network-builders) - [public page](https://auraofintelligence.github.io/straddie-vitality-network-builders/) - shared technical architecture.

### Direct and other supported connections

- [Sandworm-subterranean-systems](https://github.com/auraofintelligence/sandworm-subterranean-systems) - [public page](https://auraofintelligence.github.io/sandworm-subterranean-systems/) - explicit cross-reference.

### Minjerribah wildlife and resilience data pathway

- [bees-and-allies](https://github.com/auraofintelligence/bees-and-allies) - [public page](https://auraofintelligence.github.io/bees-and-allies/) - shared community programme.
- [minjerribah-living-twin](https://github.com/auraofintelligence/minjerribah-living-twin) - [public page](https://auraofintelligence.github.io/minjerribah-living-twin/) - explicit cross-reference, shared community programme.
- [minjerribah-wildlife-rescue](https://github.com/auraofintelligence/minjerribah-wildlife-rescue) - [public page](https://auraofintelligence.github.io/minjerribah-wildlife-rescue/) - shared community programme.
- [quandamooka-country-events-engine](https://github.com/auraofintelligence/quandamooka-country-events-engine) - [public page](https://auraofintelligence.github.io/quandamooka-country-events-engine/) - shared community programme.
- [wildlife-rescue-minjerribah](https://github.com/auraofintelligence/wildlife-rescue-minjerribah) - shared community programme.

### Regional wealth and resilience architecture

- [mineral-moonshots](https://github.com/auraofintelligence/mineral-moonshots) - [public page](https://auraofintelligence.github.io/mineral-moonshots/) - shared community programme.
- [moreton-bay-community-wealth-and-mutuals](https://github.com/auraofintelligence/moreton-bay-community-wealth-and-mutuals) - [public page](https://auraofintelligence.github.io/moreton-bay-community-wealth-and-mutuals/) - shared community programme.
- [ready-set-co-op-trust-hub](https://github.com/auraofintelligence/ready-set-co-op-trust-hub) - [public page](https://auraofintelligence.github.io/ready-set-co-op-trust-hub/) - shared community programme.
- [Redland_Flow](https://github.com/auraofintelligence/Redland_Flow) - [public page](https://auraofintelligence.github.io/Redland_Flow/) - explicit cross-reference, shared community programme.
- [Redlands_draft_ES2026-2031](https://github.com/auraofintelligence/Redlands_draft_ES2026-2031) - [public page](https://auraofintelligence.github.io/Redlands_draft_ES2026-2031/) - shared community programme.

<!-- github-organisation:end -->

Minjerribah Resilience is a single-page concept called the Minjerribah
Protocol. It explores how local power, water, food, communications, governance
and automation could form a base for longer-horizon resilience ideas.

## Public page

- [Open the Minjerribah Protocol concept](https://auraofintelligence.github.io/Minjerribah-Resilience/)

## What is here

`index.html` contains the complete interactive presentation. It includes:

- a three-part core philosophy covering the sovereign node, personal Aura and
  a proposed braided economy;
- staged ideas for foundational resilience, subterranean systems and much
  longer-term continental or space-scale possibilities;
- an interactive threat dashboard that maps proposed systems to different
  hazards; and
- small charts, tabs and calculators used to explain the concept.

The page is static and uses browser-loaded Tailwind CSS and Chart.js. It does
not operate infrastructure or fetch live emergency data.

## Open locally

Open `index.html` in a browser. An internet connection is needed for the
browser-loaded libraries.

## Status and boundaries

This is speculative systems thinking, not an adopted resilience plan,
engineering design, cultural authority, emergency guide or approval to build.
Named places, hazard claims, costs, laws and technical assumptions require
current primary sources and the right community, cultural, technical and
government review before operational use.

## Related pages

- [Redland Flow, another Minjerribah Protocol concept](https://auraofintelligence.github.io/Redland_Flow/)
- [Minjerribah Living Twin](https://auraofintelligence.github.io/minjerribah-living-twin/)
- [Sandworm Subterranean Systems](https://auraofintelligence.github.io/sandworm-subterranean-systems/)

## Licence

See [LICENSE](LICENSE). This repository uses the Strange But True Public Source
Licence.
