# Scan to Twin: a plain-English explainer for Straddie

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 25 July 2026.
- GitHub repository: [straddie-digital-twin-explainer](https://github.com/auraofintelligence/straddie-digital-twin-explainer).
- Public site: [visit the public site](https://auraofintelligence.github.io/straddie-digital-twin-explainer/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 3 relevant public connections.

### Minjerribah digital-twin builds and explainers

- [minjerribah-living-twin](https://github.com/auraofintelligence/minjerribah-living-twin) - [public page](https://auraofintelligence.github.io/minjerribah-living-twin/) - explicit cross-reference, shared named build family.
- [second-island](https://github.com/auraofintelligence/second-island) - [public page](https://auraofintelligence.github.io/second-island/) - explicit cross-reference, shared named build family.
- [straddie-digital-twin-builders](https://github.com/auraofintelligence/straddie-digital-twin-builders) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-builders/) - explicit cross-reference, shared named build family.

<!-- github-organisation:end -->

A cinematic, seven-page static site explaining, for Minjerribah / North Stradbroke Island locals and elected decision makers, how phone scanning can grow into a community-owned digital twin of the island, and how the Web3 Sensorium, fractal governance modelling, the C-hour and the Ready S.E.T. Co-op pitch fit around it.

Every claim on the site wears one of four honesty labels: Built, Designed, Proposal, Horizon. Technical language is folded behind click-to-open detail panels so the plain-English reading never breaks.

## Pages

- `index.html`: the front door, the labels, the six-step road
- `scan-to-twin.html`: how a phone scan becomes a measurable drawing (the working step)
- `island-twin.html`: the stretch goal, one pocket at a time
- `sensorium.html`: twins that nest; twin, not master
- `governance.html`: fractal governance modelling and the cinema shelves
- `c-hour.html`: hours given to community, counted and honoured
- `co-op-and-hub.html`: Ready S.E.T. Co-op, 9 Ballow Road, the shared compute pitch
- `sitemap.html`: the whole map plus sister sites

## Design

Cinematic-family skin shared with grain-by-grain and the wider aura / right-place family: self-hosted variable fonts, deep-ink base, gold kintsugi seams, reveal-on-scroll, no external dependencies, no analytics, no images that pretend to be photographs. The hero canvas is this site's own motif: a scan sweep passing over a field of points.

## Local preview

```
npx serve . -l 4200
```

## Honesty commitments carried from the source repos

- The Screen & Media Network calls itself a community pitch, not a done deal; this site repeats that framing rather than improving on it.
- Nobody has been invited to join the Ready S.E.T. Co-op; membership is described only as a future readiness stage.
- 9 Ballow Road references are dated source notes about a real third-party property, not live property advice, and no lease exists.
- No grant has been applied for; the five-million-dollar compute pitch is labelled as a pitch with its homework visibly incomplete.

## Public page and related work

- [Read the Scan to Twin explainer](https://auraofintelligence.github.io/straddie-digital-twin-explainer/)
- [Browse the source repository](https://github.com/auraofintelligence/straddie-digital-twin-explainer)
- [Straddie Digital Twin Builders](https://auraofintelligence.github.io/straddie-digital-twin-builders/)
- [Second Island instrument-first twin](https://auraofintelligence.github.io/second-island/)
- [Minjerribah Living Twin reference build](https://auraofintelligence.github.io/minjerribah-living-twin/)

---

🤝🔷 A Luke × Claude build. [Strange But True Public Source Licence](LICENCE.md).

**Luke Hayes × Claude**, Minjerribah · 2026.
