/*
 * Straddie Digital Twin Explainer: shared page behaviour + the hero animation.
 *
 * Progressive enhancement only: every page is complete without this file.
 * Pattern shared with the grain-by-grain / aura / right-place cinema family.
 * The hero canvas is this site's own motif: a quiet sweep of light passing
 * over a field of points, the way a scan reveals a surface.
 */
(() => {
  document.documentElement.classList.add('js');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* The reading order. Sitemap sits outside this rail. */
  const SEQUENCE = [
    { slug: 'home', file: 'index.html', label: 'Home' },
    { slug: 'scan', file: 'scan-to-twin.html', label: 'The scan' },
    { slug: 'twin', file: 'island-twin.html', label: 'The island twin' },
    { slug: 'sensorium', file: 'sensorium.html', label: 'The Sensorium' },
    { slug: 'governance', file: 'governance.html', label: 'Fractal governance' },
    { slug: 'c-hour', file: 'c-hour.html', label: 'The C-hour' },
    { slug: 'co-op', file: 'co-op-and-hub.html', label: 'The co-op and the hub' },
  ];

  /* ---------- Reveal on scroll + kintsugi seams ----------
     Deliberately NOT IntersectionObserver. Content visibility must never
     depend on an observer callback arriving: browsers throttle or delay IO
     in background tabs, prerendered pages and low-power modes, and the old
     version also used a fractional threshold that a block taller than the
     viewport could never meet, leaving whole sections at opacity 0 forever.
     A plain geometry sweep on scroll/resize gives the same staggered effect
     with nothing that can strand content. */
  const pending = new Set(
    [...document.querySelectorAll('.reveal'), ...document.querySelectorAll('.kintsugi-seam')]
  );
  const show = (el) => el.classList.add(el.classList.contains('kintsugi-seam') ? 'is-drawn' : 'is-visible');
  if (reduced) {
    pending.forEach(show);
    pending.clear();
  }
  const sweep = () => {
    if (!pending.size) { return; }
    /* Only the top edge is tested, so anything scrolled past stays revealed:
       an anchor jump or a restored scroll position cannot skip a block. */
    const line = window.innerHeight * 0.92;
    pending.forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.top < line) { show(el); pending.delete(el); }
    });
  };
  sweep();
  window.addEventListener('scroll', sweep, { passive: true });
  window.addEventListener('resize', sweep, { passive: true });
  window.addEventListener('load', sweep);
  /* Late-layout safety net (fonts/images shifting geometry after first paint). */
  setTimeout(sweep, 400);
  setTimeout(sweep, 1500);

  /* ---------- Mark the current page in the nav ---------- */
  const normalise = (value) => {
    const url = new URL(value, location.href);
    return url.pathname.replace(/\/index\.html$/, '/').replace(/\.html$/, '');
  };
  const here = normalise(location.href);
  document.querySelectorAll('.site-nav a').forEach((link) => {
    const href = link.getAttribute('href');
    if (!href || href.startsWith('#')) { return; }
    if (normalise(href) === here) { link.setAttribute('aria-current', 'page'); }
  });

  /* ---------- Prev / next rail, injected before the footer ---------- */
  const page = document.body.getAttribute('data-page');
  const footer = document.querySelector('.site-footer');
  const idx = SEQUENCE.findIndex((s) => s.slug === page);
  if (footer && idx !== -1) {
    const prev = SEQUENCE[idx - 1];
    const next = SEQUENCE[idx + 1];
    const rail = document.createElement('nav');
    rail.className = 'rung-nav';
    rail.setAttribute('aria-label', 'Reading order');
    const left = prev
      ? `<a href="${prev.file}">&larr; ${prev.label}</a>`
      : `<span></span>`;
    const right = next
      ? `<a href="${next.file}">${next.label} &rarr;</a>`
      : `<a href="sitemap.html">See the whole map &rarr;</a>`;
    rail.innerHTML = left + right;
    footer.insertAdjacentElement('beforebegin', rail);
  }

  /* ---------- Site map link into the footer, everywhere ---------- */
  const footerLinks = document.querySelector('.footer-links');
  if (footerLinks && !footerLinks.querySelector('[data-map-link]')) {
    const map = document.createElement('a');
    map.href = 'sitemap.html';
    map.textContent = 'Site map';
    map.setAttribute('data-map-link', '');
    footerLinks.insertBefore(map, footerLinks.firstChild);
  }

  /* ---------- To-top button ---------- */
  const toTop = document.createElement('button');
  toTop.type = 'button';
  toTop.className = 'to-top';
  toTop.setAttribute('aria-label', 'Back to top');
  toTop.innerHTML = '<span aria-hidden="true">&uarr;</span>';
  document.body.appendChild(toTop);
  const toggleTop = () => toTop.classList.toggle('is-visible', window.scrollY > 640);
  toggleTop();
  window.addEventListener('scroll', toggleTop, { passive: true });
  toTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: reduced ? 'auto' : 'smooth' });
    const target = document.getElementById('main') || document.body;
    target.setAttribute('tabindex', '-1');
    target.focus({ preventScroll: true });
  });

  /* ---------- Condensing header ---------- */
  const header = document.querySelector('.site-header');
  if (header) {
    const onScroll = () => header.classList.toggle('is-condensed', window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Hero canvas: the scan sweep ---------- */
  const canvas = document.querySelector('[data-scan-canvas]');
  if (!canvas || !canvas.getContext) { return; }
  const ctx = canvas.getContext('2d');

  const GOLD = [255, 207, 110];
  const BAY = [43, 227, 194];
  const DUSK = [177, 151, 252];

  let w = 0, h = 0;
  const resize = () => {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = canvas.clientWidth;
    h = canvas.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };
  resize();

  /* A loose point field shaped like low dunes: the surface the sweep finds. */
  const COUNT = 260;
  const points = [];
  let seed = 11;
  const rand = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
  for (let i = 0; i < COUNT; i++) {
    const x = rand();
    const dune = 0.62 + 0.16 * Math.sin(x * 9.2) + 0.08 * Math.sin(x * 23.7 + 1.4);
    const tint = rand();
    points.push({
      x,
      y: dune + (rand() - 0.5) * 0.34,
      r: 0.7 + rand() * 1.5,
      base: 0.08 + rand() * 0.16,
      col: tint < 0.66 ? GOLD : (tint < 0.88 ? BAY : DUSK),
      phase: rand() * Math.PI * 2,
    });
  }

  const SWEEP_PERIOD = 1400; /* frames per full pass */

  function frame(t) {
    ctx.clearRect(0, 0, w, h);

    /* The sweep line moves left to right and wraps. */
    const sweepX = ((t % SWEEP_PERIOD) / SWEEP_PERIOD) * 1.25 - 0.125;

    /* Points glow as the sweep passes, then fade back to a faint field. */
    points.forEach((p) => {
      const d = Math.abs(p.x - sweepX);
      const glow = Math.max(0, 1 - d * 9);
      const twinkle = 0.75 + 0.25 * Math.sin(t * 0.004 + p.phase);
      const [r, g, b] = p.col;
      ctx.globalAlpha = Math.min(0.9, (p.base + glow * 0.75) * twinkle);
      ctx.fillStyle = `rgb(${r}, ${g}, ${b})`;
      ctx.beginPath();
      ctx.arc(p.x * w, p.y * h, p.r + glow * 1.6, 0, Math.PI * 2);
      ctx.fill();
    });

    /* The sweep itself: a soft vertical blade of light. */
    if (sweepX > -0.05 && sweepX < 1.05) {
      const gx = sweepX * w;
      const grad = ctx.createLinearGradient(gx - 60, 0, gx + 14, 0);
      grad.addColorStop(0, 'rgba(43, 227, 194, 0)');
      grad.addColorStop(0.82, 'rgba(43, 227, 194, 0.05)');
      grad.addColorStop(1, 'rgba(255, 207, 110, 0.16)');
      ctx.globalAlpha = 1;
      ctx.fillStyle = grad;
      ctx.fillRect(gx - 60, 0, 74, h);
      ctx.strokeStyle = 'rgba(255, 231, 176, 0.35)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(gx + 14, 0);
      ctx.lineTo(gx + 14, h);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  let t = 300;
  frame(t);
  if (reduced) { return; }

  let visible = true;
  if ('IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      visible = entries[0] ? entries[0].isIntersecting : true;
    }).observe(canvas);
  }
  window.addEventListener('resize', () => { resize(); frame(t); }, { passive: true });

  const loop = () => {
    requestAnimationFrame(loop);
    if (!visible) { return; }
    if (canvas.clientWidth !== w || canvas.clientHeight !== h) { resize(); }
    t += 1;
    frame(t);
  };
  requestAnimationFrame(loop);
})();
