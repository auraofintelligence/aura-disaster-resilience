# Drop-zone: blockchain

Drop any research documents, build plans, scripts or notes for the "blockchain" page here, in any format. Sonnet checks this folder before building or revising this page and treats these documents as the top-ranking source for its content.
