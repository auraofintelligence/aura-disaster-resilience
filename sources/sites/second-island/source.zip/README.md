# second-island

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 18 August 2026.
- GitHub repository: [second-island](https://github.com/auraofintelligence/second-island).
- Public site: [visit the public site](https://auraofintelligence.github.io/second-island/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 3 relevant public connections.

### Minjerribah digital-twin builds and explainers

- [minjerribah-living-twin](https://github.com/auraofintelligence/minjerribah-living-twin) - [public page](https://auraofintelligence.github.io/minjerribah-living-twin/) - later build; minjerribah-living-twin is earlier, explicit cross-reference, ordered build lineage, shared named build family.
- [straddie-digital-twin-builders](https://github.com/auraofintelligence/straddie-digital-twin-builders) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-builders/) - explicit cross-reference, shared named build family.
- [straddie-digital-twin-explainer](https://github.com/auraofintelligence/straddie-digital-twin-explainer) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-explainer/) - explicit cross-reference, shared named build family.

<!-- github-organisation:end -->

The second build of a living digital twin of Minjerribah, North Stradbroke Island, Quandamooka
Country. Started clean on 18 August 2026 from the lessons of the first build, which lives at
`minjerribah-living-twin` and keeps running as the reference implementation.

The two repositories are deliberately separate and must stay that way. An agent working here does
not write into `minjerribah-living-twin`; an agent working there does not write into this one. The
first island is read as a reference and a test oracle, never edited from here.

## What exists

**Stage 0: the measurement instruments, and every one of them has been watched failing.** That is
the whole of what is built. There is no island yet: there is a sun, a tide that says it does not
know its own height, and the instruments that will judge everything after them.

    node tools/selftest.mjs        22 faults against 16 instrument columns, and the matrix it writes
    node tools/gate.mjs            ten rule modules, every rule that can execute
    node tools/check-island.mjs    the world's physics against 18 identities
    node tools/headless.mjs        the whole simulation in Node, a sim year in 0.144 s
    node tools/determinism.mjs     two runs, and the name of the system that drifted
    node tools/board.mjs read      the noticeboard
    node tools/serve.mjs           the page on 4281

- [docs/FOUNDING-PROMPT.md](docs/FOUNDING-PROMPT.md) is the brief: the order of operations, the
  executable laws, the two judging bars, the day-zero data list, the AAA path, and a failure
  catalogue of the first build with the law that prevents each entry.
- [docs/CONTRACT.md](docs/CONTRACT.md) is what the code must look like. Every rule in it is either a
  named check in `tools/gate/` or carries `NOT YET CHECKED` and a reason. There is no third state.
- [docs/STAGE-0.md](docs/STAGE-0.md) specifies the instruments and the faults that prove them.
- [docs/JURISDICTION.md](docs/JURISDICTION.md) is generated, not written: which instrument catches
  which fault, and which faults nothing catches. Read it before trusting any verdict.
- [docs/STATE-OF-PLAY.md](docs/STATE-OF-PLAY.md) says what is true, including what is unfinished.
  [docs/WINS.md](docs/WINS.md) says what is won. Both are load-bearing.
- [docs/board/](docs/board) is the noticeboard. A finding that lives only in a transcript is treated
  as never made.

## Two things this repository will not do

**It will not invent.** No published harmonic constituent table for the Dunwich standard port could
be found, so the tide ships zero constituents and the panel reads "contested or unknown" with the
date rather than a number. Where real data exists and is licensed, invention is a bug; where it does
not exist, the honest display is the absence.

**It will not present culture it has no standing to present.** Minjerribah is Quandamooka Country.
`docs/CULTURAL-QUEUE.md` is a queue of open questions and nothing in it is an approval. The gate
enforces that in code, not only in prose.

This is a work in progress. It is not a product, and it does not claim to be better than anything,
including its predecessor, until the probes say so.

## Live

The page is at [auraofintelligence.github.io/second-island](https://auraofintelligence.github.io/second-island/)
and the repository is [github.com/auraofintelligence/second-island](https://github.com/auraofintelligence/second-island).
What the page shows is what the instruments have proven, nothing more: the calibration scene, the
island clock, the sun, a tide that says it does not know its own height, and the crossings.

## Acknowledgement of Country

Minjerribah is Quandamooka Country. This project acknowledges the Quandamooka People as the
Traditional Owners of Minjerribah and of the lands and waters of Moreton Bay, and pays respect to
Elders past and present. This is a simulation built from public records. It is not a cultural work
and it does not speak for the Quandamooka People. QYAC has not seen this project.

---

*Luke Catalyst Nathan Hayes with Claude (Anthropic), August 2026.*
*Minjerribah, Quandamooka Country.*
