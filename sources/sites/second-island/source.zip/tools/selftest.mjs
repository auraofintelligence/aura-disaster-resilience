#!/usr/bin/env node
// The meta-instrument: break the build on purpose and watch the instruments catch it.
//
//     node tools/selftest.mjs
//     node tools/selftest.mjs --fault stale-frame
//     node tools/selftest.mjs --json
//     node tools/selftest.mjs --skip-browser
//
// docs/STAGE-0.md: nothing else in this repository starts until every instrument has caught a fault
// that was put there on purpose. This file is what turns "the gate is clean" into "the gate has
// been watched failing", and it writes docs/JURISDICTION.md from what it saw rather than from what
// anybody claimed.
//
// WHAT IT DOES, PER FAULT
//
//   1. Copies the repository to out/selftest/<fault>/, excluding .git, node_modules, out and shots.
//   2. Applies the fault. A tree fault edits the copy. A runtime fault sets ISLAND_FAULT for the
//      child processes and leaves the copy alone.
//   3. Runs every applicable instrument against the healthy copy and against the faulted one.
//   4. Asserts three things about the instrument the registry names as the owner of that fault:
//      the healthy run passes, the faulted run fails, and the failure output contains every string
//      in mustName. An inverted row asserts the opposite for the instrument it names in mustMiss.
//
// THE THING THIS FILE IS MOST LIKELY TO GET WRONG, SO IT IS CHECKED EXPLICITLY
//
// A fault that "fails" an instrument because the instrument crashed, or could not find a file, or
// hit a syntax error, has not been caught. It has been survived. That is the easiest way for this
// whole exercise to fool itself, so every failure is scanned for a crash signature, and a row whose
// owning instrument failed with a crash signature that mustName does not ask for is reported as
// WRONG REASON and is never counted green.
//
// IT MUST NOT TOUCH THIS REPOSITORY
//
// Every copy lives under out/, which is gitignored. `git status --porcelain` is read before the run
// and again after it, and a difference fails the run. Nothing here writes into src/, data/ or docs/
// except the one generated file it exists to generate, docs/JURISDICTION.md, and that file is
// written last and is compared against the baseline as an expected change.
//
// EXIT CODE
//
//   0  every row is green, or honestly unproven with a reason the registry carries
//   1  a row that should have been caught was missed, or was caught for the wrong reason, or this
//      repository changed during the run
//   2  a usage error
//
// An unproven row does not fail the run, because tools/bench.mjs and tools/uiprobe.mjs do not exist
// yet and an instrument that has not been written cannot be watched failing. Unproven rows are
// counted, named and carried into docs/JURISDICTION.md. They are the reason stage 0 is not finished.

import { copyFileSync, readdirSync, rmSync, mkdirSync, existsSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { FAULTS, INSTRUMENTS } from './faults.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const WORK = path.join(REPO_ROOT, 'out', 'selftest');
const HEALTHY = path.join(WORK, '_healthy');
const EXCLUDE = new Set(['.git', 'node_modules', 'out', 'shots']);

const GATE_COLUMNS = Object.keys(INSTRUMENTS).filter((k) => INSTRUMENTS[k].kind === 'gate');
const COLUMNS = Object.keys(INSTRUMENTS);

/** A failure that is a crash, not a catch. Checked on every owning instrument's failure output. */
const CRASH_SIGNS = [
  'SyntaxError',
  'ReferenceError',
  'TypeError',
  'Cannot find module',
  'ERR_MODULE_NOT_FOUND',
  'ENOENT',
  'is not a function',
  'is not defined',
  'Unexpected token',
  'unknown argument'
];

function usage() {
  return [
    'node tools/selftest.mjs [--fault <id>] [--json] [--skip-browser] [--keep]',
    '',
    '  --fault <id>     run one row only',
    '  --json           machine readable output on stdout, nothing else',
    '  --skip-browser   do not point tools/shot.mjs at recorded browser captures',
    '  --keep           leave the faulted copies under out/selftest/ for inspection',
    '',
    'Exit code 1 on a missed row, a wrong reason, or a change to this repository.'
  ].join('\n');
}

function parseArgs(argv) {
  const opts = { fault: null, json: false, skipBrowser: false, keep: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') opts.json = true;
    else if (a === '--skip-browser') opts.skipBrowser = true;
    else if (a === '--keep') opts.keep = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--fault') opts.fault = argv[++i] ?? null;
    else if (a.startsWith('--fault=')) opts.fault = a.slice(8);
    else throw new Error('unknown argument: ' + a + '\n\n' + usage());
  }
  return opts;
}

function rel(abs) {
  return path.relative(REPO_ROOT, abs).split('\\').join('/');
}

function gitPorcelain() {
  const r = spawnSync('git', ['status', '--porcelain'], { cwd: REPO_ROOT, encoding: 'utf8' });
  if (r.error || typeof r.status !== 'number') return null;
  return (r.stdout || '').replace(/\r/g, '').split('\n').map((s) => s.trimEnd()).filter(Boolean).sort();
}

/**
 * A copy of the repository at `dest`, which lives under out/ and is therefore inside the source.
 * Written by hand rather than with fs.cpSync, which refuses to copy a directory into a subdirectory
 * of itself even when a filter would exclude the subdirectory. The copy has to sit inside the
 * repository: tools/gate/sealed.mjs asks git about the tree it is given, and a tree outside any
 * working tree answers "no git", which would void the row that check exists to prove.
 */
function copyTree(dest) {
  rmSync(dest, { recursive: true, force: true });
  mkdirSync(dest, { recursive: true });
  const visit = (from, to, depth) => {
    for (const e of readdirSync(from, { withFileTypes: true })) {
      if (depth === 0 && EXCLUDE.has(e.name)) continue;
      const src = path.join(from, e.name);
      const dst = path.join(to, e.name);
      if (e.isDirectory()) {
        mkdirSync(dst, { recursive: true });
        visit(src, dst, depth + 1);
      } else if (e.isFile()) {
        copyFileSync(src, dst);
      }
    }
  };
  visit(REPO_ROOT, dest, 0);
}

// ---------------------------------------------------------------------------------------------
// Running the instruments.
// ---------------------------------------------------------------------------------------------

function runNode(script, args, { cwd, env }) {
  const r = spawnSync(process.execPath, [script, ...args], {
    cwd,
    encoding: 'utf8',
    env,
    maxBuffer: 32 * 1024 * 1024
  });
  const out = (r.stdout || '') + (r.stderr || '');
  return { status: typeof r.status === 'number' ? r.status : -1, out };
}

function childEnv(faultId) {
  const env = { ...process.env };
  delete env.ISLAND_FAULT;
  if (faultId) env.ISLAND_FAULT = faultId;
  return env;
}

/**
 * The gate, run from THIS repository against the tree under test. tools/gate.mjs loads its check
 * modules from its own directory on purpose: pointing the gate at a copy must not swap out the
 * checks as well, or a planted fault could be caught by a planted checker.
 */
function runGate(tree) {
  const r = runNode(path.join(REPO_ROOT, 'tools', 'gate.mjs'), ['--json', '--root', tree], {
    cwd: REPO_ROOT,
    env: childEnv(null)
  });
  let doc = null;
  try {
    doc = JSON.parse(r.out);
  } catch {
    doc = null;
  }
  const byModule = new Map();
  for (const name of GATE_COLUMNS) byModule.set(name, { failed: false, out: '', loaderProblem: false });
  if (!doc || !Array.isArray(doc.findings)) {
    for (const name of GATE_COLUMNS) {
      byModule.set(name, { failed: true, out: 'the gate produced no readable JSON:\n' + r.out.slice(0, 2000), loaderProblem: true });
    }
    return byModule;
  }
  for (const name of GATE_COLUMNS) {
    const module = INSTRUMENTS[name].rule;
    const mine = doc.findings.filter((f) => f.module === module && f.severity === 'blocking');
    const text = mine.map((f) => [f.rule, f.file + (f.line ? ':' + f.line : ''), f.text, f.why].join('  ')).join('\n');
    byModule.set(name, { failed: mine.length > 0, out: text, loaderProblem: false });
  }
  // A loader problem is reported under gate-loader and belongs to whichever rule failed to load.
  const loader = doc.findings.filter((f) => f.module === 'gate-loader');
  if (loader.length) {
    for (const name of GATE_COLUMNS) {
      const cell = byModule.get(name);
      cell.out += (cell.out ? '\n' : '') + loader.map((f) => f.rule + '  ' + f.file + '  ' + f.text).join('\n');
      cell.loaderProblem = true;
    }
  }
  return byModule;
}

function runNodeInstrument(name, tree, faultId) {
  const spec = INSTRUMENTS[name];
  const script = path.join(tree, ...spec.script.split('/'));
  if (!existsSync(script)) {
    return { failed: false, out: '', absent: true };
  }
  const r = runNode(script, spec.args || [], { cwd: tree, env: childEnv(faultId) });
  return { failed: r.status !== 0, out: r.out, status: r.status };
}

/**
 * tools/shot.mjs against a recorded capture. It cannot open a page, so the browser rows are proven
 * against PNGs a browser session posted to shots/. The capture paths are resolved against this
 * repository, never against the copy: the copy has no shots directory.
 */
function runCapture(name, capture, fault, ev) {
  const spec = INSTRUMENTS[name];
  const script = path.join(REPO_ROOT, ...spec.script.split('/'));
  if (!existsSync(script)) return { failed: false, out: '', absent: true, note: spec.script + ' has not been written' };
  if (!capture) return { failed: false, out: '', missing: 'no capture declared' };
  const list = Array.isArray(capture) ? capture : [capture];
  for (const f of list) {
    if (!existsSync(path.join(REPO_ROOT, f))) return { failed: false, out: '', missing: f + ' is not on disk' };
  }
  const abs = list.map((f) => path.join(REPO_ROOT, f));
  const r = runNode(script, spec.args(abs, fault, ev), { cwd: REPO_ROOT, env: childEnv(null) });
  return { failed: r.status !== 0, out: r.out, status: r.status };
}

// ---------------------------------------------------------------------------------------------
// Judging a cell.
// ---------------------------------------------------------------------------------------------

function crashSignature(text, mustName) {
  for (const sign of CRASH_SIGNS) {
    if (!text.includes(sign)) continue;
    if (mustName.some((m) => m.includes(sign))) continue;
    return sign;
  }
  return null;
}

function missingNames(text, mustName) {
  return mustName.filter((m) => !text.includes(m));
}

// ---------------------------------------------------------------------------------------------
// The run.
// ---------------------------------------------------------------------------------------------

/**
 * The columns that do not depend on which fault is being tested: the gate rules and the Node
 * instruments. Run once over the healthy copy and reused, because running them twenty two times
 * proves nothing extra and gives the one instrument with a known flake twenty two chances to take it.
 *
 * The flake, named rather than papered over: tools/headless.mjs fails a run when a tick goes over
 * budget and no garbage collector pause accounts for it, which its own header says is the operating
 * system taking the thread away. It happened once in an earlier run of this file. A healthy failure
 * is retried once and both attempts are printed, so a retry is never invisible.
 */
function healthySuite(tree, opts, say) {
  const cells = new Map();
  const gate = runGate(tree);
  for (const name of GATE_COLUMNS) cells.set(name, gate.get(name));

  for (const name of COLUMNS) {
    const spec = INSTRUMENTS[name];
    if (spec.kind === 'gate' || spec.kind === 'capture') continue;
    if (spec.kind === 'absent') {
      cells.set(name, { failed: false, out: '', absent: true, note: spec.script + ' has not been written' });
      continue;
    }
    let cell = runNodeInstrument(name, tree, null);
    if (cell.failed) {
      say('  healthy ' + name + ' failed on the first attempt, retrying once. First attempt:');
      say('    ' + (cell.out || '').split('\n').slice(-4).join('\n    '));
      const second = runNodeInstrument(name, tree, null);
      cell = { ...second, retried: true, firstAttempt: (cell.out || '').slice(-2000) };
      say('  retry: ' + (second.failed ? 'failed again' : 'passed'));
    }
    cells.set(name, cell);
  }
  return cells;
}

/**
 * The columns for one tree with one fault. `side` is 'healthy' or 'faulted' and decides which
 * recorded capture the shot column is pointed at, because that column cannot open a page and has to
 * be handed a picture somebody else took. `base` supplies the fault independent columns.
 *
 * The faulted side retries a failing column that this fault does not own, once, for the same reason
 * healthySuite retries: tools/headless.mjs fails a run when a tick goes over budget with no
 * collector pause to account for it, which its own header calls the operating system taking the
 * thread away, and it happens roughly one run in six on this machine. A flake in the owning column
 * is not retried, because that column is the row's verdict and mustName already decides it; a flake
 * anywhere else writes `caught` into a cell of the published matrix for a reason that has nothing to
 * do with the fault. Both attempts are printed, so a retry is never invisible.
 */
function suite(tree, fault, side, opts, base, say = () => {}) {
  const faultId = side === 'faulted' && fault.kind === 'runtime' ? fault.id : null;
  const cells = new Map();

  if (side === 'healthy') {
    for (const [k, v] of base) cells.set(k, v);
  } else {
    const gate = runGate(tree);
    for (const name of GATE_COLUMNS) cells.set(name, gate.get(name));
    for (const name of COLUMNS) {
      const spec = INSTRUMENTS[name];
      if (spec.kind === 'gate' || spec.kind === 'capture') continue;
      if (spec.kind === 'absent') {
        cells.set(name, { failed: false, out: '', absent: true, note: spec.script + ' has not been written' });
      } else {
        let cell = runNodeInstrument(name, tree, faultId);
        const owns = name === fault.instrument || name === fault.mustMiss;
        if (cell.failed && !owns) {
          say('  ' + fault.id + ': ' + name + ' failed on the faulted tree and does not own this row, '
            + 'retrying once. First attempt:');
          say('    ' + (cell.out || '').split('\n').slice(-4).join('\n    '));
          const second = runNodeInstrument(name, tree, faultId);
          cell = { ...second, retried: true, firstAttempt: (cell.out || '').slice(-2000) };
          say('  retry: ' + (second.failed ? 'failed again, so the cell stands' : 'passed, so the first attempt was a flake'));
        }
        cells.set(name, cell);
      }
    }
  }

  for (const name of COLUMNS) {
    if (INSTRUMENTS[name].kind !== 'capture') continue;
    if (opts.skipBrowser) {
      cells.set(name, { failed: false, out: '', missing: 'skipped with --skip-browser' });
      continue;
    }
    const ev = fault.instrument === name ? fault.evidence
      : (fault.mustMiss === name ? fault.missEvidence : null);
    if (!ev) {
      cells.set(name, { failed: false, out: '', missing: 'no capture declared for this fault' });
      continue;
    }
    const which = side === 'faulted' ? ev.faulted : ev.healthy;
    cells.set(name, runCapture(name, which, fault, ev));
  }
  return cells;
}

function judge(fault, healthy, faulted) {
  const owner = fault.instrument;
  const mustMiss = fault.mustMiss || null;
  const row = {
    id: fault.id,
    origin: fault.origin,
    kind: fault.kind,
    breaks: fault.breaks,
    owner,
    mustMiss,
    inverted: !!fault.inverted,
    blindSpot: fault.blindSpot || null,
    declaredProven: fault.proven,
    why: fault.why || '',
    cells: {},
    verdict: 'unknown',
    note: ''
  };

  for (const name of COLUMNS) {
    const h = healthy.get(name);
    const f = faulted.get(name);
    let cell;
    if (!f || f.absent) cell = { state: 'not proven', note: (f && f.note) || 'instrument does not exist' };
    else if (f.missing) cell = { state: 'n/a', note: f.missing };
    else if (h && h.failed) cell = { state: 'void', note: 'this instrument already fails on the healthy tree' };
    else if (f.failed) cell = { state: 'caught', note: '' };
    else cell = { state: 'missed', note: '' };
    row.cells[name] = cell;
  }

  // The owning instrument decides the row.
  if (!owner) {
    if (mustMiss) {
      const cell = row.cells[mustMiss];
      if (cell.state === 'missed') {
        row.verdict = 'blind spot proven';
        row.note = 'no instrument catches this, and ' + mustMiss + ' was watched not catching it';
      } else if (cell.state === 'caught') {
        row.verdict = 'wrong reason';
        row.note = mustMiss + ' caught a fault the registry says it cannot see. The registry is out of date.';
      } else {
        row.verdict = 'not proven';
        row.note = cell.note;
      }
    } else {
      row.verdict = 'not proven';
      row.note = 'no owning instrument declared';
    }
    return row;
  }

  const spec = INSTRUMENTS[owner];
  const h = healthy.get(owner);
  const f = faulted.get(owner);

  if (!spec) {
    row.verdict = 'not proven';
    row.note = 'the registry names an instrument that does not exist in the instrument table';
    return row;
  }
  if (spec.kind === 'absent' || (f && f.absent)) {
    row.verdict = 'not proven';
    row.note = spec.script ? spec.script + ' does not exist, so nothing has been watched failing' : 'instrument absent';
    // An inverted row can have one half provable and the other not. Say which, rather than letting
    // "not proven" swallow a result that was actually observed.
    if (mustMiss) {
      const cell = row.cells[mustMiss];
      if (cell.state === 'missed') {
        row.halfProven = mustMiss + ' was run with the fault injected and passed, which is the '
          + 'inverted half and it is proven';
        row.note += '. ' + row.halfProven + '.';
      } else if (cell.state === 'caught') {
        row.verdict = 'wrong reason';
        row.note = mustMiss + ' caught a fault it is required to miss, so the inverted claim is false';
      }
    }
    return row;
  }
  if (f && f.missing) {
    row.verdict = 'not proven';
    row.note = f.missing;
    return row;
  }
  if (h && h.failed) {
    row.verdict = 'void';
    row.note = owner + ' fails on the healthy tree, so its failure on the faulted tree proves nothing';
    row.healthyOutput = (h.out || '').slice(0, 1200);
    return row;
  }
  if (!f || !f.failed) {
    row.verdict = 'missed';
    row.note = owner + ' passed with the fault injected';
    return row;
  }

  const text = f.out || '';
  const crash = crashSignature(text, fault.mustName || []);
  const missing = missingNames(text, fault.mustName || []);
  if (crash) {
    row.verdict = 'wrong reason';
    row.note = owner + ' failed with a crash signature (' + crash + '), which is a failure it survived '
      + 'rather than a fault it caught';
    row.output = text.slice(0, 1600);
    return row;
  }
  if (missing.length) {
    row.verdict = 'wrong reason';
    row.note = owner + ' failed but did not name: ' + missing.join(', ');
    row.output = text.slice(0, 1600);
    return row;
  }

  // Inverted rows carry a second requirement: an instrument that has to keep passing.
  if (mustMiss) {
    const cell = row.cells[mustMiss];
    if (cell.state === 'caught') {
      row.verdict = 'wrong reason';
      row.note = mustMiss + ' caught a fault it is required to miss, so the inverted claim is false';
      return row;
    }
    if (cell.state !== 'missed') {
      row.verdict = 'not proven';
      row.note = 'the inverted half is unproven: ' + mustMiss + ' reported ' + cell.state + ', ' + cell.note;
      return row;
    }
  }

  row.verdict = 'caught';
  row.note = '';
  return row;
}

/**
 * The registry's `proven` field is the author's claim. This run is the observation. A claim of
 * `true` on a row that was not caught is the failure mode this whole file exists to make expensive,
 * so it is reported and it fails the run. `null` is the honest way to make no claim.
 */
function claimDisagreements(rows) {
  const out = [];
  for (const r of rows) {
    const observedGreen = r.verdict === 'caught' || r.verdict === 'blind spot proven';
    if (r.declaredProven === true && !observedGreen) {
      out.push({ id: r.id, kind: 'overclaimed', text: 'the registry declares proven: true and this run says ' + r.verdict });
    }
    if (r.declaredProven === false && observedGreen) {
      out.push({ id: r.id, kind: 'stale', text: 'the registry declares proven: false and this run caught it, so the reason in `why` is out of date' });
    }
  }
  return out;
}

// ---------------------------------------------------------------------------------------------
// docs/JURISDICTION.md
// ---------------------------------------------------------------------------------------------

const CELL_MARK = {
  caught: 'caught',
  missed: 'missed',
  'n/a': 'n/a',
  'not proven': 'not proven',
  void: 'void'
};

function shortColumn(name) {
  return name.replace(/^gate\//, 'g/').replace(/ --shuffle$/, '+shuf');
}

function jurisdiction(rows, meta) {
  const L = [];
  L.push('# Jurisdiction: which instrument catches which fault');
  L.push('');
  L.push('**Generated by `node tools/selftest.mjs`. Do not hand edit: the next run overwrites it.**');
  L.push('Generated ' + meta.date + '. ' + meta.summary);
  L.push('');
  L.push('Every cell below was produced by running the instrument twice, once on a healthy copy of');
  L.push('this repository and once on a copy with the fault injected. A cell reads `caught` only');
  L.push('when the instrument passed on the healthy copy, failed on the faulted one, and the failure');
  L.push('output contained every string the registry says it must name. A failure that carried a');
  L.push('crash signature the registry did not ask for is not a catch and is reported as a wrong');
  L.push('reason, because an instrument that falls over is not an instrument that saw something.');
  L.push('');
  L.push('| cell | meaning |');
  L.push('| --- | --- |');
  L.push('| caught | the instrument failed with the fault injected, naming what the registry requires |');
  L.push('| missed | the instrument passed with the fault injected |');
  L.push('| not proven | the instrument does not exist yet, or its evidence is not on disk |');
  L.push('| n/a | the instrument has nothing to point at for this fault |');
  L.push('| void | the instrument already fails on the healthy tree, so its failure proves nothing |');
  L.push('');

  L.push('## The matrix');
  L.push('');
  L.push('<!-- rows are faults, columns are instruments -->');
  L.push('');
  const header = ['fault', ...COLUMNS.map(shortColumn)];
  L.push('| ' + header.join(' | ') + ' |');
  L.push('| ' + header.map(() => '---').join(' | ') + ' |');
  for (const r of rows) {
    const cells = COLUMNS.map((c) => {
      const cell = r.cells[c];
      const mark = CELL_MARK[cell.state] || cell.state;
      if (c === r.owner) return '**' + mark + '**';
      if (c === r.mustMiss) return mark + ' (required)';
      return mark;
    });
    L.push('| `' + r.id + '` | ' + cells.join(' | ') + ' |');
  }
  L.push('');

  L.push('## Every row that is not green, and why');
  L.push('');
  const bad = rows.filter((r) => r.verdict !== 'caught' && r.verdict !== 'blind spot proven');
  if (!bad.length) {
    L.push('None. Every fault in the registry was caught by the instrument that owns it.');
  } else {
    L.push('| fault | owner | verdict | why |');
    L.push('| --- | --- | --- | --- |');
    for (const r of bad) {
      const note = (r.note || '').trim();
      const why = [note && /[.!?]$/.test(note) ? note : note && note + '.', (r.why || '').trim()]
        .filter(Boolean).join(' ').replace(/\s+/g, ' ').replace(/\|/g, '/');
      L.push('| `' + r.id + '` | ' + (r.owner || 'none') + ' | ' + r.verdict + ' | ' + why + ' |');
    }
  }
  L.push('');

  L.push('## Which instrument owns which claim');
  L.push('');
  for (const name of COLUMNS) {
    const owned = rows.filter((r) => r.owner === name).map((r) => '`' + r.id + '`');
    const misses = rows.filter((r) => r.mustMiss === name).map((r) => '`' + r.id + '`');
    L.push('**' + name + '.** ' + INSTRUMENTS[name].owns);
    L.push('');
    L.push('- proven by: ' + (owned.length ? owned.join(', ') : 'nothing, which gate/instruments refuses'));
    if (misses.length) L.push('- required to MISS: ' + misses.join(', '));
    L.push('');
  }

  L.push('## Blind spots: faults no instrument catches');
  L.push('');
  const blind = rows.filter((r) => r.blindSpot);
  if (!blind.length) {
    L.push('None declared.');
  } else {
    for (const r of blind) {
      L.push('**`' + r.id + '`** ' + r.breaks + '.');
      L.push('');
      L.push(r.blindSpot);
      L.push('');
      const seen = (r.note || '').trim();
      L.push('Observed this run: ' + r.verdict + (seen ? '. ' + seen.replace(/\.?$/, '.') : '.'));
      L.push('');
    }
  }

  L.push('## What this file does not prove');
  L.push('');
  L.push('- **The browser rows depend on captures that are not in git.** `shot`, `bench` and');
  L.push('  `uiprobe` cannot open a page. They are pointed at PNGs and JSON a browser session posted');
  L.push('  to `shots/` and `out/probes/`, both of which are gitignored. In a fresh clone those rows');
  L.push('  report `not proven` until somebody opens `http://localhost:4281/lab.html` with `?fault=<id>` and');
  L.push('  calls `ISLAND.shot`, `ISLAND.probe` or `ISLAND.bench` again. That is honest rather than');
  L.push('  convenient: no Node script in this repository can open a page, and a matrix that went');
  L.push('  green on a machine with no captures would be lying.');
  L.push('- **A `missed` cell is not a defect.** Most of this matrix is `missed`, and it should be.');
  L.push('  It says which instrument has no view of which fault, which is the useful half: it is why');
  L.push('  `shot` reading `missed (required)` on `ui-text-change` is a result rather than a gap.');
  L.push('- **The em dash row covers a document and a code comment. The commit message is covered');
  L.push('  by something this matrix cannot see.** `gate/style` reads files and a commit message is');
  L.push('  not one it can reach, so the third case named in `docs/STAGE-0.md` belongs to');
  L.push('  `tools/hooks/commit-msg`, which was watched refusing a message carrying U+2014 and');
  L.push('  passing a clean one. It has no row here and cannot get one: `.git/hooks` is not tracked,');
  L.push('  the hook is installed per machine with `node tools/hooks/install.mjs`, and no agent in');
  L.push('  this repository runs a state changing git command, so no fault in the registry can reach');
  L.push('  it. Ask `node tools/hooks/install.mjs --check` whether it is live on yours.');
  L.push('- **The derived lane reads one tree that is not in git, and one that is.**');
  L.push('  `gate/derived` has two halves. `derived/committed` reads `data/`, which is tracked, so');
  L.push('  the `derived-committed` row plants its own pack and is proven in any clone.');
  L.push('  `derived/unprovenanced` reads `ingest-inbox/derived/`, which `.gitignore` seals, so what');
  L.push('  it reads depends on which connectors have been run on the machine and a fresh clone gives');
  L.push('  it nothing. The `unprovenanced-derive` row stays green either way, because the fault');
  L.push('  plants the pack it is judged on, but silence from that half is silence and not a pass:');
  L.push('  run the connectors, then `node tools/gate.mjs --rule derived`, to make it say something.');
  L.push('- **The instrument table is hand written, so a new instrument can arrive unlisted.**');
  L.push('  `gate/instruments` fails when an instrument in the table has no fault. It cannot fail');
  L.push('  when a tool under `tools/` is an instrument and nobody added it to the table. Four tools');
  L.push('  are in that position today and each is named rather than left to be discovered.');
  L.push('  `uicompare.mjs` is the independent witness that holds the page\'s self report against an');
  L.push('  accessibility tree; the fault that would prove it is a page that lies about itself,');
  L.push('  which cannot be injected from Node. `check-island.mjs` runs eighteen identities against');
  L.push('  the world\'s physics. `check-crossings.mjs` runs forty checks over the crossings pack and');
  L.push('  the crossings system. `connections.mjs` answers whether a bus meets a boat, and board');
  L.push('  note 033 names the fault that would prove it: a bus call whose `pickupType` says no');
  L.push('  pickup counted as a connection, which would report a boat as met by a bus nobody can');
  L.push('  board.');
  L.push('- **`check-crossings.mjs` was watched not seeing a timetable drift, which is why');
  L.push('  `gate/ground-truth` exists.** A copy of the tree was taken, one middle row of the SeaLink');
  L.push('  vehicle Departs Cleveland column was moved five minutes, and `node');
  L.push('  tools/check-crossings.mjs` reported all forty checks passing. Its window checks read the');
  L.push('  first and last row of a column, its rotation checks read vessel codes, and its movement');
  L.push('  checks are row counts, so a middle row is invisible to every one of them. That is not a');
  L.push('  defect in that tool. It is the reason a second one had to own the owner\'s ground truth.');
  L.push('- **A `caught` cell outside the owning column can be a flake rather than a finding.**');
  L.push('  `tools/headless.mjs` fails a run when a tick goes over budget with no collector pause to');
  L.push('  account for it, which its own header calls the operating system taking the thread away,');
  L.push('  and it happens roughly one run in six on a busy machine. This file retries a failing');
  L.push('  non-owning column once and prints both attempts, so a retry is never invisible, but a');
  L.push('  column that fails twice writes `caught` into the matrix for a reason that has nothing to');
  L.push('  do with the fault. If the `headless` column reads `caught` on a row `headless` does not');
  L.push('  own, read the run log before believing it.');
  L.push('');
  return L.join('\n');
}

// ---------------------------------------------------------------------------------------------

async function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n');
    process.exitCode = 2;
    return;
  }
  if (opts.help) {
    process.stdout.write(usage() + '\n');
    return;
  }

  const selected = opts.fault ? FAULTS.filter((f) => f.id === opts.fault) : FAULTS;
  if (!selected.length) {
    process.stderr.write('no fault with id ' + opts.fault + '\n');
    process.exitCode = 2;
    return;
  }

  const before = gitPorcelain();
  if (before === null) {
    process.stderr.write('git could not be asked for the working tree status, so this run cannot '
      + 'prove it left the repository alone. Refusing to continue.\n');
    process.exitCode = 2;
    return;
  }

  const log = [];
  const say = (s) => { log.push(s); if (!opts.json) process.stdout.write(s + '\n'); };

  say('selftest: ' + selected.length + ' fault(s), ' + COLUMNS.length + ' instrument column(s)');
  say('healthy copy: ' + rel(HEALTHY));
  say('');

  copyTree(HEALTHY);
  const base = healthySuite(HEALTHY, opts, say);
  const baseFailures = [...base.entries()].filter(([, v]) => v.failed).map(([k]) => k);
  if (baseFailures.length) {
    say('  the healthy copy already fails: ' + baseFailures.join(', ')
      + '. Every row those columns own is void, because a failure on both sides proves nothing.');
    say('');
  }

  const rows = [];
  for (const fault of selected) {
    const tree = path.join(WORK, fault.id);
    copyTree(tree);
    if (fault.kind === 'tree') {
      if (typeof fault.apply !== 'function') {
        rows.push({ id: fault.id, verdict: 'not proven', note: 'a tree fault with no apply function', cells: {}, owner: fault.instrument, breaks: fault.breaks, blindSpot: fault.blindSpot || null, why: fault.why || '' });
        continue;
      }
      try {
        fault.apply(tree);
      } catch (err) {
        rows.push({ id: fault.id, verdict: 'wrong reason', note: 'the fault could not be applied: ' + err.message, cells: {}, owner: fault.instrument, breaks: fault.breaks, blindSpot: fault.blindSpot || null, why: fault.why || '' });
        continue;
      }
    }

    const healthy = suite(HEALTHY, fault, 'healthy', opts, base, say);
    const faulted = suite(tree, fault, 'faulted', opts, base, say);
    const row = judge(fault, healthy, faulted);
    rows.push(row);

    const owner = row.owner || (row.mustMiss ? 'none, ' + row.mustMiss + ' must miss' : 'none');
    say('  ' + fault.id.padEnd(24) + ' ' + owner.padEnd(30) + ' ' + row.verdict.toUpperCase()
      + (row.note ? '   ' + row.note : ''));
  }

  const green = rows.filter((r) => r.verdict === 'caught' || r.verdict === 'blind spot proven');
  const unproven = rows.filter((r) => r.verdict === 'not proven');
  const bad = rows.filter((r) => r.verdict === 'missed' || r.verdict === 'wrong reason' || r.verdict === 'void');

  say('');
  for (const r of bad) {
    say('NOT GREEN: ' + r.id + '  ' + r.verdict + '  ' + r.note);
    if (r.output) say('    ' + r.output.split('\n').slice(0, 6).join('\n    '));
  }

  const claims = claimDisagreements(rows);
  for (const c of claims) say('CLAIM DISAGREES: ' + c.id + '  ' + c.text);
  const overclaimed = claims.filter((c) => c.kind === 'overclaimed');

  const summary = green.length + ' of ' + rows.length + ' rows green, ' + unproven.length
    + ' not proven, ' + bad.length + ' missed or caught for the wrong reason'
    + (claims.length ? ', ' + claims.length + ' registry claim(s) disagreeing with the run' : '') + '.';
  say('');
  say((bad.length || overclaimed.length ? 'FAIL: ' : 'PASS: ') + summary);

  // The generated file, written only on a full run so a single-fault run cannot truncate the matrix.
  let wrote = null;
  if (!opts.fault) {
    const date = new Date(Date.now()).toISOString().slice(0, 10);
    const text = jurisdiction(rows, { date, summary });
    writeFileSync(path.join(REPO_ROOT, 'docs', 'JURISDICTION.md'), text, 'utf8');
    wrote = 'docs/JURISDICTION.md';
    say('wrote ' + wrote);
  }

  mkdirSync(WORK, { recursive: true });
  writeFileSync(path.join(WORK, 'report.json'), JSON.stringify({ rows, summary }, null, 2), 'utf8');

  if (!opts.keep) {
    for (const fault of selected) rmSync(path.join(WORK, fault.id), { recursive: true, force: true });
    rmSync(HEALTHY, { recursive: true, force: true });
  }

  // The proof that this run left the repository alone.
  const after = gitPorcelain();
  const expected = new Set(before);
  const changed = (after || []).filter((line) => !expected.has(line));
  const allowed = changed.filter((line) => wrote && line.endsWith(wrote));
  const unexpected = changed.filter((line) => !allowed.includes(line));
  say('');
  if (after === null) {
    say('git could not be asked for the status after the run.');
    process.exitCode = 1;
    return;
  }
  if (unexpected.length) {
    say('THIS RUN CHANGED THE REPOSITORY:');
    for (const line of unexpected) say('  ' + line);
    process.exitCode = 1;
    return;
  }
  say('git status --porcelain: unchanged apart from ' + (wrote || 'nothing') + '.');

  if (opts.json) {
    process.stdout.write(JSON.stringify({
      rows,
      columns: COLUMNS,
      counts: { green: green.length, unproven: unproven.length, bad: bad.length, total: rows.length },
      claims,
      summary,
      ok: bad.length === 0 && overclaimed.length === 0
    }, null, 2) + '\n');
  }

  process.exitCode = bad.length === 0 && overclaimed.length === 0 ? 0 : 1;
}

main();
