#!/usr/bin/env node
// The interface probe: the half of the build a screenshot structurally cannot see.
//
//     node tools/uiprobe.mjs --assert <name> [--probe <path>] [--expect <path>] [--json]
//     node tools/uiprobe.mjs --show   <name> [--probe <path>] [--json]
//     node tools/uiprobe.mjs --list   [--json]
//
// It reads out/probes/<name>.json, which the running page posted about itself, and checks it
// against the contract in docs/CONTRACT.md section 3 and docs/STAGE-0.md instrument 5:
//
//   every panel has a role and a non empty accessible name,
//   every displayed value carries data-prov naming a record, and data-register,
//   every data-prov resolves to a record in the provenance index,
//   a value the twin does not know shows a contested or unknown marker with a date, never a number.
//
// This is one of two witnesses, and it is the one that can be fooled, because it is the page's own
// account of itself. tools/uicompare.mjs is the other, and it holds this file's report against an
// accessibility tree read from outside the page. Neither replaces the other.
//
// The one design decision worth stating, because board note 009 asked for it as a decision rather
// than a patch. The page's report carries a `resolved` boolean for every citation, computed by the
// page against its own index. This tool does not take it. It builds its own index from disk, three
// kinds of id and no more:
//
//   1. the keys of data/_sources.json,
//   2. the id of every object under data/** that carries all eight provenance fields,
//   3. the two ids the page declares because they did not come out of a pack, each accepted only
//      when the file and field it names is verified present on disk. `kernel-clock-epoch` is the
//      world's epoch constant and `lore-acknowledgement` is a field path into data/lore.json, which
//      is carried from the first build in its own schema and has no record ids.
//
// Resolving against data/** alone would fail both of those, and dropping the check would let the
// page grade its own homework. Verifying the declaration is the third answer: the id is accepted
// and its locator is checked, so an id that stops pointing at anything stops resolving. The tool
// then compares its own answer with the page's `resolved` flag, and a disagreement is a failure in
// its own right: a page that reports a citation resolved when it does not is exactly the failure
// this instrument exists for.
//
// What this tool cannot do today, said here rather than discovered later. The page's self report
// carries panel names and value texts and does not carry the row labels beside the values, so a
// fault that rewrites a row label is invisible to it. --expect compares a probe against a declared
// baseline of panel names, roles, value ids, citations and registers, which catches a changed panel
// name. It cannot catch a changed row label until src/ui/panel.js reports labels.
//
// This build has two baselines, one per page: tools/panels/calibration.json, written by hand from
// src/ui/panel.js and lab.html, and tools/panels/front.json, written by hand from
// src/ui/crossings-view.js and index.html. Each is what tools/scenes/calibration.json is to the
// picture. A baseline is NOT applied
// unless --expect names it, because an instrument that silently applies an expectation is one
// nobody can tell apart from an instrument that has none. A run without it says so in its output,
// and tools/selftest.mjs is expected to pass it the way tools/faults.mjs passes args to headless:
//
//     node tools/uiprobe.mjs --assert <name> --expect tools/panels/calibration.json
//
// Without it the ui-text-change fault passes every rule here, honestly, because a renamed panel is
// wrong in exactly one way and this file's other rules do not check for that one.

import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { REQUIRED_FIELDS, REGISTERS } from '../src/kernel/record.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const PROBES_DIR = path.join(REPO_ROOT, 'out', 'probes');

/** Roles a panel may carry. A container that reports a value has to be findable in the tree. */
const PANEL_ROLES = new Set(['region', 'group', 'main', 'complementary', 'form', 'contentinfo', 'banner']);

const MARKER_PHRASE = 'contested or unknown';

const MONTHS = 'January|February|March|April|May|June|July|August|September|October|November|December';
const READABLE_DATE = new RegExp('\\b\\d{1,2}\\s+(?:' + MONTHS + ')\\s+\\d{4}\\b', 'g');
const ISO_DATE = /\b\d{4}-\d{2}-\d{2}\b/g;

/**
 * Ids the page declares rather than reads out of a pack. Each is accepted only when the thing its
 * locator names is present on disk, so the declaration is checked and not merely trusted.
 */
const PAGE_DECLARED = [
  {
    id: 'kernel-clock-epoch',
    kind: 'kernel constant',
    locator: 'src/kernel/world.js, DEFAULT_EPOCH',
    verify(root) {
      const file = path.join(root, 'src', 'kernel', 'world.js');
      if (!existsSync(file)) return 'src/kernel/world.js does not exist';
      const text = readFileSync(file, 'utf8');
      return /\bDEFAULT_EPOCH\s*=/.test(text) ? null : 'src/kernel/world.js declares no DEFAULT_EPOCH';
    }
  },
  {
    id: 'lore-acknowledgement',
    kind: 'pack wording',
    locator: 'data/lore.json, acknowledgement.game_wording.long.text',
    verify(root) {
      const file = path.join(root, 'data', 'lore.json');
      if (!existsSync(file)) return 'data/lore.json does not exist';
      let pack;
      try {
        pack = JSON.parse(readFileSync(file, 'utf8'));
      } catch (err) {
        return 'data/lore.json is not valid JSON: ' + String((err && err.message) || err);
      }
      const text = pack && pack.acknowledgement && pack.acknowledgement.game_wording
        && pack.acknowledgement.game_wording.long && pack.acknowledgement.game_wording.long.text;
      return typeof text === 'string' && text.trim()
        ? null
        : 'data/lore.json has no acknowledgement.game_wording.long.text';
    }
  }
];

/**
 * Values the twin does not know, and the fact on disk that makes them unknown. A row listed here
 * must show the marker and a date and must not show a number. This is the only rule in the file
 * that reaches past the probe into the data, and it has to: the probe alone cannot tell a value
 * that is honestly absent from a value that was invented.
 */
const UNKNOWN_WHEN = [
  {
    value: 'tide-height',
    why: 'data/tide.json carries no harmonic constituents, so the tide has no height to report',
    locator: 'data/tide.json, constituents',
    unknown(root) {
      const file = path.join(root, 'data', 'tide.json');
      if (!existsSync(file)) return { evaluated: false, why: 'data/tide.json does not exist' };
      let pack;
      try {
        pack = JSON.parse(readFileSync(file, 'utf8'));
      } catch (err) {
        return { evaluated: false, why: 'data/tide.json is not valid JSON: ' + String((err && err.message) || err) };
      }
      const list = Array.isArray(pack.constituents) ? pack.constituents : [];
      return { evaluated: true, unknown: list.length === 0, detail: list.length + ' constituents on disk' };
    }
  }
];

function usage() {
  return [
    'node tools/uiprobe.mjs --assert <name> [--probe <path>] [--expect <path>] [--json]',
    'node tools/uiprobe.mjs --show   <name> [--probe <path>] [--json]',
    'node tools/uiprobe.mjs --list   [--json]',
    '',
    '  --assert <name>   check out/probes/<name>.json against the contract',
    '  --show <name>     print what the page reported, and give no verdict',
    '  --list            the probes on disk',
    '  --probe <path>    a probe file somewhere other than out/probes/<name>.json',
    '  --expect <path>   also check the probe against a declared baseline of panels and citations.',
    '                    This build has two: tools/panels/calibration.json for lab.html and',
    '                    tools/panels/front.json for the front page. It is the only rule that',
    '                    can see a renamed panel, and it is off unless it is named.',
    '  --json            machine readable output on stdout, nothing else',
    '',
    'Exit code is 0 when every rule holds, 1 when one fails, 2 on a usage or read error.'
  ].join('\n');
}

function rel(abs) {
  return path.relative(REPO_ROOT, abs).split('\\').join('/');
}

function probeFile(nameOrPath) {
  if (nameOrPath.endsWith('.json') || nameOrPath.includes('/') || nameOrPath.includes('\\')) {
    return path.resolve(nameOrPath);
  }
  return path.join(PROBES_DIR, nameOrPath + '.json');
}

/** A selector that names the offending element without assuming how the page builds its ids. */
function selector(panelId, valueId) {
  const panel = '[data-panel="' + panelId + '"]';
  return valueId ? panel + ' [data-value="' + valueId + '"]' : panel;
}

// ---------------------------------------------------------------------------------------------
// The provenance index, built from disk rather than taken from the page.
// ---------------------------------------------------------------------------------------------

function jsonFilesUnder(dir) {
  const out = [];
  const visit = (at, prefix) => {
    let entries;
    try {
      entries = readdirSync(at, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const here = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) visit(path.join(at, e.name), here);
      else if (e.isFile() && e.name.toLowerCase().endsWith('.json')) out.push({ abs: path.join(at, e.name), rel: here });
    }
  };
  visit(dir, '');
  return out;
}

/** Every object in a pack that is a record: a string id, and all eight provenance fields. */
function recordIdsIn(node, into, where) {
  if (Array.isArray(node)) {
    for (const item of node) recordIdsIn(item, into, where);
    return;
  }
  if (!node || typeof node !== 'object') return;
  if (typeof node.id === 'string' && REQUIRED_FIELDS.every((f) => f in node)) {
    if (!into.has(node.id)) into.set(node.id, { id: node.id, kind: 'record', locator: where });
  }
  for (const key of Object.keys(node)) recordIdsIn(node[key], into, where);
}

export function buildIndex(root = REPO_ROOT) {
  const index = new Map();
  const problems = [];

  const sourcesFile = path.join(root, 'data', '_sources.json');
  if (existsSync(sourcesFile)) {
    try {
      const sources = JSON.parse(readFileSync(sourcesFile, 'utf8'));
      for (const id of Object.keys(sources)) {
        index.set(id, { id, kind: 'source', locator: 'data/_sources.json, key ' + id });
      }
    } catch (err) {
      problems.push('data/_sources.json is not valid JSON: ' + String((err && err.message) || err));
    }
  } else {
    problems.push('data/_sources.json does not exist, so no source id can resolve');
  }

  const dataDir = path.join(root, 'data');
  if (existsSync(dataDir)) {
    for (const file of jsonFilesUnder(dataDir)) {
      if (file.rel === '_sources.json') continue;
      let pack;
      try {
        pack = JSON.parse(readFileSync(file.abs, 'utf8'));
      } catch (err) {
        problems.push('data/' + file.rel + ' is not valid JSON: ' + String((err && err.message) || err));
        continue;
      }
      recordIdsIn(pack, index, 'a record in data/' + file.rel);
    }
  }

  const declared = [];
  for (const entry of PAGE_DECLARED) {
    const why = entry.verify(root);
    declared.push({ id: entry.id, kind: entry.kind, locator: entry.locator, ok: why === null, why });
    if (why === null) index.set(entry.id, { id: entry.id, kind: entry.kind, locator: entry.locator });
  }

  return { index, problems, declared };
}

// ---------------------------------------------------------------------------------------------
// Reading the probe.
// ---------------------------------------------------------------------------------------------

export function loadProbe(file) {
  let raw;
  try {
    raw = readFileSync(file, 'utf8');
  } catch (err) {
    throw new Error('the probe ' + rel(file) + ' could not be read: ' + String((err && err.message) || err)
      + '\nThe running page writes it: ISLAND.probe(\'<name>\') posts to the app server on 4281.');
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new Error(rel(file) + ' is not valid JSON: ' + String((err && err.message) || err));
  }
  if (!parsed || !Array.isArray(parsed.panels)) {
    throw new Error(rel(file) + ' has no panels array, so it is not an interface probe.');
  }
  for (const panel of parsed.panels) {
    if (!panel || typeof panel.id !== 'string' || !Array.isArray(panel.values)) {
      throw new Error(rel(file) + ' holds a panel without an id and a values array.');
    }
  }
  if (!Array.isArray(parsed.provenanceIndex)) parsed.provenanceIndex = [];
  return { file, report: parsed };
}

// ---------------------------------------------------------------------------------------------
// The rules.
// ---------------------------------------------------------------------------------------------

function hasDate(text) {
  READABLE_DATE.lastIndex = 0;
  ISO_DATE.lastIndex = 0;
  return READABLE_DATE.test(text) || ISO_DATE.test(text);
}

function withoutDates(text) {
  return String(text).replace(READABLE_DATE, ' ').replace(ISO_DATE, ' ');
}

export function assertProbe({ file, expectFile = null, root = REPO_ROOT } = {}) {
  const { report } = loadProbe(file);
  const built = buildIndex(root);
  const rules = [];
  const add = (id, what, failures, counted) => {
    rules.push({ id, what, ok: failures.length === 0, failures, counted });
  };

  const panels = report.panels;
  const values = [];
  for (const panel of panels) for (const value of panel.values) values.push({ panel, value });

  // 1. Every panel has a role, from the set a container that reports a value may carry.
  add('panel-role', 'panels carry a role from the known set',
    panels.filter((p) => !PANEL_ROLES.has(String(p.role || '')))
      .map((p) => ({
        element: selector(p.id),
        detail: p.role ? 'role "' + p.role + '" is not one a panel may carry' : 'no role at all'
      })),
    panels.length);

  // 2. Every panel has a non empty accessible name. An empty one is invisible in a screen reader
  //    and identical on screen, which is why only this instrument can see it.
  add('panel-name', 'panels carry a non empty accessible name',
    panels.filter((p) => !String(p.accessibleName || '').trim())
      .map((p) => ({
        element: selector(p.id),
        detail: 'accessibleName is empty. Its heading is still on screen, so the picture is '
          + 'unchanged and the tree is not.'
      })),
    panels.length);

  // 3. Every displayed value carries data-prov. The contract's floor is every number; this tool
  //    holds every displayed value to it, because a value that cannot say where it came from does
  //    not belong on the screen whether or not it happens to contain a digit.
  add('value-prov', 'displayed values carry data-prov',
    values.filter(({ value }) => !String(value.prov || '').trim())
      .map(({ panel, value }) => ({
        element: selector(panel.id, value.id),
        detail: 'no data-prov'
          + (/\d/.test(String(value.text || '')) ? ', and the text shows a number: "' + value.text + '"' : '')
      })),
    values.length);

  // 4. Every displayed value carries a register, from the four in the record type.
  add('value-register', 'displayed values carry a register from the four in src/kernel/record.js',
    values.filter(({ value }) => !REGISTERS.includes(String(value.register || '')))
      .map(({ panel, value }) => ({
        element: selector(panel.id, value.id),
        detail: value.register
          ? 'register "' + value.register + '" is not one of ' + REGISTERS.join(', ')
          : 'no data-register'
      })),
    values.length);

  // 5. Every citation resolves in the index built from disk.
  const resolvedByTool = new Map();
  for (const { panel, value } of values) {
    const prov = String(value.prov || '');
    resolvedByTool.set(panel.id + '/' + value.id, prov !== '' && built.index.has(prov));
  }
  add('prov-resolves', 'citations resolve in the index built from data/** and the declared page ids',
    values.filter(({ panel, value }) => String(value.prov || '') !== ''
      && !resolvedByTool.get(panel.id + '/' + value.id))
      .map(({ panel, value }) => ({
        element: selector(panel.id, value.id),
        detail: 'cites "' + value.prov + '", which is not a source in data/_sources.json, not a '
          + 'record id under data/**, and not one of the declared page ids '
          + PAGE_DECLARED.map((d) => d.id).join(' and ')
      })),
    values.filter(({ value }) => String(value.prov || '') !== '').length);

  // 6. The page's own resolved flag agrees with the independent answer. A page that marks its own
  //    citation resolved when it is not is the failure this instrument exists for.
  add('self-report-agrees', 'the page resolved flags agree with the independent resolution',
    values.filter(({ panel, value }) => typeof value.resolved === 'boolean'
      && value.resolved !== resolvedByTool.get(panel.id + '/' + value.id))
      .map(({ panel, value }) => ({
        element: selector(panel.id, value.id),
        detail: 'the page reports resolved ' + value.resolved + ' for "' + value.prov
          + '" and this tool resolves it ' + resolvedByTool.get(panel.id + '/' + value.id)
          + ' against disk'
      })),
    values.filter(({ value }) => typeof value.resolved === 'boolean').length);

  // 7. Every id in the page's own index resolves on disk. An index that carries an id nothing
  //    backs is how a resolved flag gets to be true for nothing.
  add('index-sound', 'ids in the page provenance index resolve on disk',
    report.provenanceIndex.filter((id) => !built.index.has(id))
      .map((id) => ({
        element: 'ISLAND.provenance()',
        detail: 'the page index carries "' + id + '", which does not resolve against data/** or a '
          + 'declared page id'
      })),
    report.provenanceIndex.length);

  // 8. A value the twin does not know shows the marker and a date, and never a number.
  const unknownFailures = [];
  let unknownCounted = 0;
  const unknownNotes = [];
  for (const rule of UNKNOWN_WHEN) {
    const state = rule.unknown(root);
    if (!state.evaluated) {
      unknownNotes.push(rule.value + ': not evaluated, ' + state.why);
      continue;
    }
    if (!state.unknown) {
      unknownNotes.push(rule.value + ': the twin knows this value now (' + state.detail
        + '), so the marker is not required');
      continue;
    }
    const found = values.filter(({ value }) => value.id === rule.value);
    if (found.length === 0) {
      unknownNotes.push(rule.value + ': not on this page, so nothing to check');
      continue;
    }
    for (const { panel, value } of found) {
      unknownCounted++;
      const text = String(value.text || '');
      if (!text.toLowerCase().includes(MARKER_PHRASE)) {
        unknownFailures.push({
          element: selector(panel.id, value.id),
          detail: 'the twin does not know this value (' + rule.why + ', ' + rule.locator
            + ') and the page shows "' + text + '". The honest display is a contested or unknown '
            + 'marker with a date.'
        });
        continue;
      }
      if (!hasDate(text)) {
        unknownFailures.push({
          element: selector(panel.id, value.id),
          detail: 'the marker is there and the date is not: "' + text + '". A marker without a date '
            + 'does not say when the twin last looked.'
        });
      }
    }
  }
  add('unknown-shows-marker', 'values the twin does not know show a marker and a date',
    unknownFailures, unknownCounted);

  // 9. Any marker anywhere is well formed: a date, and no number once the date is taken out.
  const markers = values.filter(({ value }) => String(value.text || '').toLowerCase().includes(MARKER_PHRASE));
  add('marker-well-formed', 'markers carry a date and no number',
    markers.filter(({ value }) => !hasDate(String(value.text || ''))
      || /\d/.test(withoutDates(String(value.text || ''))))
      .map(({ panel, value }) => ({
        element: selector(panel.id, value.id),
        detail: !hasDate(String(value.text || ''))
          ? 'the marker carries no date: "' + value.text + '"'
          : 'the marker carries a number as well as the marker: "' + value.text + '". A marker and a '
            + 'number in one value is the worst of both, because a reader takes the number.'
      })),
    markers.length);

  // 10. The declared baseline, when one is given. This is the only rule that can see a changed
  //     panel name, because a changed name is honest in every other respect.
  let expect = null;
  if (expectFile) {
    expect = loadExpect(expectFile);
    const failures = [];
    for (const want of expect.panels) {
      const got = panels.find((p) => p.id === want.id);
      if (!got) {
        failures.push({ element: selector(want.id), detail: 'the baseline declares this panel and the page does not report it' });
        continue;
      }
      if (typeof want.accessibleName === 'string' && want.accessibleName !== got.accessibleName) {
        failures.push({
          element: selector(want.id),
          detail: 'accessibleName is "' + got.accessibleName + '" and the baseline declares "'
            + want.accessibleName + '"'
        });
      }
      if (typeof want.role === 'string' && want.role !== got.role) {
        failures.push({ element: selector(want.id), detail: 'the role is "' + got.role + '" and the baseline declares "' + want.role + '"' });
      }
      for (const wantValue of want.values || []) {
        const gotValue = got.values.find((v) => v.id === wantValue.id);
        if (!gotValue) {
          failures.push({ element: selector(want.id, wantValue.id), detail: 'the baseline declares this value and the page does not report it' });
          continue;
        }
        for (const field of ['prov', 'register']) {
          if (typeof wantValue[field] === 'string' && wantValue[field] !== gotValue[field]) {
            failures.push({
              element: selector(want.id, wantValue.id),
              detail: field + ' is "' + gotValue[field] + '" and the baseline declares "' + wantValue[field] + '"'
            });
          }
        }
      }
    }
    for (const panel of panels) {
      if (!expect.panels.some((p) => p.id === panel.id)) {
        failures.push({ element: selector(panel.id), detail: 'the page reports this panel and the baseline does not declare it' });
      }
    }
    add('matches-baseline', 'panels and citations match the declared baseline ' + rel(expect.file),
      failures, expect.panels.length);
  }

  const failures = rules.reduce((n, r) => n + r.failures.length, 0);
  return {
    mode: 'assert',
    file: rel(file),
    name: report.name || null,
    tick: typeof report.tick === 'number' ? report.tick : null,
    renderPath: report.renderPath || null,
    fault: report.fault || null,
    panels: panels.length,
    values: values.length,
    indexBuilt: built.index.size,
    indexProblems: built.problems,
    declared: built.declared,
    unknownNotes,
    expect: expect ? rel(expect.file) : null,
    rules,
    failures,
    ok: failures === 0
  };
}

function loadExpect(file) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error('the baseline ' + rel(file) + ' could not be read: ' + String((err && err.message) || err));
  }
  if (!parsed || !Array.isArray(parsed.panels)) {
    throw new Error(rel(file) + ' needs a panels array of { id, role, accessibleName, values }.');
  }
  return { file, panels: parsed.panels };
}

export function showProbe({ file }) {
  const { report } = loadProbe(file);
  return {
    mode: 'show',
    file: rel(file),
    name: report.name || null,
    tick: typeof report.tick === 'number' ? report.tick : null,
    renderPath: report.renderPath || null,
    fault: report.fault || null,
    panels: report.panels,
    provenanceIndex: report.provenanceIndex,
    ok: true
  };
}

export function listProbes() {
  let names = [];
  try {
    names = readdirSync(PROBES_DIR)
      .filter((n) => n.toLowerCase().endsWith('.json') && !n.toLowerCase().endsWith('.axtree.json'))
      .sort();
  } catch {
    names = [];
  }
  return {
    mode: 'list',
    dir: rel(PROBES_DIR),
    probes: names.map((n) => {
      const abs = path.join(PROBES_DIR, n);
      let panels = null;
      let fault = null;
      let what = 'an interface probe';
      try {
        const parsed = JSON.parse(readFileSync(abs, 'utf8'));
        fault = parsed.fault || null;
        if (Array.isArray(parsed.panels)) {
          panels = parsed.panels.length;
        } else if (Array.isArray(parsed.samples)) {
          // The bench sink writes here too. Saying so beats calling a readable file unreadable.
          what = 'a frame series, ' + parsed.samples.length + ' samples: tools/bench.mjs reads it';
        } else {
          what = 'JSON with no panels array, so not an interface probe';
        }
      } catch (err) {
        what = 'not valid JSON: ' + String((err && err.message) || err);
      }
      return { file: rel(abs), bytes: statSync(abs).size, panels, fault, what };
    }),
    ok: true
  };
}

// ---------------------------------------------------------------------------------------------
// Output.
// ---------------------------------------------------------------------------------------------

function printAssert(result) {
  const lines = [];
  lines.push('interface probe ' + result.file
    + '   tick ' + (result.tick === null ? 'unknown' : result.tick)
    + ', render path ' + (result.renderPath || 'unknown')
    + ', fault ' + (result.fault || 'none'));
  lines.push('  provenance index built from disk: ' + result.indexBuilt + ' ids');
  for (const d of result.declared) {
    lines.push('    page declared ' + d.id + '  ' + (d.ok ? 'verified at ' + d.locator : 'REFUSED: ' + d.why));
  }
  for (const p of result.indexProblems) lines.push('    ' + p);
  lines.push('');

  for (const rule of result.rules) {
    const head = '  ' + (rule.ok ? 'PASS' : 'FAIL') + ' ' + rule.id.padEnd(22)
      + (rule.ok
        ? rule.counted + ' checked, ' + rule.what
        : rule.failures.length + ' of ' + rule.counted + ' failed, ' + rule.what);
    lines.push(head);
    for (const f of rule.failures) {
      lines.push('       ' + f.element);
      lines.push('         ' + f.detail);
    }
  }

  if (result.unknownNotes.length) {
    lines.push('');
    for (const n of result.unknownNotes) lines.push('  note  ' + n);
  }

  if (!result.expect) {
    lines.push('');
    lines.push('  note  no baseline was given, so a renamed panel is not checked here. That is the '
      + 'one defect');
    lines.push('        these rules cannot see, because a renamed panel keeps its role, its name, '
      + 'its citation');
    lines.push('        and its register. Add --expect tools/panels/calibration.json.');
  }

  lines.push('');
  if (result.ok) {
    lines.push('PASS: ' + result.rules.length + ' rules, 0 failures, over ' + result.panels
      + ' panels and ' + result.values + ' values.');
  } else {
    const named = result.rules.filter((r) => !r.ok).map((r) => r.id).join(', ');
    lines.push('FAIL: ' + result.failures + ' failure' + (result.failures === 1 ? '' : 's')
      + ' in ' + named + ', over ' + result.panels + ' panels and ' + result.values + ' values.');
  }
  return lines.join('\n');
}

function printShow(result) {
  const lines = [];
  lines.push('interface probe ' + result.file
    + '   tick ' + (result.tick === null ? 'unknown' : result.tick)
    + ', render path ' + (result.renderPath || 'unknown')
    + ', fault ' + (result.fault || 'none'));
  lines.push('');
  for (const panel of result.panels) {
    lines.push('  ' + (panel.role || 'no role') + '  ' + panel.id
      + '   name: ' + (panel.accessibleName ? '"' + panel.accessibleName + '"' : 'EMPTY'));
    for (const v of panel.values) {
      lines.push('      ' + String(v.id).padEnd(16) + (v.register || 'no register').padEnd(12)
        + (v.prov || 'no data-prov') + (v.resolved === false ? '  (page says unresolved)' : ''));
      lines.push('        ' + String(v.text || '').slice(0, 140));
    }
  }
  lines.push('');
  lines.push('  page provenance index, ' + result.provenanceIndex.length + ' ids: '
    + result.provenanceIndex.join(', '));
  lines.push('');
  lines.push('SHOW: no verdict. Run --assert to check against the contract.');
  return lines.join('\n');
}

function printList(result) {
  const lines = ['probes in ' + result.dir];
  if (result.probes.length === 0) lines.push('  none. The running page writes them with ISLAND.probe().');
  for (const p of result.probes) {
    lines.push('  ' + p.file.padEnd(40) + String(p.bytes).padStart(7) + ' bytes   '
      + (p.panels === null ? p.what : p.panels + ' panels')
      + (p.fault ? '   fault ' + p.fault : ''));
  }
  return lines.join('\n');
}

function main() {
  const argv = process.argv.slice(2);
  const json = argv.includes('--json');
  const args = argv.filter((a) => a !== '--json');

  const value = (flag) => {
    const i = args.indexOf(flag);
    if (i === -1) return null;
    const next = args[i + 1];
    return next && !next.startsWith('--') ? next : null;
  };

  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    process.stdout.write(usage() + '\n');
    process.exitCode = args.length === 0 ? 2 : 0;
    return;
  }

  let result;
  try {
    if (args.includes('--list')) {
      result = listProbes();
    } else if (args.includes('--assert')) {
      const name = value('--assert');
      const override = value('--probe');
      if (!name && !override) throw new Error('--assert needs a probe name\n\n' + usage());
      const expect = value('--expect');
      result = assertProbe({
        file: override ? path.resolve(override) : probeFile(name),
        expectFile: expect ? path.resolve(expect) : null
      });
    } else if (args.includes('--show')) {
      const name = value('--show');
      const override = value('--probe');
      if (!name && !override) throw new Error('--show needs a probe name\n\n' + usage());
      result = showProbe({ file: override ? path.resolve(override) : probeFile(name) });
    } else {
      throw new Error('unknown arguments: ' + args.join(' ') + '\n\n' + usage());
    }
  } catch (err) {
    if (json) {
      process.stdout.write(JSON.stringify({ ok: false, error: String(err.message || err) }, null, 2) + '\n');
    } else {
      process.stderr.write(String(err.message || err) + '\n');
    }
    process.exitCode = 2;
    return;
  }

  if (json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } else {
    const text = result.mode === 'assert' ? printAssert(result)
      : result.mode === 'show' ? printShow(result)
        : printList(result);
    process.stdout.write(text + '\n');
  }
  process.exitCode = result.ok ? 0 : 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main();
}
