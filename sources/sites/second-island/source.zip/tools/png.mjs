// Reading a PNG, far enough to sample a pixel and no further.
//
// The screenshot instrument is worth nothing unless something can open the file and say what
// colour a given pixel is. This module is that something. It is deliberately small: it decodes
// the shape of PNG that a canvas produces and refuses everything else loudly, because a decoder
// that guesses at a format it does not support returns pixels that are wrong rather than an error
// that is right.
//
// What is supported, and why that is the right subset:
//
//   8 bit samples, non interlaced, colour type 2 (RGB) and colour type 6 (RGBA).
//
// `canvas.toDataURL('image/png')` emits colour type 6 at 8 bits per sample with no interlacing,
// in every browser engine. Colour type 2 is added because tools that strip a fully opaque alpha
// channel produce it, and a shot that lost its alpha on the way to disk should still be readable.
// Palettes, 16 bit samples, greyscale and Adam7 interlacing throw with the value that was found
// and the list of values that are handled.
//
// Chunk CRCs are verified. That costs almost nothing and it is what turns "the file decoded" into
// "the file is intact", which matters when the bytes arrived over a socket. It also means the CRC
// implementation in this file is checked against every PNG written by something else, which is the
// only independent check a self written codec can get.
//
// Nothing here writes a PNG. tools/png-encode.mjs does that, and it imports the CRC from here so
// the two cannot drift apart.

import { inflateSync } from 'node:zlib';

/** The eight byte signature every PNG starts with. */
export const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

export const COLOUR_TYPE_RGB = 2;
export const COLOUR_TYPE_RGBA = 6;

const COLOUR_TYPE_NAMES = {
  0: 'greyscale',
  2: 'RGB',
  3: 'palette',
  4: 'greyscale with alpha',
  6: 'RGBA'
};

const CRC_TABLE = (() => {
  const table = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[n] = c;
  }
  return table;
})();

/** The PNG flavour of CRC-32, over a buffer or a slice of one. Returns an unsigned 32 bit number. */
export function crc32(buf, start = 0, end = buf.length) {
  let c = -1;
  for (let i = start; i < end; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
}

/** True when the buffer starts with the PNG signature. The cheapest way to reject a non PNG. */
export function isPng(buf) {
  return Buffer.isBuffer(buf) && buf.length >= 8 && buf.subarray(0, 8).equals(PNG_SIGNATURE);
}

/**
 * Split a PNG into its chunks, verifying each CRC.
 * @param {Buffer} buf
 * @returns {{type: string, data: Buffer, offset: number}[]} in file order, ending at IEND
 */
export function readChunks(buf) {
  if (!isPng(buf)) {
    throw new Error('not a PNG: the first eight bytes are ' + [...buf.subarray(0, 8)].join(',')
      + ' and a PNG starts with ' + [...PNG_SIGNATURE].join(','));
  }
  const chunks = [];
  let at = 8;
  while (at < buf.length) {
    if (at + 8 > buf.length) {
      throw new Error('truncated PNG: a chunk header starts at byte ' + at + ' but the file is only '
        + buf.length + ' bytes');
    }
    const length = buf.readUInt32BE(at);
    const type = buf.toString('latin1', at + 4, at + 8);
    const dataStart = at + 8;
    const dataEnd = dataStart + length;
    if (dataEnd + 4 > buf.length) {
      throw new Error('truncated PNG: chunk ' + type + ' at byte ' + at + ' declares ' + length
        + ' bytes of data but only ' + (buf.length - dataStart) + ' bytes remain');
    }
    const declared = buf.readUInt32BE(dataEnd);
    const actual = crc32(buf, at + 4, dataEnd);
    if (declared !== actual) {
      throw new Error('corrupt PNG: chunk ' + type + ' at byte ' + at + ' has CRC 0x'
        + declared.toString(16) + ' but its bytes hash to 0x' + actual.toString(16));
    }
    chunks.push({ type, data: buf.subarray(dataStart, dataEnd), offset: at });
    at = dataEnd + 4;
    if (type === 'IEND') break;
  }
  return chunks;
}

function unsupported(field, found, handled) {
  return new Error('unsupported PNG: ' + field + ' is ' + found + '. This decoder handles '
    + handled + '. It refuses rather than guesses, because a decoder that guesses returns pixels '
    + 'that are wrong instead of an error that is right.');
}

/** The Paeth predictor, from the PNG specification, section 9.4. */
function paeth(a, b, c) {
  const p = a + b - c;
  const pa = Math.abs(p - a);
  const pb = Math.abs(p - b);
  const pc = Math.abs(p - c);
  if (pa <= pb && pa <= pc) return a;
  if (pb <= pc) return b;
  return c;
}

/**
 * Decode a PNG to raw 8 bit samples.
 *
 * @param {Buffer} buffer the whole file
 * @returns {{width: number, height: number, channels: number, data: Buffer, bitDepth: number,
 *   colourType: number, interlace: number}} `data` is width by height by channels bytes, top row
 *   first, no padding and no filter bytes.
 */
export function decodePng(buffer) {
  const buf = Buffer.isBuffer(buffer) ? buffer : Buffer.from(buffer);
  const chunks = readChunks(buf);

  const ihdr = chunks.find((c) => c.type === 'IHDR');
  if (!ihdr) throw new Error('not a usable PNG: no IHDR chunk');
  if (ihdr.data.length !== 13) {
    throw new Error('corrupt PNG: IHDR is ' + ihdr.data.length + ' bytes and must be 13');
  }
  const width = ihdr.data.readUInt32BE(0);
  const height = ihdr.data.readUInt32BE(4);
  const bitDepth = ihdr.data[8];
  const colourType = ihdr.data[9];
  const compression = ihdr.data[10];
  const filterMethod = ihdr.data[11];
  const interlace = ihdr.data[12];

  if (width === 0 || height === 0) {
    throw new Error('corrupt PNG: IHDR declares ' + width + ' by ' + height);
  }
  if (bitDepth !== 8) throw unsupported('bit depth', bitDepth, '8 bit samples only');
  if (colourType !== COLOUR_TYPE_RGB && colourType !== COLOUR_TYPE_RGBA) {
    throw unsupported('colour type', colourType + ' (' + (COLOUR_TYPE_NAMES[colourType] || 'unknown') + ')',
      '2 (RGB) and 6 (RGBA), which is what a canvas emits');
  }
  if (compression !== 0) throw unsupported('compression method', compression, 'method 0, deflate');
  if (filterMethod !== 0) throw unsupported('filter method', filterMethod, 'method 0');
  if (interlace !== 0) throw unsupported('interlace method', interlace, 'method 0, non interlaced');

  const idat = chunks.filter((c) => c.type === 'IDAT').map((c) => c.data);
  if (idat.length === 0) throw new Error('not a usable PNG: no IDAT chunk');

  let raw;
  try {
    raw = inflateSync(Buffer.concat(idat));
  } catch (err) {
    throw new Error('PNG image data did not inflate: ' + (err && err.message ? err.message : err));
  }

  const channels = colourType === COLOUR_TYPE_RGBA ? 4 : 3;
  const stride = width * channels;
  const expected = height * (stride + 1);
  if (raw.length !== expected) {
    throw new Error('corrupt PNG: inflated to ' + raw.length + ' bytes and ' + width + ' by '
      + height + ' at ' + channels + ' channels needs ' + expected);
  }

  const data = Buffer.alloc(height * stride);
  let src = 0;
  for (let y = 0; y < height; y++) {
    const filter = raw[src++];
    const row = y * stride;
    const prev = row - stride;
    for (let i = 0; i < stride; i++) {
      const x = raw[src + i];
      const a = i >= channels ? data[row + i - channels] : 0;
      const b = y > 0 ? data[prev + i] : 0;
      const c = y > 0 && i >= channels ? data[prev + i - channels] : 0;
      let value;
      switch (filter) {
        case 0: value = x; break;
        case 1: value = x + a; break;
        case 2: value = x + b; break;
        case 3: value = x + ((a + b) >> 1); break;
        case 4: value = x + paeth(a, b, c); break;
        default:
          throw new Error('corrupt PNG: scanline ' + y + ' declares filter type ' + filter
            + ' and only 0 to 4 exist');
      }
      data[row + i] = value & 0xff;
    }
    src += stride;
  }

  return { width, height, channels, data, bitDepth, colourType, interlace };
}

/**
 * One pixel, always as four numbers. A colour type 2 image has no alpha, so 255 is returned for it:
 * an opaque pixel is what a missing alpha channel means.
 *
 * @param {{width: number, height: number, channels: number, data: Buffer}} img from decodePng
 * @param {number} x
 * @param {number} y
 * @returns {[number, number, number, number]}
 */
export function pixelAt(img, x, y) {
  if (!Number.isInteger(x) || !Number.isInteger(y)) {
    throw new Error('pixelAt needs integer coordinates, got ' + x + ', ' + y);
  }
  if (x < 0 || y < 0 || x >= img.width || y >= img.height) {
    throw new Error('pixelAt (' + x + ', ' + y + ') is outside a ' + img.width + ' by ' + img.height
      + ' image');
  }
  const i = (y * img.width + x) * img.channels;
  return [img.data[i], img.data[i + 1], img.data[i + 2], img.channels === 4 ? img.data[i + 3] : 255];
}

/** Every pixel as RGBA, whatever the source channel count. Useful for a round trip comparison. */
export function toRgba(img) {
  if (img.channels === 4) return Buffer.from(img.data);
  const out = Buffer.alloc(img.width * img.height * 4);
  for (let p = 0; p < img.width * img.height; p++) {
    out[p * 4] = img.data[p * 3];
    out[p * 4 + 1] = img.data[p * 3 + 1];
    out[p * 4 + 2] = img.data[p * 3 + 2];
    out[p * 4 + 3] = 255;
  }
  return out;
}
