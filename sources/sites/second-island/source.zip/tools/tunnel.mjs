// The tunnel instrument. Lay a network, see what it costs in time and what it yields in material.
//
//   node tools/tunnel.mjs                       the starting network, at the default bore
//   node tools/tunnel.mjs --bore 2.5            two abreast, which is the top of what people need
//   node tools/tunnel.mjs --machines 2          two boring machines working at once
//   node tools/tunnel.mjs --sinuosity 1.3       how much longer the alignment is than the line
//   node tools/tunnel.mjs --loop 2000           the Dunwich park and ride loop, metres around
//   node tools/tunnel.mjs --json
//
// The route below is a starting position, not a proposal. It is here so the thing exists and can be
// moved. The owner's instruction on 19 August 2026 when asked what order the legs should be built
// in: "who cares what order. its a game engine." So the legs are parameters and the network is
// meant to be redrawn.

import { SANDWORM, PLACES, BORE_BANDS, segment, network, picture, networkForSpoil } from '../src/world/tunnels.js';

const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf('--' + name);
  if (i < 0) return fallback;
  const v = args[i + 1];
  return v && !v.startsWith('--') ? Number(v) : true;
};
const JSON_ONLY = args.includes('--json');
const say = (...a) => { if (!JSON_ONLY) console.log(...a); };

const bore = flag('bore', SANDWORM.boreDefaultM);
const machines = flag('machines', 1);
const sinuosity = flag('sinuosity', 1.25);
const loopM = flag('loop', 2000);

const segs = [
  segment({ id: 'dunwich-park-and-ride', purpose: 'park and ride loop', lengthM: loopM, boreM: bore }),
  segment({ id: 'dunwich-amity', from: PLACES.dunwich, to: PLACES.amityPoint, boreM: bore, sinuosity }),
  segment({ id: 'dunwich-point-lookout', from: PLACES.dunwich, to: PLACES.pointLookout, boreM: bore, sinuosity }),
  segment({ id: 'amity-point-lookout', from: PLACES.amityPoint, to: PLACES.pointLookout, boreM: bore, sinuosity })
];
const net = network(segs, { machines });

if (JSON_ONLY) {
  console.log(JSON.stringify({ parameters: { bore, machines, sinuosity, loopM }, segments: segs, network: net, picture: picture(net.spoilVolumeM3) }, null, 2));
  process.exit(0);
}

say('TUNNEL NETWORK, starting position\n');
say(`  bore ${bore} m, sinuosity ${sinuosity}, ${machines} machine(s)`);
say(`  parameters from ${SANDWORM.source}`);
say(`  advance ${SANDWORM.advanceMetresPerWeek} m a week, forming factor ${SANDWORM.formingFactor}\n`);

say('  segment'.padEnd(28) + 'line'.padStart(9) + 'bored'.padStart(10) + 'spoil m3'.padStart(12) + 'weeks'.padStart(9));
for (const s of segs) {
  say('  ' + s.id.padEnd(26)
    + (s.straightLineM ? (s.straightLineM / 1000).toFixed(2) + ' km' : '     -').padStart(9)
    + ((s.lengthM / 1000).toFixed(2) + ' km').padStart(10)
    + Math.round(s.spoilVolumeM3).toLocaleString().padStart(12)
    + s.boringWeeks.toFixed(1).padStart(9));
}
say('  ' + 'TOTAL'.padEnd(26) + ' '.repeat(9) + (net.lengthKm.toFixed(2) + ' km').padStart(10)
  + Math.round(net.spoilVolumeM3).toLocaleString().padStart(12) + net.boringWeeks.toFixed(1).padStart(9));

say(`\n  boring time ${net.boringWeeks.toFixed(0)} weeks, ${net.boringYears.toFixed(1)} years at ${machines} machine(s)`);

const p = picture(net.spoilVolumeM3);
say('\nWHAT THE SPOIL IS, in something a person can picture\n');
say(`  ${Math.round(net.spoilVolumeM3).toLocaleString()} cubic metres of sand`);
say(`  ${p.olympicPools.toFixed(1)} Olympic swimming pools`);
say(`  ${Math.round(p.shippingContainers).toLocaleString()} forty-foot shipping containers`);
say(`  ${Math.round(p.tipperTruckLoads).toLocaleString()} tipper truck loads`);

say('\n  This is a budget, not an allocation. What it becomes, in the owner\'s order: bus shelters,');
say('  artificial reefs carrying wave and tidal power, oyster reefs, erosion protection, community');
say('  buildings, sand sports courts, sand batteries. This tool does not divide it between them,');
say('  because the conversion rates are not in this repository and inventing them would be worse');
say('  than leaving the budget whole.');

say('\nBORE, AND WHAT IT CARRIES\n');
say('  bore m'.padEnd(10) + 'spoil m3'.padStart(14) + 'pools'.padStart(8) + '   seats');
for (const b of BORE_BANDS) {
  const n = network(segs.map((s) => segment({ id: s.id, lengthM: s.lengthM, boreM: b.m })), { machines });
  say('  ' + String(b.m).padEnd(8) + Math.round(n.spoilVolumeM3).toLocaleString().padStart(14)
    + picture(n.spoilVolumeM3).olympicPools.toFixed(0).padStart(8) + '   ' + b.seats + (b.note ? ', ' + b.note : ''));
}

say('\nTHE INVERSION. Fix the material, and a smaller bore buys network by the square.\n');
const budget = network(segs.map((s) => segment({ id: s.id, lengthM: s.lengthM, boreM: 5 })), { machines }).spoilVolumeM3;
const ROAD_KM = 591.4; // OSM road centreline on this island, fetched 19 August 2026
say('  budget: the spoil this network yields at a 5 m bore, ' + Math.round(budget).toLocaleString() + ' m3\n');
say('  bore m'.padEnd(10) + 'network for that same spoil'.padStart(28) + '   share of the island road network');
for (const b of BORE_BANDS) {
  const km = networkForSpoil(budget, b.m) / 1000;
  say('  ' + String(b.m).padEnd(8) + (km.toFixed(0) + ' km').padStart(28) + '   ' + (100 * km / ROAD_KM).toFixed(0) + ' per cent of ' + ROAD_KM + ' km');
}
say('\n  Boring wide to harvest material is backwards. Bore what a seated person needs and the');
say('  material arrives anyway, spread across more network and therefore more destinations.');
say('  Advance is held at the declared rate for every bore, so small-bore weeks are a ceiling:');
say('  a smaller machine almost certainly advances faster and the real rate is not in here.');

say('\nWHAT THIS TOOL DOES NOT KNOW');
say('  the alignment. Sinuosity is a multiplier on a straight line, set by --sinuosity, and a real');
say('    route follows ground, water table, tenure and Country, none of which are in here.');
say('  the geotechnics. Board note: sand island hydrogeology is not in this repository.');
say('  what a metre of tunnel costs, and what a cubic metre of spoil is worth as product.');
say('  Each of those is a real gap and none of them stop the network existing and being moved.');
