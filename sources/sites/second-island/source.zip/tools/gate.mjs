#!/usr/bin/env node
// The gate: every rule in docs/CONTRACT.md that can execute.
//
// The contract's rule zero is that a rule which is not in the gate does not exist. This file is the
// runner, and it is deliberately thin: it finds the check modules, gives each one a root to look at,
// and prints what they found. All judgement lives in tools/gate/*.mjs, one file per rule, so a rule
// can be added without touching the runner and a broken rule cannot take the others down with it.
//
//     node tools/gate.mjs
//     node tools/gate.mjs --rule style
//     node tools/gate.mjs --root out/gate-proof
//     node tools/gate.mjs --json
//
// Two things here are load bearing.
//
// The modules are loaded from THIS file's own directory, never from the root under test. The gate is
// the instrument and the root is the subject: pointing the gate at a copy of the tree must not swap
// out the checks as well, or a planted fault could be "caught" by a planted checker.
//
// Every check takes its paths from `root`. Nothing in tools/gate may read process.cwd() or a
// hardcoded repository path, because tools/selftest.mjs proves these checks by copying the tree,
// breaking the copy and pointing the gate at it.
//
// A module that fails to load, or does not export `id` and `run`, or throws while running, is a
// blocking finding under the rule id `gate-loader`. A check that silently does not run is the exact
// failure this repository exists to avoid, so it is never silent.

import { readdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const MODULE_DIR = path.join(HERE, 'gate');

const SEVERITIES = new Set(['blocking', 'advisory']);

function usage() {
  return [
    'node tools/gate.mjs [--rule <id>] [--root <dir>] [--json]',
    '',
    '  --rule <id>   run one check only, by its id or its file name without .mjs',
    '  --root <dir>  the tree to check, default the repository this file lives in',
    '  --json        machine readable output on stdout, nothing else',
    '',
    'Exit code is 1 when any blocking finding exists, 0 otherwise.'
  ].join('\n');
}

function parseArgs(argv) {
  const opts = { rule: null, root: REPO_ROOT, json: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') opts.json = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--rule') opts.rule = argv[++i] ?? null;
    else if (a.startsWith('--rule=')) opts.rule = a.slice(7);
    else if (a === '--root') opts.root = argv[++i] ?? opts.root;
    else if (a.startsWith('--root=')) opts.root = a.slice(7);
    else throw new Error('unknown argument: ' + a + '\n\n' + usage());
  }
  opts.root = path.resolve(opts.root);
  return opts;
}

/**
 * Findings arrive from nine separate modules, so the runner normalises rather than trusts. `module`
 * is the module the finding came from and is what the report groups by; `rule` is the module's own
 * name for the specific rule, which is usually finer grained.
 */
function normalise(finding, moduleId) {
  const rule = typeof finding.rule === 'string' && finding.rule ? finding.rule : moduleId;
  const severity = SEVERITIES.has(finding.severity) ? finding.severity : 'blocking';
  const line = Number.isInteger(finding.line) && finding.line > 0 ? finding.line : 0;
  const file = typeof finding.file === 'string' ? finding.file.split('\\').join('/') : '';
  const text = typeof finding.text === 'string' ? finding.text : String(finding.text ?? '');
  const why = typeof finding.why === 'string' ? finding.why : '';
  return { module: moduleId, rule, severity, file, line, text, why };
}

function compare(a, b) {
  if (a.module !== b.module) return a.module < b.module ? -1 : 1;
  if (a.file !== b.file) return a.file < b.file ? -1 : 1;
  if (a.line !== b.line) return a.line - b.line;
  if (a.rule !== b.rule) return a.rule < b.rule ? -1 : 1;
  return a.text < b.text ? -1 : a.text > b.text ? 1 : 0;
}

async function loadModules() {
  let names;
  try {
    names = readdirSync(MODULE_DIR).filter((n) => n.endsWith('.mjs') && !n.startsWith('_')).sort();
  } catch (err) {
    return { loaded: [], problems: [{
      rule: 'gate-loader', severity: 'blocking', file: 'tools/gate', line: 0,
      text: String(err && err.message ? err.message : err),
      why: 'tools/gate/ could not be read, so no rule ran at all.'
    }] };
  }
  const loaded = [];
  const problems = [];
  for (const name of names) {
    const file = path.join(MODULE_DIR, name);
    const rel = 'tools/gate/' + name;
    let mod;
    try {
      mod = await import(pathToFileURL(file).href);
    } catch (err) {
      problems.push({
        rule: 'gate-loader', severity: 'blocking', file: rel, line: 0,
        text: String(err && err.message ? err.message : err),
        why: 'This check module did not load, so its rule did not run.'
      });
      continue;
    }
    if (typeof mod.run !== 'function' || typeof mod.id !== 'string' || !mod.id) {
      problems.push({
        rule: 'gate-loader', severity: 'blocking', file: rel, line: 0,
        text: 'exports id=' + JSON.stringify(mod.id ?? null) + ' run=' + typeof mod.run,
        why: 'A check module must export a string `id` and a function `run({ root })`.'
      });
      continue;
    }
    loaded.push({ id: mod.id, stem: name.replace(/\.mjs$/, ''), file: rel, run: mod.run });
  }
  loaded.sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
  return { loaded, problems };
}

async function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n');
    process.exitCode = 2;
    return;
  }
  if (opts.help) {
    process.stdout.write(usage() + '\n');
    return;
  }

  const { loaded, problems } = await loadModules();
  const selected = opts.rule
    ? loaded.filter((m) => m.id === opts.rule || m.stem === opts.rule)
    : loaded;

  const findings = [...problems.map((p) => normalise(p, 'gate-loader'))];
  const ran = [];

  if (opts.rule && selected.length === 0) {
    findings.push(normalise({
      rule: 'gate-loader', severity: 'blocking', file: 'tools/gate', line: 0,
      text: '--rule ' + opts.rule,
      why: 'No check module has that id. Loaded ids: ' + (loaded.map((m) => m.id).join(', ') || 'none')
    }, 'gate-loader'));
  }

  for (const mod of selected) {
    let result;
    try {
      result = await mod.run({ root: opts.root });
    } catch (err) {
      findings.push(normalise({
        rule: mod.id, severity: 'blocking', file: mod.file, line: 0,
        text: String(err && err.stack ? err.stack.split('\n')[0] : err),
        why: 'The check threw instead of reporting. A rule that cannot run is a rule that does not exist.'
      }, mod.id));
      ran.push({ id: mod.id, ok: false, findings: 0 });
      continue;
    }
    const list = Array.isArray(result && result.findings) ? result.findings : [];
    for (const f of list) findings.push(normalise(f, mod.id));
    ran.push({ id: mod.id, ok: true, findings: list.length });
  }

  findings.sort(compare);
  const blocking = findings.filter((f) => f.severity === 'blocking');
  const advisory = findings.filter((f) => f.severity === 'advisory');

  if (opts.json) {
    process.stdout.write(JSON.stringify({
      root: opts.root.split('\\').join('/'),
      rules: ran,
      counts: { blocking: blocking.length, advisory: advisory.length },
      ok: blocking.length === 0,
      findings
    }, null, 2) + '\n');
  } else {
    const out = [];
    out.push('gate: ' + opts.root.split('\\').join('/'));
    out.push('rules: ' + (ran.map((r) => r.id).join(', ') || 'none loaded'));
    out.push('');
    const byModule = new Map();
    for (const f of findings) {
      if (!byModule.has(f.module)) byModule.set(f.module, []);
      byModule.get(f.module).push(f);
    }
    for (const r of ran) {
      if (r.ok && r.findings === 0) out.push('  ' + r.id.padEnd(14) + 'clean');
    }
    for (const mod of [...byModule.keys()].sort()) {
      const list = byModule.get(mod);
      const b = list.filter((f) => f.severity === 'blocking').length;
      out.push('');
      out.push(mod + ': ' + list.length + ' finding(s), ' + b + ' blocking');
      for (const f of list) {
        const where = f.line > 0 ? f.file + ':' + f.line : f.file;
        out.push('  [' + f.severity + '] ' + f.rule + '  ' + where);
        if (f.text) out.push('      ' + f.text);
        if (f.why) out.push('      why: ' + f.why);
      }
    }
    out.push('');
    out.push(blocking.length === 0
      ? 'PASS: 0 blocking, ' + advisory.length + ' advisory'
      : 'FAIL: ' + blocking.length + ' blocking, ' + advisory.length + ' advisory');
    process.stdout.write(out.join('\n') + '\n');
  }

  process.exitCode = blocking.length === 0 ? 0 : 1;
}

main();
