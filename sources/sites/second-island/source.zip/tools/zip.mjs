// A zip reader, because node:zlib inflates a stream and a zip is a container.
//
// GTFS is published as a zip of CSV files. `zlib.gunzipSync` cannot open one: gzip and zip are
// different formats that share a compression algorithm. What a zip entry holds is a raw deflate
// stream with no gzip header, so `zlib.inflateRawSync` is the right call once you have found the
// bytes. Finding the bytes is what this file does, and it does it with no dependency, because the
// contract allows none.
//
// Scope, stated so nobody assumes more: stored (method 0) and deflated (method 8) entries, which is
// all GTFS uses and all the zip specification requires a reader to support. Zip64 sizes and offsets
// are read where present, because a feed can outgrow four gigabytes and a reader that silently
// truncates an offset is worse than one that refuses. Encryption, multi disk archives and any other
// compression method are refused by name rather than guessed at.
//
// Every entry read is checked against the CRC-32 the archive itself carries. That is the receipt
// that the decompression was right, rather than merely uncomplaining.
//
//     import { openZip } from './zip.mjs';
//     const zip = openZip(readFileSync('feed.zip'));
//     zip.names();                 the entry names, in central directory order
//     zip.read('routes.txt');      a Buffer, CRC checked
//     zip.text('routes.txt');      the same, decoded as UTF-8 with a BOM stripped

import { inflateRawSync } from 'node:zlib';

const SIG_EOCD = 0x06054b50;
const SIG_EOCD64 = 0x06064b50;
const SIG_EOCD64_LOCATOR = 0x07064b50;
const SIG_CENTRAL = 0x02014b50;
const SIG_LOCAL = 0x04034b50;

const METHOD_STORED = 0;
const METHOD_DEFLATE = 8;

const METHOD_NAMES = new Map([
  [0, 'stored'], [1, 'shrunk'], [6, 'imploded'], [8, 'deflate'], [9, 'deflate64'],
  [12, 'bzip2'], [14, 'lzma'], [93, 'zstd'], [95, 'xz'], [98, 'ppmd']
]);

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

/** CRC-32 as the zip specification defines it, returned unsigned. */
export function crc32(buf) {
  let c = 0 ^ -1;
  for (let i = 0; i < buf.length; i++) c = (c >>> 8) ^ CRC_TABLE[(c ^ buf[i]) & 0xff];
  return (c ^ -1) >>> 0;
}

function readU64(buf, off) {
  const v = buf.readBigUInt64LE(off);
  if (v > BigInt(Number.MAX_SAFE_INTEGER)) {
    throw new Error('zip: a 64 bit field exceeds what a JavaScript number can hold exactly: ' + v);
  }
  return Number(v);
}

/**
 * The end of central directory record. It sits at the end of the file behind a comment of up to
 * 65535 bytes, so it is found by scanning backwards for its signature rather than by arithmetic.
 */
function findEocd(buf) {
  const min = 22;
  if (buf.length < min) throw new Error('zip: file is too short to be an archive, ' + buf.length + ' bytes');
  const scanFrom = Math.max(0, buf.length - (0xffff + min));
  for (let i = buf.length - min; i >= scanFrom; i--) {
    if (buf.readUInt32LE(i) !== SIG_EOCD) continue;
    const commentLength = buf.readUInt16LE(i + 20);
    if (i + min + commentLength !== buf.length) continue;
    return i;
  }
  throw new Error('zip: no end of central directory record found. This is not a zip archive, or it is truncated.');
}

/** Zip64 widens the fields the classic record saturates at 0xffff and 0xffffffff. */
function readDirectoryLocation(buf, eocd) {
  let entries = buf.readUInt16LE(eocd + 10);
  let size = buf.readUInt32LE(eocd + 12);
  let offset = buf.readUInt32LE(eocd + 16);
  const saturated = entries === 0xffff || size === 0xffffffff || offset === 0xffffffff;
  if (!saturated) return { entries, size, offset, zip64: false };

  const loc = eocd - 20;
  if (loc < 0 || buf.readUInt32LE(loc) !== SIG_EOCD64_LOCATOR) {
    throw new Error('zip: a field is saturated for zip64 but no zip64 locator sits before the end record');
  }
  const eocd64 = readU64(buf, loc + 8);
  if (eocd64 + 56 > buf.length || buf.readUInt32LE(eocd64) !== SIG_EOCD64) {
    throw new Error('zip: the zip64 locator points at offset ' + eocd64 + ', which is not a zip64 end record');
  }
  entries = readU64(buf, eocd64 + 32);
  size = readU64(buf, eocd64 + 40);
  offset = readU64(buf, eocd64 + 48);
  return { entries, size, offset, zip64: true };
}

/** The zip64 extended information extra field, which only carries the fields that were saturated. */
function applyZip64Extra(extra, entry) {
  let i = 0;
  while (i + 4 <= extra.length) {
    const id = extra.readUInt16LE(i);
    const size = extra.readUInt16LE(i + 2);
    const body = extra.subarray(i + 4, i + 4 + size);
    i += 4 + size;
    if (id !== 0x0001) continue;
    let j = 0;
    if (entry.size === 0xffffffff && j + 8 <= body.length) { entry.size = readU64(body, j); j += 8; }
    if (entry.compressedSize === 0xffffffff && j + 8 <= body.length) { entry.compressedSize = readU64(body, j); j += 8; }
    if (entry.offset === 0xffffffff && j + 8 <= body.length) { entry.offset = readU64(body, j); j += 8; }
  }
}

function parseCentralDirectory(buf, location) {
  const entries = [];
  let p = location.offset;
  const end = location.offset + location.size;
  while (p < end) {
    if (p + 46 > buf.length) throw new Error('zip: the central directory runs past the end of the file');
    if (buf.readUInt32LE(p) !== SIG_CENTRAL) {
      throw new Error('zip: expected a central directory header at offset ' + p);
    }
    const flags = buf.readUInt16LE(p + 8);
    const nameLength = buf.readUInt16LE(p + 28);
    const extraLength = buf.readUInt16LE(p + 30);
    const commentLength = buf.readUInt16LE(p + 32);
    const entry = {
      name: buf.subarray(p + 46, p + 46 + nameLength).toString(flags & 0x800 ? 'utf8' : 'latin1'),
      flags,
      method: buf.readUInt16LE(p + 10),
      crc: buf.readUInt32LE(p + 16),
      compressedSize: buf.readUInt32LE(p + 20),
      size: buf.readUInt32LE(p + 24),
      offset: buf.readUInt32LE(p + 42),
      diskStart: buf.readUInt16LE(p + 34)
    };
    applyZip64Extra(buf.subarray(p + 46 + nameLength, p + 46 + nameLength + extraLength), entry);
    entries.push(entry);
    p += 46 + nameLength + extraLength + commentLength;
  }
  if (location.entries !== entries.length) {
    throw new Error('zip: the end record claims ' + location.entries + ' entries and the directory holds ' + entries.length);
  }
  return entries;
}

function methodName(method) {
  return METHOD_NAMES.get(method) || 'method ' + method;
}

/**
 * Open an archive already in memory. Nothing is decompressed until an entry is read.
 *
 * @param {Buffer} buf
 */
export function openZip(buf) {
  const eocd = findEocd(buf);
  const location = readDirectoryLocation(buf, eocd);
  const entries = parseCentralDirectory(buf, location);
  const byName = new Map(entries.map((e) => [e.name, e]));

  function read(name) {
    const entry = byName.get(name);
    if (!entry) {
      throw new Error('zip: no entry named ' + name + '. The archive holds: ' + entries.map((e) => e.name).join(', '));
    }
    if (entry.flags & 0x0001) throw new Error('zip: entry ' + name + ' is encrypted, which this reader does not open');
    if (entry.diskStart !== 0) throw new Error('zip: entry ' + name + ' lives on disk ' + entry.diskStart + ' of a multi disk archive');
    if (entry.offset + 30 > buf.length || buf.readUInt32LE(entry.offset) !== SIG_LOCAL) {
      throw new Error('zip: entry ' + name + ' does not have a local header at offset ' + entry.offset);
    }
    const nameLength = buf.readUInt16LE(entry.offset + 26);
    const extraLength = buf.readUInt16LE(entry.offset + 28);
    const start = entry.offset + 30 + nameLength + extraLength;
    const raw = buf.subarray(start, start + entry.compressedSize);

    let out;
    if (entry.method === METHOD_STORED) out = Buffer.from(raw);
    else if (entry.method === METHOD_DEFLATE) out = inflateRawSync(raw);
    else throw new Error('zip: entry ' + name + ' uses ' + methodName(entry.method) + ', and this reader opens stored and deflated entries only');

    if (out.length !== entry.size) {
      throw new Error('zip: entry ' + name + ' inflated to ' + out.length + ' bytes and the directory says ' + entry.size);
    }
    const got = crc32(out);
    if (got !== entry.crc) {
      throw new Error('zip: entry ' + name + ' failed its CRC-32 check, got ' + got.toString(16) + ' and the archive says ' + entry.crc.toString(16));
    }
    return out;
  }

  function text(name) {
    const buffer = read(name);
    const s = buffer.toString('utf8');
    return s.charCodeAt(0) === 0xfeff ? s.slice(1) : s;
  }

  return {
    zip64: location.zip64,
    entries,
    names: () => entries.map((e) => e.name),
    has: (name) => byName.has(name),
    entry: (name) => byName.get(name) || null,
    read,
    text
  };
}
