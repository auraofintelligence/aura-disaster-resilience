#!/usr/bin/env node
// The second witness: the page's own report, held against a tree read from outside the page.
//
//     node tools/uicompare.mjs --assert <name> [--probe <path>] [--tree <path>] [--strict] [--json]
//     node tools/uicompare.mjs --show   <name> [--tree <path>] [--json]
//
// tools/uiprobe.mjs checks what the page says about itself. That is worth having and it is not
// enough on its own, because it is the page's own account. This tool reads an accessibility tree
// captured by something that is not the page, matches it against the same probe, and reports what
// appears in one and not the other. A page that lies about itself fails here.
//
// -------------------------------------------------------------------------------------------
// HOW TO CAPTURE AN ACCESSIBILITY TREE IN THIS ENVIRONMENT
// -------------------------------------------------------------------------------------------
//
// Written out so the next agent does not have to work it out again.
//
//   1. Start the app server:            node tools/serve.mjs
//      It serves the repository on 4281 and accepts the two sinks the page posts to.
//   2. Open http://localhost:4281/lab.html in the browser pane and let it boot. The bench, meaning
//      the calibration scene and the stage 0 panels, lives there since 20 August 2026. The front
//      page at http://localhost:4281/ is a second capture target: its probe is named front and its
//      baseline is tools/panels/front.json. Do not ask the pane for a
//      screenshot: it does not composite frames in this environment, which is the whole reason the
//      page posts its own PNGs, and the pane's screenshot action times out after five seconds.
//   3. Advance the world if you want a tick other than zero, from the console:  ISLAND.step(720)
//   4. Post the page's own report first, so the two witnesses describe the same moment:
//      ISLAND.probe('calibration')   which writes out/probes/calibration.json
//   5. Read the tree with the browser pane's read_page action, filter "all", not "interactive".
//      It prints one line per node: leading spaces for depth, the role, the text in double quotes,
//      a [ref_N] handle, and sometimes a trailing attribute such as type="button".
//   6. Save it to out/probes/<name>.axtree.json in the shape this tool reads:
//
//        {
//          "what": "...", "capturedBy": "...", "url": "http://localhost:4281/lab.html",
//          "tick": 720, "renderPath": "webgpu", "fault": null,
//          "limits": ["..."],
//          "tree": ["region [ref_3]", " heading \"Island clock\" [ref_4]", ...]
//        }
//
//      `tree` may also be one string with newlines in it. Everything except `tree` is metadata, and
//      `limits` is the honest part: write down what the capture could not see.
//
// What the capture can and cannot settle today, from out/probes/calibration.axtree.json:
//
//   It settles the roles, the structure and the order of the landmarks, every displayed value, the
//   contested or unknown marker and the buttons.
//
//   It does NOT settle an accessible name. The pane prints a node's role and its text and does not
//   compute a name, and window.getComputedAccessibleNode is undefined in this browser, so the
//   browser's own name computation is not reachable from the page either. This tool therefore
//   compares the page's reported accessibleName with the text of the landmark's own heading, which
//   is what aria-labelledby points at on every panel in this build. That is evidence and not proof,
//   and it has one known blind spot worth stating: if aria-labelledby is removed while the heading
//   stays on screen, the heading still reads correctly here and the page honestly reports an empty
//   name, so this tool reports a disagreement it cannot tell apart from a lie. uiprobe is the
//   instrument that settles that case, by failing on the empty name directly.
//
//   Settling names independently needs a Chrome DevTools Protocol capture, Accessibility.getFullAXTree,
//   and nothing in this repository speaks that protocol. Until something does, this is the second
//   witness available, and its limit belongs in its output rather than in a footnote.
//
// -------------------------------------------------------------------------------------------
//
// -------------------------------------------------------------------------------------------
// THE MATCHING RULE, AND THE BUG THAT WROTE IT
// -------------------------------------------------------------------------------------------
//
// Text in the capture is truncated at about 100 characters, sometimes with a trailing ellipsis and
// sometimes without, so every text comparison here is prefix aware. A tree text corroborates a
// reported text when, after whitespace is normalised, they are equal, or the tree text with any
// trailing ellipsis removed is a prefix of the reported text, or it is a run of at least four
// characters of it, or the reported text appears inside the tree text at both word boundaries and
// is at least four characters long.
//
// Those length floors and that word boundary are not caution. The first version of this rule
// accepted any substring in either direction, and it passed a capture that was missing a value:
// the sun panel reported the daylight row as "no", the capture did not hold that node at all, and
// "no" is inside "register: known" one node away. The tool printed "No contradiction: every panel,
// name and value the page reported is corroborated by the capture". An instrument that answers
// agreement by accident is worse than no instrument, because somebody believes it.
//
// The same run turned up the capture limit underneath: the pane's read_page drops a two character
// text and keeps a three character one. Checked twice on the same page rather than assumed. At
// tick 1305 the daylight row read "no", the DOM held it, checked at the console with
// document.getElementById('value-daylight').outerHTML, and the capture had no node for it. Stepping
// the same page to tick 2160, where the row reads "yes", brought the node back. So a reported text
// shorter than three characters cannot be corroborated or contradicted from a capture. This tool
// reports it as UNSETTLED rather than as agreement or as a lie, it says so in the verdict, and
// --strict fails on it. The threshold comes from that one observed pair and is written here as
// what it is: an observation, not a documented rule of the tool that produced it.

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const PROBES_DIR = path.join(REPO_ROOT, 'out', 'probes');

/** Container roles a panel can be. Anything else in the tree is content inside one. */
const CONTAINER_ROLES = new Set([
  'region', 'group', 'main', 'complementary', 'form', 'search', 'navigation', 'banner', 'contentinfo'
]);

const MARKER_PHRASE = 'contested or unknown';

function usage() {
  return [
    'node tools/uicompare.mjs --assert <name> [--probe <path>] [--tree <path>] [--strict] [--json]',
    'node tools/uicompare.mjs --show   <name> [--tree <path>] [--json]',
    '',
    '  --assert <name>  compare out/probes/<name>.json with out/probes/<name>.axtree.json',
    '  --show <name>    print the landmarks the capture holds, and give no verdict',
    '  --probe <path>   a self report somewhere else',
    '  --tree <path>    a capture somewhere else',
    '  --strict         also fail on a landmark in the tree that the self report does not carry',
    '  --json           machine readable output on stdout, nothing else',
    '',
    'Exit code is 0 when the two witnesses agree, 1 when they contradict each other,',
    '2 on a usage or read error, including a capture that is not there.'
  ].join('\n');
}

function rel(abs) {
  return path.relative(REPO_ROOT, abs).split('\\').join('/');
}

function probeFile(nameOrPath) {
  if (nameOrPath.endsWith('.json') || nameOrPath.includes('/') || nameOrPath.includes('\\')) {
    return path.resolve(nameOrPath);
  }
  return path.join(PROBES_DIR, nameOrPath + '.json');
}

function treeFile(nameOrPath) {
  if (nameOrPath.endsWith('.json') || nameOrPath.includes('/') || nameOrPath.includes('\\')) {
    return path.resolve(nameOrPath);
  }
  return path.join(PROBES_DIR, nameOrPath + '.axtree.json');
}

const norm = (s) => String(s === null || s === undefined ? '' : s).replace(/\s+/g, ' ').trim();

/** A tree text with its truncation marks taken off, so a prefix comparison means something. */
function untruncated(text) {
  return norm(text).replace(/\s*(?:\.\.\.|\u2026)$/, '').trim();
}

/** The shortest reported text this capture can settle either way. See the header. */
export const SETTLEABLE_LENGTH = 3;

/** The shortest run of text that may stand for a whole value. Four is not a magic number: it is */
/** long enough that ", as at" style fragments still match and short enough to stay useful. */
const MIN_RUN = 4;

const WORD = /[A-Za-z0-9]/;

/** Is `needle` inside `hay` with a non word character, or nothing, on each side of it? */
function containsWholeWord(hay, needle) {
  let from = 0;
  for (;;) {
    const at = hay.indexOf(needle, from);
    if (at === -1) return false;
    const before = at === 0 ? '' : hay[at - 1];
    const after = at + needle.length >= hay.length ? '' : hay[at + needle.length];
    if (!WORD.test(before || ' ') && !WORD.test(after || ' ')) return true;
    from = at + 1;
  }
}

/**
 * Does a text from the capture corroborate a text the page reported? The capture truncates, and it
 * splits a value that holds a marker element into two nodes, so exact equality is the strongest
 * case and not the only one. Every other case carries a length floor and, in the containment
 * direction, a word boundary: the header says which run of this tool made that necessary.
 */
export function corroborates(treeText, reportedText) {
  const t = untruncated(treeText);
  const r = norm(reportedText);
  if (t === '' || r === '') return t === r;
  if (t === r) return true;
  // The capture truncated a long value: what it holds is the front of what the page reported.
  if (t.length >= MIN_RUN && r.startsWith(t)) return true;
  // The page reported a whole value that the capture split across nodes, the marker row being the
  // one in this build: the tree node is a run of the reported text.
  const trimmed = t.replace(/^[\s,.;:]+/, '').replace(/[\s,.;:]+$/, '');
  if (trimmed.length >= MIN_RUN && r.includes(trimmed)) return true;
  // The reported value sits inside a longer tree text. Whole words only, or "no" matches "known".
  if (r.length >= MIN_RUN && containsWholeWord(t, r)) return true;
  return false;
}

/**
 * Parse one line of the pane's read_page output. Returns null for a line that is not a node.
 *
 *   `  generic "contested or unknown" [ref_42]`  ->  { depth: 2, role: 'generic', text: '...' }
 */
export function parseNodeLine(line) {
  const raw = String(line);
  if (!raw.trim()) return null;
  const indent = raw.length - raw.replace(/^\s+/, '').length;
  const body = raw.trim();
  const m = /^([A-Za-z][A-Za-z0-9_-]*)\s*(?:"([\s\S]*)")?\s*(?:\[(ref_\d+)\])?\s*(.*)$/.exec(body);
  if (!m) return null;
  return {
    depth: indent,
    role: m[1],
    text: m[2] === undefined ? '' : m[2],
    ref: m[3] || null,
    extra: (m[4] || '').trim(),
    line: raw
  };
}

export function loadTree(file) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error('the accessibility tree ' + rel(file) + ' could not be read: '
      + String((err && err.message) || err)
      + '\nCapture one with the browser pane read_page action: see the header of tools/uicompare.mjs.');
  }
  const lines = Array.isArray(parsed) ? parsed
    : Array.isArray(parsed.tree) ? parsed.tree
      : typeof parsed.tree === 'string' ? parsed.tree.split(/\r?\n/) : null;
  if (!lines) {
    throw new Error(rel(file) + ' has no tree: expected an array of node lines, or one string with '
      + 'newlines, under the key "tree".');
  }
  const nodes = lines.map(parseNodeLine).filter(Boolean);
  if (nodes.length === 0) throw new Error(rel(file) + ' holds a tree with no readable nodes.');
  return {
    file,
    meta: Array.isArray(parsed) ? {} : parsed,
    nodes,
    limits: (!Array.isArray(parsed) && Array.isArray(parsed.limits)) ? parsed.limits : []
  };
}

/** The landmarks in the capture, each with its heading text and the texts inside it. */
export function landmarks(nodes) {
  const out = [];
  for (let i = 0; i < nodes.length; i++) {
    const node = nodes[i];
    if (!CONTAINER_ROLES.has(node.role)) continue;
    const inside = [];
    for (let j = i + 1; j < nodes.length && nodes[j].depth > node.depth; j++) inside.push(nodes[j]);
    const heading = inside.find((n) => n.role === 'heading');
    out.push({
      index: out.length,
      role: node.role,
      ref: node.ref,
      heading: heading ? norm(heading.text) : '',
      inside,
      texts: inside.filter((n) => n.role !== 'heading').map((n) => n.text).filter((t) => norm(t) !== '')
    });
  }
  return out;
}

function loadProbe(file) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error('the self report ' + rel(file) + ' could not be read: '
      + String((err && err.message) || err));
  }
  if (!parsed || !Array.isArray(parsed.panels)) {
    throw new Error(rel(file) + ' has no panels array, so it is not an interface probe.');
  }
  return parsed;
}

/**
 * Match the panels the page reported to the landmarks in the capture. Three passes, weakest last,
 * so a name that disagrees still finds its landmark and gets reported as a disagreement rather than
 * disappearing as two one sided misses.
 *
 *   1. by name: the reported accessibleName equals the landmark heading.
 *   2. by content: the landmark corroborates the most of the panel's reported values, at least one.
 *   3. by order: whatever is left, in document order, role for role.
 */
export function match(panels, marks) {
  const pairs = [];
  const usedMark = new Set();
  const usedPanel = new Set();

  panels.forEach((panel, pi) => {
    const name = norm(panel.accessibleName);
    if (!name) return;
    const hit = marks.find((m) => !usedMark.has(m.index) && m.heading === name);
    if (hit) {
      pairs.push({ panel, panelIndex: pi, mark: hit, how: 'name' });
      usedMark.add(hit.index);
      usedPanel.add(pi);
    }
  });

  panels.forEach((panel, pi) => {
    if (usedPanel.has(pi)) return;
    const wanted = (panel.values || []).map((v) => norm(v.text)).filter(Boolean);
    if (wanted.length === 0) return;
    let best = null;
    for (const m of marks) {
      if (usedMark.has(m.index)) continue;
      const score = wanted.filter((w) => m.texts.some((t) => corroborates(t, w))).length;
      if (score > 0 && (!best || score > best.score)) best = { m, score };
    }
    if (best) {
      pairs.push({ panel, panelIndex: pi, mark: best.m, how: 'values' });
      usedMark.add(best.m.index);
      usedPanel.add(pi);
    }
  });

  panels.forEach((panel, pi) => {
    if (usedPanel.has(pi)) return;
    const hit = marks.find((m) => !usedMark.has(m.index) && m.role === panel.role);
    if (hit) {
      pairs.push({ panel, panelIndex: pi, mark: hit, how: 'order and role' });
      usedMark.add(hit.index);
      usedPanel.add(pi);
    }
  });

  pairs.sort((a, b) => a.panelIndex - b.panelIndex);
  return {
    pairs,
    unmatchedPanels: panels.filter((_, pi) => !usedPanel.has(pi)),
    unmatchedMarks: marks.filter((m) => !usedMark.has(m.index))
  };
}

export function compare({ probe, tree, strict = false }) {
  const report = loadProbe(probe);
  const capture = loadTree(tree);
  const marks = landmarks(capture.nodes);
  const { pairs, unmatchedPanels, unmatchedMarks } = match(report.panels, marks);

  const contradictions = [];
  const unreported = [];
  const unsettled = [];
  const agreements = [];

  for (const panel of unmatchedPanels) {
    contradictions.push({
      kind: 'panel-not-in-tree',
      element: '[data-panel="' + panel.id + '"]',
      detail: 'the page reports a panel named "' + norm(panel.accessibleName) + '" with '
        + (panel.values || []).length + ' value(s), and no landmark in the capture holds any of it'
    });
  }

  for (const pair of pairs) {
    const reported = norm(pair.panel.accessibleName);
    const heading = pair.mark.heading;
    if (heading === '' && reported !== '') {
      contradictions.push({
        kind: 'no-heading-in-tree',
        element: '[data-panel="' + pair.panel.id + '"]',
        detail: 'the page reports the name "' + reported + '" and the matched ' + pair.mark.role
          + ' in the capture has no heading to corroborate it'
      });
    } else if (heading !== reported) {
      contradictions.push({
        kind: 'name-disagrees',
        element: '[data-panel="' + pair.panel.id + '"]',
        detail: 'the page reports the accessible name '
          + (reported === '' ? 'EMPTY' : '"' + reported + '"')
          + ' and the capture shows the heading "' + heading + '". These agree on every panel in '
          + 'this build, because aria-labelledby points at that heading. A removed aria-labelledby '
          + 'produces this line honestly, and uiprobe is what tells the two apart.'
      });
    } else {
      agreements.push({ panel: pair.panel.id, name: reported, how: pair.how, role: pair.mark.role });
    }

    if (pair.panel.role && pair.mark.role !== pair.panel.role) {
      contradictions.push({
        kind: 'role-disagrees',
        element: '[data-panel="' + pair.panel.id + '"]',
        detail: 'the page reports role "' + pair.panel.role + '" and the capture shows "'
          + pair.mark.role + '"'
      });
    }

    for (const value of pair.panel.values || []) {
      const text = norm(value.text);
      if (!text) continue;
      const seen = pair.mark.texts.some((t) => corroborates(t, text));
      if (!seen && text.length < SETTLEABLE_LENGTH) {
        // The capture drops a text this short, evidenced twice on this page: see the header. So
        // its absence is neither agreement nor a lie, and calling it either would be a guess.
        unsettled.push({
          kind: 'value-too-short-for-this-capture',
          element: '[data-panel="' + pair.panel.id + '"] [data-value="' + value.id + '"]',
          detail: 'the page reports "' + text + '", which is under ' + SETTLEABLE_LENGTH
            + ' characters, and this kind of capture drops a text that short. Nothing in the '
            + 'matched ' + pair.mark.role + ' corroborates it and nothing contradicts it either. '
            + 'tools/uiprobe.mjs still checks its citation and its register, and a value this short '
            + 'is the one case where the second witness has nothing to say.'
        });
      } else if (!seen) {
        contradictions.push({
          kind: 'value-not-in-tree',
          element: '[data-panel="' + pair.panel.id + '"] [data-value="' + value.id + '"]',
          detail: 'the page reports the text "' + text.slice(0, 120)
            + '" and nothing in the matched ' + pair.mark.role + ' corroborates it'
        });
      }
      if (text.toLowerCase().includes(MARKER_PHRASE)) {
        const markerNode = pair.mark.inside.some((n) => norm(n.text).toLowerCase() === MARKER_PHRASE);
        if (!markerNode) {
          contradictions.push({
            kind: 'marker-not-its-own-node',
            element: '[data-panel="' + pair.panel.id + '"] [data-value="' + value.id + '"]',
            detail: 'the page reports a contested or unknown marker and the capture holds no node '
              + 'whose whole text is that marker. A marker buried in a sentence is not visually '
              + 'distinct, and a reader of the tree sees prose rather than an absence.'
          });
        }
      }
    }
  }

  for (const mark of unmatchedMarks) {
    unreported.push({
      kind: 'landmark-not-in-self-report',
      element: mark.role + (mark.heading ? ' "' + mark.heading + '"' : ' with no heading')
        + (mark.ref ? ' ' + mark.ref : ''),
      detail: 'the capture holds this landmark and the self report does not carry it, so no '
        + 'instrument is checking what is inside it'
    });
  }

  const ok = contradictions.length === 0
    && (!strict || (unreported.length === 0 && unsettled.length === 0));
  return {
    mode: 'assert',
    probe: rel(probe),
    tree: rel(tree),
    strict,
    probeTick: typeof report.tick === 'number' ? report.tick : null,
    treeTick: typeof capture.meta.tick === 'number' ? capture.meta.tick : null,
    probeFault: report.fault || null,
    treeFault: capture.meta.fault || null,
    panels: report.panels.length,
    landmarks: marks.length,
    matched: pairs.map((p) => ({ panel: p.panel.id, role: p.mark.role, heading: p.mark.heading, how: p.how })),
    agreements,
    contradictions,
    unreported,
    unsettled,
    limits: capture.limits,
    ok
  };
}

export function show({ tree }) {
  const capture = loadTree(tree);
  const marks = landmarks(capture.nodes);
  return {
    mode: 'show',
    tree: rel(tree),
    nodes: capture.nodes.length,
    landmarks: marks.map((m) => ({
      role: m.role, heading: m.heading, ref: m.ref, texts: m.texts.length
    })),
    limits: capture.limits,
    ok: true
  };
}

function printAssert(result) {
  const lines = [];
  lines.push('two witnesses');
  lines.push('  self report  ' + result.probe + '   tick ' + (result.probeTick === null ? 'unknown' : result.probeTick)
    + ', fault ' + (result.probeFault || 'none'));
  lines.push('  capture      ' + result.tree + '   tick ' + (result.treeTick === null ? 'unknown' : result.treeTick)
    + ', fault ' + (result.treeFault || 'none'));
  if (result.probeTick !== null && result.treeTick !== null && result.probeTick !== result.treeTick) {
    lines.push('  WARNING  the two witnesses describe different ticks, so a value that changes with '
      + 'the tick will differ for a reason that is not a defect.');
  }
  if ((result.probeFault || null) !== (result.treeFault || null)) {
    lines.push('  WARNING  the two witnesses record different faults, so they are not describing the '
      + 'same run.');
  }
  lines.push('  ' + result.panels + ' panels reported, ' + result.landmarks + ' landmarks captured.');
  lines.push('');

  for (const m of result.matched) {
    lines.push('  matched  ' + String(m.panel).padEnd(14) + m.role.padEnd(10)
      + '"' + m.heading + '"   by ' + m.how);
  }
  lines.push('');

  if (result.contradictions.length === 0) {
    lines.push('  No contradiction: every panel, every name and every value the page reported that '
      + 'this capture can settle is corroborated by it.');
  } else {
    for (const c of result.contradictions) {
      lines.push('  CONTRADICTION ' + c.kind);
      lines.push('       ' + c.element);
      lines.push('         ' + c.detail);
    }
  }

  if (result.unsettled.length) {
    lines.push('');
    for (const u of result.unsettled) {
      lines.push('  ' + (result.strict ? 'UNSETTLED (strict, blocking) ' : 'UNSETTLED (advisory) ') + u.kind);
      lines.push('       ' + u.element);
      lines.push('         ' + u.detail);
    }
  }

  if (result.unreported.length) {
    lines.push('');
    for (const u of result.unreported) {
      lines.push('  ' + (result.strict ? 'UNREPORTED (strict, blocking) ' : 'UNREPORTED (advisory) ') + u.kind);
      lines.push('       ' + u.element);
      lines.push('         ' + u.detail);
    }
  }

  if (result.limits.length) {
    lines.push('');
    lines.push('  What this capture says it cannot settle:');
    for (const l of result.limits) lines.push('    ' + l);
  }

  lines.push('');
  if (result.ok) {
    lines.push('PASS: the two witnesses agree on ' + result.agreements.length + ' panel name(s) and '
      + 'every value this capture can settle, with ' + result.unsettled.length
      + ' value(s) it cannot settle and ' + result.unreported.length
      + ' landmark(s) the self report does not carry.');
  } else {
    const also = [];
    if (result.strict && result.unsettled.length) also.push(result.unsettled.length + ' unsettled value(s)');
    if (result.strict && result.unreported.length) also.push(result.unreported.length + ' unreported landmark(s)');
    lines.push('FAIL: ' + result.contradictions.length + ' contradiction(s)'
      + (also.length ? ' and ' + also.join(' and ') : '')
      + ' between the page and the capture.');
  }
  return lines.join('\n');
}

function printShow(result) {
  const lines = ['capture ' + result.tree + ', ' + result.nodes + ' nodes'];
  for (const m of result.landmarks) {
    lines.push('  ' + m.role.padEnd(12) + (m.heading ? '"' + m.heading + '"' : 'no heading').padEnd(36)
      + m.texts + ' text node(s)' + (m.ref ? '   ' + m.ref : ''));
  }
  if (result.limits.length) {
    lines.push('');
    lines.push('  What this capture says it cannot settle:');
    for (const l of result.limits) lines.push('    ' + l);
  }
  lines.push('');
  lines.push('SHOW: no verdict. Run --assert to hold it against the page self report.');
  return lines.join('\n');
}

function main() {
  const argv = process.argv.slice(2);
  const json = argv.includes('--json');
  const strict = argv.includes('--strict');
  const args = argv.filter((a) => a !== '--json' && a !== '--strict');

  const value = (flag) => {
    const i = args.indexOf(flag);
    if (i === -1) return null;
    const next = args[i + 1];
    return next && !next.startsWith('--') ? next : null;
  };

  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    process.stdout.write(usage() + '\n');
    process.exitCode = args.length === 0 ? 2 : 0;
    return;
  }

  let result;
  try {
    if (args.includes('--assert')) {
      const name = value('--assert');
      const probeOverride = value('--probe');
      const treeOverride = value('--tree');
      if (!name && !(probeOverride && treeOverride)) {
        throw new Error('--assert needs a name, or both --probe and --tree\n\n' + usage());
      }
      result = compare({
        probe: probeOverride ? path.resolve(probeOverride) : probeFile(name),
        tree: treeOverride ? path.resolve(treeOverride) : treeFile(name),
        strict
      });
    } else if (args.includes('--show')) {
      const name = value('--show');
      const treeOverride = value('--tree');
      if (!name && !treeOverride) throw new Error('--show needs a name or --tree\n\n' + usage());
      result = show({ tree: treeOverride ? path.resolve(treeOverride) : treeFile(name) });
    } else {
      throw new Error('unknown arguments: ' + args.join(' ') + '\n\n' + usage());
    }
  } catch (err) {
    if (json) {
      process.stdout.write(JSON.stringify({ ok: false, error: String(err.message || err) }, null, 2) + '\n');
    } else {
      process.stderr.write(String(err.message || err) + '\n');
    }
    process.exitCode = 2;
    return;
  }

  if (json) process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  else process.stdout.write((result.mode === 'assert' ? printAssert(result) : printShow(result)) + '\n');
  process.exitCode = result.ok ? 0 : 1;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main();
}
