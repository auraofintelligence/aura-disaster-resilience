// The crossings, checked against arithmetic rather than against themselves.
//
//   node tools/check-crossings.mjs
//   node tools/check-crossings.mjs --json
//   node tools/check-crossings.mjs --days 7
//
// Two subjects, on purpose. The first half checks data/crossings.json against figures worked out
// here from the published departure times, so a transcription error in the pack shows up as a
// window that is not the window. The second half runs the world with src/systems/crossings.js
// registered and checks that what the running island says matches what the pack says, which is a
// different claim and the one a system can quietly break.
//
// Every identity below holds independently of the model. The off-island vehicle window is 07:00 to
// 17:30 because those are the first and last rows of the Departs Dunwich column, not because a
// system computed it. The five hour gap is the difference between two published windows. The
// movement counts are row counts at a landing point. A pack can be wrong in a way that still looks
// like a timetable; it cannot be wrong in a way that satisfies all of these.
//
// WHERE THE ORCHESTRATOR'S FIGURES CAME OUT DIFFERENT, and it is a day-of-week thing rather than a
// disagreement: 48 movements at Junner Street and 28 at One Mile are both true on a Friday, which
// is the epoch this world starts at. They are not true on every day, because two SeaLink sailings
// run Friday, Saturday and Sunday only and four Gold Cats Flyer sailings do not run on a Saturday,
// a Sunday or a public holiday. The per-weekday table is printed rather than one number.

import { buildIslandWith } from '../src/world/island.js';
import { loadPacks, loadSourceIds, validatePacks } from '../src/world/data.js';
import { registerCrossings, hhmm } from '../src/systems/crossings.js';
import { DEFAULT_EPOCH } from '../src/kernel/world.js';

const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf('--' + name);
  return i === -1 ? fallback : args[i + 1];
};
const JSON_OUT = args.includes('--json');
const DAYS = Number(flag('days', 7));

const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const I2M = 'island-to-mainland';
const M2I = 'mainland-to-island';
const VEHICLE = 'sealink-vehicle-barge';
const SEALINK_PAX = 'sealink-passenger-ferry';
const FLYER = 'gold-cats-flyer-passenger-ferry';
const JUNNER = 'junner-street-dunwich';
const ONE_MILE = 'one-mile-dunwich';

const checks = [];
const check = (name, pass, detail) => checks.push({ name, pass, detail });

// ---- the pack, and the record type it has to satisfy -------------------------------------------

const packs = await loadPacks(['tide', 'crossings']);
const pack = packs.crossings;
const sourceIds = await loadSourceIds();
const recordProblems = validatePacks({ crossings: pack }, sourceIds);
check('every record in the pack passes src/kernel/record.js',
  recordProblems.length === 0,
  recordProblems.length ? recordProblems.slice(0, 3).join(' | ') : `${pack.sailings.length} sailings and their surrounding records, 0 problems`);

// ---- the two-crossings law, structurally --------------------------------------------------------

const allowed = new Set(pack.carriesEnum.values);
check('the carries enum has exactly two values and no third meaning both',
  pack.carriesEnum.values.length === 2 && allowed.has('vehicles') && allowed.has('passengers'),
  `carriesEnum ${JSON.stringify(pack.carriesEnum.values)}`);

const badCarries = pack.sailings.filter((s) => !allowed.has(s.carries));
check('every sailing carries one of the two allowed values',
  badCarries.length === 0,
  badCarries.length ? badCarries.map((s) => s.id + ': ' + s.carries).slice(0, 3).join(', ') : `${pack.sailings.length} sailings checked`);

// A sailing may not hold a vehicle figure and a passenger figure at once, because a schema that
// offers both offers a place to add them together.
const numericFields = (o) => Object.keys(o).filter((k) => typeof o[k] === 'number');
const looksVehicle = (k) => /vehicle|(^|[^a-z])cars?([^a-z]|$)|truck/i.test(k);
const looksPassenger = (k) => /passenger|people|person|\bpax\b|foot/i.test(k);
const bothOnOne = pack.sailings.filter((s) => {
  const keys = numericFields(s);
  return keys.some(looksVehicle) && keys.some(looksPassenger);
});
check('no sailing record holds a vehicle figure and a passenger figure at the same time',
  bothOnOne.length === 0,
  bothOnOne.length ? bothOnOne.map((s) => s.id).join(', ') : 'no sailing carries either kind of count at all, which is the honest state: nothing here counts what is on board');

// ---- the three services, counted -----------------------------------------------------------------

const byService = new Map();
for (const s of pack.sailings) {
  if (!byService.has(s.serviceId)) byService.set(s.serviceId, []);
  byService.get(s.serviceId).push(s);
}
const countOf = (serviceId, direction) =>
  byService.get(serviceId).filter((s) => s.direction === direction).length;

check('the vehicle barge carries ten departures each way in the base timetable',
  countOf(VEHICLE, M2I) === 10 && countOf(VEHICLE, I2M) === 10,
  `sealink-vehicle-barge: ${countOf(VEHICLE, M2I)} from the mainland, ${countOf(VEHICLE, I2M)} from the island`);
check('the SeaLink passenger ferry carries fourteen departures each way',
  countOf(SEALINK_PAX, M2I) === 14 && countOf(SEALINK_PAX, I2M) === 14,
  `sealink-passenger-ferry: ${countOf(SEALINK_PAX, M2I)} from the mainland, ${countOf(SEALINK_PAX, I2M)} from the island`);
check('the Gold Cats Flyer carries fourteen departures each way',
  countOf(FLYER, M2I) === 14 && countOf(FLYER, I2M) === 14,
  `gold-cats-flyer-passenger-ferry: ${countOf(FLYER, M2I)} from the mainland, ${countOf(FLYER, I2M)} from the island`);

// ---- the windows, per weekday --------------------------------------------------------------------

const runsOn = (s, w) => s.days.weekdays.includes(w);
const windowFor = (w, predicate) => {
  const list = pack.sailings
    .filter((s) => s.direction === I2M && runsOn(s, w) && predicate(s))
    .map((s) => s.departsMinuteOfDay)
    .sort((a, b) => a - b);
  if (!list.length) return { first: null, last: null, minutes: null };
  return { first: list[0], last: list[list.length - 1], minutes: list[list.length - 1] - list[0] };
};

const perWeekday = [];
for (let w = 0; w < 7; w++) {
  const vehicle = windowFor(w, (s) => s.carries === 'vehicles');
  const passenger = windowFor(w, (s) => s.carries === 'passengers');
  const running = pack.sailings.filter((s) => runsOn(s, w));
  const movementsAt = (point) => running.filter((s) => s.islandPoint === point).length;
  perWeekday.push({
    weekday: w,
    name: WEEKDAY_NAMES[w],
    vehicle,
    passenger,
    gapMorning: vehicle.first - passenger.first,
    gapEvening: passenger.last - vehicle.last,
    gapTotal: (vehicle.first - passenger.first) + (passenger.last - vehicle.last),
    junnerStreet: movementsAt(JUNNER),
    oneMile: movementsAt(ONE_MILE),
    sailings: running.length
  });
}

const everyDay = (fn) => perWeekday.every(fn);

check('the off-island vehicle window is 07:00 to 17:30 on every day of the week',
  everyDay((d) => d.vehicle.first === 420 && d.vehicle.last === 1050),
  perWeekday.map((d) => `${d.name.slice(0, 3)} ${hhmm(d.vehicle.first)} to ${hhmm(d.vehicle.last)}`).join(', '));
check('the off-island vehicle window is ten and a half hours',
  everyDay((d) => d.vehicle.minutes === 630),
  `${perWeekday[0].vehicle.minutes} minutes, ${(perWeekday[0].vehicle.minutes / 60).toFixed(2)} hours`);

check('the off-island passenger window is 05:15 to 20:45 on every day of the week',
  everyDay((d) => d.passenger.first === 315 && d.passenger.last === 1245),
  perWeekday.map((d) => `${d.name.slice(0, 3)} ${hhmm(d.passenger.first)} to ${hhmm(d.passenger.last)}`).join(', '));
check('the off-island passenger window is fifteen and a half hours',
  everyDay((d) => d.passenger.minutes === 930),
  `${perWeekday[0].passenger.minutes} minutes, ${(perWeekday[0].passenger.minutes / 60).toFixed(2)} hours`);

check('the gap between the two windows is five hours, every day',
  everyDay((d) => d.gapTotal === 300),
  perWeekday.map((d) => `${d.name.slice(0, 3)} ${d.gapTotal}`).join(', ') + ' minutes');
check('the gap is one and three quarter hours in the morning and three and a quarter in the evening',
  everyDay((d) => d.gapMorning === 105 && d.gapEvening === 195),
  `${perWeekday[0].gapMorning} minutes before the first vehicle sailing off the island, ${perWeekday[0].gapEvening} minutes after the last`);

// Which operator holds each end of the passenger window, since it is not the same one at both ends.
const holdsEnd = (w, minute) => pack.sailings
  .filter((s) => s.direction === I2M && s.carries === 'passengers' && runsOn(s, w) && s.departsMinuteOfDay === minute)
  .map((s) => s.serviceId);
check('the first passenger departure off the island is held by SeaLink every day, and on a Saturday it is held by SeaLink alone',
  everyDay((d) => holdsEnd(d.weekday, 315).includes(SEALINK_PAX))
    && holdsEnd(6, 315).length === 1,
  `Saturday 05:15: ${holdsEnd(6, 315).join(', ')}; Friday 05:15: ${holdsEnd(5, 315).join(', ')}`);
check('the last passenger departure off the island is held by the Gold Cats Flyer every day, and on a Wednesday it is held by the Flyer alone',
  everyDay((d) => holdsEnd(d.weekday, 1245).includes(FLYER))
    && holdsEnd(3, 1245).length === 1,
  `Wednesday 20:45: ${holdsEnd(3, 1245).join(', ')}; Friday 20:45: ${holdsEnd(5, 1245).join(', ')}`);

// ---- movements at each landing point ---------------------------------------------------------------

const friday = perWeekday[5];
const wednesday = perWeekday[3];
const saturday = perWeekday[6];

check('Junner Street ferry terminal carries 48 vessel movements on a Friday',
  friday.junnerStreet === 48,
  `Friday ${friday.junnerStreet}, of which sealink-vehicle-barge ${byService.get(VEHICLE).length} and sealink-passenger-ferry ${byService.get(SEALINK_PAX).filter((s) => runsOn(s, 5)).length}`);
check('One Mile jetty carries 28 vessel movements on a Friday',
  friday.oneMile === 28,
  `Friday ${friday.oneMile}, all of them gold-cats-flyer-passenger-ferry`);
check('the Friday figures are not the every-day figures, and the difference is the day rules',
  wednesday.junnerStreet === 46 && saturday.oneMile === 24,
  `Junner Street: Friday ${friday.junnerStreet}, Wednesday ${wednesday.junnerStreet}. One Mile: Friday ${friday.oneMile}, Saturday ${saturday.oneMile}`);

// ---- the vessel rotation ---------------------------------------------------------------------------

const vehicleSailings = byService.get(VEHICLE);
const rotationOf = (direction) => vehicleSailings
  .filter((s) => s.direction === direction)
  .sort((a, b) => a.departsMinuteOfDay - b.departsMinuteOfDay)
  .map((s) => s.vesselCode);
const rotM2I = rotationOf(M2I);
const rotI2M = rotationOf(I2M);
const countCode = (list, code) => list.filter((c) => c === code).length;

check('the vessel rotation gives five sailings to each vessel in each direction',
  countCode(rotM2I, 'M') === 5 && countCode(rotM2I, 'SB') === 5
    && countCode(rotI2M, 'M') === 5 && countCode(rotI2M, 'SB') === 5,
  `from Cleveland ${rotM2I.join(' ')}; from Dunwich ${rotI2M.join(' ')}`);
check('the two vessels alternate in both directions',
  rotM2I.every((c, i) => i === 0 || c !== rotM2I[i - 1])
    && rotI2M.every((c, i) => i === 0 || c !== rotI2M[i - 1]),
  'no vessel takes two consecutive departures in either column');
check('the rotation names the two vessels the owner named and no others',
  new Set(vehicleSailings.map((s) => s.vessel)).size === 2,
  [...new Set(vehicleSailings.map((s) => s.vessel))].sort().join(' and '));

// ---- public holidays, which are not fed --------------------------------------------------------------

const holidaySensitive = pack.sailings.filter((s) => s.days.publicHolidays === 'does-not-run');
check('the public holiday input is an absence with a name on it, not a guess',
  holidaySensitive.length === 4 && holidaySensitive.every((s) => s.serviceId === FLYER),
  `${holidaySensitive.length} sailings say they stop on a public holiday, all gold-cats-flyer-passenger-ferry: ${holidaySensitive.map((s) => s.departsLocal).sort().join(' ')}`);

// ---- now the running world ---------------------------------------------------------------------------

const world = buildIslandWith(packs, { boot: false, epoch: DEFAULT_EPOCH });
registerCrossings(world, { pack });
world.boot();

const epochWeekday = world.clock.civil(0).weekday;
check('the epoch this world starts at is a Friday, which is what the movement figures above assume',
  epochWeekday === 5,
  `${DEFAULT_EPOCH} is a ${WEEKDAY_NAMES[epochWeekday]}`);

const state = world.state.crossings;
check('the crossings system reports itself fed',
  state.fed === true && state.reason === '',
  `fed ${state.fed}, ${state.sailingCount} sailings, reason ${JSON.stringify(state.reason)}`);

const events = [];
const seen = new Set();
const minuteSamples = [];
const TICKS = DAYS * 1440;
let personNotVehicle = 0;
let bothClosed = 0;

for (let t = 0; t < TICKS; t++) {
  world.step(1);
  const c = world.clock.civil(t);
  const s = world.state.crossings;
  if (t < 1440) {
    if (s.canAPersonLeaveNow && !s.canAVehicleLeaveNow) personNotVehicle++;
    if (!s.canAPersonLeaveNow && !s.canAVehicleLeaveNow) bothClosed++;
    if ([0, 315, 419, 420, 1050, 1051, 1245, 1246].includes(c.minuteOfDay)) {
      minuteSamples.push({
        minuteOfDay: c.minuteOfDay,
        at: hhmm(c.minuteOfDay),
        canAPersonLeaveNow: s.canAPersonLeaveNow,
        canAVehicleLeaveNow: s.canAVehicleLeaveNow,
        minutesUntilLastVehicleOffIsland: s.minutesUntilLastVehicleOffIsland,
        minutesUntilNextPersonOffIsland: s.minutesUntilNextPersonOffIsland
      });
    }
  }
  for (const ev of world.inbox) {
    const id = ev.type + '@' + ev.tick + '@' + (ev.payload.sailingId || '');
    if (seen.has(id)) continue;
    seen.add(id);
    events.push({ type: ev.type, tick: ev.tick, weekday: c.weekday, minuteOfDay: c.minuteOfDay, payload: ev.payload });
  }
}

const departures = events.filter((e) => e.type === 'crossing.departed');
const fridayDepartures = departures.filter((e) => e.weekday === 5);
const firstVehicle = events.filter((e) => e.type === 'crossing.first-vehicle-of-day');
const lastVehicle = events.filter((e) => e.type === 'crossing.last-vehicle-of-day');

check('the running world emits one departure event per scheduled sailing on the Friday',
  fridayDepartures.length === friday.sailings,
  `${fridayDepartures.length} crossing.departed events on the Friday, pack says ${friday.sailings} sailings run that day`);
check('every departure event names its service, its operator and what it carries',
  departures.every((e) => e.payload.serviceId && e.payload.operator && (e.payload.carries === 'vehicles' || e.payload.carries === 'passengers')),
  `${departures.length} events over ${DAYS} days, every one attributed`);
check('the first vehicle of the day fires once a day, at 06:00, from the mainland',
  firstVehicle.length === DAYS && firstVehicle.every((e) => e.minuteOfDay === 360 && e.payload.direction === M2I),
  `${firstVehicle.length} events in ${DAYS} days, at ${[...new Set(firstVehicle.map((e) => hhmm(e.minuteOfDay)))].join(', ')}`);
check('the last vehicle of the day fires once a day, at 17:30, off the island',
  lastVehicle.length === DAYS && lastVehicle.every((e) => e.minuteOfDay === 1050 && e.payload.direction === I2M),
  `${lastVehicle.length} events in ${DAYS} days, at ${[...new Set(lastVehicle.map((e) => hhmm(e.minuteOfDay)))].join(', ')}`);

check('the running world holds the five hours open where a person can leave and a vehicle cannot',
  personNotVehicle === 300,
  `${personNotVehicle} minutes of the Friday, which is ${(personNotVehicle / 60).toFixed(2)} hours`);
check('the running world closes both windows overnight rather than leaving one true',
  bothClosed === 1440 - 931,
  `${bothClosed} minutes with neither window open`);

const at = (m) => minuteSamples.find((s) => s.minuteOfDay === m);
check('at midnight the last vehicle off the island is 17:30 and 1050 minutes away',
  at(0).minutesUntilLastVehicleOffIsland === 1050 && at(0).canAVehicleLeaveNow === false,
  `midnight: ${at(0).minutesUntilLastVehicleOffIsland} minutes until the last vehicle sailing off the island, window open ${at(0).canAVehicleLeaveNow}`);
check('at 05:15 a person can leave and a vehicle cannot',
  at(315).canAPersonLeaveNow === true && at(315).canAVehicleLeaveNow === false,
  `05:15: person ${at(315).canAPersonLeaveNow}, vehicle ${at(315).canAVehicleLeaveNow}`);
check('at 07:00 both windows are open',
  at(420).canAPersonLeaveNow === true && at(420).canAVehicleLeaveNow === true,
  `07:00: person ${at(420).canAPersonLeaveNow}, vehicle ${at(420).canAVehicleLeaveNow}`);
check('at 17:30 the last vehicle off the island is this minute, and at 17:31 it has gone',
  at(1050).minutesUntilLastVehicleOffIsland === 0 && at(1051).minutesUntilLastVehicleOffIsland === null
    && at(1051).canAVehicleLeaveNow === false && at(1051).canAPersonLeaveNow === true,
  `17:30: ${at(1050).minutesUntilLastVehicleOffIsland} minutes; 17:31: ${at(1051).minutesUntilLastVehicleOffIsland}, and a person can still leave for another ${at(1051).minutesUntilNextPersonOffIsland} minutes`);
check('at 20:45 a person can still leave and at 20:46 nobody can',
  at(1245).canAPersonLeaveNow === true && at(1246).canAPersonLeaveNow === false,
  `20:45 person ${at(1245).canAPersonLeaveNow}, 20:46 person ${at(1246).canAPersonLeaveNow}`);

// The system's own weekday is what this compares against, not the clock's. After the loop the clock
// has advanced past the last tick that ran, so world.clock.civil() is already the next day while the
// state still answers for the day that was simulated. Reading the clock here instead was a real
// wrong answer on the first run of this file: it compared a Thursday's state against a Friday's
// figures and reported the system had 46 movements at Junner Street where the pack said 48.
const finalState = world.state.crossings;
const finalDay = perWeekday[finalState.weekday];
check('the running world agrees with the pack on movements at each landing point',
  finalState.movementsTodayByLandingPoint[JUNNER] === finalDay.junnerStreet
    && finalState.movementsTodayByLandingPoint[ONE_MILE] === finalDay.oneMile,
  `on the ${finalDay.name} the system says Junner Street ${finalState.movementsTodayByLandingPoint[JUNNER]} and One Mile ${finalState.movementsTodayByLandingPoint[ONE_MILE]}, and the pack says ${finalDay.junnerStreet} and ${finalDay.oneMile}`);
check('the system reports the public holiday calendar as unfed',
  finalState.publicHolidays.fed === false && finalState.publicHolidays.calendar === null,
  finalState.publicHolidays.reason);

// ---- determinism, which this system has to obey like every other ---------------------------------
//
// tools/determinism.mjs runs the island buildIsland() gives it, and crossings is not registered
// there yet, so the two runs that prove this system are done here. A second world from the same
// seed must hash identically, and shuffling the registration order of the systems around it must
// change nothing, because systems are sorted by their declared order and never by the order
// somebody happened to register them in.
//
// WHAT THIS DOES NOT PROVE, and it is worth reading before copying the pattern. Both worlds below
// register crossings last, because buildIslandWith registers solar and tide inside itself and the
// supported build path has no seam before them. Registering crossings on a bare `new World()`
// instead was tried and gives a DIFFERENT world hash, and the reason is not this system: board note
// 031 hands the tide system the world's field resolver at registration time, and a bare World has
// no resolver, so tide silently answers "no resolver was supplied" and hashes differently. A system
// in this repository is registered on a world that buildIslandWith built, never on a bare one.

function runWorld(ticks, opts = {}) {
  const w = buildIslandWith(packs, { boot: false, epoch: DEFAULT_EPOCH, ...opts });
  registerCrossings(w, { pack });
  w.boot();
  w.step(ticks);
  return w;
}

const runA = runWorld(1440);
const runB = runWorld(1440);
const runShuf = runWorld(1440, { shuffle: true });

check('two runs from the same seed give the same crossings state',
  runA.hashes().crossings === runB.hashes().crossings,
  `${runA.hashes().crossings} against ${runB.hashes().crossings}`);
check('shuffling the registration order of the systems around it changes nothing',
  runA.hash() === runShuf.hash(),
  `world hash ${runA.hash()} against ${runShuf.hash()}, with tide registered before solar`);
check('the world sorts crossings after solar and tide, by declared order',
  runShuf.order.map((s) => s.name).join(',') === 'solar,tide,crossings',
  runShuf.order.map((s) => `${s.name}(${s.order})`).join(' then '));

// ---- output -------------------------------------------------------------------------------------------

const report = world.report();
const summary = {
  epoch: DEFAULT_EPOCH,
  epochWeekday: WEEKDAY_NAMES[epochWeekday],
  ticks: TICKS,
  pack: { sailings: pack.sailings.length, services: pack.services.length, landingPoints: pack.landingPoints.length },
  perWeekday,
  rotation: { fromCleveland: rotM2I, fromDunwich: rotI2M },
  events: {
    departed: departures.length,
    firstVehicleOfDay: firstVehicle.length,
    lastVehicleOfDay: lastVehicle.length
  },
  minuteSamples,
  seams: report.seams.filter((s) => s.type.startsWith('crossing.')),
  hash: report.hashes.crossings,
  checks
};

if (JSON_OUT) {
  console.log(JSON.stringify(summary, null, 2));
} else {
  console.log(`crossings: ${pack.sailings.length} sailings across ${pack.services.length} services, ${pack.landingPoints.length} landing points`);
  console.log(`world:     ${DEFAULT_EPOCH}, a ${WEEKDAY_NAMES[epochWeekday]}, ${TICKS} ticks`);
  console.log('');
  console.log('the two crossings are not the same day, off the island:');
  for (const d of perWeekday) {
    console.log(`  ${d.name.padEnd(10)} person ${hhmm(d.passenger.first)} to ${hhmm(d.passenger.last)}   vehicle ${hhmm(d.vehicle.first)} to ${hhmm(d.vehicle.last)}   gap ${(d.gapTotal / 60).toFixed(2)} h`);
  }
  console.log('');
  console.log('vessel movements at each landing point, by day:');
  for (const d of perWeekday) {
    console.log(`  ${d.name.padEnd(10)} Junner Street ${String(d.junnerStreet).padStart(2)}   One Mile ${String(d.oneMile).padStart(2)}`);
  }
  console.log('');
  console.log('sailings by service, base timetable:');
  for (const svc of pack.services) {
    const list = byService.get(svc.serviceId);
    console.log(`  ${svc.serviceId.padEnd(32)} ${String(list.length).padStart(2)} in the timetable, carries ${svc.carries}`);
  }
  console.log('');
  console.log(`vessel rotation, from Cleveland: ${rotM2I.join(' ')}`);
  console.log(`vessel rotation, from Dunwich:   ${rotI2M.join(' ')}`);
  console.log('');
  console.log('the running world, one Friday:');
  for (const s of minuteSamples) {
    console.log(`  ${s.at}  person ${String(s.canAPersonLeaveNow).padEnd(5)} vehicle ${String(s.canAVehicleLeaveNow).padEnd(5)} minutes until the last vehicle off the island: ${s.minutesUntilLastVehicleOffIsland}`);
  }
  console.log('');
  console.log('seams:');
  for (const s of summary.seams) {
    console.log(`  ${s.type}: emitters [${s.emitters}], listeners [${s.listeners.length ? s.listeners : 'none yet'}], fired ${s.fired}`);
  }
  console.log('');
  console.log('checks:');
  for (const c of checks) console.log(`  ${c.pass ? 'pass' : 'FAIL'}  ${c.name}: ${c.detail}`);
}

const failed = checks.filter((c) => !c.pass);
if (failed.length) {
  console.error(`\n${failed.length} of ${checks.length} checks failed`);
  process.exit(1);
}
if (!JSON_OUT) console.log(`\nall ${checks.length} checks passed`);
