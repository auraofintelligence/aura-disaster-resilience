#!/usr/bin/env node
// The wiring instrument: is the record store actually in the world, or only beside it.
//
//     node tools/check-wiring.mjs
//     node tools/check-wiring.mjs --json
//
// WHY THIS IS A SEPARATE INSTRUMENT FROM tools/bitemporal.mjs
//
// tools/bitemporal.mjs proves that the store and the ladder behave, over a fixture record set it
// builds itself. It would keep passing on a world that never built a store at all, because it never
// asks the world for one. Board note 018 was blunt about the state that left: "Nothing is wired.
// src/world/island.js builds no store, no system reads one, no number on screen goes through the
// ladder." Board note 031 wired it, and proved the wiring with a script under out/, which is
// gitignored, so the proof evaporated the moment that agent finished. This file is that proof, kept.
//
// The claim it owns, in one line: the world carries a record store, and every field the twin
// publishes is answered by asking the ladder over that store, not by reading a system's own state.
//
// WHY THAT SECOND HALF MATTERS AS MUCH AS THE FIRST
//
// The ladder's rule is that the bottom rung never wins a live question. A system's own computed
// number is the bottom rung. So a panel that reads a system's field directly has quietly promoted
// the simulation above every rule the ladder exists to enforce, and nothing on screen would say so.
// The first build did exactly that with synthetic weather standing beside a free real feed. The
// check here is that the value the page reads is the ladder's answer object, in one of the ladder's
// two shapes, and that the system says out loud where its answer came from.
//
// NO CHECK IN THIS FILE THROWS
//
// Every assertion is written to return a result rather than to raise one, including the build
// itself. tools/selftest.mjs treats a crash signature as a failure the instrument survived rather
// than a fault it saw, and it is right to: an instrument that falls over has not seen anything.
//
// EXIT CODE
//
//   0  every check passed
//   1  a check failed, and the failure names which one, what it wanted and what it got
//   2  a usage error

import { buildIsland, FIELDS } from '../src/world/island.js';
import { MODES } from '../src/world/bitemporal.js';
import { isUnknown } from '../src/world/ladder.js';
import { faultBanner } from '../src/kernel/faults.js';

function usage() {
  return [
    'node tools/check-wiring.mjs [--json]',
    '',
    '  --json   machine readable output on stdout, nothing else',
    '',
    'Exit code 1 on a failed check, 2 on a usage error.'
  ].join('\n');
}

const argv = process.argv.slice(2);
let JSON_OUT = false;
for (const a of argv) {
  if (a === '--json') JSON_OUT = true;
  else if (a === '--help' || a === '-h') {
    process.stdout.write(usage() + '\n');
    process.exit(0);
  } else {
    process.stderr.write('unknown argument: ' + a + '\n\n' + usage() + '\n');
    process.exit(2);
  }
}

const checks = [];
const check = (id, asserts, fn) => {
  let r;
  try {
    r = fn();
  } catch (err) {
    // Kept, but it should be unreachable: every assertion below tests for shape before it reads.
    const msg = String(err && err.message ? err.message : err).split('\n')[0];
    r = { ok: false, want: 'the check to run without raising', got: 'the check stopped: ' + msg };
  }
  checks.push({ id, asserts, ok: Boolean(r && r.ok), want: String(r ? r.want : ''), got: String(r ? r.got : '') });
};

const eq = (want, got) => ({ ok: String(want) === String(got), want: String(want), got: String(got) });

/** The two shapes src/world/ladder.js may return, named. Anything else is not a ladder answer. */
function shapeOf(result) {
  if (!result || typeof result !== 'object') return 'not an object';
  if (result.unknown === true) {
    return typeof result.asAt === 'string' && typeof result.why === 'string'
      ? 'a dated unknown'
      : 'an unknown with no date or no reason';
  }
  if (typeof result.rung === 'string' && result.value !== undefined) return 'an answer at a rung';
  return 'neither of the two ladder shapes';
}

// ---------------------------------------------------------------------------------------------
// Build the island the way every other instrument builds it.
// ---------------------------------------------------------------------------------------------

let world = null;
let buildError = null;
try {
  world = await buildIsland();
} catch (err) {
  buildError = String(err && err.message ? err.message : err).split('\n')[0];
}

check('the-island-builds',
  'buildIsland returns a world, or says why it refused to',
  () => eq('the island built', buildError === null ? 'the island built' : 'the island refused to build: ' + buildError));

const records = world && world.records ? world.records : null;
const fields = world && world.fields ? world.fields : FIELDS;

// ---------------------------------------------------------------------------------------------
// 1. The store is in the world.
// ---------------------------------------------------------------------------------------------

check('the-world-carries-a-record-store',
  'world.records is a store with a read, a cursor and records in it, not a field somebody meant to add',
  () => {
    if (!records) return { ok: false, want: 'a store on world.records', got: 'world.records is ' + (world ? String(world.records) : 'no world') };
    const has = typeof records.read === 'function' && typeof records.cursor === 'function'
      && typeof records.size === 'number';
    if (!has) return { ok: false, want: 'read, cursor and size on the store', got: 'read ' + typeof records.read + ', cursor ' + typeof records.cursor + ', size ' + typeof records.size };
    return { ok: records.size > 0, want: 'at least one record in the store', got: records.size + ' records' };
  });

check('every-loaded-record-went-in-through-the-door',
  'the load report and the store agree on how many records are held, so nothing was added around the check',
  () => {
    if (!records || !world || !world.recordsLoaded) return { ok: false, want: 'a load report beside the store', got: 'no world.recordsLoaded' };
    return eq(records.size, world.recordsLoaded.loaded);
  });

check('a-quarantined-record-is-named-rather-than-skipped',
  'a record the pack marks unusable is held out of the store and reported with the reason',
  () => {
    if (!world || !world.recordsLoaded) return { ok: false, want: 'a load report', got: 'no world.recordsLoaded' };
    const list = world.recordsLoaded.quarantined || [];
    const unnamed = list.filter((q) => !q || typeof q.why !== 'string' || q.why.trim() === '');
    return { ok: unnamed.length === 0, want: 'every quarantined record carries a reason', got: list.length + ' quarantined, ' + unnamed.length + ' with no reason' };
  });

// ---------------------------------------------------------------------------------------------
// 2. The cursor is the world's, and the world's clock drives it.
// ---------------------------------------------------------------------------------------------

check('the-world-offers-the-three-cursors',
  'live, history and scenario are three positions the world can be asked for',
  () => {
    if (!world || typeof world.cursor !== 'function') return { ok: false, want: 'world.cursor to be a function', got: 'world.cursor is ' + (world ? typeof world.cursor : 'no world') };
    const live = world.cursor(MODES.LIVE);
    const ok = live && live.mode === MODES.LIVE && Number.isInteger(live.validAt);
    return { ok: Boolean(ok), want: 'a live cursor with an integer valid time', got: live ? live.mode + ' at ' + live.validAt : String(live) };
  });

check('the-store-present-follows-the-world-clock',
  'the store never reads a clock: the world moves its present forward and nothing else does',
  () => {
    if (!records || !world || typeof world.cursor !== 'function') return { ok: false, want: 'a store and a cursor', got: 'not wired' };
    world.cursor(MODES.LIVE);
    return eq(world.clock.minuteAt(), records.present);
  });

// ---------------------------------------------------------------------------------------------
// 3. Every field the twin publishes is answered through the ladder.
// ---------------------------------------------------------------------------------------------

const fieldNames = fields && typeof fields === 'object' ? Object.keys(fields) : [];

check('the-world-declares-at-least-one-published-field',
  'a resolver with nothing declared cannot be watched working',
  () => ({ ok: fieldNames.length > 0, want: 'at least one field in world.fields', got: fieldNames.length + ' fields: ' + fieldNames.join(', ') }));

for (const field of fieldNames) {
  check('the-field-resolves-through-the-ladder: ' + field,
    'world.resolve returns one of the two ladder shapes, an answer at a rung or a dated unknown',
    () => {
      if (!world || typeof world.resolve !== 'function') {
        return { ok: false, want: 'world.resolve to be a function', got: 'world.resolve is ' + (world ? typeof world.resolve : 'no world') };
      }
      const r = world.resolve(field);
      const shape = shapeOf(r);
      return { ok: shape === 'a dated unknown' || shape === 'an answer at a rung', want: 'a ladder shape for ' + field, got: shape };
    });

  check('an-absence-carries-the-record-that-explains-it: ' + field,
    'when the answer is not known, the reason is a record read at the same cursor and not a sentence in code',
    () => {
      if (!world || typeof world.resolve !== 'function') {
        return { ok: false, want: 'world.resolve to be a function', got: 'world.resolve is ' + (world ? typeof world.resolve : 'no world') };
      }
      const r = world.resolve(field);
      if (!isUnknown(r)) return { ok: true, want: 'an answer or an explained absence', got: 'answered at the ' + r.rung + ' rung, so there is no absence to explain' };
      const declared = fields[field] && fields[field].because ? fields[field].because : null;
      if (!declared) return { ok: false, want: 'a record id declared to explain an absence of ' + field, got: 'none declared in world.fields' };
      const carried = r.because && r.because.source ? r.because.source : null;
      return { ok: r.becauseId === declared && Boolean(carried), want: 'the absence to cite ' + declared + ' with its source', got: 'cites ' + String(r.becauseId) + ', source ' + String(carried) };
    });
}

// ---------------------------------------------------------------------------------------------
// 4. The value a panel reads is the ladder's answer, not a system's own state.
// ---------------------------------------------------------------------------------------------
//
// src/main.js builds the frame's view from world.state.tide and hands `answer` to src/ui/panel.js,
// which shows it. So the value on the page is world.state.tide.answer, and it has to have come from
// the ladder rather than from the tide system's own heightM, which is the simulation rung and which
// live mode is required to refuse.
//
// The system does not hand the ladder's object straight through. It flattens it into a payload a
// panel can read without knowing the ladder's two shapes: field, known, value, mode, asAt, rung,
// source, because, why. That is a reasonable seam and it is also exactly where a second opinion
// could be introduced without anybody noticing, so this checks the payload against a fresh resolve
// at the same cursor rather than only checking that it looks like an answer.

const tide = world && world.state ? world.state.tide : null;
const TIDE_FIELD = 'tide.heightM';

/** The shape src/systems/tide.js hands to the page. Anything else did not come from the ladder. */
function pageAnswerShape(a) {
  if (a === null || a === undefined) return 'no answer at all';
  if (typeof a !== 'object') return 'not an object';
  if (typeof a.field !== 'string') return 'an answer naming no field';
  if (typeof a.known !== 'boolean') return 'an answer that does not say whether it is known';
  if (typeof a.mode !== 'string' || typeof a.asAt !== 'string') return 'an answer with no mode or no date';
  if (a.known === false) {
    if (a.value !== null) return 'an unknown carrying a value';
    if (typeof a.why !== 'string' || a.why.trim() === '') return 'an unknown with no reason';
    return 'a dated unknown for ' + a.field;
  }
  if (typeof a.rung !== 'string' || typeof a.source !== 'string') return 'an answer with no rung or no source';
  return 'an answer at the ' + a.rung + ' rung for ' + a.field;
}

check('the-answer-on-the-page-came-through-the-ladder',
  'world.state.tide.answer is the shape the ladder produced, dated and saying which mode answered',
  () => {
    if (!tide) return { ok: false, want: 'a tide system in the world', got: 'world.state.tide is ' + String(tide) };
    return eq('a dated unknown for ' + TIDE_FIELD, pageAnswerShape(tide.answer));
  });

check('the-page-answer-and-a-fresh-resolve-agree',
  'the value a panel shows is the ladder\'s answer at this cursor and not a second opinion beside it',
  () => {
    if (!tide) return { ok: false, want: 'a tide system in the world', got: 'world.state.tide is ' + String(tide) };
    if (!world || typeof world.resolve !== 'function') {
      return { ok: false, want: 'world.resolve to be a function', got: 'world.resolve is ' + (world ? typeof world.resolve : 'no world') };
    }
    const a = tide.answer;
    if (!a || typeof a !== 'object') return { ok: false, want: 'an answer to compare', got: pageAnswerShape(a) };
    const r = world.resolve(TIDE_FIELD);
    const want = [TIDE_FIELD, r.mode, isUnknown(r) ? 'not known' : 'known', isUnknown(r) ? String(r.becauseId) : String(r.rung)].join(' / ');
    const got = [String(a.field), String(a.mode), a.known ? 'known' : 'not known', a.known ? String(a.rung) : String(a.because)].join(' / ');
    return eq(want, got);
  });

check('the-system-says-where-its-answer-came-from',
  'answerFrom names the ladder, so a world with no resolver reads as unwired instead of as a null',
  () => {
    if (!tide) return { ok: false, want: 'a tide system in the world', got: 'world.state.tide is ' + String(tide) };
    return eq('the world source ladder over the record store', tide.answerFrom);
  });

check('the-simulation-rung-is-not-the-answer',
  'the system keeps its own value and the twin publishes the ladder\'s, and they are two different things',
  () => {
    if (!tide) return { ok: false, want: 'a tide system in the world', got: 'world.state.tide is ' + String(tide) };
    const a = tide.answer;
    const borrowed = a !== null && typeof a === 'object' && a.known === true && a.rung === 'simulation';
    const flattened = a !== null && typeof a !== 'object';
    return {
      ok: !borrowed && !flattened,
      want: 'the answer to be a ladder result rather than the system\'s own heightM',
      got: 'heightM ' + String(tide.heightM) + ', answer ' + pageAnswerShape(a)
    };
  });

// ---------------------------------------------------------------------------------------------
// Report
// ---------------------------------------------------------------------------------------------

const failed = checks.filter((c) => !c.ok);
const summary = {
  built: buildError === null,
  buildError,
  storeSize: records ? records.size : null,
  packs: world && world.recordsLoaded ? world.recordsLoaded.packs : null,
  quarantined: world && world.recordsLoaded ? world.recordsLoaded.quarantined : null,
  fields: fieldNames,
  checks
};

if (JSON_OUT) {
  console.log(JSON.stringify(summary, null, 2));
} else {
  console.log('wiring: the record store in src/world/island.js, and the fields the twin publishes through it');
  const banner = faultBanner();
  if (banner) console.log(banner);
  console.log('store:  ' + (records ? records.size + ' records from ' + (world.recordsLoaded.packs || []).map((p) => p.pack).join(', ') : 'no store on the world'));
  console.log('fields: ' + (fieldNames.length ? fieldNames.join(', ') : 'none declared'));
  console.log('');
  for (const c of checks) console.log('  [' + (c.ok ? 'ok' : 'FAIL') + '] ' + c.id);
  for (const c of failed) {
    console.log('');
    console.log('FAILED CHECK: ' + c.id);
    console.log('  asserts: ' + c.asserts);
    console.log('  wanted:  ' + c.want);
    console.log('  got:     ' + c.got);
  }
  console.log('');
  console.log(failed.length
    ? 'FAIL: ' + failed.length + ' of ' + checks.length + ' checks failed, first ' + failed[0].id
    : 'PASS: ' + checks.length + ' checks over a world built the way every instrument builds it');
}

process.exitCode = failed.length ? 1 : 0;
