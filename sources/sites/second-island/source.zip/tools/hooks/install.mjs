// Install this repository's git hooks.
//
//     node tools/hooks/install.mjs           install, or report that they are already installed
//     node tools/hooks/install.mjs --check   exit 1 if any hook is missing or out of date
//
// Hooks live in .git/hooks, which git does not track, so a hook that is not installed on your
// machine is not running on your machine. --check is the honest way to find that out, and it is
// the shape docs/CONTRACT.md asks for: prove it by asking, do not assume.

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const HOOKS_SRC = HERE;
const HOOKS_DST = path.join(ROOT, '.git', 'hooks');
const HOOKS = ['commit-msg'];

const check = process.argv.includes('--check');
let bad = 0;

if (!fs.existsSync(HOOKS_DST)) {
  console.error('no .git/hooks directory at ' + HOOKS_DST + ': is this a git repository?');
  process.exit(1);
}

for (const name of HOOKS) {
  const src = path.join(HOOKS_SRC, name);
  const dst = path.join(HOOKS_DST, name);
  const want = fs.readFileSync(src, 'utf8');
  const have = fs.existsSync(dst) ? fs.readFileSync(dst, 'utf8') : null;

  if (have === want) {
    console.log(`  ${name}  installed and current`);
    continue;
  }
  if (check) {
    console.error(`  ${name}  ${have === null ? 'NOT INSTALLED' : 'out of date'}`);
    bad++;
    continue;
  }
  fs.writeFileSync(dst, want, { mode: 0o755 });
  try { fs.chmodSync(dst, 0o755); } catch { /* Windows filesystems may refuse the mode; git still runs it */ }
  console.log(`  ${name}  ${have === null ? 'installed' : 'updated'}`);
}

if (bad) {
  console.error(`\n${bad} hook(s) not current. Run: node tools/hooks/install.mjs`);
  process.exit(1);
}
console.log('\nhooks current.');
