// gate/lore: the cultural boundary, executed.
//
// docs/CONTRACT.md section 0: a rule that is not in the gate does not exist. The first build wrote
// its cultural rules into data/lore.json, gave each one a machine-checkable `check` block, and then
// had an agent violate them anyway, because for several waves nothing read those blocks. This file
// reads them.
//
// The rules are NOT restated here. They are read out of data/lore.json, which is carried from the
// first build byte for byte, and each `check.type` gets a handler below. A rule whose type has no
// handler is reported as unimplemented rather than passing silently, so the pack can grow without
// quietly growing a hole.
//
// Severities. tools/gate.mjs accepts exactly two and turns anything else into `blocking`, so this
// module emits exactly two and carries the shade of meaning in a prefix on `why`:
//
//   blocking      the gate fails. A cultural rule was broken, or a rule could not be executed.
//   advisory      the gate still passes. Three kinds live here, each labelled in `why`:
//     MANUAL:         the pack marks the rule manual, so no code can decide it. Printed every run,
//                     because a manual rule nobody is ever shown is a rule nobody runs.
//     STOP AND ASK:   a word or phrase that is probably fine and might not be. A human answers it.
//     NOT YET RUN:    the rule's subject does not exist yet, so the check ran against nothing. This
//                     is the "exists, untested" row of docs/CONTRACT.md section 6, and it is
//                     recorded so it can never be mistaken for a pass.
//
// Two things in here are this repository's, not the first build's. They are gathered under the
// heading THIS BUILD'S ADDITIONS near the bottom and every finding they raise says so in `why`.
//
// What this file honestly cannot do, said here rather than discovered later:
//
//   The token allowlist cannot read free English prose. There is no way to tell an invented
//   Quandamooka-looking word from an ordinary English word by spelling alone, and the measurement
//   is in the report for this task: an orthographic profile built from the pack's own vocabulary
//   matched about fifty distinct ordinary English words in this repository's Markdown ("along",
//   "among", "season", "renderer", "database"). Blocking on that would drown the gate and the gate
//   would be switched off, which is how the first build lost its cultural check in the first place.
//   So the blocking tier is POSITIONAL: a word is blocked when it sits where a language word sits,
//   in a cultural field or a word-keyed map or a name field, and is shaped like the words the pack
//   already carries. Prose in docs/** raises nothing. That is a real gap and it is stated, not hidden.
//
//   The shape profile is derived from the pack's own vocabulary (its allowlist, its variant
//   spellings, its clan spellings and its banned tokens), so it moves when the pack moves. It is a
//   filter against noise, not a language detector, and it is never the only signal for a block.

import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const id = 'lore';

export const SEVERITIES = ['blocking', 'advisory'];

const MANUAL = 'MANUAL: ';
const ASK = 'STOP AND ASK: ';
const NOT_YET = 'NOT YET RUN: ';

const LORE_PATH = 'data/lore.json';

const TEXT_EXT = new Set([
  '.js', '.mjs', '.cjs', '.json', '.geojson', '.md', '.txt', '.html', '.htm', '.css',
  '.csv', '.tsv', '.svg', '.glsl', '.wgsl', '.yml', '.yaml', '.xml'
]);

const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox', '.vscode', '.idea']);

// ---------------------------------------------------------------------------------------------
// Small file and path helpers. No dependencies, by the repository's rule.
// ---------------------------------------------------------------------------------------------

/** Every file under root, as repo-relative posix paths, sorted so two runs agree. */
function walkFiles(root) {
  const out = [];
  const stack = [''];
  while (stack.length) {
    const rel = stack.pop();
    const abs = rel ? path.join(root, rel) : root;
    let entries;
    try {
      entries = fs.readdirSync(abs, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      if (e.name.startsWith('.') && e.name !== '.gitignore' && e.name !== '.gitattributes') {
        if (SKIP_DIRS.has(e.name)) continue;
      }
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        stack.push(rel ? `${rel}/${e.name}` : e.name);
      } else if (e.isFile()) {
        out.push(rel ? `${rel}/${e.name}` : e.name);
      }
    }
  }
  return out.sort();
}

function readText(root, file) {
  try {
    return fs.readFileSync(path.join(root, file), 'utf8');
  } catch {
    return null;
  }
}

function exists(root, file) {
  try {
    fs.accessSync(path.join(root, file));
    return true;
  } catch {
    return false;
  }
}

function escapeRe(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** A scope entry such as `src/**`, `data/places.json` or `index.html`, as a regular expression. */
function globToRegExp(glob) {
  let out = '^';
  for (let i = 0; i < glob.length; i++) {
    const c = glob[i];
    if (c === '*') {
      if (glob[i + 1] === '*') {
        if (glob[i + 2] === '/') { out += '(?:.*/)?'; i += 2; } else { out += '.*'; i += 1; }
      } else {
        out += '[^/]*';
      }
    } else if (c === '?') {
      out += '[^/]';
    } else {
      out += escapeRe(c);
    }
  }
  return new RegExp(out + '$');
}

const globCache = new Map();
function matchesGlob(file, glob) {
  if (!globCache.has(glob)) globCache.set(glob, globToRegExp(glob));
  return globCache.get(glob).test(file);
}

function inScope(file, scope) {
  if (!scope || !scope.length) return true;
  return scope.some((g) => matchesGlob(file, g));
}

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}

/** First line on which any of the needles appears, or 1 when none does. */
function locate(text, needles) {
  for (const n of needles) {
    if (typeof n !== 'string' || !n.length) continue;
    const i = text.indexOf(n);
    if (i >= 0) return lineOf(text, i);
  }
  return 1;
}

function lineText(text, line) {
  const lines = text.split('\n');
  const raw = (lines[line - 1] || '').trim();
  return raw.length > 200 ? `${raw.slice(0, 197)}...` : raw;
}

/**
 * A token as a whole word. Multi-word tokens such as "welcome to country" match across any run of
 * whitespace, because a JSON file and a Markdown file break lines in different places.
 */
function tokenRegExp(token, caseInsensitive) {
  const body = String(token).trim().split(/\s+/).map(escapeRe).join('\\s+');
  return new RegExp(`(?<![A-Za-z0-9_])${body}(?![A-Za-z0-9_])`, caseInsensitive ? 'gi' : 'g');
}

function tokenHits(text, token, caseInsensitive) {
  const rx = tokenRegExp(token, caseInsensitive);
  const out = [];
  let m;
  while ((m = rx.exec(text)) !== null) {
    out.push({ index: m.index, line: lineOf(text, m.index), match: m[0] });
    if (rx.lastIndex === m.index) rx.lastIndex++;
  }
  return out;
}

/**
 * Resolve a pack path such as `language.allowlist[*].variants[*].spelling` to the values it names.
 * The pack writes its own check blocks in this notation, so the checks read it rather than
 * hardcoding where the words live.
 */
function resolvePackPath(root, spec) {
  let nodes = [root];
  for (const step of String(spec).split('.')) {
    const m = /^([A-Za-z0-9_$]+)((?:\[\*\]|\[\d+\])*)$/.exec(step);
    if (!m) return [];
    const [, key, subs] = m;
    let next = [];
    for (const n of nodes) {
      if (n && typeof n === 'object' && key in n) next.push(n[key]);
    }
    for (const sub of subs.match(/\[(?:\*|\d+)\]/g) || []) {
      const expanded = [];
      for (const n of next) {
        if (!Array.isArray(n)) continue;
        if (sub === '[*]') expanded.push(...n);
        else expanded.push(n[Number(sub.slice(1, -1))]);
      }
      next = expanded;
    }
    nodes = next.filter((v) => v !== undefined);
  }
  return nodes;
}

/** Walk a parsed JSON document, yielding every key and every leaf with its pointer and ancestry. */
function* walkJson(node, pointer = '', ancestors = []) {
  if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) yield* walkJson(node[i], `${pointer}[${i}]`, ancestors);
  } else if (node && typeof node === 'object') {
    for (const key of Object.keys(node)) {
      const p = pointer ? `${pointer}.${key}` : key;
      yield { kind: 'key', key, pointer: p, ancestors, parent: ancestors[ancestors.length - 1] || '', value: node[key], object: node };
      yield* walkJson(node[key], p, ancestors.concat(key));
    }
  } else {
    yield { kind: 'leaf', key: ancestors[ancestors.length - 1] || '', pointer, ancestors, value: node };
  }
}

/** Every object in a parsed JSON document, with its pointer. */
function* walkObjects(node, pointer = '') {
  if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) yield* walkObjects(node[i], `${pointer}[${i}]`);
  } else if (node && typeof node === 'object') {
    yield { object: node, pointer };
    for (const key of Object.keys(node)) {
      yield* walkObjects(node[key], pointer ? `${pointer}.${key}` : key);
    }
  }
}

// ---------------------------------------------------------------------------------------------
// The scan context: files read once, lore read once, findings collected in one place.
// ---------------------------------------------------------------------------------------------

class Scan {
  constructor(root, lore) {
    this.root = root;
    this.lore = lore;
    this.files = walkFiles(root);
    this.textCache = new Map();
    this.jsonCache = new Map();
    this.findings = [];
    this.loreText = readText(root, LORE_PATH) || '';
  }

  text(file) {
    if (!this.textCache.has(file)) this.textCache.set(file, readText(this.root, file));
    return this.textCache.get(file);
  }

  json(file) {
    if (!this.jsonCache.has(file)) {
      const t = this.text(file);
      let parsed = null;
      if (t !== null) { try { parsed = JSON.parse(t); } catch { parsed = null; } }
      this.jsonCache.set(file, parsed);
    }
    return this.jsonCache.get(file);
  }

  /** Files in a rule's scope. `textOnly` filters to files this module can read as text. */
  scoped(scope, { textOnly = true } = {}) {
    return this.files.filter((f) => inScope(f, scope)
      && (!textOnly || TEXT_EXT.has(path.extname(f).toLowerCase())));
  }

  add(f) {
    this.findings.push({
      rule: f.rule,
      severity: f.severity,
      file: f.file,
      line: f.line || 0,
      text: f.text || '',
      why: f.why || ''
    });
  }

  /** The line in data/lore.json on which a rule is declared, so every finding has somewhere to point. */
  ruleLine(ruleId) {
    return locate(this.loreText, [`"id": "${ruleId}"`, `"${ruleId}"`]);
  }
}

// ---------------------------------------------------------------------------------------------
// check.type handlers. One per type the pack uses.
// ---------------------------------------------------------------------------------------------

const CHECKERS = Object.create(null);

/** Tokens for a token rule: either listed in the check block, or named by a path into the pack. */
function ruleTokens(scan, check) {
  if (Array.isArray(check.tokens)) return check.tokens.filter((t) => typeof t === 'string' && t.trim());
  if (check.tokens_path) {
    return resolvePackPath(scan.lore, check.tokens_path)
      .map((v) => (typeof v === 'string' ? v : v && v.token))
      .filter((t) => typeof t === 'string' && t.trim());
  }
  return [];
}

/**
 * forbidden_tokens and the token half of manual_plus_tokens. Word boundaries, the rule's own
 * case setting, the rule's own exempt files, and the rule's own scope, widened where THIS BUILD'S
 * ADDITIONS widen it.
 *
 * File paths are scanned as well as file contents. An asset cannot be read as text, so the name of
 * the file is the only handle there is on it, and a restricted place name in a file name publishes
 * the place just as surely as one in a data value.
 */
function tokenScan(scan, rule, { severityForHit, hintForHit }) {
  const check = rule.check || {};
  const tokens = ruleTokens(scan, check);
  const ci = check.case_insensitive !== false;
  const exempt = new Set(check.exempt_files || []);
  for (const f of LOCAL_EXEMPTIONS[rule.id] || []) exempt.add(f.file);
  const added = LOCAL_SCOPE_ADDITIONS[rule.id] || [];
  const declaredScope = rule.scope || [];
  const scope = declaredScope.concat(added);

  if (!tokens.length) {
    scan.add({
      rule: rule.id,
      severity: 'blocking',
      file: LORE_PATH,
      line: scan.ruleLine(rule.id),
      text: rule.rule || '',
      why: `The check block for "${rule.id}" names no tokens, so the token half of this rule scanned `
        + 'nothing. A rule that checks nothing is a failure of the check, never a clean run.'
    });
    return;
  }

  // File names first, for every file in scope including files with no readable text.
  for (const file of scan.scoped(scope, { textOnly: false })) {
    if (exempt.has(file)) continue;
    for (const token of tokens) {
      if (!tokenHits(file, token, ci).length) continue;
      scan.add({
        rule: rule.id,
        severity: severityForHit,
        file,
        line: 0,
        text: file,
        why: `The token "${token}" appears in the file name itself. ${hintForHit}`
          + scopeNote(file, declaredScope, added)
      });
    }
  }

  for (const file of scan.scoped(scope)) {
    if (exempt.has(file)) continue;
    const text = scan.text(file);
    if (text === null) continue;
    for (const token of tokens) {
      for (const hit of tokenHits(text, token, ci)) {
        scan.add({
          rule: rule.id,
          severity: severityForHit,
          file,
          line: hit.line,
          text: lineText(text, hit.line),
          why: `The token "${token}" appears at ${file} line ${hit.line}. ${hintForHit}`
            + scopeNote(file, declaredScope, added)
        });
      }
    }
  }
}

function scopeNote(file, declaredScope, added) {
  if (!added.length) return '';
  if (inScope(file, declaredScope)) return '';
  return ` This file is outside the scope the carried pack declares; second-island widened the scope to ${added.join(', ')}.`;
}

CHECKERS.forbidden_tokens = (scan, rule) => {
  tokenScan(scan, rule, {
    severityForHit: rule.severity === 'advisory' ? 'advisory' : 'blocking',
    hintForHit: (rule.check && rule.check.note)
      || 'A hit is a stop-and-ask, not automatically a violation. The usual right answer is to delete the line.'
  });
};

CHECKERS.manual_plus_tokens = (scan, rule) => {
  tokenScan(scan, rule, {
    severityForHit: rule.severity === 'advisory' ? 'advisory' : 'blocking',
    hintForHit: (rule.check && rule.check.note)
      || 'A hit is a stop-and-ask, not automatically a violation. The usual right answer is to delete the line.'
  });
  scan.add({
    rule: rule.id,
    severity: 'advisory',
    file: LORE_PATH,
    line: scan.ruleLine(rule.id),
    text: rule.rule || '',
    why: `${MANUAL}The pack marks this rule part manual. The token scan above covers only the wording `
      + 'that is easiest to write by accident, so a human still has to read the change.'
  });
};

CHECKERS.manual = (scan, rule) => {
  const q = (rule.check && rule.check.reviewer_question) || rule.rule || '';
  scan.add({
    rule: rule.id,
    severity: 'advisory',
    file: LORE_PATH,
    line: scan.ruleLine(rule.id),
    text: q,
    why: `${MANUAL}The pack marks this rule manual: no code can decide it. It is printed every run `
      + 'because a manual rule nobody is ever shown is a rule nobody runs.'
  });
};

/** field_absent: named fields may not appear as keys in the named files. */
CHECKERS.field_absent = (scan, rule) => {
  const check = rule.check || {};
  const fields = (check.fields || []).map((f) => String(f).toLowerCase());
  const files = check.in || (rule.scope || []).filter((s) => s.endsWith('.json'));
  const present = files.filter((f) => exists(scan.root, f));
  if (!present.length) {
    scan.add({
      rule: rule.id,
      severity: 'advisory',
      file: files[0] || LORE_PATH,
      line: 0,
      text: rule.rule || '',
      why: `${NOT_YET}None of the files this rule guards exist yet `
        + `(${files.join(', ') || 'none named'}), so the check ran against nothing. It starts working `
        + 'the moment one of them lands.'
    });
    return;
  }
  for (const file of present) {
    const doc = scan.json(file);
    const text = scan.text(file) || '';
    if (doc === null) continue;
    for (const node of walkJson(doc)) {
      if (node.kind !== 'key') continue;
      if (!fields.includes(node.key.toLowerCase())) continue;
      const line = locate(text, [`${JSON.stringify(node.key)}:`, JSON.stringify(node.key)]);
      scan.add({
        rule: rule.id,
        severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
        file,
        line,
        text: lineText(text, line),
        why: `Forbidden field "${node.key}" on a record at ${node.pointer}. ${rule.rationale || ''}`.trim()
      });
    }
  }
};

/**
 * field_gate: a field may not take certain values when a condition holds. The pack writes the
 * condition as `player_facing is true`, which is parsed rather than assumed.
 */
CHECKERS.field_gate = (scan, rule) => {
  const check = rule.check || {};
  const field = check.field;
  const forbidden = new Set((check.forbidden_values || []).map((v) => String(v)));
  const cond = /^([A-Za-z0-9_]+)\s+is\s+(true|false)$/.exec(String(check.when || '').trim());
  if (!field || !forbidden.size || !cond) {
    scan.add({
      rule: rule.id,
      severity: 'blocking',
      file: LORE_PATH,
      line: scan.ruleLine(rule.id),
      text: rule.rule || '',
      why: `This check block could not be executed as written: field="${field}", when="${check.when}". `
        + 'It is a failure of the check, never a clean run.'
    });
    return;
  }
  const [, gateField, gateValueRaw] = cond;
  const gateValue = gateValueRaw === 'true';
  const files = [LORE_PATH, ...scan.scoped(['data/**'])].filter((f, i, a) => a.indexOf(f) === i);
  for (const file of files) {
    if (path.extname(file).toLowerCase() !== '.json') continue;
    const doc = scan.json(file);
    const text = scan.text(file) || '';
    if (doc === null) continue;
    for (const { object, pointer } of walkObjects(doc)) {
      if (object[gateField] !== gateValue) continue;
      if (!(field in object)) continue;
      if (!forbidden.has(String(object[field]))) continue;
      const line = locate(text, [`${JSON.stringify(field)}: ${JSON.stringify(object[field])}`,
        `${JSON.stringify(field)}:${JSON.stringify(object[field])}`]);
      scan.add({
        rule: rule.id,
        severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
        file,
        line,
        text: lineText(text, line),
        why: `The record at ${pointer} has ${gateField}=${gateValue} and ${field}="${object[field]}", `
          + `which the pack forbids. ${rule.rationale || ''}`.trim()
      });
    }
  }
};

/** string_present: one of several pack strings must appear verbatim in the files the rule scopes. */
CHECKERS.string_present = (scan, rule) => {
  const paths = (rule.check && rule.check.one_of_paths) || [];
  const candidates = paths.flatMap((p) => resolvePackPath(scan.lore, p)).filter((v) => typeof v === 'string');
  if (!candidates.length) {
    scan.add({
      rule: rule.id,
      severity: 'blocking',
      file: LORE_PATH,
      line: scan.ruleLine(rule.id),
      text: rule.rule || '',
      why: `None of the pack paths this rule names resolve to a string (${paths.join(', ')}), so the `
        + 'check had nothing to look for.'
    });
    return;
  }
  const files = scan.scoped(rule.scope);
  if (!files.length) {
    scan.add({
      rule: rule.id,
      severity: 'advisory',
      file: (rule.scope || [LORE_PATH])[0],
      line: 0,
      text: rule.rule || '',
      why: `${NOT_YET}No file in this rule's scope (${(rule.scope || []).join(', ')}) exists yet, so `
        + 'the acknowledgement has nowhere to be. The check starts working with the first page.'
    });
    return;
  }
  const found = files.some((f) => {
    const t = scan.text(f);
    return t !== null && candidates.some((c) => t.includes(c));
  });
  if (found) return;
  scan.add({
    rule: rule.id,
    severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
    file: files[0],
    line: 0,
    text: candidates[0].slice(0, 160),
    why: 'Neither acknowledgement wording from the pack appears verbatim in any file in scope '
      + `(${files.join(', ')}). ${rule.rationale || ''}`.trim()
  });
};

/**
 * cross_reference: the pack writes the reference as a sentence, which no generic handler can
 * execute. Each one is implemented against its rule id, and a cross_reference rule with no
 * implementation falls through to the unimplemented report rather than passing.
 */
const CROSS_REFERENCE = Object.create(null);

CHECKERS.cross_reference = (scan, rule) => {
  const impl = CROSS_REFERENCE[rule.id];
  if (!impl) {
    scan.add({
      rule: rule.id,
      severity: 'blocking',
      file: LORE_PATH,
      line: scan.ruleLine(rule.id),
      text: (rule.check && rule.check.rule) || rule.rule || '',
      why: 'This cross reference is written as a sentence and has no implementation keyed to its rule '
        + 'id in tools/gate/lore.mjs. It is a failure of the check, never a clean run.'
    });
    return;
  }
  impl(scan, rule);
};

CROSS_REFERENCE['no-quandamooka-position-without-citation'] = (scan, rule) => {
  const positions = (scan.lore.qyac_public_positions && scan.lore.qyac_public_positions.positions) || [];
  const known = new Set(positions.map((p) => p && p.id).filter(Boolean));
  const files = scan.scoped(rule.scope).filter((f) => path.extname(f).toLowerCase() === '.json');
  for (const file of files) {
    const doc = scan.json(file);
    const text = scan.text(file) || '';
    if (doc === null) continue;
    for (const node of walkJson(doc)) {
      if (node.kind !== 'key') continue;
      if (!/^(qyac|quandamooka)_position$/i.test(node.key)) continue;
      const v = node.value;
      const ref = typeof v === 'string' ? v : (v && (v.position_ref || v.id));
      if (known.has(ref)) continue;
      const line = locate(text, [`${JSON.stringify(node.key)}:`]);
      scan.add({
        rule: rule.id,
        severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
        file,
        line,
        text: lineText(text, line),
        why: `A Quandamooka position at ${node.pointer} resolves to no id in `
          + `lore.qyac_public_positions (${known.size} positions on record). Silence is accurate; an `
          + 'invented position is not.'
      });
    }
  }
};

CROSS_REFERENCE['no-cultural-content-without-source'] = (scan, rule) => {
  const ids = new Set();
  for (const node of walkJson(scan.lore)) {
    if (node.kind === 'key' && node.key === 'id' && typeof node.value === 'string') ids.add(node.value);
  }
  for (const k of Object.keys(scan.lore.sources || {})) ids.add(k);

  const files = scan.scoped(rule.scope);
  for (const file of files) {
    const text = scan.text(file);
    if (text === null || !text.includes('lore_ref')) continue;
    const rx = /["']lore_ref["']\s*:\s*["']([^"']+)["']/g;
    let m;
    while ((m = rx.exec(text)) !== null) {
      if (ids.has(m[1])) continue;
      const line = lineOf(text, m.index);
      scan.add({
        rule: rule.id,
        severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
        file,
        line,
        text: lineText(text, line),
        why: `lore_ref "${m[1]}" resolves to nothing in ${LORE_PATH}.`
      });
    }
  }

  // The other half, executable inside the pack: anything the pack marks player facing has to cite
  // something and has to be at least medium confidence.
  const loreText = scan.loreText;
  for (const { object, pointer } of walkObjects(scan.lore)) {
    if (object.player_facing !== true) continue;
    // A citation can sit one level down. Seven allowlist entries carry theirs on each variant
    // spelling rather than on the word itself, which is the pack's own shape and not a missing source.
    const citedVariant = Array.isArray(object.variants)
      && object.variants.some((v) => v && (v.source || v.source_2 || v.url));
    const cited = Boolean(object.source || object.source_ref || object.sources
      || object.source_2 || object.published_meanings || object.published_meaning || citedVariant);
    const conf = object.confidence;
    if (cited && (conf === undefined || conf === 'high' || conf === 'medium')) continue;
    const line = locate(loreText, [object.word ? JSON.stringify(object.word) : '', `"${pointer.split('.').pop()}"`]);
    scan.add({
      rule: rule.id,
      severity: rule.severity === 'advisory' ? 'advisory' : 'blocking',
      file: LORE_PATH,
      line,
      text: lineText(loreText, line),
      why: `The pack record at ${pointer} is player_facing`
        + (cited ? '' : ' and cites nothing')
        + (conf && conf !== 'high' && conf !== 'medium' ? ` and carries confidence "${conf}"` : '')
        + '. Nothing below medium confidence reaches a reader as a claim.'
    });
  }
};

// ---------------------------------------------------------------------------------------------
// token_allowlist. The most important check in this repository, so the reasoning is written out.
//
// The pack's own scan hint says: tokenise on word boundaries, and anything outside the known set is
// a new word that must be sourced before it ships. Tokenising is the easy half. The hard half is
// that "outside the known set" describes every English word in the repository as well, so the check
// has to decide where a word is standing before it decides whether the word is a problem.
//
// Two signals, and a block needs both:
//
//   POSITION. A word is in a cultural position when it sits where a language word sits: as the
//   value of a field that names a word, a spelling, a gloss, a season or a traditional name, or as
//   a key inside a map that is keyed BY such words. The first build's second cultural failure
//   arrived exactly there, as object keys under `season_bias`. Weaker but still worth reporting is
//   a name position: the value of `name`, `id`, `label`, `title` or anything ending `_name` in a
//   data pack, which is how an invented word gets used as a place or a season.
//
//   SHAPE. An orthographic profile built from the pack's own words: the letters they use, the
//   letter pairs they use, and their length. It is a noise filter and nothing more. It passes plenty
//   of English ("season", "renderer", "database"), which is exactly why it never blocks on its own.
//
// Prose is not scanned. See the header.
// ---------------------------------------------------------------------------------------------

// Maps whose keys are themselves language words, and fields whose value is a single word.
const CULTURAL_CONTAINER = /^(seasons?|season_bias|seasonal_calendar|words|vocabulary|glosses|spellings|language_words|language_name|traditional_names|place_names_language|clans?|moiet(?:y|ies)|totems?|dreamings?|songlines?)$/i;
const CULTURAL_FIELD = /^(word|spelling|gloss|season|language_name|traditional_name|indigenous_name|aboriginal_name|country_name|clan|moiety|totem|dreaming|songline)$/i;

// Fields that hold a citation, a URL or an English sentence. Their contents are not vocabulary.
const NOT_VOCABULARY = /^(source|sources|source_\d|source_ref|url|href|link|note|notes|reason|rationale|citation|confidence|read|what|who|where|when|why|register|severity|scope|locator|description|summary|comment|player_facing|meaning|usage|hint)$/i;

// Fields whose value names a thing. An invented word arrives here when it is used as a place.
// `title` is deliberately absent: a title is a sentence, not a name for a thing in the world.
const NAME_FIELD = /^(name|id|label|slug|word|season|display_name|short_name)$|_name$|_id$/i;

// Sections of the pack that exist to RECORD words. Scanning them for new words would report the
// allowlist to itself.
const PACK_RECORDING_SECTIONS = [
  /^language\.allowlist/,      // the allowlist cannot be reported to itself
  /^language\.banned_tokens/,  // the record of the words an earlier agent invented
  /^sources/,                  // citations and URLs, not vocabulary
  /^prohibitions/,             // the rules themselves, whose ids are English
  /\.spellings/                // published clan spellings, the allowlist's other half
];

function nameLike(value) {
  const v = String(value).trim();
  if (!v || v.length > 64) return false;
  return v.split(/\s+/).length <= 4;
}

/** The pack's own vocabulary, used only to build the shape profile. */
function packVocabulary(lore) {
  const words = new Set();
  const add = (s) => {
    if (typeof s !== 'string') return;
    for (const t of s.split(/[^A-Za-z]+/)) if (t.length > 2) words.add(t.toLowerCase());
  };
  for (const e of (lore.language && lore.language.allowlist) || []) {
    add(e.word);
    for (const v of e.variants || []) add(v.spelling);
  }
  for (const g of ((lore.peoples && lore.peoples.clans && lore.peoples.clans.groups) || [])) {
    add(g.name);
    for (const s of g.spellings || []) add(s.spelling);
  }
  for (const t of ((lore.language && lore.language.banned_tokens && lore.language.banned_tokens.tokens) || [])) {
    add(typeof t === 'string' ? t : t && t.token);
  }
  return words;
}

function shapeProfile(lore) {
  const vocab = packVocabulary(lore);
  const bigrams = new Set();
  const letters = new Set();
  for (const w of vocab) {
    for (const ch of w) letters.add(ch);
    for (let i = 0; i < w.length - 1; i++) bigrams.add(w.slice(i, i + 2));
  }
  const unused = 'abcdefghijklmnopqrstuvwxyz'.split('').filter((c) => !letters.has(c));
  return { bigrams, unusedLetters: new RegExp(`[${unused.join('')}]`), size: vocab.size };
}

function languageShaped(token, profile) {
  const t = String(token).toLowerCase();
  if (t.length < 5 || t.length > 20) return false;
  if (!/^[a-z]+$/.test(t)) return false;
  if (profile.unusedLetters.test(t)) return false;
  for (let i = 0; i < t.length - 1; i++) if (!profile.bigrams.has(t.slice(i, i + 2))) return false;
  return true;
}

/** The allowlist, read from the paths the rule's own check block names. */
function allowlistWords(lore, check) {
  const allow = new Set();
  for (const spec of check.allowlist_paths || []) {
    for (const v of resolvePackPath(lore, spec)) {
      if (typeof v !== 'string') continue;
      for (const t of v.split(/[^A-Za-z']+/)) if (t.length > 2) allow.add(t.toLowerCase());
    }
  }
  return allow;
}

// THIS BUILD'S ADDITION (c). See the heading below for (a) and (b).
//
// Being on the allowlist is permission to use a word, not permission to use it for anything. The
// first build's cultural failure had two halves. The half an allowlist check catches on its own is
// six invented season names. The half it does not is Yalingbila, a published word for whale, used
// in src/kernel/clock.js as the name of a season and glossed there as "hot wet time". Yalingbila is
// on the allowlist, so a plain allowlist check passes it, and the fault reached the repository.
//
// The pack already holds what is needed to catch it: every allowlist entry says what its word
// refers to. So when an allowlisted word turns up inside a container that names a KIND of thing,
// this check asks whether any published meaning in the pack says the word names that kind. Nothing
// in the pack refers to a season, which is the pack's own finding: no published Quandamooka
// seasonal calendar was found. So any allowlisted word used as a season name fails, by the data.
//
// `usage` is deliberately not part of the haystack. Yalingbila's usage note is the sentence that
// forbids exactly this, and it contains the word "season"; reading it would make the fault pass.
const CONTAINER_KIND = {
  season: 'season', seasons: 'season', season_bias: 'season', seasonal_calendar: 'season',
  month: 'month', months: 'month',
  clan: 'clan', clans: 'clan',
  totem: 'totem', totems: 'totem',
  moiety: 'moiety', moieties: 'moiety',
  dreaming: 'dreaming', dreamings: 'dreaming',
  songline: 'songline', songlines: 'songline'
};

/** word token to the allowlist entry that publishes it. */
function allowlistEntries(lore) {
  const byToken = new Map();
  for (const entry of (lore.language && lore.language.allowlist) || []) {
    const forms = [entry.word, ...(entry.variants || []).map((v) => v && v.spelling)];
    for (const form of forms) {
      if (typeof form !== 'string') continue;
      for (const t of form.split(/[^A-Za-z']+/)) {
        if (t.length > 2 && !byToken.has(t.toLowerCase())) byToken.set(t.toLowerCase(), entry);
      }
    }
  }
  return byToken;
}

// A closed vocabulary of container names is not enough, and we know that from the live data. The
// first build removed Yalingbila from its season names in src/kernel/clock.js and recorded the
// correction in the pack, and then the same misuse reappeared in
// data/feeds/_events-engine.json as "listing_period": "Yalingbila / winter-spring transition".
// The key was not called season, so a check keyed on the word "season" walks straight past it.
// So the kind is inferred two ways, and either is enough.
const KIND_PATTERNS = [
  [/(^|_)seasons?($|_)|seasonal|listing_period|(^|_)periods?($|_)|calendar|(^|_)cycles?($|_)/, 'season'],
  [/(^|_)months?($|_)|(^|_)moons?($|_)/, 'month'],
  [/clan/, 'clan'],
  [/totem/, 'totem'],
  [/moiet/, 'moiety'],
  [/dreaming/, 'dreaming'],
  [/songline/, 'songline']
];

// Plain English words for the same kinds. When one of these sits in the same string as an
// allowlisted word, the allowlisted word is being used as a label for that kind, whatever the key
// happens to be called.
const KIND_COMPANIONS = [
  [/\b(summer|autumn|winter|spring|wet season|dry season|equinox|solstice)\b/i, 'season'],
  [/\b(january|february|march|april|may|june|july|august|september|october|november|december)\b/i, 'month']
];

/** The nearest kind of thing a pointer's ancestry names, or null. */
function kindOf(keys) {
  for (let i = keys.length - 1; i >= 0; i--) {
    const key = String(keys[i] || '').toLowerCase();
    const exact = CONTAINER_KIND[key];
    if (exact) return exact;
    for (const [rx, kind] of KIND_PATTERNS) if (rx.test(key)) return kind;
  }
  return null;
}

/** The kind a value's own words give away, when its key gave nothing away. */
function kindFromCompanions(value) {
  const s = String(value || '');
  for (const [rx, kind] of KIND_COMPANIONS) if (rx.test(s)) return kind;
  return null;
}

/**
 * An allowlisted word used to name a kind of thing no published source says it names. Returns the
 * entry when that is what is happening, and null when it is not.
 */
function misusedAllowlistWord(entries, token, kind) {
  if (!kind) return null;
  const entry = entries.get(String(token).toLowerCase());
  if (!entry) return null;
  const published = [
    entry.refers_to,
    entry.published_meaning,
    ...(entry.published_meanings || []).map((m) => m && m.gloss)
  ].filter((s) => typeof s === 'string').join(' ');
  if (new RegExp(`\\b${kind}s?\\b`, 'i').test(published)) return null;
  return entry;
}

CHECKERS.token_allowlist = (scan, rule) => {
  const check = rule.check || {};
  const allow = allowlistWords(scan.lore, check);
  const entries = allowlistEntries(scan.lore);
  if (!allow.size) {
    scan.add({
      rule: rule.id,
      severity: 'blocking',
      file: LORE_PATH,
      line: scan.ruleLine(rule.id),
      text: rule.rule || '',
      why: 'The allowlist paths in this rule resolve to no words at all, so the check would pass '
        + 'everything. That is reported as a failure of the check, not as a clean run.'
    });
    return;
  }
  const profile = shapeProfile(scan.lore);
  const exempt = new Set(check.exempt_files || []);
  const blockingSeverity = rule.severity === 'advisory' ? 'advisory' : 'blocking';

  for (const file of scan.scoped(rule.scope)) {
    if (exempt.has(file)) continue;
    const isPack = file === LORE_PATH;
    const ext = path.extname(file).toLowerCase();
    const text = scan.text(file);
    if (text === null) continue;

    if (ext === '.json' || ext === '.geojson') {
      const doc = scan.json(file);
      if (doc === null) continue;
      for (const node of walkJson(doc)) {
        if (isPack && PACK_RECORDING_SECTIONS.some((rx) => rx.test(node.pointer))) continue;

        let position = null;
        let candidateText = null;
        if (node.kind === 'key') {
          if (CULTURAL_CONTAINER.test(node.parent)) { position = 'cultural'; candidateText = node.key; }
        } else {
          if (typeof node.value !== 'string') continue;
          if (NOT_VOCABULARY.test(node.key)) continue;
          if (nameLike(node.value)) {
            if (CULTURAL_FIELD.test(node.key) || node.ancestors.some((a) => CULTURAL_CONTAINER.test(a))) {
              position = 'cultural';
            } else if (NAME_FIELD.test(node.key)) {
              position = 'name';
            }
            candidateText = node.value;
          }
          // The third position, and the one the live data taught us. A string in a field with an
          // unremarkable name, which does not read as a name at all, but which puts an allowlisted
          // word beside a plain English word for a kind of thing. That is what
          // "Yalingbila / winter-spring transition" is, and the two tests above both walk past it.
          // Label-like only. A word inside a paragraph of prose is being written about, not used
          // as the name of anything, and treating a sentence as a label produces noise that
          // teaches the reader to skip this rule's findings. That is worse than missing one.
          if (!position && nameLike(node.value)
              && (kindOf(node.ancestors.concat(node.key)) || kindFromCompanions(node.value))) {
            for (const raw of String(node.value).split(/[^A-Za-z']+/)) {
              if (allow.has(raw.replace(/'/g, '').toLowerCase())) { position = 'kind-use'; candidateText = node.value; break; }
            }
          }
        }
        if (!position || !candidateText) continue;

        // The kind is asked of the key first and of the value second, for every position. Asking
        // only the value, or only the key, is how the live instance in the first build's event
        // feed slipped past an earlier draft of this check.
        const kind = kindOf(node.kind === 'key' ? [node.parent] : node.ancestors.concat(node.key))
          || kindFromCompanions(candidateText);

        for (const token of String(candidateText).split(/[^A-Za-z']+/)) {
          const t = token.replace(/'/g, '').toLowerCase();
          if (!t) continue;
          if (allow.has(t)) {
            const entry = misusedAllowlistWord(entries, t, kind);
            if (!entry) continue;
            const line = locate(text, [JSON.stringify(node.value), token]);
            scan.add({
              rule: rule.id,
              severity: isPack ? 'advisory' : blockingSeverity,
              file,
              line,
              text: lineText(text, line),
              why: (isPack ? ASK : '')
                + `"${token}" is on the allowlist, but here it names a ${kind} (${node.pointer}). `
                + `The pack publishes it as: ${(entry.refers_to || entry.published_meaning || '').slice(0, 120)}. `
                + `No published meaning in the pack says it names a ${kind}. This is the second half of `
                + "the first build's cultural failure, where a published word for whale was used as the "
                + 'name of a season. Being on the allowlist is permission to use a word, not permission '
                + 'to use it for anything. Use English for the label, or ask.'
            });
            continue;
          }
          if (!languageShaped(t, profile)) continue;
          const line = node.kind === 'key'
            ? locate(text, [`${JSON.stringify(node.key)}:`, JSON.stringify(node.key)])
            : locate(text, [JSON.stringify(node.value), token]);
          const severity = position === 'cultural' && !isPack ? blockingSeverity : 'advisory';
          scan.add({
            rule: rule.id,
            severity,
            file,
            line,
            text: lineText(text, line),
            why: (severity === 'advisory' ? ASK : '')
              + `"${token}" is not on the allowlist and it sits in a ${position} position `
              + `(${node.pointer}). `
              + (position === 'cultural'
                ? 'A word in a cultural position is being presented as language. '
                : 'A word in a name position is being used to name a thing. ')
              + (isPack
                ? 'It is inside the carried pack, which this build may not edit, so it is a question '
                  + 'for the owner rather than a build failure.'
                : 'If it is an Aboriginal language word it must be in lore.language.allowlist with a '
                  + 'published source before it ships. If it is not a language word, rename it to '
                  + 'plain English.')
          });
        }
      }
      continue;
    }

    // Code and markup. A cultural region is a marker line and the lines that follow it, which is
    // the shape the first build's fault had: a seasons constant with invented names underneath.
    if (ext === '.md' || ext === '.txt') continue;
    const lines = text.split('\n');
    const CULTURAL_MARKER = /\b(seasons?|seasonal|season_bias|clans?|glosse?s?|spellings?|totems?|moiet(?:y|ies)|dreaming|songline|language_?words?|traditional[\s_-]?names?|indigenous[\s_-]?names?)\b/i;
    let regionLeft = 0;
    for (let i = 0; i < lines.length; i++) {
      const raw = lines[i];
      if (CULTURAL_MARKER.test(raw)) regionLeft = 20;
      else if (!raw.trim()) regionLeft = 0;
      else if (regionLeft > 0) regionLeft--;
      if (regionLeft <= 0) continue;
      for (const token of raw.split(/[^A-Za-z']+/)) {
        const t = token.replace(/'/g, '').toLowerCase();
        if (!t || allow.has(t)) continue;
        if (!languageShaped(t, profile)) continue;
        if (CULTURAL_MARKER.test(t)) continue;
        scan.add({
          rule: rule.id,
          severity: blockingSeverity,
          file,
          line: i + 1,
          text: lineText(text, i + 1),
          why: `"${token}" is not on the allowlist and it appears inside a cultural region of code: `
            + `a line naming seasons, clans, glosses, spellings or traditional names opened at or `
            + `above line ${i + 1}. The first build's invented season names lived in exactly this `
            + 'shape, in src/kernel/clock.js.'
        });
      }
    }
  }
};

// ---------------------------------------------------------------------------------------------
// THIS BUILD'S ADDITIONS
//
// Everything above executes a rule that came over in data/lore.json unchanged. The two things below
// are second-island's own, and any finding they raise says so.
// ---------------------------------------------------------------------------------------------

/**
 * Addition (a). The carried rule `no-sacred-or-restricted-sites` scopes itself to three data files,
 * src/world/** and src/render/layers/**. It does not cover assets/**, so a committed capture of a
 * restricted place, or a file named after one, walks past it. The first build noticed this gap and
 * widened the scope inside its own harness; it never closed it in the pack, and the pack is carried
 * here byte for byte, so it is still open in the data. It is closed here, in the check.
 *
 * A finding raised only because of the widening says so in `why`, so the pack and this file can be
 * reconciled later without guessing which findings came from where.
 */
export const LOCAL_SCOPE_ADDITIONS = {
  'no-sacred-or-restricted-sites': ['assets/**']
};

/**
 * Files exempted by this build rather than by the pack, each with the reason. A file that exists to
 * enforce a rule will contain the words that rule forbids; the alternative to exempting it is a
 * check that fails on itself, which is a check somebody switches off.
 */
export const LOCAL_EXEMPTIONS = {
  'cultural-queue-is-not-an-approval': [
    { file: 'tools/gate/lore.mjs', reason: 'this file states and enforces the rule, so it quotes the wording it forbids' }
  ],
  'no-sacred-or-restricted-sites': [
    { file: 'tools/gate/lore.mjs', reason: 'this file carries the rule text and the token list' }
  ],
  'no-invented-ceremony': [
    { file: 'tools/gate/lore.mjs', reason: 'this file carries the rule text and the token list' }
  ],
  'no-banned-tokens': [
    { file: 'tools/gate/lore.mjs', reason: 'this file names the check, though it must never quote a banned token' }
  ]
};

/**
 * Addition (b). docs/CULTURAL-QUEUE.md holds open questions for the Traditional Owners. QYAC has not
 * seen this project. An open question described as approved, endorsed, cleared, signed off or
 * reviewed by QYAC or by Traditional Owners is a false claim of consent, and it is the kind of
 * sentence that gets written by accident when someone is summarising progress.
 *
 * The check reads the queue and anything that refers to it, finds each approval word, and asks
 * whether an authority is named nearby and whether the sentence is negated. "Nothing in it is an
 * approval" is the correct wording and must not fail; "approved by QYAC" must.
 *
 * Registered in docs/STAGE-0.md's fault registry as `approval-claim`.
 */
export const LOCAL_RULES = [{
  id: 'cultural-queue-is-not-an-approval',
  origin: 'second-island',
  rule: 'docs/CULTURAL-QUEUE.md, and any file that refers to it, may never describe an open question '
    + 'as approved, endorsed, cleared, signed off or reviewed by QYAC or by the Traditional Owners.',
  severity: 'blocking',
  rationale: 'QYAC has not seen this project. A queue of questions described as an approval is a '
    + 'claim of consent nobody gave.'
}];

const QUEUE_DOC = 'docs/CULTURAL-QUEUE.md';
const APPROVAL_WORDS = [
  'approved', 'approval', 'approvals', 'approves',
  'endorsed', 'endorsement', 'endorsements', 'endorses',
  'cleared', 'clearance',
  'signed off', 'sign-off', 'signoff', 'signs off',
  'reviewed'
];
const AUTHORITY = /\b(QYAC|Quandamooka\s+Yoolooburrabee\s+Aboriginal\s+Corporation|traditional[\s_-]+(?:owner|custodian)s?)\b/i;
const NEGATION = /\b(not|never|nothing|none|no|without|cannot|can't|isn't|aren't|hasn't|haven't|un-?reviewed|un-?approved|unapproved|yet\s+to|awaiting|pending|open\s+question|open\s+questions|must\s+not|may\s+not|do\s+not|does\s+not|is\s+not|are\s+not|was\s+not|were\s+not|rather\s+than|instead\s+of)\b/i;

// How far back to look for the body being named, when it is named in the sentence before.
const AUTHORITY_LOOKBACK = 200;

/**
 * The sentence around an index. The negation test has to be sentence tight, or one correct line
 * ("Nothing here is approved by QYAC") cancels the false claim two lines below it. The authority
 * test is looser on purpose, because "questions for the Traditional Owners. Signed off last week"
 * names the body in the sentence before.
 */
function sentenceBounds(text, index) {
  let start = 0;
  for (let i = index; i > 0; i--) {
    const c = text[i];
    if (c === '.' || c === '!' || c === '?' || c === ';') { start = i + 1; break; }
    if (c === '\n' && (text[i - 1] === '\n' || /^\s*([-*+]|\d+\.|#{1,6}|\|)/.test(text.slice(i + 1, i + 12)))) {
      start = i + 1;
      break;
    }
  }
  let end = text.length;
  for (let i = index; i < text.length; i++) {
    const c = text[i];
    if (c === '.' || c === '!' || c === '?' || c === ';') { end = i + 1; break; }
    if (c === '\n' && (text[i + 1] === '\n' || /^\s*([-*+]|\d+\.|#{1,6}|\|)/.test(text.slice(i + 1, i + 12)))) {
      end = i;
      break;
    }
  }
  return [start, end];
}

function checkCulturalQueue(scan) {
  const rule = LOCAL_RULES[0];
  const exempt = new Set((LOCAL_EXEMPTIONS[rule.id] || []).map((e) => e.file));
  const targets = [];
  for (const file of scan.scoped(['**'])) {
    if (exempt.has(file)) continue;
    if (file === QUEUE_DOC) { targets.push(file); continue; }
    const t = scan.text(file);
    if (t !== null && t.includes('CULTURAL-QUEUE')) targets.push(file);
  }
  if (!targets.length) {
    scan.add({
      rule: rule.id,
      severity: 'advisory',
      file: QUEUE_DOC,
      line: 0,
      text: rule.rule,
      why: `${NOT_YET}This is second-island's own rule. Neither the cultural queue nor any file `
        + 'referring to it exists yet, so the check ran against nothing.'
    });
    return;
  }
  for (const file of targets) {
    const text = scan.text(file);
    if (text === null) continue;
    for (const word of APPROVAL_WORDS) {
      for (const hit of tokenHits(text, word, true)) {
        const [start, end] = sentenceBounds(text, hit.index);
        const sentence = text.slice(start, end);
        const around = text.slice(Math.max(0, start - AUTHORITY_LOOKBACK), end);
        if (!AUTHORITY.test(around)) continue;
        if (NEGATION.test(sentence)) continue;
        scan.add({
          rule: rule.id,
          severity: rule.severity,
          file,
          line: hit.line,
          text: lineText(text, hit.line),
          why: "This build's own rule, not one carried from the first island. "
            + `"${hit.match.trim()}" is used of QYAC or the Traditional Owners, unnegated, in a file `
            + 'that refers to the cultural queue: "'
            + sentence.trim().replace(/\s+/g, ' ').slice(0, 180)
            + '". QYAC has not seen this project, so nothing in the queue is approved, endorsed, '
            + 'cleared, signed off or reviewed. Write what is true instead: the question is open.'
        });
      }
    }
  }
}

// ---------------------------------------------------------------------------------------------
// The runner.
// ---------------------------------------------------------------------------------------------

const SEVERITY_RANK = { blocking: 0, advisory: 1 };

/**
 * @param {{root: string}} opts root is the directory to scan, so a self test can point this at a
 *   temporary copy of the tree rather than at the repository.
 * @returns {Promise<{id: string, findings: Array<{rule: string, severity: string, file: string, line: number, text: string, why: string}>}>}
 */
export async function run({ root } = {}) {
  if (typeof root !== 'string' || !root) {
    return {
      id,
      findings: [{
        rule: 'lore-pack-present',
        severity: 'blocking',
        file: LORE_PATH,
        line: 0,
        text: '',
        why: 'run() was called without a root. Nothing in tools/gate falls back to the current working '
          + 'directory: the gate is the instrument and the root is the subject, and a check that '
          + 'guesses its subject can be pointed at the wrong tree without anyone noticing.'
      }]
    };
  }
  const base = root;
  const lorePath = path.join(base, LORE_PATH);
  let lore;
  try {
    lore = JSON.parse(fs.readFileSync(lorePath, 'utf8'));
  } catch (err) {
    return {
      id,
      findings: [{
        rule: 'lore-pack-present',
        severity: 'blocking',
        file: LORE_PATH,
        line: 0,
        text: '',
        why: `${LORE_PATH} could not be read or parsed (${err.message}), so no cultural rule could be `
          + 'checked at all. Every other finding from this module would be a false clean run.'
      }]
    };
  }

  const scan = new Scan(base, lore);
  const rules = (lore.prohibitions && lore.prohibitions.rules) || [];
  if (!rules.length) {
    scan.add({
      rule: 'lore-pack-present',
      severity: 'blocking',
      file: LORE_PATH,
      line: 0,
      text: '',
      why: 'The pack carries no prohibitions.rules array, so there were no rules to execute.'
    });
  }

  for (const rule of rules) {
    const type = rule.check && rule.check.type;
    if (!type) {
      scan.add({
        rule: rule.id,
        severity: 'blocking',
        file: LORE_PATH,
        line: scan.ruleLine(rule.id),
        text: rule.rule || '',
        why: 'This rule carries no check block, so nothing about it can execute. It is reported as a '
          + 'failure of the check, never as a clean run.'
      });
      continue;
    }
    const checker = CHECKERS[type];
    if (!checker) {
      scan.add({
        rule: rule.id,
        severity: 'blocking',
        file: LORE_PATH,
        line: scan.ruleLine(rule.id),
        text: rule.rule || '',
        why: `check.type "${type}" has no handler in tools/gate/lore.mjs, so this rule did not run. `
          + 'It is reported as unimplemented rather than passing silently.'
      });
      continue;
    }
    checker(scan, rule);
  }

  checkCulturalQueue(scan);

  scan.findings.sort((a, b) => (SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity])
    || a.file.localeCompare(b.file)
    || a.line - b.line
    || a.rule.localeCompare(b.rule)
    || a.why.localeCompare(b.why));

  return { id, findings: scan.findings };
}

// ---------------------------------------------------------------------------------------------
// Runnable alone, so a proof can point it at a copy of the tree without a gate runner.
//
//   node tools/gate/lore.mjs --root .
//   node tools/gate/lore.mjs --root out/lore-proof --json
// ---------------------------------------------------------------------------------------------

const invokedDirectly = process.argv[1]
  && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;

if (invokedDirectly) {
  const argv = process.argv.slice(2);
  const rootArg = argv.includes('--root') ? argv[argv.indexOf('--root') + 1] : '.';
  const asJson = argv.includes('--json');
  const only = argv.includes('--severity') ? argv[argv.indexOf('--severity') + 1] : null;
  const result = await run({ root: path.resolve(rootArg) });
  const findings = only ? result.findings.filter((f) => f.severity === only) : result.findings;
  if (asJson) {
    process.stdout.write(`${JSON.stringify({ ...result, findings }, null, 2)}\n`);
  } else {
    const counts = Object.create(null);
    for (const f of result.findings) counts[f.severity] = (counts[f.severity] || 0) + 1;
    process.stdout.write(`gate/${result.id} on ${path.resolve(rootArg)}\n`);
    process.stdout.write(`${SEVERITIES.map((s) => `${s}: ${counts[s] || 0}`).join('  ')}\n\n`);
    for (const f of findings) {
      process.stdout.write(`[${f.severity}] ${f.rule}\n  ${f.file}:${f.line}\n`);
      if (f.text) process.stdout.write(`  text: ${f.text}\n`);
      process.stdout.write(`  why:  ${f.why}\n\n`);
    }
  }
  const blocking = result.findings.filter((f) => f.severity === 'blocking').length;
  process.exit(blocking ? 1 : 0);
}
