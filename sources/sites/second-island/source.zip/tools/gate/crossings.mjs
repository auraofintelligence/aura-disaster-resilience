// gate/crossings: the two-crossings law, executed rather than written down again.
//
// docs/CONTRACT.md section 6 carries the law and, until this file, carried it as NOT YET CHECKED:
// "Passenger and vehicle crossings are never one figure. You can almost always get off the island.
// You cannot always get your car off, and that is the useful question." The first build merged the
// two and made the useful question unanswerable. Board note 029 sharpened the law: it is three
// service classes across two operators and two landing points, and modelling it as two would still
// be wrong.
//
// THREE RULES, AND WHY EACH ONE IS NARROW
//
// A rule that fires on everything gets ignored, which is worse than not having it, so each rule
// here names the exact shape it refuses and says what it cannot see.
//
//   crossings/summed        a vehicle figure added to a passenger figure, or one identifier that
//                           names both classes so the two could be held as one number
//   crossings/carries-enum  a `carries` value that is not one of the two allowed values, or a
//                           sailing-shaped record with no `carries` at all
//   crossings/unattributed  a crossing figure written without saying which of the three services
//                           it belongs to
//   crossings/specimen      advisory, never blocking: a line marked as a quotation of one of the
//                           shapes above, printed every run so the exemption is never quiet
//
// WHY `carries` HAS EXACTLY TWO VALUES AND NO THIRD
//
// A vehicle sailing also carries people, and that is fine. What is refused is a value meaning both,
// because the moment one exists somebody writes one number for it. The vehicle number and the
// passenger number are two numbers about one sailing and the schema must not offer a field where
// they could be added.
//
// WHAT THE THIRD RULE MEANS BY ATTRIBUTED, and it is not the same test for both kinds of figure
//
//   a sailing, crossing or departure count belongs to ONE service, so the line has to name one:
//   a serviceId, the word vehicle or barge or a vessel name (only one service carries vehicles),
//   the Gold Cats Flyer or One Mile (only one service lands there), or SeaLink together with
//   passenger. The word "passenger" on its own is NOT attribution, and that is the case worth
//   catching: both passenger services run fourteen departures each way, so a bare "28 sailings"
//   could be either of them.
//
//   a movement count is a landing point figure by nature, because a landing point is where two
//   services meet, so naming Junner Street or One Mile is enough for that one.
//
// WHAT THIS RULE CANNOT SEE, said here rather than discovered later
//
//   A figure built at runtime. This reads files as text, so `${count} sailings` carries no literal
//   number and is invisible to the third rule. A number printed by a program is the program's
//   honesty problem, and tools/check-crossings.mjs is where that is held instead.
//   A sum hidden in a reduce, a Math.max or a loop accumulator. The first rule reads `a + b` and
//   identifier names. Widening it to every accumulation would fire on arithmetic that has nothing
//   to do with either crossing, and the rule would be switched off within a week.
//   Prose that states a merged figure in words rather than digits.
//   A merged field whose name uses neither class word. `onBoardTotal = 460` reads as innocent text
//   and only the arithmetic that built it would give it away, which is why tools/check-crossings.mjs
//   also checks the pack for a record holding a vehicle figure and a passenger figure at once.
//
// The service vocabulary is read out of data/crossings.json rather than listed here, so a fourth
// service, a renamed operator or a new landing point is covered on the day it lands. If that pack
// is missing, the rules that need it report why and stand down rather than passing silently.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'crossings';

const SCAN_DIRS = ['src', 'tools', 'data', 'docs'];
const SCAN_FILES = ['index.html', 'lab.html'];
const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);
const TEXT_EXT = new Set(['.js', '.mjs', '.cjs', '.json', '.geojson', '.md', '.txt', '.html', '.htm', '.css']);
const MAX_BYTES = 8 * 1024 * 1024;

// This file has to spell out the shapes it refuses in order to look for them, so it skips itself,
// the way tools/gate/ports.mjs and tools/gate/instruments.mjs skip themselves.
const SELF = 'tools/gate/crossings.mjs';

const PACK = 'data/crossings.json';
const CARRIES_VALUES = ['vehicles', 'passengers'];

/** Word tokens of an identifier or key: camelCase, snake_case and kebab-case all split. */
function tokens(name) {
  return String(name)
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .split(/[^A-Za-z0-9]+/)
    .filter(Boolean)
    .map((t) => t.toLowerCase());
}

const VEHICLE_WORDS = new Set(['vehicle', 'vehicles', 'car', 'cars', 'truck', 'trucks', 'barge', 'barges']);
const PASSENGER_WORDS = new Set(['passenger', 'passengers', 'person', 'persons', 'people', 'pax', 'foot', 'pedestrian', 'pedestrians']);
const FIGURE_WORDS = new Set(['sailing', 'sailings', 'crossing', 'crossings', 'departure', 'departures', 'movement', 'movements', 'capacity', 'count', 'total', 'spaces', 'seats']);

const isVehicleWord = (t) => VEHICLE_WORDS.has(t);
const isPassengerWord = (t) => PASSENGER_WORDS.has(t);

/** A name that holds both classes at once, which is a place two numbers could become one. */
function namesBothClasses(name) {
  const t = tokens(name);
  if (!t.some(isVehicleWord) || !t.some(isPassengerWord)) return false;
  // Both classes AND something countable. `vehicleOrPassenger` as a type name is not a merged
  // figure; `vehicleAndPassengerTotal` is. This is the line between describing the law and breaking it.
  return t.some((w) => FIGURE_WORDS.has(w));
}

function classOf(expr) {
  const t = tokens(expr.split('.').pop());
  if (t.some(isVehicleWord)) return 'vehicles';
  if (t.some(isPassengerWord)) return 'passengers';
  return null;
}

// ---------------------------------------------------------------------------------------------
// File walking
// ---------------------------------------------------------------------------------------------

function filesUnder(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile() && TEXT_EXT.has(path.extname(e.name).toLowerCase())) {
        out.push(rel);
      }
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

function readIfSmall(root, rel) {
  const abs = path.join(root, rel);
  try {
    if (statSync(abs).size > MAX_BYTES) return null;
    return readFileSync(abs, 'utf8');
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------------------------
// The service vocabulary, read out of the pack
// ---------------------------------------------------------------------------------------------

/**
 * The phrases that name a landing point in running prose. The id and the full name are not enough:
 * a person writes "Junner Street", not "junner-street-dunwich" and not the whole name with its
 * township on the end, so the first two words of the name are a phrase too. That is what makes the
 * difference between a rule that reads what people write and one that reads what a schema holds.
 */
function pointPhrases(p) {
  const out = [];
  if (p && typeof p.id === 'string') out.push(p.id.toLowerCase());
  if (p && typeof p.name === 'string') {
    const head = p.name.split(',')[0].trim().toLowerCase();
    out.push(head);
    const words = head.split(/\s+/);
    if (words.length >= 2) out.push(words.slice(0, 2).join(' '));
  }
  return out;
}

function vocabulary(root) {
  const text = readIfSmall(root, PACK);
  if (text === null) return { pack: null, problem: 'data/crossings.json is not in this tree' };
  let doc;
  try {
    doc = JSON.parse(text);
  } catch (err) {
    return { pack: null, problem: 'data/crossings.json is not valid JSON: ' + String(err.message) };
  }
  const services = Array.isArray(doc.services) ? doc.services : [];
  const landingPoints = Array.isArray(doc.landingPoints) ? doc.landingPoints : [];
  const serviceIds = services.map((s) => s.serviceId || s.id).filter(Boolean);

  // A phrase that names ONE service on its own. Built from the pack: a class word only qualifies
  // when exactly one service carries that class, and a landing point only when one service lands
  // there, so this tightens or loosens by itself as the pack changes.
  const unique = new Set(serviceIds.map((s) => s.toLowerCase()));
  for (const value of CARRIES_VALUES) {
    const withThat = services.filter((s) => s.carries === value);
    if (withThat.length === 1) {
      unique.add(value.replace(/s$/, ''));
      if (value === 'vehicles') unique.add('barge');
    }
  }
  for (const p of landingPoints) {
    const here = services.filter((s) => s.islandPoint === p.id || s.mainlandPoint === p.id);
    if (here.length === 1) for (const phrase of pointPhrases(p)) unique.add(phrase);
  }
  const vessels = [];
  const capacity = doc.capacity && Array.isArray(doc.capacity.vessels) ? doc.capacity.vessels : [];
  for (const v of capacity) if (typeof v.name === 'string') vessels.push(v.name.toLowerCase());
  // A vessel name is attribution only when it is not also the name of somewhere on this island.
  const islandWords = new Set(landingPoints.map((p) => String(p.name).toLowerCase().split(',')[0].trim())
    .concat(['minjerribah', 'north stradbroke island', 'dunwich']));
  for (const v of vessels) if (!islandWords.has(v)) unique.add(v);

  // Operator plus a class word, for the services a class word alone cannot separate.
  const pairs = [];
  for (const s of services) {
    const op = (doc.operators || []).find((o) => o.id === s.operator);
    if (!op || typeof op.name !== 'string') continue;
    pairs.push([op.name.toLowerCase(), String(s.carries).replace(/s$/, '')]);
    if ((doc.operators || []).filter((o) => o.id === s.operator).length && services.filter((x) => x.operator === s.operator).length === 1) {
      unique.add(op.name.toLowerCase());
    }
  }

  const landingWords = new Set();
  for (const p of landingPoints) for (const phrase of pointPhrases(p)) landingWords.add(phrase);

  return { pack: doc, serviceIds, unique: [...unique].sort(), pairs, landingWords: [...landingWords].sort(), problem: null };
}

// ---------------------------------------------------------------------------------------------

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}

const ADDITION = /([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\+\s*([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)/g;
const SAILING_FIGURE = /(?<![\w.])(\d+(?:,\d{3})*)\s+(sailings?|crossings?|departures?)\b/gi;
const MOVEMENT_FIGURE = /(?<![\w.])(\d+(?:,\d{3})*)\s+((?:vessel\s+)?movements?)\b/gi;
const CARRIES_LITERAL = /\bcarries\s*(?::|===|==)\s*(['"])([^'"]*)\1/g;
const DOMAIN = /crossing|sailing|\bbarge\b|ferry terminal|junner|one mile jetty/i;

/**
 * The escape hatch, and the reason it is this narrow.
 *
 * A rule that refuses a shape cannot be written about without writing the shape down, and a
 * document that cannot quote what the gate refuses has to describe it vaguely instead. Board note
 * 016 hit exactly this in gate/style, which blocks a verbatim quotation of the licence this
 * repository is most obliged to quote accurately, and worked around it rather than fixing it.
 *
 * So: a line carrying this marker is a specimen and is skipped. Per line, never per file, written
 * on the line it excuses, and every use is reported as an advisory naming the line and its text.
 * An exemption nobody can see is how a check stops checking; this one is printed every run.
 */
const SPECIMEN = /gate\/crossings:\s*specimen/;


export function run({ root }) {
  const findings = [];
  const vocab = vocabulary(root);

  const files = [];
  for (const dir of SCAN_DIRS) files.push(...filesUnder(root, dir));
  for (const f of SCAN_FILES) {
    if (readIfSmall(root, f) !== null) files.push(f);
  }

  const namesAService = (line) => {
    const l = line.toLowerCase();
    if (vocab.unique && vocab.unique.some((u) => l.includes(u))) return true;
    if (vocab.pairs && vocab.pairs.some(([op, cls]) => l.includes(op) && l.includes(cls))) return true;
    return false;
  };
  const namesALandingPoint = (line) => {
    const l = line.toLowerCase();
    return Boolean(vocab.landingWords && vocab.landingWords.some((w) => l.includes(w)));
  };

  for (const rel of files.sort()) {
    if (rel === SELF) continue;
    const text = readIfSmall(root, rel);
    if (text === null) continue;
    const isData = rel.startsWith('data/') && rel.endsWith('.json');
    const inDomain = DOMAIN.test(text);
    const lines = text.split('\n');

    // ---------------------------------------------------------------- rule one, in code and prose
    const lineAt = (index) => lines[lineOf(text, index) - 1] || '';
    for (let i = 0; i < lines.length; i++) {
      if (!SPECIMEN.test(lines[i])) continue;
      findings.push({
        rule: 'crossings/specimen',
        severity: 'advisory',
        file: rel,
        line: i + 1,
        text: lines[i].trim(),
        why: 'This line is marked as a specimen and was skipped by all three rules. It is here so a '
          + 'document can quote the shape the gate refuses. Every use is printed, so an exemption '
          + 'cannot be quiet.'
      });
    }

    ADDITION.lastIndex = 0;
    let m;
    while ((m = ADDITION.exec(text)) !== null) {
      if (SPECIMEN.test(lineAt(m.index))) continue;
      const left = classOf(m[1]);
      const right = classOf(m[2]);
      if (!left || !right || left === right) continue;
      findings.push({
        rule: 'crossings/summed',
        severity: 'blocking',
        file: rel,
        line: lineOf(text, m.index),
        text: m[0].trim(),
        why: 'A vehicle figure and a passenger figure are two numbers about one crossing and are '
          + 'never added. docs/CONTRACT.md section 6, and board note 029. A vehicle sailing also '
          + 'carries people, and that is fine: what is refused is one figure standing for both, '
          + 'because the question this island actually asks is whether a car can get off, and a '
          + 'merged number cannot answer it.'
      });
    }

    // ------------------------------------------------- rule one, second half: one name, both classes
    const nameRx = /[A-Za-z_$][\w$]*/g;
    nameRx.lastIndex = 0;
    const reported = new Set();
    let n;
    while ((n = nameRx.exec(text)) !== null) {
      const name = n[0];
      if (reported.has(name)) continue;
      if (!namesBothClasses(name)) continue;
      if (SPECIMEN.test(lineAt(n.index))) continue;
      reported.add(name);
      findings.push({
        rule: 'crossings/summed',
        severity: 'blocking',
        file: rel,
        line: lineOf(text, n.index),
        text: name,
        why: 'This name holds both crossing classes and something countable, so it is a field where '
          + 'a vehicle number and a passenger number could be held as one figure. Split it into two '
          + 'named fields, the way data/crossings.json holds carsMax and deckPassengersMax.'
      });
    }

    // ------------------------------------------------------------------- rule two, the carries enum
    CARRIES_LITERAL.lastIndex = 0;
    let c;
    while ((c = CARRIES_LITERAL.exec(text)) !== null) {
      if (CARRIES_VALUES.includes(c[2])) continue;
      if (SPECIMEN.test(lineAt(c.index))) continue;
      findings.push({
        rule: 'crossings/carries-enum',
        severity: 'blocking',
        file: rel,
        line: lineOf(text, c.index),
        text: c[0].trim(),
        why: 'carries is an enum with exactly two values, ' + CARRIES_VALUES.join(' and ')
          + ', and there is no third value meaning both. A sailing that carries vehicles also '
          + 'carries people; it is still a vehicle sailing, and the passenger figure for it is a '
          + 'separate number that this schema deliberately does not offer a home for.'
      });
    }

    // -------------------------------------------------------- rule three, an unattributed figure
    if (inDomain) {
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (SPECIMEN.test(line)) continue;
        SAILING_FIGURE.lastIndex = 0;
        let f;
        while ((f = SAILING_FIGURE.exec(line)) !== null) {
          if (namesAService(line)) continue;
          findings.push({
            rule: 'crossings/unattributed',
            severity: 'blocking',
            file: rel,
            line: i + 1,
            text: f[0].trim(),
            why: 'A count of sailings, crossings or departures belongs to one of the three services '
              + 'and this line does not say which. Name a serviceId, or the vehicle service, or the '
              + 'Gold Cats Flyer, or One Mile, or SeaLink together with passenger. "Passenger" on '
              + 'its own is not enough: both passenger services run fourteen departures each way, '
              + 'so the reader cannot tell which one a bare figure means.'
          });
        }
        MOVEMENT_FIGURE.lastIndex = 0;
        while ((f = MOVEMENT_FIGURE.exec(line)) !== null) {
          if (namesAService(line) || namesALandingPoint(line)) continue;
          findings.push({
            rule: 'crossings/unattributed',
            severity: 'blocking',
            file: rel,
            line: i + 1,
            text: f[0].trim(),
            why: 'A movement count is a figure about a landing point, and this line names neither a '
              + 'landing point nor a service. Junner Street and One Mile carry different services '
              + 'and different totals, and the difference between them is the whole of the '
              + 'consolidation question in board note 029.'
          });
        }
      }
    }

    // ---------------------------------------- rule two and three, inside the packs rather than the prose
    if (isData) {
      let doc;
      try {
        doc = JSON.parse(text);
      } catch {
        continue; // gate/provenance owns an unreadable pack
      }
      walk(doc, '', (node, pointer) => {
        if (Object.prototype.hasOwnProperty.call(node, 'carries')) {
          if (!CARRIES_VALUES.includes(node.carries)) {
            findings.push({
              rule: 'crossings/carries-enum',
              severity: 'blocking',
              file: rel,
              line: lineOfKey(text, node.id),
              text: pointer + ': carries is ' + JSON.stringify(node.carries),
              why: 'carries must be exactly ' + CARRIES_VALUES.join(' or ') + '.'
            });
          }
        } else if (typeof node.departsMinuteOfDay === 'number') {
          findings.push({
            rule: 'crossings/carries-enum',
            severity: 'blocking',
            file: rel,
            line: lineOfKey(text, node.id),
            text: pointer + ': a sailing with no carries field',
            why: 'A record with a departure minute is a sailing, and a sailing says what it carries. '
              + 'An absent carries is the same failure as a merged one: it leaves a reader to guess '
              + 'whether a car can be on it.'
          });
        }

        for (const key of Object.keys(node)) {
          const value = node[key];
          const t = tokens(key);
          const isFigureKey = t.some((w) => ['sailings', 'sailing', 'crossings', 'crossing', 'departures', 'departure', 'movements', 'movement'].includes(w));
          if (!isFigureKey) continue;
          const numeric = typeof value === 'number'
            || (value && typeof value === 'object' && !Array.isArray(value)
              && Object.values(value).every((v) => typeof v === 'number'));
          if (!numeric) continue;
          const aboutMovements = t.includes('movement') || t.includes('movements');
          const attributed = typeof node.serviceId === 'string'
            || (aboutMovements && (typeof node.islandPoint === 'string' || typeof node.landingPoint === 'string'));
          if (attributed) continue;
          findings.push({
            rule: 'crossings/unattributed',
            severity: 'blocking',
            file: rel,
            line: lineOfKey(text, key),
            text: pointer + '.' + key,
            why: 'A crossing figure in a pack sits inside the record it belongs to. This one is in an '
              + 'object with no serviceId'
              + (aboutMovements ? ' and no landing point' : '')
              + ', so nothing says which of the three services it counts.'
          });
        }
      });
    }
  }

  if (vocab.problem) {
    findings.push({
      rule: 'crossings/vocabulary',
      severity: 'advisory',
      file: PACK,
      line: 0,
      text: vocab.problem,
      why: 'The service names, landing points and vessels this check reads come out of the pack '
        + 'rather than a list in the rule, so that a fourth service is covered the day it lands. '
        + 'Without the pack, the first two rules still run on shape alone and the third has no '
        + 'vocabulary to check attribution against. Advisory rather than blocking, because a tree '
        + 'with no crossings pack has no crossing figures to misattribute.'
    });
  }

  return { id, findings };
}

function walk(node, pointer, onObject) {
  if (Array.isArray(node)) {
    node.forEach((child, i) => walk(child, pointer + '[' + i + ']', onObject));
    return;
  }
  if (!node || typeof node !== 'object') return;
  onObject(node, pointer || '(root)');
  for (const key of Object.keys(node)) {
    walk(node[key], pointer ? pointer + '.' + key : key, onObject);
  }
}

function lineOfKey(text, key) {
  if (typeof key !== 'string' || !key) return 0;
  const at = text.indexOf('"' + key + '"');
  if (at === -1) return 0;
  let line = 1;
  for (let i = 0; i < at; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}
