// Personal data never lands in the repository. docs/CONTRACT.md section 5.
//
// The first build found six named individuals and a mobile number one commit away from a public
// repository, in an export of the owner's own map. The patterns below are carried from that build
// unchanged, which the contract allows for gate rules and data: they are Australian formats,
// because a general international matcher fires on every four digit year in a pack.
//
// This check never prints the value it found. A gate log is a file, a scrollback and a screen
// share, and a check that says "found the number 04xx xxx xxx in this file" has published the thing
// it exists to protect. Every finding names the file, the line and the shape of what matched, and
// stops there.
//
// Scope: data/**, assets/** and docs/**. Everything a pack, a caption or a note could carry.
//
// Exemptions, and there is exactly one kind. Contact details that the owner has published about
// himself in LICENCE.md or README.md are his own published contact, so the same value appearing
// elsewhere is not a leak. Those two files are read first and whatever contact detail they carry
// becomes the allowlist for this run. As of this writing they carry none: LICENCE.md names a person
// and a GitHub project URL, README.md names neither, so the allowlist is empty and every match is
// blocking. It is built by reading rather than hardcoded so that it stays true when the owner adds
// a contact address to either file.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'personal';

const SCAN_DIRS = ['data', 'assets', 'docs'];
const PUBLISHED_CONTACT_FILES = ['LICENCE.md', 'README.md'];
const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);
const TEXT_EXT = new Set([
  '.md', '.txt', '.js', '.mjs', '.cjs', '.json', '.html', '.htm', '.css', '.csv', '.tsv',
  '.geojson', '.gpx', '.kml', '.svg', '.yml', '.yaml', '.srt', '.vtt'
]);

const PATTERNS = [
  {
    id: 'mobile',
    label: 'an Australian mobile number',
    rx: /(?:\+?61[ ()-]?|\b0)4\d{2}[ -]?\d{3}[ -]?\d{3}\b/g,
    redact: (m) => 'a ' + String(m).replace(/\D/g, '').length + ' digit mobile number'
  },
  {
    id: 'landline',
    label: 'an Australian landline number',
    rx: /(?:\+?61[ ()-]?|\b0)[23578][ -]?\d{4}[ -]?\d{4}\b/g,
    redact: (m) => 'a ' + String(m).replace(/\D/g, '').length + ' digit landline number'
  },
  {
    id: 'email',
    label: 'an email address',
    rx: /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,
    redact: (m) => {
      const domain = String(m).split('@')[1] || '';
      return 'an email address at ' + (domain ? domain.replace(/[^.]/g, 'x') : 'a hidden domain');
    }
  },
  {
    id: 'street-address',
    label: 'a street address with a number',
    rx: /\b\d{1,4}[A-Za-z]?[ ,]+[A-Z][A-Za-z'-]*(?:[ ][A-Z][A-Za-z'-]*){0,3}[ ](?:Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Court|Ct|Crescent|Cres|Parade|Pde|Place|Pl|Terrace|Tce|Way|Esplanade|Esp|Lane|Close|Boulevard|Blvd)\b/g,
    redact: () => 'a street address'
  }
];

function walk(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile() && TEXT_EXT.has(path.extname(e.name).toLowerCase())) {
        out.push(rel);
      }
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

const MAX_BYTES = 8 * 1024 * 1024;

// A file this rule cannot read is a file nobody screened, and that is the exact shape a leak would
// hide in: a large bulk import. So a skip raises a finding rather than returning quietly. The
// wording follows tools/gate/provenance.mjs, which already got this right. A critic caught the
// silent version of this function on 19 August 2026 by putting the same email address in two files
// that differed only in padding: the small one failed the gate and the 9.4 MB one printed clean.
function readText(root, rel) {
  const abs = path.join(root, rel);
  try {
    const size = statSync(abs).size;
    if (size > MAX_BYTES) {
      return { skipped: `file is ${size} bytes, over the ${MAX_BYTES} byte limit this rule scans` };
    }
    const t = readFileSync(abs, 'utf8');
    if (t.includes('\u0000')) return { skipped: 'file contains NUL bytes and is not readable as text' };
    return { text: t };
  } catch (err) {
    return { skipped: 'could not be read: ' + err.message };
  }
}

/** The finding a caller raises when readText declined to read a file. */
function unreadable(rel, skipped) {
  return {
    rule: 'personal/unreadable', severity: 'blocking', file: rel, line: 0,
    text: skipped,
    why: 'A file the personal data rule cannot read is a file nobody screened for contact details. '
      + 'This rule stands between a public repository and a leaked phone number, so it says so '
      + 'rather than passing quietly. Split the file, stage it under ingest-inbox/, or raise the '
      + 'limit deliberately and record why.'
  };
}

/** Contact details the owner has published about himself, which are therefore not a leak. */
function publishedContacts(root) {
  const allow = new Set();
  for (const rel of PUBLISHED_CONTACT_FILES) {
    const read = readText(root, rel);
    if (read.skipped) continue; // this pass only harvests the owner's own published details
    const text = read.text;
    for (const p of PATTERNS) {
      if (p.id === 'street-address') continue; // an address is never waved through, even his own
      p.rx.lastIndex = 0;
      let m;
      while ((m = p.rx.exec(text)) !== null) {
        allow.add(m[0]);
        if (p.rx.lastIndex === m.index) p.rx.lastIndex++;
      }
    }
  }
  return allow;
}

export function run({ root }) {
  const findings = [];
  const allow = publishedContacts(root);

  const files = [];
  for (const dir of SCAN_DIRS) files.push(...walk(root, dir));

  for (const rel of files) {
    const read = readText(root, rel);
    if (read.skipped) { findings.push(unreadable(rel, read.skipped)); continue; }
    const text = read.text;
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      for (const p of PATTERNS) {
        p.rx.lastIndex = 0;
        let m;
        while ((m = p.rx.exec(line)) !== null) {
          if (p.rx.lastIndex === m.index) p.rx.lastIndex++;
          const published = allow.has(m[0]);
          findings.push({
            rule: 'personal/' + p.id,
            severity: published ? 'advisory' : 'blocking',
            file: rel,
            line: i + 1,
            text: p.redact(m[0]) + ' at column ' + (m.index + 1),
            why: published
              ? 'This matches ' + p.label + ' the owner has published about himself in '
                + PUBLISHED_CONTACT_FILES.join(' or ') + ', so it is not a leak. Named here so the '
                + 'exemption is visible rather than silent.'
              : 'This file carries ' + p.label + '. Personal data never lands in the repository, '
                + 'and this repository is public. The value is not printed here on purpose: open '
                + rel + ' at line ' + (i + 1) + ' to see it. Remove it, or replace it with the '
                + 'published contact of an organisation if that is what it is.'
          });
        }
      }
    }
  }

  if (!files.length) {
    findings.push({
      rule: 'personal/empty', severity: 'advisory', file: SCAN_DIRS.join(', '), line: 0,
      text: 'no text files found under the scanned directories',
      why: 'Nothing to check. Reported so a run against the wrong root cannot look like a pass.'
    });
  }

  return { id, findings };
}
