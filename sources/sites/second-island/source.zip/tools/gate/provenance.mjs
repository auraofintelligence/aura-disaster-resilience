// Provenance is a type, not a convention. docs/CONTRACT.md section 3.
//
// Every record in data/** carries eight fields: source, locator, validFrom, validTo, recordedAt,
// recordedUntil, confidence and register. The validator is src/kernel/record.js, imported here so
// the gate and the runtime agree by construction rather than by two people writing the same rules
// twice. `source` is checked against the ids in data/_sources.json, because a source that is free
// text cannot be opened and checked.
//
// How a record is recognised. This walks nested arrays and objects, and treats any object that
// carries at least one of the eight fields as a record. That is the point: an object with three of
// the eight is a half-provenanced record and must be a finding, and an object with none is not a
// record at all. The alternative, only checking objects that carry all eight, would make the exact
// failure this check exists to catch invisible.
//
// Two files are exempt, and only two.
//
//   data/lore.json       carried from the first build in that build's own schema. It is the
//                        allowlist and banned-token pack that gate/lore reads, not a pack of island
//                        records, and rewriting its schema to satisfy this check would mean editing
//                        a carried cultural artefact to suit a validator.
//   data/_sources.json   the vocabulary this check reads. It is the list of what a `source` may be,
//                        so it cannot itself carry one without circularity.
//
// The validator comes from this repository's src/kernel/record.js, not from the tree under test.
// The gate is the instrument; `root` is the subject.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { checkRecord, REQUIRED_FIELDS } from '../../src/kernel/record.js';

export const id = 'provenance';

const EXEMPT = new Set(['data/lore.json', 'data/_sources.json']);
const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);

function jsonFilesUnder(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile() && /\.(json|geojson)$/i.test(e.name)) {
        out.push(rel);
      }
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

/**
 * The source ids, from whichever shape data/_sources.json turns out to have. The file does not
 * exist yet, so this accepts the three shapes it could reasonably arrive in rather than guessing
 * one and failing the day it lands: a list of objects with ids, an object keyed by id, or either of
 * those under a `sources` key.
 */
function readSourceIds(root) {
  const abs = path.join(root, 'data', '_sources.json');
  let doc;
  try {
    doc = JSON.parse(readFileSync(abs, 'utf8'));
  } catch (err) {
    return { ids: null, problem: err && err.code === 'ENOENT' ? 'missing' : 'unreadable: ' + err.message };
  }
  const body = doc && !Array.isArray(doc) && doc.sources ? doc.sources : doc;
  const ids = new Set();
  if (Array.isArray(body)) {
    for (const s of body) {
      if (s && typeof s.id === 'string') ids.add(s.id);
      else if (typeof s === 'string') ids.add(s);
    }
  } else if (body && typeof body === 'object') {
    for (const key of Object.keys(body)) {
      const v = body[key];
      if (v && typeof v === 'object' && typeof v.id === 'string') ids.add(v.id);
      else ids.add(key);
    }
  }
  return ids.size ? { ids, problem: null } : { ids: null, problem: 'no source ids could be read from it' };
}

function looksLikeRecord(node) {
  return REQUIRED_FIELDS.some((f) => Object.prototype.hasOwnProperty.call(node, f));
}

/** Where in the file to look, by the record's own id where it has one. Honest zero when it has not. */
function lineOfRecord(text, rec) {
  const needles = [];
  if (typeof rec.id === 'string' && rec.id) needles.push('"' + rec.id + '"');
  if (typeof rec.name === 'string' && rec.name) needles.push('"' + rec.name + '"');
  for (const needle of needles) {
    const at = text.indexOf(needle);
    if (at === -1) continue;
    let line = 1;
    for (let i = 0; i < at; i++) if (text[i] === '\n') line++;
    return line;
  }
  return 0;
}

function walkRecords(node, pointer, onRecord) {
  if (Array.isArray(node)) {
    node.forEach((child, i) => walkRecords(child, pointer + '[' + i + ']', onRecord));
    return;
  }
  if (!node || typeof node !== 'object') return;
  if (looksLikeRecord(node)) onRecord(node, pointer || '(root)');
  for (const key of Object.keys(node)) {
    walkRecords(node[key], pointer ? pointer + '.' + key : key, onRecord);
  }
}

export function run({ root }) {
  const findings = [];
  const files = jsonFilesUnder(root, 'data').filter((f) => !EXEMPT.has(f));

  const { ids: sourceIds, problem } = readSourceIds(root);
  if (problem) {
    findings.push({
      rule: 'provenance/sources',
      severity: files.length ? 'blocking' : 'advisory',
      file: 'data/_sources.json',
      line: 0,
      text: problem,
      why: 'Every record names a source by id from data/_sources.json. Without that file the id '
        + 'cannot be resolved, so a record could cite a source that does not exist.'
        + (files.length ? '' : ' Advisory today because data/ carries no packs yet.')
    });
  }

  if (!files.length) {
    findings.push({
      rule: 'provenance/empty',
      severity: 'advisory',
      file: 'data',
      line: 0,
      text: 'no packs under data/ yet',
      why: 'Nothing to check. The first real data arrives at stage 2, and this check is here first '
        + 'on purpose so it cannot arrive unprovenanced.'
    });
    return { id, findings };
  }

  for (const rel of files) {
    const abs = path.join(root, rel);
    let text;
    try {
      if (statSync(abs).size > 32 * 1024 * 1024) {
        findings.push({
          rule: 'provenance/unreadable', severity: 'blocking', file: rel, line: 0,
          text: 'file too large to parse in the gate',
          why: 'A pack the gate cannot read is a pack whose provenance nobody checked.'
        });
        continue;
      }
      text = readFileSync(abs, 'utf8');
    } catch (err) {
      findings.push({
        rule: 'provenance/unreadable', severity: 'blocking', file: rel, line: 0,
        text: String(err.message),
        why: 'A pack the gate cannot read is a pack whose provenance nobody checked.'
      });
      continue;
    }

    let doc;
    try {
      doc = JSON.parse(text);
    } catch (err) {
      findings.push({
        rule: 'provenance/unreadable', severity: 'blocking', file: rel, line: 0,
        text: 'not valid JSON: ' + String(err.message),
        why: 'A pack the gate cannot parse is a pack whose provenance nobody checked.'
      });
      continue;
    }

    let records = 0;
    walkRecords(doc, '', (rec, pointer) => {
      records++;
      const problems = checkRecord(rec, sourceIds ? { sourceIds } : {});
      const line = lineOfRecord(text, rec);
      for (const p of problems) {
        findings.push({
          rule: 'provenance/record',
          severity: 'blocking',
          file: rel,
          line,
          text: pointer + (typeof rec.id === 'string' ? ' (id ' + rec.id + ')' : '') + ': ' + p,
          why: 'Every record carries source, locator, validFrom, validTo, recordedAt, recordedUntil, '
            + 'confidence and register. Live, history and scenario mode are three cursor positions '
            + 'over one store, and that only works if no record was ever written with one time.'
        });
      }
    });

    if (records === 0) {
      findings.push({
        rule: 'provenance/no-records',
        severity: 'advisory',
        file: rel,
        line: 0,
        text: 'no object in this pack carries any of the eight provenance fields',
        why: 'Either this file is not a pack of records, or every record in it is missing its '
          + 'provenance entirely. The second case is invisible to a field-by-field check, so it is '
          + 'reported here for a human to look at once.'
      });
    }
  }

  return { id, findings };
}
