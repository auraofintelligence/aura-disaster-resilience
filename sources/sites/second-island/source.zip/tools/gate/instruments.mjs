// The registry and the source have to agree. docs/STAGE-0.md, "Fault injection".
//
// A fault hook is a branch in shipping code that changes what the code does. Left unlisted it is a
// back door, and left listed but unimplemented it is a fault nobody can inject. So this check reads
// tools/faults.mjs and the source together and refuses five kinds of disagreement:
//
//   1. a fault with no declared hook site
//   2. an instrument with no fault that proves it
//   3. a declared hook site with no faulty() call for that fault in it
//   4. a faulty() call in a file no fault declares, or naming an id no fault declares
//   5. a fault caught by no instrument that does not say, in the registry, why not
//
// Rule two is the one that matters most and is the one that is easiest to forget. An instrument
// with no fault has never been watched failing, and this repository's word for that is a rumour.
//
// WHY THIS CHECK IMPORTS FROM THE TREE UNDER TEST
//
// Every other module in tools/gate reads the tree as text. This one imports `root`/tools/faults.mjs,
// because the registry is a JavaScript module with functions in it and there is no honest way to
// read a function as text. That is a real difference and it is written here rather than hidden: the
// tree under test gets to declare its own registry, which is the right reading of "check this
// tree", and it means a tree that tampers with its own registry can hide a hook from rule four.
// Nothing else here trusts the tree. The claim this check makes is narrow: this tree's registry and
// this tree's source agree with each other.

import { readdirSync, readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const id = 'instruments';

const REGISTRY = 'tools/faults.mjs';
const SCAN_DIRS = ['src', 'tools'];
const CODE_EXT = new Set(['.js', '.mjs', '.cjs']);
const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);

/** faulty('<id>') with a string literal. `faulty(id)` in the definition is not a call site. */
const FAULTY_CALL = /\bfaulty\s*\(\s*(['"])([^'"]+)\1\s*\)/g;

// This file has to spell out the shape it is looking for in order to look for it, so it skips
// itself, the way tools/gate/ports.mjs and tools/gate/lore.mjs skip themselves. Nothing else is
// exempt: an exemption list is how a check stops checking.
const SELF = 'tools/gate/instruments.mjs';

function filesUnder(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile() && CODE_EXT.has(path.extname(e.name).toLowerCase())) {
        out.push(rel);
      }
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}

/** Every faulty('<id>') call under src/ and tools/, as { file, line, fault }. */
function callSites(root) {
  const sites = [];
  for (const dir of SCAN_DIRS) {
    for (const rel of filesUnder(root, dir)) {
      if (rel === SELF) continue;
      let text;
      try {
        text = readFileSync(path.join(root, rel), 'utf8');
      } catch {
        continue;
      }
      FAULTY_CALL.lastIndex = 0;
      let m;
      while ((m = FAULTY_CALL.exec(text)) !== null) {
        sites.push({ file: rel, line: lineOf(text, m.index), fault: m[2] });
      }
    }
  }
  return sites;
}

export async function run({ root }) {
  const findings = [];
  const registryAbs = path.join(root, REGISTRY);

  if (!existsSync(registryAbs)) {
    findings.push({
      rule: 'instruments/registry-missing', severity: 'blocking', file: REGISTRY, line: 0,
      text: 'no fault registry in this tree',
      why: 'docs/STAGE-0.md says nothing else in this repository starts until every instrument has '
        + 'caught a fault put there on purpose. With no registry there are no faults, so no '
        + 'instrument has been watched failing.'
    });
    return { id, findings };
  }

  let reg;
  try {
    reg = await import(pathToFileURL(registryAbs).href);
  } catch (err) {
    findings.push({
      rule: 'instruments/registry-unreadable', severity: 'blocking', file: REGISTRY, line: 0,
      text: String(err && err.message ? err.message : err),
      why: 'The registry did not load, so nothing about the faults in this tree could be checked.'
    });
    return { id, findings };
  }

  const faults = Array.isArray(reg.FAULTS) ? reg.FAULTS : null;
  const instruments = reg.INSTRUMENTS && typeof reg.INSTRUMENTS === 'object' ? reg.INSTRUMENTS : null;
  if (!faults || !instruments) {
    findings.push({
      rule: 'instruments/registry-shape', severity: 'blocking', file: REGISTRY, line: 0,
      text: 'exports FAULTS=' + typeof reg.FAULTS + ' INSTRUMENTS=' + typeof reg.INSTRUMENTS,
      why: 'The registry must export an array FAULTS and an object INSTRUMENTS. Without both, this '
        + 'check cannot say anything and must not pretend it did.'
    });
    return { id, findings };
  }

  const declaredIds = new Set(faults.map((f) => f && f.id).filter(Boolean));

  // Runtime faults own hook sites. A tree fault writes files, which is a different thing, so the
  // file it writes is not treated as a place where a faulty() call is allowed to live.
  const hookFiles = new Map();
  for (const f of faults) {
    if (!f || f.kind !== 'runtime') continue;
    for (const site of f.hookSites || []) {
      if (!hookFiles.has(site)) hookFiles.set(site, new Set());
      hookFiles.get(site).add(f.id);
    }
  }

  // 1. A fault with no declared hook site.
  for (const f of faults) {
    if (!f || !f.id) continue;
    if (!Array.isArray(f.hookSites) || f.hookSites.length === 0) {
      findings.push({
        rule: 'instruments/no-hook-site', severity: 'blocking', file: REGISTRY, line: 0,
        text: 'fault ' + f.id + ' declares no hook site',
        why: 'A fault with no hook site cannot be injected and cannot be found again. Name the file '
          + 'the branch lives in, or the file the fault writes.'
      });
    }
  }

  // 5. A fault caught by no instrument, with no reason given.
  for (const f of faults) {
    if (!f || !f.id) continue;
    const owner = f.instrument || (f.inverted ? f.mustMiss : null);
    if (owner) continue;
    const reason = typeof f.blindSpot === 'string' ? f.blindSpot.trim() : '';
    if (!reason) {
      findings.push({
        rule: 'instruments/unexplained-blind-spot', severity: 'blocking', file: REGISTRY, line: 0,
        text: 'fault ' + f.id + ' names no instrument and carries no blindSpot reason',
        why: 'A fault nothing catches is a hole in the measurement. It may stay, but it has to be '
          + 'written down as a known blind spot with the reason, so the next person finds it in '
          + 'docs/JURISDICTION.md instead of discovering it.'
      });
    }
  }

  // 2. An instrument with no fault that proves it.
  const proven = new Set();
  for (const f of faults) {
    if (!f) continue;
    if (f.instrument) proven.add(f.instrument);
    if (f.mustMiss) proven.add(f.mustMiss);
  }
  for (const name of Object.keys(instruments)) {
    if (proven.has(name)) continue;
    findings.push({
      rule: 'instruments/unproven-instrument', severity: 'blocking', file: REGISTRY, line: 0,
      text: 'instrument ' + name + ' has no fault that proves it',
      why: 'An instrument nobody has watched fail is a rumour. Add a fault whose registry entry '
        + 'names ' + name + ', or remove the instrument.'
    });
  }

  const sites = callSites(root);
  const seen = new Map();
  for (const s of sites) {
    if (!seen.has(s.file)) seen.set(s.file, new Set());
    seen.get(s.file).add(s.fault);
  }

  // 3. A declared hook site with no matching faulty() call.
  for (const [file, ids] of hookFiles) {
    const abs = path.join(root, file);
    if (!existsSync(abs)) {
      findings.push({
        rule: 'instruments/hook-site-missing', severity: 'blocking', file, line: 0,
        text: 'declared hook site for ' + [...ids].sort().join(', ') + ' does not exist',
        why: 'The registry points at a file that is not in this tree, so the fault it names cannot '
          + 'be injected.'
      });
      continue;
    }
    const found = seen.get(file) || new Set();
    for (const wanted of [...ids].sort()) {
      if (found.has(wanted)) continue;
      findings.push({
        rule: 'instruments/hook-site-empty', severity: 'blocking', file, line: 0,
        text: 'no faulty(' + JSON.stringify(wanted) + ') call in this declared hook site',
        why: 'The registry says this file carries the switch for ' + wanted + ' and it does not. '
          + 'Either the hook was removed and the row is now a claim about nothing, or the fault '
          + 'moved and the registry was not moved with it.'
      });
    }
  }

  // 4. A faulty() call in a file no fault declares, or naming an id no fault declares.
  for (const s of sites) {
    if (!declaredIds.has(s.fault)) {
      findings.push({
        rule: 'instruments/undeclared-fault-id', severity: 'blocking', file: s.file, line: s.line,
        text: 'faulty(' + JSON.stringify(s.fault) + ') names a fault the registry does not declare',
        why: 'Faults are named in ' + REGISTRY + ' and nowhere else. An id that only exists at the '
          + 'call site is a switch nobody can find, which is what a back door looks like.'
      });
    }
    if (!hookFiles.has(s.file)) {
      findings.push({
        rule: 'instruments/undeclared-hook', severity: 'blocking', file: s.file, line: s.line,
        text: 'faulty(' + JSON.stringify(s.fault) + ') in a file no fault declares as a hook site',
        why: 'Fault hooks may appear only in files the registry declares, so injection code cannot '
          + 'drift into behaviour unnoticed. Add ' + s.file + ' to the hookSites of ' + s.fault
          + ', or take the branch out.'
      });
    }
  }

  return { id, findings };
}
