// No wall clock in simulation. docs/CONTRACT.md section 2.
//
// Banned under src/kernel, src/systems and src/world: Date.now, new Date, performance.now and
// Math.random. Each of the four makes a run depend on something outside the seed, and a world whose
// state depends on when it ran cannot be diffed against itself. The clock is integer ticks from an
// epoch string parsed by hand in src/kernel/clock.js, and randomness comes from named streams in
// src/kernel/rng.js.
//
// src/kernel/faults.js is not exempt and must not need to be. Fault injection reads an environment
// variable and a query string, both of which are inputs rather than clocks, so the ban costs it
// nothing. An exemption there would be a door held open in exactly the file whose job is to let
// things break on purpose.
//
// Comments and string literals are blanked before the scan, keeping newlines so lines still line
// up. That is deliberate and it is why src/kernel/clock.js can explain in its own header why the
// Date object is banned without failing the check that bans it. The ban is on the call, not on the
// name of the call.
//
// Not checked, and said out loud rather than implied: `Date(` called without `new`, `Date.parse`,
// `crypto.getRandomValues`, and a wall clock reached through a variable such as
// `const clock = Date; clock.now()`. The four named forms are what the contract names and what a
// person writes without thinking. The rest is human judged until something in the repository needs
// it to be otherwise.

import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';

export const id = 'no-wallclock';

const SIM_DIRS = ['src/kernel', 'src/systems', 'src/world'];
const CODE_EXT = new Set(['.js', '.mjs', '.cjs']);

const BANNED = [
  [/\bDate\s*\.\s*now\b/g, 'Date.now'],
  [/\bnew\s+Date\b/g, 'new Date'],
  [/\bperformance\s*\.\s*now\b/g, 'performance.now'],
  [/\bMath\s*\.\s*random\b/g, 'Math.random']
];

const REPLACEMENT = {
  'Date.now': 'the tick, or `now` injected into the World for the perf instruments',
  'new Date': 'src/kernel/clock.js, which is integer arithmetic from an island civil epoch',
  'performance.now': 'the `now` function injected into the World, so the kernel never reads a clock itself',
  'Math.random': "the system's own named stream, world.rng('<system>')"
};

function filesUnder(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) visit(path.join(dir, e.name), rel);
      else if (e.isFile() && CODE_EXT.has(path.extname(e.name).toLowerCase())) out.push(rel);
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

/** Comments and string literals to spaces, newlines kept, so a line number still means something. */
function blank(src) {
  let out = '';
  let i = 0;
  let mode = 'code';
  let quote = '';
  while (i < src.length) {
    const c = src[i];
    const d = src[i + 1];
    if (mode === 'code') {
      if (c === '/' && d === '/') { mode = 'line'; out += '  '; i += 2; continue; }
      if (c === '/' && d === '*') { mode = 'block'; out += '  '; i += 2; continue; }
      if (c === '"' || c === "'" || c === '`') { mode = 'string'; quote = c; out += ' '; i++; continue; }
      out += c; i++; continue;
    }
    if (mode === 'line') {
      if (c === '\n') { mode = 'code'; out += '\n'; } else out += ' ';
      i++; continue;
    }
    if (mode === 'block') {
      if (c === '*' && d === '/') { mode = 'code'; out += '  '; i += 2; continue; }
      out += c === '\n' ? '\n' : ' ';
      i++; continue;
    }
    if (c === '\\') { out += '  '; i += 2; continue; }
    if (c === quote) { mode = 'code'; out += ' '; i++; continue; }
    out += c === '\n' ? '\n' : ' ';
    i++;
  }
  return out;
}

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text[i] === '\n') line++;
  return line;
}

export function run({ root }) {
  const findings = [];
  const files = [];
  for (const dir of SIM_DIRS) files.push(...filesUnder(root, dir));

  if (!files.length) {
    findings.push({
      rule: 'no-wallclock/empty', severity: 'advisory', file: SIM_DIRS.join(', '), line: 0,
      text: 'no simulation source files found under this root',
      why: 'Nothing to check. Reported so a run against the wrong root cannot look like a pass.'
    });
    return { id, findings };
  }

  for (const rel of files) {
    let src;
    try {
      src = readFileSync(path.join(root, rel), 'utf8');
    } catch {
      continue;
    }
    const code = blank(src);
    const lines = src.split('\n');
    for (const [rx, label] of BANNED) {
      rx.lastIndex = 0;
      let m;
      while ((m = rx.exec(code)) !== null) {
        const line = lineOf(code, m.index);
        findings.push({
          rule: 'no-wallclock/' + label.replace(/[^a-z]+/gi, '-').toLowerCase(),
          severity: 'blocking',
          file: rel,
          line,
          text: (lines[line - 1] || '').trim().slice(0, 140),
          why: label + ' is a wall clock or an unseeded source under ' + rel.split('/').slice(0, 2).join('/')
            + '. Use ' + REPLACEMENT[label] + '. A world whose state depends on when it ran cannot '
            + 'be diffed against itself.'
        });
      }
    }
  }

  return { id, findings };
}
