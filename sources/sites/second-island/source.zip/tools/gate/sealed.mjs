// The staging areas are sealed, proven by asking git. docs/CONTRACT.md section 5.
//
// ingest-inbox/ holds raw imports nobody has judged yet. out/ and shots/ hold what the instruments
// write. None of it may be committable, and the first build's lesson is precise: it had a rule that
// downgraded findings in staged files on the reasoning that staged files never get committed, and
// nothing anywhere checked whether that reasoning was true. On the day a critic looked, two mobile
// numbers were sitting one `git add -A` from a public repository.
//
// So this check asks git rather than reading a file and believing it. Two questions, both of them
// git's to answer:
//
//   check-ignore -v   is a path under each staging tree ignored, and which rule in which file says so
//   ls-files          is anything under each staging tree already tracked
//
// A tracked file under a staging path is blocking on its own. Being ignored is not retrospective:
// git keeps tracking what it already tracks.
//
// The second witness, and why it exists. git will not read a .gitignore that sits inside a
// directory it has already excluded, so when `root` is a copy of the tree placed under out/, which
// is how tools/selftest.mjs proves this check, git answers about the enclosing repository and the
// copy's own .gitignore is invisible to it. In that case the git answer is reported as advisory
// context, and the rule is decided on the .gitignore inside root, read as text: the same file git
// would read if this tree were a working tree of its own. Both witnesses are reported, and which
// one decided is always named.

import { readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';

export const id = 'sealed';

export const STAGING = ['ingest-inbox', 'out', 'shots'];
const PROBE = '.gate-probe';

function git(root, args) {
  const r = spawnSync('git', args, { cwd: root, encoding: 'utf8' });
  return {
    ok: r.error == null,
    status: typeof r.status === 'number' ? r.status : -1,
    stdout: (r.stdout || '').replace(/\r/g, ''),
    stderr: (r.stderr || '').replace(/\r/g, ''),
    error: r.error ? String(r.error.message) : null
  };
}

/** The git working tree `root` belongs to, as an absolute path, or null when there is none. */
function toplevelOf(root) {
  const r = git(root, ['rev-parse', '--show-toplevel']);
  if (!r.ok || r.status !== 0) return null;
  const line = r.stdout.trim().split('\n')[0];
  return line ? path.resolve(line) : null;
}

function inside(parent, child) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

/**
 * Files git already tracks under a directory, asked of git. Exported because the branch it feeds is
 * the one a planted violation cannot reach: planting a tracked file would take `git add`, which no
 * agent in this repository runs. It is proven instead by calling it against a path that is tracked.
 */
export function trackedUnder(root, dir) {
  const r = git(root, ['ls-files', '--', dir]);
  if (!r.ok || r.status !== 0) return [];
  return r.stdout.split('\n').map((s) => s.trim()).filter(Boolean);
}

/** What check-ignore says about a probe path: ignored, and the rule that decided it. */
function askCheckIgnore(root, dir) {
  const probe = dir + '/' + PROBE;
  const r = git(root, ['check-ignore', '-v', '--', probe]);
  if (!r.ok) return { asked: false, ignored: false, source: null, line: 0, pattern: null, error: r.error };
  if (r.status === 1) return { asked: true, ignored: false, source: null, line: 0, pattern: null, error: null };
  if (r.status !== 0) {
    return { asked: false, ignored: false, source: null, line: 0, pattern: null, error: r.stderr.trim() || ('git exited ' + r.status) };
  }
  const first = r.stdout.split('\n').find(Boolean) || '';
  const m = /^(.*?):(\d+):(.*?)\t/.exec(first);
  if (!m) return { asked: true, ignored: true, source: null, line: 0, pattern: null, error: null };
  return { asked: true, ignored: true, source: m[1], line: Number(m[2]), pattern: m[3], error: null };
}

/**
 * The .gitignore inside root, read as text: which line seals a directory and which line unseals it.
 * A later line wins, which is git's own rule, so a negation after a rule is a genuine unsealing and
 * not a quibble.
 */
function readOwnGitignore(root) {
  let text;
  try {
    text = readFileSync(path.join(root, '.gitignore'), 'utf8');
  } catch {
    return null;
  }
  const lines = text.replace(/\r/g, '').split('\n');
  const decide = (dir) => {
    let last = null;
    for (let i = 0; i < lines.length; i++) {
      const raw = lines[i];
      const line = raw.trim();
      if (!line || line.startsWith('#')) continue;
      const negated = line.startsWith('!');
      const body = (negated ? line.slice(1) : line).replace(/^\//, '').replace(/\/$/, '');
      if (body !== dir) continue;
      last = { line: i + 1, text: raw.trim(), negated };
    }
    return last;
  };
  return { decide };
}

export function run({ root }) {
  const findings = [];
  const toplevel = toplevelOf(root);

  if (!toplevel) {
    findings.push({
      rule: 'sealed/no-git', severity: 'blocking', file: '.', line: 0,
      text: 'git could not name a working tree for this root',
      why: 'This check exists because the staging areas must be proven sealed by asking git rather '
        + 'than assumed sealed. With no git to ask, nothing is proven.'
    });
    return { id, findings };
  }

  const own = readOwnGitignore(root);
  if (!own) {
    findings.push({
      rule: 'sealed/no-gitignore', severity: 'blocking', file: '.gitignore', line: 0,
      text: 'no .gitignore in the tree under test',
      why: 'Without it nothing seals ' + STAGING.join('/, ') + '/, and every raw import in them is '
        + 'one `git add -A` from a public repository.'
    });
  }

  for (const dir of STAGING) {
    // Witness one: git.
    const ci = askCheckIgnore(root, dir);
    const gitIsAboutThisTree = ci.source
      ? inside(root, path.resolve(toplevel, ci.source))
      : false;

    if (!ci.asked) {
      findings.push({
        rule: 'sealed/git-unavailable', severity: 'blocking', file: '.gitignore', line: 0,
        text: 'git check-ignore failed for ' + dir + '/' + PROBE + ': ' + (ci.error || 'unknown'),
        why: 'The seal is proven by asking git. A question git could not answer is not a pass.'
      });
    } else if (!ci.ignored) {
      findings.push({
        rule: 'sealed/not-ignored', severity: 'blocking', file: '.gitignore', line: 0,
        text: 'git check-ignore says ' + dir + '/' + PROBE + ' is not ignored',
        why: 'Anything written into ' + dir + '/ can be committed. Add a rule for ' + dir + '/ to '
          + '.gitignore, and check for a later negation that re-includes it.'
      });
    } else if (!gitIsAboutThisTree) {
      findings.push({
        rule: 'sealed/git-answered-elsewhere', severity: 'advisory', file: '.gitignore', line: 0,
        text: 'git says ' + dir + '/' + PROBE + ' is ignored by ' + ci.source + ':' + ci.line
          + ' (' + ci.pattern + '), which is outside the tree under test',
        why: 'This root sits inside a repository that already ignores it, so git will not read this '
          + "tree's own .gitignore. The rule below is decided on that file read as text, and the "
          + 'git witness is reported for what it is.'
      });
    }

    // Witness two: the .gitignore inside the tree under test.
    if (own) {
      const seal = own.decide(dir);
      if (!seal) {
        findings.push({
          rule: 'sealed/unsealed', severity: 'blocking', file: '.gitignore', line: 0,
          text: 'no rule for ' + dir + '/ in this tree\'s .gitignore',
          why: 'The staging tree ' + dir + '/ is committable. Raw imports and instrument output are '
            + 'one `git add -A` from a public repository.'
        });
      } else if (seal.negated) {
        findings.push({
          rule: 'sealed/unsealed', severity: 'blocking', file: '.gitignore', line: seal.line,
          text: seal.text,
          why: 'A negation re-includes ' + dir + '/, and in git a later line wins. The staging tree '
            + 'is committable again. Remove this line.'
        });
      }
    }

    // Witness three: what git already tracks. Being ignored is not retrospective.
    for (const tracked of trackedUnder(root, dir)) {
      findings.push({
        rule: 'sealed/tracked', severity: 'blocking', file: tracked, line: 0,
        text: 'git ls-files lists this file under the staging tree ' + dir + '/',
        why: 'git keeps tracking what it already tracks, whatever .gitignore says afterwards. This '
          + 'file is committed or staged now. Remove it from the index before anything else.'
      });
    }
  }

  return { id, findings };
}
