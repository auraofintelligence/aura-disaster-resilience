// The two ports that belong to the first island. CLAUDE.md, the separation rules.
//
// This repository serves on 4281 for the app and 4282 for the progress page. 4271 and 4272 belong
// to minjerribah-living-twin, which keeps running next door as the reference implementation. A
// server started here on one of its ports either fails to bind or, worse, answers for it, and then
// two builds are quietly comparing notes through the same socket.
//
// What is blocking and what is not. In a port position, meaning next to a colon, an equals sign, or
// a word like port, listen, bind, serve or localhost, the number is blocking wherever it appears,
// including in a document: a document that tells someone to open http://localhost:4271 is as
// harmful as a server that binds it. Outside a port position:
//
//   .md and .txt        skipped. CLAUDE.md has to write both numbers down in order to forbid them,
//                       and a rule that fails on the sentence stating the rule gets switched off.
//   .json .geojson .csv advisory. Four digit numbers are what data is made of, and 4271 could
//                       honestly be a count, a lot number or a coordinate. A human looks once.
//   everything else     blocking. A bare 4271 in code or configuration has no other reason to be
//                       there.
//
// This file is the one exemption, and only itself, not the directory it sits in. It has to write
// both numbers down in order to reject them, the same way gate/style spells the em dash as a code
// point. Every other module under tools/gate is scanned like any other code.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'ports';

const FIRST_ISLAND_PORTS = /\b(427[12])\b/g;
const OURS = { 4271: 4281, 4272: 4282 };

const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);
const TEXT_EXT = new Set([
  '.md', '.txt', '.js', '.mjs', '.cjs', '.json', '.html', '.htm', '.css', '.csv', '.tsv',
  '.geojson', '.svg', '.yml', '.yaml', '.sh', '.ps1', '.bat'
]);
const BARE_TEXT_NAMES = new Set(['.gitignore', '.gitattributes', '.editorconfig']);
const PROSE_EXT = new Set(['.md', '.txt']);
const DATA_EXT = new Set(['.json', '.geojson', '.csv', '.tsv']);
const SELF = 'tools/gate/ports.mjs';

/** A port position: what the number looks like when something is about to bind or fetch it. */
const PORT_CONTEXT = [
  /[:=]\s*$/,
  /\b(?:ports?|listen(?:s|ing)?|bind(?:s|ing)?|serve[sd]?|serving|host|origin|localhost|127\.0\.0\.1)\b\W{0,12}$/i
];

function walk(root) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile()) {
        const ext = path.extname(e.name).toLowerCase();
        if (TEXT_EXT.has(ext) || BARE_TEXT_NAMES.has(e.name)) out.push(rel);
      }
    }
  };
  visit(root, '');
  return out;
}

export function run({ root }) {
  const findings = [];

  for (const rel of walk(root)) {
    if (rel === SELF) continue; // names both numbers in order to reject them
    const abs = path.join(root, rel);
    let text;
    try {
      // A skip is reported, never silent. See tools/gate/personal.mjs for what a silent one cost.
      const size = statSync(abs).size;
      if (size > 8 * 1024 * 1024) {
        findings.push({ rule: 'ports/unreadable', severity: 'advisory', file: rel, line: 0,
          text: `file is ${size} bytes, over the limit this rule scans`,
          why: 'A file the port rule cannot read is a file nobody checked for 4271 or 4272, which belong to the first build.' });
        continue;
      }
      text = readFileSync(abs, 'utf8');
      if (text.includes('\u0000')) {
        findings.push({ rule: 'ports/unreadable', severity: 'advisory', file: rel, line: 0,
          text: 'file contains NUL bytes and is not readable as text',
          why: 'A file the port rule cannot read is a file nobody checked for 4271 or 4272.' });
        continue;
      }
    } catch (err) {
      findings.push({ rule: 'ports/unreadable', severity: 'advisory', file: rel, line: 0,
        text: 'could not be read: ' + err.message,
        why: 'A file the port rule cannot read is a file nobody checked for 4271 or 4272.' });
      continue;
    }
    const ext = path.extname(rel).toLowerCase();
    const lines = text.replace(/\r/g, '').split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      FIRST_ISLAND_PORTS.lastIndex = 0;
      let m;
      while ((m = FIRST_ISLAND_PORTS.exec(line)) !== null) {
        const before = line.slice(Math.max(0, m.index - 24), m.index);
        const inPortPosition = PORT_CONTEXT.some((rx) => rx.test(before));
        let severity;
        if (inPortPosition) severity = 'blocking';
        else if (PROSE_EXT.has(ext)) continue;
        else if (DATA_EXT.has(ext)) severity = 'advisory';
        else severity = 'blocking';

        findings.push({
          rule: inPortPosition ? 'ports/first-island-port' : 'ports/first-island-number',
          severity,
          file: rel,
          line: i + 1,
          text: line.trim().slice(0, 140),
          why: m[1] + ' belongs to minjerribah-living-twin. This repository serves on '
            + OURS[m[1]] + '. '
            + (inPortPosition
              ? 'This is a port position, so it is blocking wherever it appears.'
              : (severity === 'advisory'
                ? 'Advisory: in a data file this could honestly be a count or a coordinate. Check it once.'
                : 'A bare ' + m[1] + ' in code or configuration has no other reason to be here.'))
        });
      }
    }
  }

  return { id, findings };
}
