// The derived data lane: what a connector emits, and where it is allowed to live.
//
// Two rules, both of them about data this repository did not write by hand.
//
//   derived/committed      a derived pack under data/ while the licence question is open
//   derived/unprovenanced  a record a connector emitted without the eight provenance fields
//
// WHY THE FIRST RULE EXISTS
//
// The founding prompt, section 5, says to resolve the ODbL share-alike question against LICENCE.md
// BEFORE committing any OpenStreetMap derived pack. Board note 007 says it is not resolved. Board
// note 013 puts the decision in front of the owner, and docs/LICENCE-QUESTIONS.md is the reading
// behind it. Until that lands, connector CODE is committed and derived PACKS are not: they live
// under ingest-inbox/, which .gitignore seals and tools/gate/sealed.mjs proves sealed by asking git.
//
// gate/sealed answers a different question from this one. Sealed says the inbox cannot reach git.
// It says nothing about a pack that was copied OUT of the inbox and into data/, which is one
// `cp` away and is exactly how an unresolved licence question gets answered by accident.
//
// WHY IT IS NARROW, AND WHAT IT WOULD COST TO BE BROAD
//
// A rule that fires on everything gets ignored, which is worse than not having it. data/tide.json
// and data/lore.json both carry a top level `pack` field, so "has a pack field" is not a mark of a
// derived pack and this rule does not use it. It looks for four marks instead, and each one is
// reported on its own so a reader can see which one fired:
//
//   1. the pack name is one a connector under tools/ingest/ actually writes, read out of the
//      connector source rather than listed here, so a new connector is covered the day it lands
//   2. a string in the file points at ingest-inbox/, which is a staging path no committed pack has
//      any reason to name as its own provenance
//   3. the pack declares committable: false about itself
//   4. a bulk feature set: an array of fifty or more objects that almost all carry both geometry
//      and full provenance. That is a machine extract, not a hand written pack
//
// THE SWITCH THAT TURNS THIS RULE OFF
//
// Board note 007's `status`, ASKED ONLY OF A PACK THE NOTE REACHES. While it reads anything other
// than `resolved`, the marks above are blocking for a pack whose own sources put it behind that
// question. The day the owner settles it and that note is resolved, this rule stands down by itself
// for those packs and reports what it would have blocked as advisory, so the change is visible in
// one gate run rather than needing an edit here. docs/LICENCE-QUESTIONS.md is the reading behind the
// decision and carries no machine readable verdict, so it is not the switch; it is named in the
// finding so the reader knows where to go.
//
// WHICH PACKS THE NOTE REACHES, AND WHY THIS IS NARROWER THAN IT WAS
//
// Until 19 August 2026 this rule blocked EVERY derived pack under data/ while note 007 was open.
// That was the wave's blanket hold rather than the note's own scope, and board note 024 put the
// consequence in front of the owner: four lanes with four different licences were held behind one
// question about a fifth. Board note 007 is the ODbL share-alike question and nothing else.
//
// So the rule now reads the source ids the pack's own records cite, looks each one up in
// data/_sources.json, and asks whether the OpenStreetMap question reaches this pack. It is blocking
// when a cited source is registered under the Open Database Licence or is published by
// OpenStreetMap, when a cited source is not registered at all, or when the pack cites no source,
// because in the last two cases the licence cannot be read and an unreadable licence is treated as
// the blocking one. Otherwise the marks are reported as advisory with the licence named.
//
// What this rule does NOT decide, stated so nobody reads more into a green run: it decides whether
// board note 007 is this pack's question. It does not decide that a pack's licence is settled. A
// source under some other licence with its own conditions needs its own reading and, if that
// reading produces a rule, its own rule. The advisory line names the licence so that the human who
// has to make that call can see what they are being asked about.
//
// WHY THE SECOND RULE READS THE INBOX, WHICH NO OTHER GATE RULE DOES
//
// docs/CONTRACT.md section 3 says every record in data/** AND every record the twin creates at
// runtime carries the eight fields. gate/provenance covers the first half and skips ingest-inbox/
// with every other staging tree. A connector's output is the second half, and until this rule it
// was checked only by the connector checking itself, which is the shape of a claim rather than a
// measurement. The scope here is deliberately one directory deep: ingest-inbox/derived/*.json, the
// place the connectors write packs. The raw responses beside it are somebody else's bytes and are
// not records.
//
// Source ids are NOT checked against data/_sources.json here, on purpose. Registering a derived
// source id is itself a commit, and this wave commits nothing derived, so a derived pack citing an
// unregistered source is the correct state today and must not be reported as a fault.
//
// THE VALIDATOR COMES FROM THIS REPOSITORY
//
// checkRecord is imported from this tree's src/kernel/record.js, never from the tree under test.
// The gate is the instrument and `root` is the subject, the same way tools/gate/provenance.mjs
// does it.

import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import path from 'node:path';
import { checkRecord, REQUIRED_FIELDS } from '../../src/kernel/record.js';

export const id = 'derived';

/** Where a connector is allowed to put a pack, and where its code lives. */
const DERIVED_DIR = 'ingest-inbox/derived';
const CONNECTOR_DIR = 'tools/ingest';

/** The note whose status decides whether the first rule is blocking. */
const LICENCE_NOTE_ID = '007';
const LICENCE_READING = 'docs/LICENCE-QUESTIONS.md';

/** Read by gate/provenance for the same reason: they are vocabulary, not packs of records. */
const DATA_EXEMPT = new Set(['data/_sources.json', 'data/lore.json']);

/**
 * What board note 007 is about, looked for in a registered source's own licence text and publisher.
 * Deliberately narrow: it must not match a licence field that merely mentions OpenStreetMap while
 * saying the source is under something else, which is exactly what the TransLink entry does when it
 * says the note is not its question.
 */
const ODBL_IN_LICENCE = /open database licen[cs]e|\bodbl\b/i;
const OSM_PUBLISHER = /openstreetmap/i;

/** A key that carries a shape rather than a scalar. The mark of a machine extract. */
const GEOMETRY_KEYS = ['outline', 'centreline', 'geometry', 'coordinates', 'polygon', 'points'];

/**
 * The fields only a record carries. `source`, `locator` and `confidence` are citation fields and a
 * descriptor may hold them honestly: the weather connector's `site` block says where the twin got
 * Dunwich's coordinate from and makes no claim about a moment, which is not a record and must not be
 * reported as a broken one. The two time pairs and the register are the fields that only something
 * claiming to be true of the island at a time would carry.
 */
const RECORD_ONLY_FIELDS = ['validFrom', 'validTo', 'recordedAt', 'recordedUntil', 'register'];

const BULK_MIN = 50;
const BULK_SHARE = 0.8;
const MAX_BYTES = 32 * 1024 * 1024;

// ---------------------------------------------------------------------------------------------
// Small readers
// ---------------------------------------------------------------------------------------------

function isPlainObject(v) {
  return Boolean(v) && typeof v === 'object' && !Array.isArray(v);
}

function hasField(o, f) {
  return Object.prototype.hasOwnProperty.call(o, f);
}

function hasAllEight(o) {
  return REQUIRED_FIELDS.every((f) => hasField(o, f));
}

function someOfEight(o) {
  return REQUIRED_FIELDS.some((f) => hasField(o, f));
}

function claimsAMoment(o) {
  return RECORD_ONLY_FIELDS.some((f) => hasField(o, f));
}

function hasId(o) {
  return typeof o.id === 'string' && o.id !== '';
}

function lineOf(text, needle) {
  if (!needle) return 0;
  const at = text.indexOf(needle);
  if (at === -1) return 0;
  let line = 1;
  for (let i = 0; i < at; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}

function jsonFilesUnder(root, sub, { recurse }) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (recurse) visit(path.join(dir, e.name), rel);
      } else if (e.isFile() && /\.(json|geojson)$/i.test(e.name)) {
        out.push(rel);
      }
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

function readJson(root, rel) {
  const abs = path.join(root, rel);
  try {
    if (statSync(abs).size > MAX_BYTES) return { error: 'file too large to parse in the gate' };
  } catch (err) {
    return { error: String(err && err.message ? err.message : err) };
  }
  let text;
  try {
    text = readFileSync(abs, 'utf8');
  } catch (err) {
    return { error: String(err && err.message ? err.message : err) };
  }
  try {
    return { text, doc: JSON.parse(text) };
  } catch (err) {
    return { text, error: 'not valid JSON: ' + String(err && err.message ? err.message : err) };
  }
}

// ---------------------------------------------------------------------------------------------
// The licence switch
// ---------------------------------------------------------------------------------------------

/**
 * Board note 007's status, read from its own front matter. A note that cannot be found is treated
 * as unresolved: this rule refuses to stand down because its evidence went missing.
 */
function licenceQuestion(root) {
  const dir = path.join(root, 'docs', 'board');
  let names = [];
  try {
    names = readdirSync(dir).filter((n) => n.endsWith('.md')).sort();
  } catch {
    return { resolved: false, status: null, note: null, why: 'docs/board/ could not be read' };
  }
  for (const name of names) {
    let text;
    try {
      text = readFileSync(path.join(dir, name), 'utf8');
    } catch {
      continue;
    }
    const head = text.replace(/\r/g, '').split('\n').slice(0, 20);
    const idLine = head.find((l) => /^id:\s*/.test(l));
    if (!idLine) continue;
    if (idLine.replace(/^id:\s*/, '').trim() !== LICENCE_NOTE_ID) continue;
    const statusLine = head.find((l) => /^status:\s*/.test(l));
    const status = statusLine ? statusLine.replace(/^status:\s*/, '').trim() : null;
    return {
      resolved: status === 'resolved',
      status,
      note: 'docs/board/' + name,
      why: status ? null : 'the note carries no status line'
    };
  }
  return { resolved: false, status: null, note: null, why: 'no board note with id ' + LICENCE_NOTE_ID };
}

/**
 * The registered sources, by id, from data/_sources.json. The reader accepts the same three shapes
 * gate/provenance accepts, because the two rules must not disagree about what a source id is.
 */
function readSourceRegistry(root) {
  let doc;
  try {
    doc = JSON.parse(readFileSync(path.join(root, 'data', '_sources.json'), 'utf8'));
  } catch {
    return null;
  }
  const body = doc && !Array.isArray(doc) && doc.sources ? doc.sources : doc;
  const out = new Map();
  if (Array.isArray(body)) {
    for (const s of body) if (s && typeof s.id === 'string') out.set(s.id, s);
  } else if (body && typeof body === 'object') {
    for (const key of Object.keys(body)) {
      const v = body[key];
      out.set(key, v && typeof v === 'object' ? v : {});
      if (v && typeof v === 'object' && typeof v.id === 'string') out.set(v.id, v);
    }
  }
  return out;
}

/** Every distinct `source` string carried by anything in the document that looks like a record. */
function sourcesCited(node, out = new Set()) {
  if (Array.isArray(node)) {
    for (const el of node) sourcesCited(el, out);
    return out;
  }
  if (!isPlainObject(node)) return out;
  if (typeof node.source === 'string' && node.source !== '' && someOfEight(node)) out.add(node.source);
  for (const key of Object.keys(node)) sourcesCited(node[key], out);
  return out;
}

/**
 * Does board note 007 reach this pack? Answered from the pack's own sources rather than from the
 * fact that it is derived. See the header for why that is the question this rule asks.
 */
function noteReaches(doc, registry) {
  const cited = [...sourcesCited(doc)].sort();
  if (!cited.length) {
    return { reached: true, cited, why: 'the pack cites no source id, so no licence can be read for it' };
  }
  if (!registry) {
    return { reached: true, cited, why: 'data/_sources.json could not be read, so no licence can be read' };
  }
  const unregistered = cited.filter((id) => !registry.has(id));
  if (unregistered.length) {
    return {
      reached: true, cited,
      why: 'cites source ids that are not registered in data/_sources.json, so their licences '
        + 'cannot be read: ' + unregistered.join(', ')
    };
  }
  const odbl = cited.filter((id) => {
    const s = registry.get(id) || {};
    return ODBL_IN_LICENCE.test(String(s.licence || '')) || OSM_PUBLISHER.test(String(s.publisher || ''));
  });
  if (odbl.length) {
    return {
      reached: true, cited,
      why: 'cites a source registered under the Open Database Licence: ' + odbl.join(', ')
    };
  }
  const licences = cited.map((id) => {
    const s = registry.get(id) || {};
    const first = String(s.licence || 'no licence recorded').split(/(?<=\.)\s/)[0];
    return id + ': ' + (first.length > 140 ? first.slice(0, 140) + '...' : first);
  });
  return { reached: false, cited, licences, why: 'no cited source is under the Open Database Licence' };
}

// ---------------------------------------------------------------------------------------------
// What a connector writes, read out of the connector rather than listed here
// ---------------------------------------------------------------------------------------------

/**
 * Pack names the connectors under tools/ingest/ write, found by reading their source for a
 * `pack: '<name>'` property. Listing them here instead would go stale the day a connector is added,
 * and a stale allowlist is how a rule quietly stops checking.
 */
function connectorPackNames(root) {
  const names = new Set();
  const dir = path.join(root, CONNECTOR_DIR);
  let entries = [];
  try {
    entries = readdirSync(dir).filter((n) => /\.(mjs|js)$/.test(n)).sort();
  } catch {
    return names;
  }
  const rx = /\bpack:\s*(['"])([A-Za-z0-9][A-Za-z0-9_-]*)\1/g;
  for (const name of entries) {
    let text;
    try {
      text = readFileSync(path.join(dir, name), 'utf8');
    } catch {
      continue;
    }
    rx.lastIndex = 0;
    let m;
    while ((m = rx.exec(text)) !== null) names.add(m[2]);
  }
  return names;
}

/** Pack names sitting in the inbox right now, so a pack derived before this rule existed counts. */
function inboxPackNames(root) {
  const names = new Set();
  const dir = path.join(root, DERIVED_DIR);
  if (!existsSync(dir)) return names;
  for (const rel of jsonFilesUnder(root, DERIVED_DIR, { recurse: false })) {
    const { doc } = readJson(root, rel);
    if (doc && typeof doc.pack === 'string') names.add(doc.pack);
  }
  return names;
}

// ---------------------------------------------------------------------------------------------
// Rule one: a derived pack under data/
// ---------------------------------------------------------------------------------------------

/** The first string anywhere in the document that names the staging inbox, with its own pointer. */
function findInboxReference(node, pointer) {
  if (typeof node === 'string') {
    return node.includes('ingest-inbox/') ? { pointer: pointer || '(root)', value: node } : null;
  }
  if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i++) {
      const hit = findInboxReference(node[i], pointer + '[' + i + ']');
      if (hit) return hit;
    }
    return null;
  }
  if (!isPlainObject(node)) return null;
  for (const key of Object.keys(node)) {
    const hit = findInboxReference(node[key], pointer ? pointer + '.' + key : key);
    if (hit) return hit;
  }
  return null;
}

/**
 * A bulk feature set: a top level array of fifty or more objects where at least four in five carry
 * both a geometry key and the full eight fields. Two conditions rather than one, because an array
 * of fifty provenanced records with no geometry is an ordinary pack and an array of fifty shapes
 * with no provenance is already gate/provenance's finding.
 */
function bulkFeatureSet(doc) {
  if (!isPlainObject(doc)) return null;
  for (const key of Object.keys(doc)) {
    const v = doc[key];
    if (!Array.isArray(v) || v.length < BULK_MIN) continue;
    let featureLike = 0;
    for (const el of v) {
      if (!isPlainObject(el)) continue;
      const geometry = GEOMETRY_KEYS.some((g) => Array.isArray(el[g]));
      if (geometry && hasAllEight(el)) featureLike++;
    }
    if (featureLike >= Math.ceil(v.length * BULK_SHARE)) {
      return { key, count: v.length, featureLike };
    }
  }
  return null;
}

function marksOfADerivedPack(doc, packNames) {
  const marks = [];
  if (isPlainObject(doc) && typeof doc.pack === 'string' && packNames.has(doc.pack)) {
    marks.push({
      mark: 'connector pack name',
      needle: '"' + doc.pack + '"',
      text: 'top level pack is "' + doc.pack + '", which is a pack a connector under '
        + CONNECTOR_DIR + '/ writes into ' + DERIVED_DIR + '/'
    });
  }
  const inbox = findInboxReference(doc, '');
  if (inbox) {
    marks.push({
      mark: 'ingest-inbox provenance',
      needle: inbox.value.length > 80 ? null : inbox.value,
      text: inbox.pointer + ' points at the staging inbox: ' + JSON.stringify(
        inbox.value.length > 120 ? inbox.value.slice(0, 120) + '...' : inbox.value)
    });
  }
  if (isPlainObject(doc) && doc.committable === false) {
    marks.push({
      mark: 'self declared not committable',
      needle: '"committable"',
      text: 'the pack declares committable: false about itself and is committed anyway'
    });
  }
  const bulk = bulkFeatureSet(doc);
  if (bulk) {
    marks.push({
      mark: 'bulk feature set',
      needle: '"' + bulk.key + '"',
      text: bulk.key + ' holds ' + bulk.count + ' entries, ' + bulk.featureLike
        + ' of which carry both geometry and the full eight provenance fields'
    });
  }
  return marks;
}

// ---------------------------------------------------------------------------------------------
// Rule two: an unprovenanced record in a derived pack
// ---------------------------------------------------------------------------------------------

/**
 * Records inside a derived pack.
 *
 * Two ways in, and the second is the one that matters.
 *
 * An object qualifies on its own when it has a string id and at least one field only a record
 * carries: a time bound or a register. Half of the eight is a half provenanced record and that is
 * precisely the failure to catch. Citing a source without claiming a moment is not, which is why
 * `source` and `locator` alone do not bring an object in here.
 *
 * It also qualifies when it sits in an array that has already shown itself to be a record array,
 * meaning some sibling carries all eight. That second route catches a record with NO provenance at
 * all, which the first route cannot see and which is what a connector produces when one code path
 * forgets to spread the provenance in.
 *
 * An object in neither position is not judged. The feed manifest in the GTFS pack and the site
 * block in the weather pack are both that shape, and neither is a record.
 */
function collectRecords(node, pointer, out, inRecordArray) {
  if (Array.isArray(node)) {
    const recordArray = node.some((el) => isPlainObject(el) && hasAllEight(el));
    node.forEach((el, i) => collectRecords(el, pointer + '[' + i + ']', out, recordArray));
    return;
  }
  if (!isPlainObject(node)) return;
  const onItsOwn = hasId(node) && claimsAMoment(node);
  if (onItsOwn || inRecordArray) out.push({ pointer: pointer || '(root)', rec: node });
  for (const key of Object.keys(node)) {
    collectRecords(node[key], pointer ? pointer + '.' + key : key, out, false);
  }
}

// ---------------------------------------------------------------------------------------------

export function run({ root }) {
  const findings = [];
  const licence = licenceQuestion(root);

  // ------------------------------------------------------------- rule one, data/ against the inbox
  const packNames = new Set([...connectorPackNames(root), ...inboxPackNames(root)]);
  const registry = readSourceRegistry(root);
  const dataFiles = jsonFilesUnder(root, 'data', { recurse: true }).filter((f) => !DATA_EXEMPT.has(f));

  for (const rel of dataFiles) {
    const { text, doc, error } = readJson(root, rel);
    if (error || doc === undefined) continue; // gate/provenance owns unreadable packs under data/
    const marks = marksOfADerivedPack(doc, packNames);
    if (!marks.length) continue;

    const reach = noteReaches(doc, registry);

    for (const m of marks) {
      // Two of the four marks are a committed pack contradicting itself rather than a licence
      // question, and they stay blocking whatever the licence says. A pack that names the staging
      // inbox as its own provenance is telling a reader to look somewhere it does not live, and a
      // pack that declares committable: false and is committed says one thing and does another.
      const contradiction = m.mark === 'ingest-inbox provenance' || m.mark === 'self declared not committable';
      const behindTheNote = reach.reached && !licence.resolved;
      const blocking = contradiction || behindTheNote;

      let why;
      if (contradiction) {
        why = 'A committed pack must not contradict itself about where it lives or whether it may '
          + 'be committed. This mark is blocking whatever the licence says: fix the pack, or move '
          + 'it back to ' + DERIVED_DIR + '/, which .gitignore seals.';
      } else if (behindTheNote) {
        why = 'Board note ' + LICENCE_NOTE_ID + ' is the OpenStreetMap share-alike question and it '
          + 'reaches this pack, because it ' + reach.why + '. ' + (licence.note || 'That note')
          + ' reads status ' + JSON.stringify(licence.status) + '. The founding prompt, section 5, '
          + 'says to resolve the ODbL share-alike question against LICENCE.md before committing an '
          + 'OpenStreetMap derived pack. Move this file to ' + DERIVED_DIR + '/, which .gitignore '
          + 'seals, and read ' + LICENCE_READING + '. The first build invented 1,922 building '
          + 'outlines while 1,059 real ones sat unused, so the answer to this rule is never to '
          + 'weaken it.';
      } else if (licence.resolved) {
        why = 'This file carries the marks of a derived pack. Board note ' + LICENCE_NOTE_ID
          + ' is resolved, so committing it is the owner\'s settled decision and this is reported '
          + 'rather than blocked. Check that ' + LICENCE_READING + ' section on attribution has '
          + 'been carried into LICENCE.md and onto the page.';
      } else {
        why = 'This file carries the marks of a derived pack and board note ' + LICENCE_NOTE_ID
          + ' does not reach it: ' + reach.why + '. Reported rather than blocked, and the licences '
          + 'it is committed under are ' + (reach.licences || []).join(' | ')
          + '. THIS RULE DOES NOT SAY THE LICENCE IS SATISFIED. It says the OpenStreetMap question '
          + 'is not this pack\'s question. Attribution owed under those licences is owed wherever '
          + 'a figure from this pack is displayed, and no rule here can check that a screen carries '
          + 'it.';
      }

      findings.push({
        rule: 'derived/committed',
        severity: blocking ? 'blocking' : 'advisory',
        file: rel,
        line: lineOf(text, m.needle),
        text: m.mark + ': ' + m.text,
        why
      });
    }
  }

  // ------------------------------------------- rule two, what the connectors actually emitted
  if (existsSync(path.join(root, DERIVED_DIR))) {
    for (const rel of jsonFilesUnder(root, DERIVED_DIR, { recurse: false })) {
      const { text, doc, error } = readJson(root, rel);
      if (error) {
        findings.push({
          rule: 'derived/unreadable', severity: 'blocking', file: rel, line: 0,
          text: error,
          why: 'A derived pack the gate cannot read is a pack whose provenance nobody checked, and '
            + 'this one was written by a connector in this repository rather than received.'
        });
        continue;
      }
      const records = [];
      collectRecords(doc, '', records, false);
      for (const { pointer, rec } of records) {
        // No sourceIds: registering a derived source id is itself a commit, and this wave commits
        // nothing derived, so an unregistered source here is the correct state.
        const problems = checkRecord(rec, { where: typeof rec.id === 'string' ? rec.id : pointer });
        for (const p of problems) {
          findings.push({
            rule: 'derived/unprovenanced',
            severity: 'blocking',
            file: rel,
            line: lineOf(text, typeof rec.id === 'string' && rec.id ? '"' + rec.id + '"' : null),
            text: pointer + ': ' + p,
            why: 'docs/CONTRACT.md section 3: every record the twin creates carries source, locator, '
              + 'validFrom, validTo, recordedAt, recordedUntil, confidence and register. A connector '
              + 'that emits a record without them has produced a number nobody can go and check, '
              + 'which is the failure this repository was started to correct. Source ids are not '
              + 'checked here, because registering one is a commit and this wave commits nothing '
              + 'derived.'
          });
        }
      }
    }
  }

  return { id, findings };
}
