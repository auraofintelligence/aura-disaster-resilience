// The noticeboard is well formed. docs/CONTRACT.md section 6, the founding prompt's board law.
//
// A finding that lives only in a transcript is treated as never made. docs/board/ is where a finding
// goes so it survives a session limit: one note per file, read before starting, posted before
// finishing. That only works if a note can be read by a tool as well as by a person, so the shape is
// checked here.
//
// The shape, and this file is where it is defined, because tools/board.mjs and this check have to
// agree and one of them has to say it first:
//
//     ---
//     id: 2026-08-18-gate-runner
//     title: The gate runner reports by rule
//     status: open
//     opened: 2026-08-18
//     author: gate builder
//     ---
//
//     A body. What was found, where, and what the next agent should do about it.
//
// Front matter first, delimited by a line of three hyphens at the top and another below the fields.
// Five required keys, in any order: id, title, status, opened, author. Status is one of open, taken,
// resolved or for-owner. `opened` is an island date, four digits, two, two. Ids are unique across
// the board, because a note nobody can point at unambiguously is a note that gets lost twice.
//
// An empty board is advisory, not blocking. On a repository this young it is the truth, and a gate
// that fails the day the board is empty teaches people to run it with the rule switched off.

import { readdirSync, readFileSync } from 'node:fs';
import path from 'node:path';

export const id = 'board';

const BOARD_DIR = 'docs/board';
const REQUIRED = ['id', 'title', 'status', 'opened', 'author'];
const STATUSES = ['open', 'taken', 'resolved', 'for-owner'];
const DATE = /^\d{4}-\d{2}-\d{2}$/;

function listNotes(root) {
  try {
    return readdirSync(path.join(root, BOARD_DIR), { withFileTypes: true })
      .filter((e) => e.isFile())
      .map((e) => e.name)
      .sort();
  } catch {
    return null;
  }
}

/** Front matter, the line each field sits on, and the body below it. */
function parseNote(text) {
  const lines = text.replace(/\r/g, '').split('\n');
  if (lines[0].trim() !== '---') return { ok: false, reason: 'no front matter: the first line is not three hyphens' };
  let end = -1;
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].trim() === '---') { end = i; break; }
  }
  if (end === -1) return { ok: false, reason: 'front matter is never closed by a second line of three hyphens' };
  const fields = new Map();
  const bad = [];
  for (let i = 1; i < end; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const m = /^([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)$/.exec(line);
    if (!m) { bad.push({ line: i + 1, text: line.trim() }); continue; }
    fields.set(m[1], { value: m[2].trim(), line: i + 1 });
  }
  const body = lines.slice(end + 1).join('\n').trim();
  return { ok: true, fields, bad, body, closeLine: end + 1 };
}

export function run({ root }) {
  const findings = [];
  const names = listNotes(root);

  if (names === null) {
    findings.push({
      rule: 'board/missing', severity: 'advisory', file: BOARD_DIR, line: 0,
      text: 'docs/board/ does not exist',
      why: 'The board is where a finding goes so it outlives a session. Create the directory and '
        + 'post the first note.'
    });
    return { id, findings };
  }

  const notes = names.filter((n) => n.toLowerCase().endsWith('.md'));
  for (const other of names.filter((n) => !n.toLowerCase().endsWith('.md'))) {
    findings.push({
      rule: 'board/not-a-note', severity: 'advisory', file: BOARD_DIR + '/' + other, line: 0,
      text: 'not a .md note',
      why: 'One note per file, and a note is markdown. Anything else in this directory is invisible '
        + 'to the people who read the board.'
    });
  }

  if (!notes.length) {
    findings.push({
      rule: 'board/empty', severity: 'advisory', file: BOARD_DIR, line: 0,
      text: 'the board carries no notes',
      why: 'Advisory, not blocking: an empty board on a young repository is honest. It stops being '
        + 'honest the first time an agent finishes a wave without posting.'
    });
    return { id, findings };
  }

  const seen = new Map(); // id to the file that claimed it

  for (const name of notes) {
    const rel = BOARD_DIR + '/' + name;
    let text;
    try {
      text = readFileSync(path.join(root, BOARD_DIR, name), 'utf8');
    } catch (err) {
      findings.push({
        rule: 'board/unreadable', severity: 'blocking', file: rel, line: 0,
        text: String(err.message), why: 'A note nobody can read is a finding that never landed.'
      });
      continue;
    }

    const note = parseNote(text);
    if (!note.ok) {
      findings.push({
        rule: 'board/front-matter', severity: 'blocking', file: rel, line: 1,
        text: note.reason,
        why: 'A note is read by tools/board.mjs as well as by a person. Front matter is three '
          + 'hyphens, then ' + REQUIRED.join(', ') + ', then three hyphens, then the body.'
      });
      continue;
    }

    for (const b of note.bad) {
      findings.push({
        rule: 'board/front-matter', severity: 'blocking', file: rel, line: b.line,
        text: b.text,
        why: 'Front matter is one `key: value` per line. This line is neither.'
      });
    }

    for (const key of REQUIRED) {
      if (!note.fields.has(key)) {
        findings.push({
          rule: 'board/missing-field', severity: 'blocking', file: rel, line: 1,
          text: 'missing ' + key,
          why: 'Every note carries ' + REQUIRED.join(', ') + '. Without ' + key + ' the board cannot '
            + 'be read as a list.'
        });
      }
    }

    const status = note.fields.get('status');
    if (status && !STATUSES.includes(status.value)) {
      findings.push({
        rule: 'board/status', severity: 'blocking', file: rel, line: status.line,
        text: 'status: ' + status.value,
        why: 'Status is one of ' + STATUSES.join(', ') + '. Anything else cannot be counted, and the '
          + 'board exists to be counted.'
      });
    }

    const opened = note.fields.get('opened');
    if (opened && !DATE.test(opened.value)) {
      findings.push({
        rule: 'board/opened', severity: 'blocking', file: rel, line: opened.line,
        text: 'opened: ' + opened.value,
        why: 'The opened date is an island date written 2026-08-18. Anything else cannot be sorted.'
      });
    }

    for (const key of ['title', 'author']) {
      const f = note.fields.get(key);
      if (f && !f.value) {
        findings.push({
          rule: 'board/missing-field', severity: 'blocking', file: rel, line: f.line,
          text: key + ' is empty',
          why: 'An empty ' + key + ' is the same as a missing one to anyone reading the board.'
        });
      }
    }

    if (!note.body) {
      findings.push({
        rule: 'board/no-body', severity: 'blocking', file: rel, line: note.closeLine,
        text: 'front matter with nothing under it',
        why: 'A note with no body says a thing happened without saying what. Write what was found, '
          + 'where, and what the next agent should do about it.'
      });
    }

    const noteId = note.fields.get('id');
    if (noteId) {
      if (!noteId.value) {
        findings.push({
          rule: 'board/missing-field', severity: 'blocking', file: rel, line: noteId.line,
          text: 'id is empty', why: 'A note is pointed at by its id.'
        });
      } else if (seen.has(noteId.value)) {
        findings.push({
          rule: 'board/duplicate-id', severity: 'blocking', file: rel, line: noteId.line,
          text: 'id: ' + noteId.value + ' is already used by ' + seen.get(noteId.value),
          why: 'Two notes with one id means a reply lands on the wrong finding. Ids are unique '
            + 'across the board.'
        });
      } else {
        seen.set(noteId.value, rel);
      }
    }
  }

  return { id, findings };
}
