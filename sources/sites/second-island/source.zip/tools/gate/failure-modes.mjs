// A "no" needs a number, or it needs to have been asked.
//
// The owner's rule, 19 August 2026: "dont assume anything. if you think you've found a failure mode,
// ask me what I think."
//
// This repository already refuses a number without a source. This rule is the other half: it refuses
// an assertion that something cannot work, is ruled out, is defeated or is not viable, unless there
// is a measurement near it or a record that the question was put to someone who would know.
//
// It exists because of a specific and repeated failure. Four times on 19 August 2026 this build
// reported a blocker that was not one, and every time the error ran the same way, toward the
// conventional answer and away from what the owner was actually designing:
//
//   the island has 601 buildings          a dataset's coverage reported as the ground
//   people need a 5 m bore                metro clearance applied to a pod
//   the small bore floats worse           written backwards, the table said the opposite
//   the drive rules out freezing          a general caution about moving water, never computed;
//                                         the seepage is 0.22 m a day and a freeze tolerates 1
//
// Three of the four were caught in this build's own output. The fourth sat committed for two
// messages until the owner pushed back on it. So the rule is not that the conclusion was wrong. It
// is that a conclusion of impossibility is a question, and asking costs a sentence.
//
// Advisory, not blocking. A finding here means go and get the number or go and ask, not stop.

import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'failure-modes';

// Phrases that assert a design cannot work. Deliberately short and specific: a rule that fires on
// everything gets ignored, which is worse than not having it.
const IMPOSSIBILITY = [
  /\brules? out\b/i,
  /\bnot viable\b/i,
  /\bis not possible\b/i,
  /\bcannot work\b/i,
  /\bwill not work\b/i,
  /\bmakes it impossible\b/i,
  /\bdefeats? (?:a|the|any)\b/i,
  /\bprevents? (?:a|the|any) \w+ (?:entirely|outright|altogether)\b/i,
  /\bis unworkable\b/i,
  /\bwill never\b/i
];

// What discharges it: a measurement with a unit, or a record that it was asked.
const HAS_NUMBER = /\d[\d,.]*\s*(m|mm|km|m2|m3|kg|t|kN|kPa|MPa|kWh|kJ|MJ|W|kW|MW|C|degC|per cent|%|m\/day|m\/s|hours?|days?|weeks?)\b/i;
const WAS_ASKED = /\b(the owner (said|replied|answered|corrected)|OWNER:|ASKED:|board note \d+|he is right)\b/i;
const IS_QUOTING_THE_RULE = /A "no" needs a number|failure-modes|this rule|IMPOSSIBILITY|specimen/i;

const SELF = 'tools/gate/failure-modes.mjs'; // states the phrases in order to reject them
const SCOPE = ['src', 'tools', 'docs'];
const SKIP_DIRS = new Set(['node_modules', '.git', 'out', 'shots', 'ingest-inbox']);
const TEXT = new Set(['.js', '.mjs', '.md', '.json', '.html']);
const CONTEXT_LINES = 6;

function walk(root, sub, out = []) {
  let entries;
  try { entries = readdirSync(path.join(root, sub), { withFileTypes: true }); } catch { return out; }
  for (const e of entries) {
    if (SKIP_DIRS.has(e.name)) continue;
    const rel = sub ? sub + '/' + e.name : e.name;
    if (e.isDirectory()) walk(root, rel, out);
    else if (TEXT.has(path.extname(e.name).toLowerCase())) out.push(rel);
  }
  return out;
}

export async function run({ root }) {
  const findings = [];
  const files = SCOPE.flatMap((s) => walk(root, s));

  for (const rel of files) {
    if (rel === SELF) continue;
    const abs = path.join(root, rel);
    let text;
    try {
      if (statSync(abs).size > 4 * 1024 * 1024) {
        findings.push({
          rule: 'failure-modes/unreadable', severity: 'advisory', file: rel, line: 0,
          text: 'file too large to scan',
          why: 'A file this rule cannot read is a file whose impossibility claims nobody checked.'
        });
        continue;
      }
      text = readFileSync(abs, 'utf8');
    } catch { continue; }

    const lines = text.replace(/\r/g, '').split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const hit = IMPOSSIBILITY.find((rx) => rx.test(line));
      if (!hit) continue;
      if (IS_QUOTING_THE_RULE.test(line)) continue;

      const from = Math.max(0, i - CONTEXT_LINES);
      const to = Math.min(lines.length, i + CONTEXT_LINES + 1);
      const context = lines.slice(from, to).join('\n');
      if (HAS_NUMBER.test(context) || WAS_ASKED.test(context)) continue;

      findings.push({
        rule: 'failure-modes/unmeasured-no', severity: 'advisory', file: rel, line: i + 1,
        text: line.trim().slice(0, 160),
        why: 'This asserts that something cannot work, and there is no measurement within '
          + CONTEXT_LINES + ' lines and no record that the question was put to anyone who would know. '
          + 'The owner\'s rule: if you think you have found a failure mode, ask. On 19 August 2026 '
          + 'this build reported four blockers that were not blockers, every one of them reaching '
          + 'for the conventional answer instead of the number. Get the measurement, or ask, or '
          + 'soften the claim to what the evidence actually supports.'
      });
    }
  }

  return { id, findings };
}
