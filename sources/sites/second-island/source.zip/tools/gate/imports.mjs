// Simulation never imports the renderer or the UI. docs/CONTRACT.md section 1.
//
// This is the rule that lets the whole island run in Node with no browser, which is what makes
// determinism testable at all. If a system can only run where a canvas exists, the headless
// instrument cannot run it, and an instrument that cannot run is not an instrument.
//
// Two ways to break it, so two checks.
//
//   1. A file under src/kernel, src/systems or src/world imports something under src/render or
//      src/ui. Direct, and the easy case.
//   2. The same file imports a helper somewhere else, and the helper imports the renderer. The
//      import graph is followed one level past the simulation directories for exactly this: a
//      helper cannot launder a dependency the direct check would have caught.
//
// And the same rule stated as identifiers: nothing in simulation may reference `document`,
// `window`, `navigator`, `HTMLElement` or `canvas`. Comments and string literals are blanked before
// this pass, so a comment that explains why the DOM is banned is not itself a violation. The ban is
// on the reference, not on the word.

import { readdirSync, readFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'imports';

const SIM_DIRS = ['src/kernel', 'src/systems', 'src/world'];
const FORBIDDEN_DIRS = ['src/render', 'src/ui'];
const BROWSER_IDENTIFIERS = ['document', 'window', 'navigator', 'HTMLElement', 'canvas'];
const CODE_EXT = new Set(['.js', '.mjs', '.cjs']);

function filesUnder(root, sub) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) visit(path.join(dir, e.name), rel);
      else if (e.isFile() && CODE_EXT.has(path.extname(e.name).toLowerCase())) out.push(rel);
    }
  };
  visit(path.join(root, sub), sub);
  return out;
}

/**
 * Blank out comments, and optionally string literals, keeping every newline so line numbers survive.
 * Import specifiers are string literals, so the import scan keeps strings and the identifier scan
 * does not.
 *
 * Known limit, stated rather than hidden: a regular expression literal containing a quote character
 * can start a false string. Nothing under the simulation directories does that today, and the
 * failure mode is a missed finding in that one file, not a false one.
 */
function blank(src, { strings }) {
  let out = '';
  let i = 0;
  let mode = 'code';
  let quote = '';
  while (i < src.length) {
    const c = src[i];
    const d = src[i + 1];
    if (mode === 'code') {
      if (c === '/' && d === '/') { mode = 'line'; out += '  '; i += 2; continue; }
      if (c === '/' && d === '*') { mode = 'block'; out += '  '; i += 2; continue; }
      if (strings && (c === '"' || c === "'" || c === '`')) { mode = 'string'; quote = c; out += ' '; i++; continue; }
      out += c; i++; continue;
    }
    if (mode === 'line') {
      if (c === '\n') { mode = 'code'; out += '\n'; } else out += ' ';
      i++; continue;
    }
    if (mode === 'block') {
      if (c === '*' && d === '/') { mode = 'code'; out += '  '; i += 2; continue; }
      out += c === '\n' ? '\n' : ' ';
      i++; continue;
    }
    if (c === '\\') { out += '  '; i += 2; continue; }
    if (c === quote) { mode = 'code'; out += ' '; i++; continue; }
    out += c === '\n' ? '\n' : ' ';
    i++;
  }
  return out;
}

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text[i] === '\n') line++;
  return line;
}

const IMPORT_PATTERNS = [
  /\bimport\s+(?:[\w${}\s*,]+\s+from\s+)?['"]([^'"]+)['"]/g,
  /\bimport\s*\(\s*['"]([^'"]+)['"]\s*\)/g,
  /\bexport\s+(?:\*(?:\s+as\s+\w+)?|\{[^}]*\})\s+from\s+['"]([^'"]+)['"]/g
];

/** Every import specifier in a file, with the line it sits on. */
function importsOf(source) {
  const code = blank(source, { strings: false });
  const out = [];
  for (const rx of IMPORT_PATTERNS) {
    rx.lastIndex = 0;
    let m;
    while ((m = rx.exec(code)) !== null) {
      out.push({ spec: m[1], line: lineOf(code, m.index), text: m[0].replace(/\s+/g, ' ').trim() });
    }
  }
  return out.sort((a, b) => a.line - b.line);
}

/** A relative specifier resolved to a path relative to root, or null when it leaves the tree. */
function resolveLocal(root, fromRel, spec) {
  if (!spec.startsWith('.')) return null;
  const abs = path.resolve(path.dirname(path.join(root, fromRel)), spec);
  const candidates = [abs, abs + '.js', abs + '.mjs', path.join(abs, 'index.js')];
  for (const c of candidates) {
    try {
      if (existsSync(c) && statSync(c).isFile()) {
        return path.relative(root, c).split('\\').join('/');
      }
    } catch { /* keep trying the next shape */ }
  }
  return path.relative(root, abs).split('\\').join('/');
}

function isForbidden(rel) {
  return rel !== null && FORBIDDEN_DIRS.some((d) => rel === d || rel.startsWith(d + '/'));
}

function isSimulation(rel) {
  return rel !== null && SIM_DIRS.some((d) => rel === d || rel.startsWith(d + '/'));
}

export function run({ root }) {
  const findings = [];
  const files = [];
  for (const dir of SIM_DIRS) files.push(...filesUnder(root, dir));

  if (!files.length) {
    findings.push({
      rule: 'imports/empty', severity: 'advisory', file: SIM_DIRS.join(', '), line: 0,
      text: 'no simulation source files found under this root',
      why: 'Nothing to check. Reported so a run against the wrong root cannot look like a pass.'
    });
    return { id, findings };
  }

  const sourceCache = new Map();
  const readSource = (rel) => {
    if (sourceCache.has(rel)) return sourceCache.get(rel);
    let src = null;
    try {
      src = readFileSync(path.join(root, rel), 'utf8');
    } catch { src = null; }
    sourceCache.set(rel, src);
    return src;
  };

  for (const rel of files) {
    const src = readSource(rel);
    if (src === null) continue;

    for (const imp of importsOf(src)) {
      const target = resolveLocal(root, rel, imp.spec);

      if (isForbidden(target)) {
        findings.push({
          rule: 'imports/sim-imports-render',
          severity: 'blocking',
          file: rel,
          line: imp.line,
          text: imp.text,
          why: 'Simulation imports ' + target + '. src/kernel, src/systems and src/world run in Node '
            + 'with no browser, which is what makes determinism testable. The renderer reads state; '
            + 'it is never imported by the thing it draws.'
        });
        continue;
      }

      // One level deeper, so a helper outside the simulation directories cannot launder it. Files
      // inside the simulation directories are checked directly by the loop above.
      if (target && !isSimulation(target) && CODE_EXT.has(path.extname(target).toLowerCase())) {
        const helper = readSource(target);
        if (helper === null) continue;
        for (const deeper of importsOf(helper)) {
          const deeperTarget = resolveLocal(root, target, deeper.spec);
          if (!isForbidden(deeperTarget)) continue;
          findings.push({
            rule: 'imports/laundered-render',
            severity: 'blocking',
            file: rel,
            line: imp.line,
            text: imp.text + '   [' + target + ':' + deeper.line + ' imports ' + deeperTarget + ']',
            why: 'Simulation reaches ' + deeperTarget + ' through ' + target + '. A helper in the '
              + 'middle does not change what gets loaded when the island runs headless.'
          });
        }
      }
    }

    const code = blank(src, { strings: true });
    for (const name of BROWSER_IDENTIFIERS) {
      const rx = new RegExp('\\b' + name + '\\b', 'g');
      let m;
      while ((m = rx.exec(code)) !== null) {
        findings.push({
          rule: 'imports/browser-identifier',
          severity: 'blocking',
          file: rel,
          line: lineOf(code, m.index),
          text: src.split('\n')[lineOf(code, m.index) - 1].trim().slice(0, 120),
          why: 'Simulation referenced `' + name + '`, which does not exist in Node. Comments and '
            + 'strings are blanked before this pass, so this is a real reference and not a mention.'
        });
      }
    }
  }

  return { id, findings };
}
