// House style, executable. docs/CONTRACT.md section 6.
//
// Three checks live here.
//
//   1. No em dash, U+2014, anywhere in a text file, code comments included. Blocking.
//   2. No en dash, U+2013, used between words. A numeric range is what an en dash is for, so
//      "9 to 5" written with one between two numbers is left alone. Blocking.
//   3. Australian spelling, from a short list of American forms that have no other reading here.
//      Blocking.
//   4. Overstatement, from a word list. Advisory only, because the judgement is human.
//
// Both dash characters are spelled here as code points rather than typed. A file that must name a
// character in order to reject it must not be the one file in the repository that contains it. The
// first build learned this when its own em dash check failed on its own source.
//
// Scope. Every text file under `root`, skipping .git, node_modules and the three sealed staging
// trees, which git ignores and gate/sealed proves ignored. The dash checks read the raw bytes of a
// file. The spelling and overstatement checks read only the prose parts of a file: markdown and
// text lines, JavaScript comments and prose-shaped string literals, HTML text with script and style
// removed, and JSON string values. An identifier is never judged for spelling, and .css and .svg
// are skipped entirely, because `color` is the name of a CSS property and correcting it would break
// the page.
//
// tools/gate/ is exempt from the spelling and overstatement lists, and only from those, because the
// modules in it have to write the words out in order to reject them.

import { readdirSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';

export const id = 'style';

const EM_DASH = String.fromCharCode(0x2014);
const EN_DASH = String.fromCharCode(0x2013);

const SKIP_DIRS = new Set(['.git', 'node_modules', 'out', 'shots', 'ingest-inbox']);
const TEXT_EXT = new Set([
  '.md', '.txt', '.js', '.mjs', '.cjs', '.json', '.html', '.htm', '.css',
  '.csv', '.tsv', '.geojson', '.svg', '.yml', '.yaml'
]);
const BARE_TEXT_NAMES = new Set(['.gitignore', '.gitattributes', '.editorconfig']);

/** Files judged by their code, not their prose: their spelling is a language keyword's spelling. */
const NO_PROSE_EXT = new Set(['.css', '.svg']);

/**
 * American spellings with no second reading in this repository. Short on purpose. Every entry is a
 * word where the Australian form is the only correct one here, so the check can be blocking without
 * being argued with.
 *
 * Deliberately left out, each for a reason:
 *   program      a computer program is spelled that way in Australian English. Only a program in
 *                the sense of a schedule of events takes the -mme spelling, and no regular
 *                expression can tell those apart. Human judged.
 *   licensed, licensing, to license   the verb is spelled with an s in Australian English. Only the
 *                noun takes the c, so only the noun is matched, and narrowly.
 *   practice     the noun is spelled with a c. Only the verb takes the s, so only verb shapes match.
 *   meter        a meter is a device and a metre is a distance, and both words are correct here. A
 *                number in front of it is what makes it a distance, so only that shape matches.
 *   labor        the Australian Labor Party is spelled that way on purpose.
 *   gray         grayscale is a code identifier in most graphics libraries.
 *   modeled, labeled, travelled and the rest of the doubled-l family, judgment, sulfur, tire, curb.
 *                Correct candidates for a later pass; left out today rather than guessed at.
 */
const AMERICAN = [
  [/\borganiz(e|es|ed|ing|ation|ations|ational|er|ers)\b/gi, 'organise, organisation'],
  [/\bcolor(s|ed|ing|ful|less)?\b/gi, 'colour'],
  [/\bharbor(s|ed|ing)?\b/gi, 'harbour'],
  [/\bdefense(s|less)?\b/gi, 'defence'],
  [/\bcenter(s|ed|ing)?\b/gi, 'centre'],
  [/\bcatalog(s|ed|ing)?\b/gi, 'catalogue'],
  [/\banalyz(e|es|ed|ing|er|ers)\b/gi, 'analyse'],
  // A distance, because a number is in front of it. A meter on a wall is left alone.
  [/\b\d+(\.\d+)?\s*(square\s+|cubic\s+)?meters?\b/gi, 'metres'],
  // The noun, narrowly: a determiner in front of it, or a noun compound after it.
  [/\b(a|an|the|this|that|these|those|its|their|our|your|his|her|my|no|any|each|one|per)\s+licenses?\b/gi, 'licence, the noun'],
  [/\blicense\s+(agreement|agreements|terms|fee|fees|holder|holders|number|numbers|plate|plates|condition|conditions)\b/gi, 'licence, the noun'],
  // The verb, narrowly.
  [/\bpractic(ed|ing)\b/gi, 'practised, practising'],
  [/\b(to|we|they|you|will|must|should|can|may|might|would)\s+practice\b/gi, 'practise, the verb']
];

/** Overstatement. Advisory, never blocking: the smaller true claim beats the bigger vague one. */
const OVERSTATEMENT = [
  /\brevolutionary\b/gi,
  /\bincredible\b/gi,
  /\bseamless(ly)?\b/gi,
  /\bworld[ -]class\b/gi,
  /\bcutting[ -]edge\b/gi,
  /\bgame[ -]chang(ing|er|ers)\b/gi,
  /\bunprecedented\b/gi,
  /\brobust(ly|ness)?\b/gi,
  /\bblazing(ly)?\b/gi,
  /\beffortless(ly)?\b/gi,
  /\bmagical(ly)?\b/gi
];

function walk(root) {
  const out = [];
  const visit = (dir, prefix) => {
    let entries;
    try {
      entries = readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries.sort((a, b) => (a.name < b.name ? -1 : 1))) {
      const rel = prefix ? prefix + '/' + e.name : e.name;
      if (e.isDirectory()) {
        if (SKIP_DIRS.has(e.name)) continue;
        visit(path.join(dir, e.name), rel);
      } else if (e.isFile()) {
        const ext = path.extname(e.name).toLowerCase();
        if (TEXT_EXT.has(ext) || BARE_TEXT_NAMES.has(e.name)) out.push(rel);
      }
    }
  };
  visit(root, '');
  return out;
}

const MAX_BYTES = 4 * 1024 * 1024;

// A skip is reported, never silent. Same reasoning as tools/gate/personal.mjs, one severity lower:
// an unreadable file is a house style risk rather than a leak.
function readText(root, rel) {
  const abs = path.join(root, rel);
  try {
    const size = statSync(abs).size;
    if (size > MAX_BYTES) {
      return { skipped: `file is ${size} bytes, over the ${MAX_BYTES} byte limit this rule scans` };
    }
    const t = readFileSync(abs, 'utf8');
    if (t.includes('\u0000')) return { skipped: 'file contains NUL bytes and is not readable as text' };
    return { text: t };
  } catch (err) {
    return { skipped: 'could not be read: ' + err.message };
  }
}

function lineOf(text, index) {
  let line = 1;
  for (let i = 0; i < index && i < text.length; i++) if (text[i] === '\n') line++;
  return line;
}

function snippet(text, index, width = 44) {
  const from = Math.max(0, index - width);
  const to = Math.min(text.length, index + width);
  return text.slice(from, to).replace(/\s+/g, ' ').trim();
}

/**
 * The prose parts of a file, line by line. Everything else is code, and code is not judged for its
 * spelling. Returns `{ text, line }` pieces.
 */
function prosePieces(rel, text) {
  const ext = path.extname(rel).toLowerCase();
  const lines = text.split('\n');
  const out = [];
  if (NO_PROSE_EXT.has(ext)) return out;

  if (ext === '.md' || ext === '.txt' || ext === '.csv' || ext === '.tsv' ||
      ext === '.yml' || ext === '.yaml' || BARE_TEXT_NAMES.has(path.basename(rel))) {
    lines.forEach((l, i) => out.push({ text: l, line: i + 1 }));
    return out;
  }

  if (ext === '.html' || ext === '.htm') {
    const masked = text
      .replace(/<script[\s\S]*?<\/script>/gi, (m) => m.replace(/[^\n]/g, ' '))
      .replace(/<style[\s\S]*?<\/style>/gi, (m) => m.replace(/[^\n]/g, ' '));
    masked.split('\n').forEach((l, i) => out.push({ text: l.replace(/<[^>]*>/g, ' '), line: i + 1 }));
    return out;
  }

  if (ext === '.json' || ext === '.geojson') {
    lines.forEach((l, i) => {
      const strings = l.match(/"(?:\\.|[^"\\])*"/g) || [];
      const prose = strings
        .map((s) => s.slice(1, -1))
        .filter((s) => /\s/.test(s) && !/^https?:\/\//.test(s) && !s.includes('://'));
      if (prose.length) out.push({ text: prose.join(' '), line: i + 1 });
    });
    return out;
  }

  // JavaScript. Comments always, and string literals that read like a sentence rather than like an
  // identifier, a class list or a fragment of CSS.
  let inBlock = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let piece = '';
    if (inBlock) {
      piece = line;
      if (line.includes('*/')) inBlock = false;
    } else if (/^\s*\/\*/.test(line)) {
      piece = line;
      if (!line.includes('*/')) inBlock = true;
    } else if (/^\s*(\/\/|\*)/.test(line)) {
      piece = line;
    } else {
      const inline = line.match(/\/\/.*$/);
      const strings = line.match(/(['"`])(?:\\.|(?!\1)[^\\])*\1/g) || [];
      piece = [
        inline ? inline[0] : '',
        ...strings.map((s) => s.slice(1, -1)).filter((s) => /\s/.test(s) && !/[;{}]\s*$/.test(s))
      ].join(' ');
    }
    if (piece.trim()) out.push({ text: piece, line: i + 1 });
  }
  return out;
}

/** A word inside straight quotes is being named, not used. gate and doctrine files do that a lot. */
function isQuotedMention(piece, index, length) {
  return piece[index - 1] === '"' && piece[index + length] === '"';
}

export function run({ root }) {
  const findings = [];
  const files = walk(root);

  for (const rel of files) {
    const read = readText(root, rel);
    if (read.skipped) {
      findings.push({ rule: 'style/unreadable', severity: 'advisory', file: rel, line: 0, text: read.skipped,
        why: 'A file the style rule cannot read is a file whose house style nobody checked.' });
      continue;
    }
    const text = read.text;

    // 1. em dash, raw bytes, every text file.
    for (let i = text.indexOf(EM_DASH); i !== -1; i = text.indexOf(EM_DASH, i + 1)) {
      findings.push({
        rule: 'style/em-dash',
        severity: 'blocking',
        file: rel,
        line: lineOf(text, i),
        text: snippet(text, i),
        why: 'An em dash, U+2014. House rule: use a colon, a semicolon, a comma or a full stop. '
          + 'A file that must name the character spells it as a code point, the way this one does.'
      });
    }

    // 2. en dash between words. Between two numbers it is a range and is left alone.
    for (let i = text.indexOf(EN_DASH); i !== -1; i = text.indexOf(EN_DASH, i + 1)) {
      let before = i - 1;
      while (before >= 0 && (text[before] === ' ' || text[before] === '\t')) before--;
      let after = i + 1;
      while (after < text.length && (text[after] === ' ' || text[after] === '\t')) after++;
      const b = before >= 0 ? text[before] : '';
      const a = after < text.length ? text[after] : '';
      if (/\d/.test(b) && /\d/.test(a)) continue;
      findings.push({
        rule: 'style/en-dash',
        severity: 'blocking',
        file: rel,
        line: lineOf(text, i),
        text: snippet(text, i),
        why: 'An en dash, U+2013, between words. An en dash is for a numeric range. Between words '
          + 'use a colon, a semicolon, a comma or a full stop.'
      });
    }

    if (rel.startsWith('tools/gate/')) continue; // must name the words in order to reject them

    for (const piece of prosePieces(rel, text)) {
      // 3. Australian spelling.
      for (const [rx, want] of AMERICAN) {
        rx.lastIndex = 0;
        let m;
        while ((m = rx.exec(piece.text)) !== null) {
          if (m[0].length === 0) { rx.lastIndex++; continue; }
          findings.push({
            rule: 'style/australian-english',
            severity: 'blocking',
            file: rel,
            line: piece.line,
            text: m[0].trim(),
            why: 'Australian English uses ' + want + '.'
          });
        }
      }
      // 4. Overstatement, advisory.
      for (const rx of OVERSTATEMENT) {
        rx.lastIndex = 0;
        let m;
        while ((m = rx.exec(piece.text)) !== null) {
          if (m[0].length === 0) { rx.lastIndex++; continue; }
          if (isQuotedMention(piece.text, m.index, m[0].length)) continue;
          findings.push({
            rule: 'style/overstatement',
            severity: 'advisory',
            file: rel,
            line: piece.line,
            text: m[0].trim(),
            why: 'Overstatement. The smaller true claim beats the bigger vague one. Advisory: if the '
              + 'word is the plain truth here, keep it.'
          });
        }
      }
    }
  }

  return { id, findings };
}
