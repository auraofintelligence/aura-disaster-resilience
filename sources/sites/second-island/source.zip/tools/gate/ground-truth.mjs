// gate/ground-truth: the owner's supplied timetable cannot change without somebody saying so.
//
// WHY THIS RULE EXISTS AT ALL
//
// Every other figure in this repository came out of a file somebody can download again. The
// crossing timetables did not. They came from the person who lives on the island, on 19 August
// 2026, out of the two operators' published timetables and a photographed sign, and board notes
// 029 and 030 carry them in his words. No connector will ever refetch them, no API holds them, and
// if a value in data/crossings.json drifts there is nothing in the world to compare it against.
// That makes it the most valuable and the least recoverable data here, and until this file the only
// thing standing between it and a silent edit was that nobody had made one yet.
//
// WHAT A SEAL IS AND WHAT IT IS NOT
//
// This is not a claim that the timetable is correct. It is a claim that the timetable in the pack
// is the timetable that was supplied, which is a much smaller claim and the only one a program can
// make. Correctness belongs to the operators and to the owner.
//
// TWO CHECKS, AND WHY BOTH
//
//   ground-truth/timetable-drift   the departure times in the pack, compared position by position
//                                  against the times transcribed below from the owner's own supply.
//                                  This is the check that names what moved, because a digest can
//                                  only say that something did.
//   ground-truth/seal              a digest over the whole sailing structure, so a change the times
//                                  list does not cover is still caught: a vessel code, a day rule,
//                                  a direction, a sailing added or taken away.
//
// The times below are a SECOND COPY, written out from the owner's supply rather than read back out
// of the pack, which is the only way a comparison means anything. src/world/island.js already holds
// the same pattern for the island reference site: two copies of a number, compared, and a
// disagreement stops the build rather than being reconciled. If this transcription is wrong the
// gate blocks on a healthy tree, which is the loud direction for that mistake to fail in.
//
// WHAT THE SEAL DELIBERATELY DOES NOT COVER
//
// Notes, locators, confidences and every other word around the sailings. Those are this
// repository's writing about the timetable rather than the timetable, and they should be free to
// improve without a seal to update. The seal covers service, direction, departure minute, the
// published clock time, the vessel code and the day rule, and nothing else.
//
// WHEN THE TIMETABLE REALLY CHANGES
//
// It will. An operator republishes, or the owner corrects a reading. The intended path is: change
// the pack, change the transcription below, change SEAL to the digest this rule prints in its own
// failure, and say in the commit message and on the board who supplied the new times and when. That
// is three edits in two files with a reason attached, which is the point. One quiet edit is what
// this refuses.

import { readFileSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';

export const id = 'ground-truth';

const PACK = 'data/crossings.json';

// The day markers as the two sources print them, mapped to the rule the pack records.
//
//   ''     no marker: the source states no day restriction
//   '*'    SeaLink's asterisk, "Friday, Saturday and Sunday only"
//   'red'  a time printed in red on the Gold Cats Flyer sign, whose legend reads "Times in Red
//          Denotes no services at that time Saturday, Sunday & Public Holidays". Board note 032
//          records the red reading at medium confidence, because it came from a transcription that
//          used a hash symbol and nobody in this repository has seen the sign. The seal holds the
//          reading that was supplied; it does not raise it to certain.
const DAY_RULES = Object.freeze({
  '': 'daily',
  '*': 'friday-saturday-sunday-only',
  red: 'not-saturday-sunday-or-public-holiday'
});

/**
 * The owner's supply, transcribed. Board notes 029 and 030 carry the same times in his words.
 *
 * A vehicle entry carries the vessel code the timetable prints beside it: (M) Minjerribah,
 * (SB) Sea Breeze. A passenger entry carries no vessel, because neither passenger source names one.
 */
const OWNER_TIMETABLE = Object.freeze({
  'sealink-vehicle-barge': {
    // SeaLink vehicle ferry, described by SeaLink as a base timetable. Extra services are added and
    // are visible only on its booking page, so this is a floor on the day and never the day.
    'mainland-to-island': [
      '06:00 M', '07:00 SB', '08:00 M', '09:30 SB', '10:30 M',
      '12:00 SB', '13:00 M', '14:00 SB', '15:30 M', '16:30 SB'
    ],
    'island-to-mainland': [
      '07:00 M', '08:00 SB', '09:00 M', '10:30 SB', '11:30 M',
      '13:00 SB', '14:00 M', '15:00 SB', '16:30 M', '17:30 SB'
    ]
  },
  'sealink-passenger-ferry': {
    'mainland-to-island': [
      '04:45', '05:45', '06:45', '07:45', '09:00', '10:15', '11:30',
      '12:45', '14:00', '15:30', '17:00', '18:15', '19:15', '20:15 *'
    ],
    'island-to-mainland': [
      '05:15', '06:15', '07:15', '08:15', '09:30', '10:45', '12:00',
      '13:15', '14:30', '16:15', '17:30', '18:45', '19:45', '20:45 *'
    ]
  },
  'gold-cats-flyer-passenger-ferry': {
    // From the sign headed "DEPARTURE TIMES ONLY, Effective 16 December 2024", columns CLEVELAND
    // and 1 MILE JETTY DUNWICH.
    'mainland-to-island': [
      '04:45 red', '05:45', '06:45', '07:45', '09:00', '10:15', '11:30',
      '12:45', '14:00', '15:30', '16:45', '18:00', '19:15', '20:15 red'
    ],
    'island-to-mainland': [
      '05:15 red', '06:15', '07:15', '08:15', '09:30', '10:45', '12:00',
      '13:15', '14:30', '16:15', '17:30', '18:45', '19:45 red', '20:45'
    ]
  }
});

/**
 * The digest of the sailing structure in data/crossings.json as it was supplied.
 *
 * Printed by this rule whenever it disagrees, so an intended change is a copy of one line and never
 * a number anybody has to work out by hand.
 */
const SEAL = '5eeb669817312a5e680fb0f7eda24057c2214a2d298afae71c4086ae07cdd367';

// ---------------------------------------------------------------------------------------------

/** One sailing as the seal sees it: the timetable, and none of the writing around it. */
export function canonicalLine(s) {
  return [
    s.serviceId,
    s.direction,
    s.departsMinuteOfDay,
    s.departsLocal,
    s.vesselCode === null || s.vesselCode === undefined ? '-' : s.vesselCode,
    s.days && s.days.rule ? s.days.rule : '(no day rule)'
  ].join('|');
}

/** Every sailing in a fixed order, so two runs over the same pack produce the same text. */
export function canonicalSailings(pack) {
  const list = Array.isArray(pack && pack.sailings) ? pack.sailings : [];
  return list.map(canonicalLine).sort().join('\n');
}

export function digestOf(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex');
}

/** '10:30' to 630. Returns null when the string is not a clock time. */
function minuteOfClock(hhmm) {
  const m = /^(\d{2}):(\d{2})$/.exec(String(hhmm || ''));
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return null;
  return h * 60 + mi;
}

/** An entry as transcribed above, split into the time and its marker. */
function parseEntry(entry) {
  const parts = String(entry).trim().split(/\s+/);
  const time = parts[0];
  const marker = parts.length > 1 ? parts[1] : '';
  const isVessel = marker === 'M' || marker === 'SB';
  return {
    time,
    vesselCode: isVessel ? marker : '-',
    dayMarker: isVessel ? '' : marker,
    dayRule: DAY_RULES[isVessel ? '' : marker]
  };
}

/** The same shape, read off a record in the pack. */
function packEntry(s) {
  return {
    time: s.departsLocal,
    vesselCode: s.vesselCode === null || s.vesselCode === undefined ? '-' : s.vesselCode,
    dayRule: s.days && s.days.rule ? s.days.rule : '(no day rule)',
    minute: s.departsMinuteOfDay,
    id: s.id
  };
}

function lineOfText(text, needle) {
  const at = text.indexOf(needle);
  if (at === -1) return 0;
  let line = 1;
  for (let i = 0; i < at; i++) if (text.charCodeAt(i) === 10) line++;
  return line;
}

const WHY_DRIFT = 'data/crossings.json is the only data in this repository that no connector can '
  + 'fetch again. It came from the owner on 19 August 2026, out of the two operators\' published '
  + 'timetables, and board notes 029 and 030 carry it in his words. A departure that no longer '
  + 'matches what he supplied is either a correction nobody recorded or a mistake nobody saw, and '
  + 'the two look identical in a diff. Put the supplied time back, or change the transcription in '
  + 'tools/gate/ground-truth.mjs and the seal beside it and say on the board who supplied the new '
  + 'one and when.';

export function run({ root }) {
  const findings = [];
  const abs = path.join(root, PACK);

  let text;
  try {
    if (statSync(abs).size > 16 * 1024 * 1024) {
      findings.push({
        rule: 'ground-truth/unreadable', severity: 'blocking', file: PACK, line: 0,
        text: 'the sealed pack is larger than this rule will read',
        why: 'A rule that goes quiet is worse than a rule that is absent, because the gate prints '
          + 'clean either way and only one of them looks like coverage.'
      });
      return { id, findings };
    }
    text = readFileSync(abs, 'utf8');
  } catch (err) {
    findings.push({
      rule: 'ground-truth/pack-missing', severity: 'blocking', file: PACK, line: 0,
      text: 'the sealed pack is not in this tree: ' + String(err && err.code ? err.code : err),
      why: 'This rule seals the owner\'s supplied timetable. Deleting or moving the file it seals '
        + 'is the largest possible change to it, so it blocks rather than standing down.'
    });
    return { id, findings };
  }

  let pack;
  try {
    pack = JSON.parse(text);
  } catch (err) {
    findings.push({
      rule: 'ground-truth/unreadable', severity: 'blocking', file: PACK, line: 0,
      text: 'the sealed pack is not valid JSON: ' + String(err.message),
      why: 'The seal cannot be checked against a file that will not parse, and silence here would '
        + 'read as a pass.'
    });
    return { id, findings };
  }

  // ------------------------------------------------------- the times, compared position by position
  const list = Array.isArray(pack.sailings) ? pack.sailings : [];
  for (const serviceId of Object.keys(OWNER_TIMETABLE).sort()) {
    for (const direction of Object.keys(OWNER_TIMETABLE[serviceId]).sort()) {
      const supplied = OWNER_TIMETABLE[serviceId][direction];
      const held = list
        .filter((s) => s.serviceId === serviceId && s.direction === direction)
        .sort((a, b) => (a.departsMinuteOfDay - b.departsMinuteOfDay)
          || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
        .map(packEntry);

      if (held.length !== supplied.length) {
        findings.push({
          rule: 'ground-truth/timetable-drift', severity: 'blocking', file: PACK,
          line: lineOfText(text, serviceId),
          text: serviceId + ' ' + direction + ': the owner supplied ' + supplied.length
            + ' departures and this pack holds ' + held.length,
          why: WHY_DRIFT
        });
      }

      const n = Math.max(held.length, supplied.length);
      for (let i = 0; i < n; i++) {
        const want = i < supplied.length ? parseEntry(supplied[i]) : null;
        const got = i < held.length ? held[i] : null;
        const where = serviceId + ' ' + direction + ' departure ' + (i + 1);
        if (!want || !got) continue; // the count finding above already names it

        if (want.time !== got.time) {
          findings.push({
            rule: 'ground-truth/timetable-drift', severity: 'blocking', file: PACK,
            line: lineOfText(text, got.id),
            text: where + ' (' + got.id + '): the owner supplied ' + want.time
              + ' and this pack says ' + got.time,
            why: WHY_DRIFT
          });
        }
        if (want.vesselCode !== got.vesselCode) {
          findings.push({
            rule: 'ground-truth/timetable-drift', severity: 'blocking', file: PACK,
            line: lineOfText(text, got.id),
            text: where + ' (' + got.id + '): the owner supplied vessel code ' + want.vesselCode
              + ' and this pack says ' + got.vesselCode,
            why: WHY_DRIFT + ' The vehicle timetable prints a vessel beside every row, (M) for '
              + 'Minjerribah and (SB) for Sea Breeze, and the rotation is part of what was supplied.'
          });
        }
        if (want.dayRule !== got.dayRule) {
          findings.push({
            rule: 'ground-truth/timetable-drift', severity: 'blocking', file: PACK,
            line: lineOfText(text, got.id),
            text: where + ' (' + got.id + '): the owner supplied the day rule ' + want.dayRule
              + ' and this pack says ' + got.dayRule,
            why: WHY_DRIFT + ' A day rule is why the passenger window is held open at one end by '
              + 'one operator and at the other by the other, so moving one silently moves an '
              + 'answer about who can leave the island and when.'
          });
        }
        const wantMinute = minuteOfClock(want.time);
        if (wantMinute !== null && got.minute !== wantMinute && want.time === got.time) {
          findings.push({
            rule: 'ground-truth/timetable-drift', severity: 'blocking', file: PACK,
            line: lineOfText(text, got.id),
            text: where + ' (' + got.id + '): the clock time reads ' + got.time
              + ' and the minute of day is ' + got.minute + ', which is ' + wantMinute
              + ' in the supplied timetable',
            why: 'The clock time is what a person reads and the minute is what the simulation runs '
              + 'on. When they disagree the pack shows one timetable and runs another.'
          });
        }
      }
    }
  }

  // ------------------------------------------------------------------------------------ the seal
  const canonical = canonicalSailings(pack);
  const digest = digestOf(canonical);
  if (digest !== SEAL) {
    findings.push({
      rule: 'ground-truth/seal', severity: 'blocking', file: PACK, line: 0,
      text: 'the sailing structure no longer matches its seal: sealed ' + SEAL + ', now ' + digest
        + ', over ' + list.length + ' sailings',
      why: 'The seal is a digest over service, direction, departure minute, published clock time, '
        + 'vessel code and day rule, and over nothing else. It catches a change the transcribed '
        + 'times cannot see, such as a sailing added, a direction turned around, or a service '
        + 'renamed. If the change is intended, put this digest in SEAL in tools/gate/ground-truth.mjs '
        + 'and say on the board who supplied the new timetable and when.'
    });
  }

  return { id, findings };
}
