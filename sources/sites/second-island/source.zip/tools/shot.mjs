#!/usr/bin/env node
// The screenshot instrument: real pixels, checked by a program rather than by a description.
//
//     node tools/shot.mjs --assert <scene> [--shot <name|path>] [--json]
//     node tools/shot.mjs --moved <scene> <a> <b> [--json]
//     node tools/shot.mjs --list [--json]
//
// A screenshot nobody can machine check is a screenshot a builder can talk their way past. The
// first build spent three waves of critics judging a wash of magenta fog through a tool that could
// not see what it was judging, and every verdict from that period was worthless. So a picture in
// this repository is only evidence once a scene file says what should be at which pixel, and this
// tool has opened the file and agreed.
//
// A scene file, in tools/scenes/<name>.json, carries the frame size, the background, a list of
// samples with expected colours and tolerances, and a list of movement points that must differ
// between two frames drawn at different simulation ticks. tools/scenes/calibration.json is the
// worked example and its render block is complete enough to draw from.
//
// The two modes exist because two different faults hide from each other.
//
//   --assert  catches a frame that is wrong. A renderer that clears and draws nothing produces a
//             frame of pure background, and every quadrant sample fails and names itself.
//   --moved   catches a frame that is right and stale. A renderer that stopped following the
//             simulation keeps producing a picture that passes every sample assertion, because
//             every sample it is asserted against is a constant. Only two frames at two ticks show
//             it, which is why the movement points are declared separately.
//
// What this tool does not do: it does not drive a browser and it does not ask a page for a
// picture. The page posts its own frames to the app server, which writes them to shots/. Driving
// the page lands with the page itself, and `--name` says so rather than pretending.

import { readFileSync, readdirSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { decodePng, pixelAt } from './png.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const SCENES_DIR = path.join(HERE, 'scenes');
const SHOTS_DIR = path.join(REPO_ROOT, 'shots');

const DEFAULT_TOLERANCE = 8;

function usage() {
  return [
    'node tools/shot.mjs --assert <scene> [--shot <name|path>] [--json]',
    'node tools/shot.mjs --moved <scene> <a> <b> [--json]',
    'node tools/shot.mjs --list [--json]',
    '',
    '  --assert <scene>   check shots/<scene>.png against tools/scenes/<scene>.json',
    '  --shot <name>      check a different file against that scene',
    '  --moved <scene> <a> <b>   check the scene movement points differ between two shots',
    '  --list             the scenes, and whether a shot exists for each',
    '  --json             machine readable output on stdout, nothing else',
    '',
    'Exit code is 0 when every check passes, 1 when one fails, 2 on a usage or read error.'
  ].join('\n');
}

function rel(abs) {
  return path.relative(REPO_ROOT, abs).split('\\').join('/');
}

/** A scene by name, or by path when the argument looks like one. */
function sceneFile(nameOrPath) {
  if (nameOrPath.endsWith('.json') || nameOrPath.includes('/') || nameOrPath.includes('\\')) {
    return path.resolve(nameOrPath);
  }
  return path.join(SCENES_DIR, nameOrPath + '.json');
}

/** A shot by name, or by path when the argument looks like one. */
function shotFile(nameOrPath) {
  if (nameOrPath.endsWith('.png') || nameOrPath.includes('/') || nameOrPath.includes('\\')) {
    return path.resolve(nameOrPath);
  }
  return path.join(SHOTS_DIR, nameOrPath + '.png');
}

function loadScene(nameOrPath) {
  const file = sceneFile(nameOrPath);
  let text;
  try {
    text = readFileSync(file, 'utf8');
  } catch {
    throw new Error('no scene file at ' + rel(file));
  }
  let scene;
  try {
    scene = JSON.parse(text);
  } catch (err) {
    throw new Error('scene ' + rel(file) + ' is not valid JSON: ' + err.message);
  }
  const problems = checkScene(scene);
  if (problems.length) {
    throw new Error('scene ' + rel(file) + ' is not usable:\n  ' + problems.join('\n  '));
  }
  return { scene, file };
}

/** A scene file that is wrong about itself would fail pictures that are right, so it is checked. */
function checkScene(scene) {
  const problems = [];
  const colour = (v, where) => {
    if (!Array.isArray(v) || v.length !== 3 || v.some((n) => !Number.isInteger(n) || n < 0 || n > 255)) {
      problems.push(where + ' must be three integers from 0 to 255, got ' + JSON.stringify(v));
    }
  };
  if (!scene || typeof scene !== 'object') return ['not an object'];
  if (typeof scene.name !== 'string' || !scene.name) problems.push('name must be a string');
  if (!Number.isInteger(scene.width) || scene.width <= 0) problems.push('width must be a positive integer');
  if (!Number.isInteger(scene.height) || scene.height <= 0) problems.push('height must be a positive integer');
  colour(scene.background, 'background');
  if (!Array.isArray(scene.samples) || scene.samples.length === 0) {
    problems.push('samples must be a non empty array');
  } else {
    scene.samples.forEach((s, i) => {
      const where = 'samples[' + i + ']';
      if (typeof s.id !== 'string' || !s.id) problems.push(where + '.id must be a string');
      if (!Number.isInteger(s.x) || !Number.isInteger(s.y)) problems.push(where + ' needs integer x and y');
      else if (s.x >= scene.width || s.y >= scene.height || s.x < 0 || s.y < 0) {
        problems.push(where + ' at (' + s.x + ', ' + s.y + ') is outside the '
          + scene.width + ' by ' + scene.height + ' frame');
      }
      colour(s.expect, where + '.expect');
      if (s.tolerance !== undefined && (!Number.isFinite(s.tolerance) || s.tolerance < 0)) {
        problems.push(where + '.tolerance must be a number of 0 or more');
      }
    });
  }
  if (scene.movement !== undefined) {
    if (!Array.isArray(scene.movement)) problems.push('movement must be an array when present');
    else {
      scene.movement.forEach((m, i) => {
        const where = 'movement[' + i + ']';
        if (typeof m.id !== 'string' || !m.id) problems.push(where + '.id must be a string');
        if (!Number.isInteger(m.x) || !Number.isInteger(m.y)) problems.push(where + ' needs integer x and y');
        else if (m.x >= scene.width || m.y >= scene.height || m.x < 0 || m.y < 0) {
          problems.push(where + ' at (' + m.x + ', ' + m.y + ') is outside the frame');
        }
      });
    }
  }
  const ids = new Set();
  for (const s of [...(scene.samples || []), ...(scene.movement || [])]) {
    if (s && typeof s.id === 'string') {
      if (ids.has(s.id)) problems.push('duplicate id ' + s.id + ': a failure has to name one point');
      ids.add(s.id);
    }
  }
  return problems;
}

function loadShot(nameOrPath) {
  const file = shotFile(nameOrPath);
  let bytes;
  try {
    bytes = readFileSync(file);
  } catch {
    throw new Error('no shot at ' + rel(file));
  }
  let img;
  try {
    img = decodePng(bytes);
  } catch (err) {
    throw new Error('shot ' + rel(file) + ' did not decode: ' + err.message);
  }
  return { img, file, bytes };
}

const fmt = (c) => c.slice(0, 3).join(',');

function distances(expect, found) {
  const d = [0, 1, 2].map((i) => Math.abs(expect[i] - found[i]));
  return {
    perChannel: d,
    maxChannel: Math.max(...d),
    euclidean: Number(Math.sqrt(d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).toFixed(2))
  };
}

/**
 * Named encodings a movement point may declare, so the tool can read the simulation tick back out
 * of the picture. Named rather than parsed: a scene file that carried an expression would need an
 * expression evaluator here, and then a scene file could run code.
 */
const ENCODINGS = {
  'tick-lo16-rgb': (px) => (px[2] === 128
    ? { tick: px[0] + px[1] * 256, ok: true }
    : { tick: null, ok: false, why: 'blue is ' + px[2] + ' and this encoding holds it at 128' })
};

function decodeTick(encoding, px) {
  const fn = ENCODINGS[encoding];
  if (!fn) return null;
  return fn(px);
}

// ---- modes -------------------------------------------------------------------------------------

function assertScene(sceneArg, shotArg) {
  const { scene, file: sceneFilePath } = loadScene(sceneArg);
  const { img, file, bytes } = loadShot(shotArg || sceneArg);

  const result = {
    mode: 'assert',
    scene: scene.name,
    sceneFile: rel(sceneFilePath),
    shot: rel(file),
    shotBytes: bytes.length,
    width: img.width,
    height: img.height,
    channels: img.channels,
    sizeOk: img.width === scene.width && img.height === scene.height,
    samples: [],
    failed: [],
    ok: false
  };

  if (!result.sizeOk) {
    result.error = 'the shot is ' + img.width + ' by ' + img.height + ' and the scene declares '
      + scene.width + ' by ' + scene.height
      + '. Sample coordinates mean nothing across a size change, so nothing else was checked.';
    return result;
  }

  for (const s of scene.samples) {
    const tolerance = s.tolerance === undefined ? DEFAULT_TOLERANCE : s.tolerance;
    const found = pixelAt(img, s.x, s.y);
    const d = distances(s.expect, found);
    const ok = d.maxChannel <= tolerance;
    const row = {
      id: s.id,
      x: s.x,
      y: s.y,
      expect: s.expect,
      found: found.slice(0, 3),
      alpha: found[3],
      tolerance,
      distance: d.maxChannel,
      euclidean: d.euclidean,
      perChannel: d.perChannel,
      ok,
      why: s.why || ''
    };
    result.samples.push(row);
    if (!ok) result.failed.push(row);
  }

  result.ok = result.failed.length === 0;
  if (!result.ok) {
    const bg = scene.background;
    const allBackground = result.failed.every((f) => distances(bg, [...f.found, 255]).maxChannel <= DEFAULT_TOLERANCE);
    result.everyFailureIsBackground = allBackground;
  }
  return result;
}

function movedScene(sceneArg, aArg, bArg) {
  const { scene, file: sceneFilePath } = loadScene(sceneArg);
  const movement = scene.movement || [];
  const a = loadShot(aArg);
  const b = loadShot(bArg);

  const result = {
    mode: 'moved',
    scene: scene.name,
    sceneFile: rel(sceneFilePath),
    a: rel(a.file),
    b: rel(b.file),
    identicalFiles: a.bytes.equals(b.bytes),
    points: [],
    still: [],
    ok: false
  };

  if (movement.length === 0) {
    result.error = 'scene ' + scene.name + ' declares no movement points, so there is nothing this '
      + 'mode can check. Add one to the scene file.';
    return result;
  }
  for (const [label, img] of [['a', a.img], ['b', b.img]]) {
    if (img.width !== scene.width || img.height !== scene.height) {
      result.error = 'shot ' + label + ' is ' + img.width + ' by ' + img.height
        + ' and the scene declares ' + scene.width + ' by ' + scene.height + '.';
      return result;
    }
  }

  for (const m of movement) {
    const pa = pixelAt(a.img, m.x, m.y);
    const pb = pixelAt(b.img, m.x, m.y);
    const d = distances(pa, pb);
    const row = {
      id: m.id,
      x: m.x,
      y: m.y,
      a: pa.slice(0, 3),
      b: pb.slice(0, 3),
      changedChannels: d.perChannel.filter((v) => v > 0).length,
      distance: d.maxChannel,
      euclidean: d.euclidean,
      moved: d.maxChannel > 0,
      why: m.why || ''
    };
    if (m.encoding) {
      row.encoding = m.encoding;
      const ta = decodeTick(m.encoding, pa);
      const tb = decodeTick(m.encoding, pb);
      if (ta && tb) row.ticks = { a: ta, b: tb };
      else row.encodingUnknown = true;
    }
    result.points.push(row);
    if (!row.moved) result.still.push(row);
  }

  result.ok = result.still.length === 0;
  return result;
}

function listScenes() {
  let names;
  try {
    names = readdirSync(SCENES_DIR).filter((n) => n.endsWith('.json')).sort();
  } catch {
    names = [];
  }
  const rows = [];
  for (const name of names) {
    const stem = name.replace(/\.json$/, '');
    const row = { scene: stem, file: rel(path.join(SCENES_DIR, name)) };
    try {
      const { scene } = loadScene(stem);
      row.width = scene.width;
      row.height = scene.height;
      row.samples = scene.samples.length;
      row.movement = (scene.movement || []).length;
      row.usable = true;
    } catch (err) {
      row.usable = false;
      row.problem = err.message;
    }
    const shot = path.join(SHOTS_DIR, stem + '.png');
    try {
      row.shot = rel(shot);
      row.shotBytes = statSync(shot).size;
      row.shotExists = true;
    } catch {
      row.shotExists = false;
      row.shotBytes = 0;
    }
    rows.push(row);
  }
  let shots = [];
  try {
    shots = readdirSync(SHOTS_DIR).filter((n) => n.endsWith('.png')).sort();
  } catch {
    shots = [];
  }
  return { mode: 'list', scenesDir: rel(SCENES_DIR), shotsDir: rel(SHOTS_DIR), scenes: rows, shots, ok: true };
}

// ---- printing ----------------------------------------------------------------------------------

function printAssert(r) {
  const out = [];
  out.push('scene  ' + r.sceneFile + '  ' + r.width + ' by ' + r.height);
  out.push('shot   ' + r.shot + '  ' + r.shotBytes + ' bytes, ' + r.channels + ' channels');
  out.push('');
  if (r.error) {
    out.push('FAIL: ' + r.error);
    return out.join('\n');
  }
  const pad = Math.max(...r.samples.map((s) => s.id.length));
  for (const s of r.samples) {
    const at = '(' + s.x + ', ' + s.y + ')';
    out.push('  ' + (s.ok ? 'PASS ' : 'FAIL ') + s.id.padEnd(pad)
      + '  at ' + at.padEnd(12)
      + '  expected ' + fmt(s.expect).padEnd(12)
      + '  found ' + fmt(s.found).padEnd(12)
      + '  distance ' + String(s.distance).padStart(3) + ' of ' + s.tolerance
      + '  (' + s.euclidean + ' euclidean)');
    if (!s.ok && s.why) out.push('       ' + s.why);
  }
  out.push('');
  if (r.ok) {
    out.push('PASS: ' + r.samples.length + ' of ' + r.samples.length + ' samples within tolerance.');
  } else {
    out.push('FAIL: ' + r.failed.length + ' of ' + r.samples.length + ' samples wrong: '
      + r.failed.map((f) => f.id).join(', '));
    if (r.everyFailureIsBackground) {
      out.push('      Every failing sample holds the scene background colour, which is what a '
        + 'renderer that cleared the frame and drew nothing produces.');
    }
  }
  return out.join('\n');
}

function printMoved(r) {
  const out = [];
  out.push('scene  ' + r.sceneFile);
  out.push('a      ' + r.a);
  out.push('b      ' + r.b);
  out.push('');
  if (r.error) {
    out.push('FAIL: ' + r.error);
    return out.join('\n');
  }
  for (const p of r.points) {
    out.push('  ' + (p.moved ? 'MOVED' : 'STILL') + ' ' + p.id
      + '  at (' + p.x + ', ' + p.y + ')'
      + '  a ' + fmt(p.a) + '  b ' + fmt(p.b)
      + '  distance ' + p.distance + ' in ' + p.changedChannels + ' channel(s)');
    if (p.ticks) {
      const say = (t) => (t.ok ? 'tick ' + t.tick : 'not this encoding, ' + t.why);
      out.push('       encoding ' + p.encoding + ': a reads as ' + say(p.ticks.a)
        + ', b reads as ' + say(p.ticks.b));
    }
    if (!p.moved && p.why) out.push('       ' + p.why);
  }
  out.push('');
  if (r.ok) {
    out.push('PASS: ' + r.points.length + ' movement point(s) differ between the two shots.');
  } else {
    out.push('FAIL: ' + r.still.length + ' of ' + r.points.length + ' movement point(s) identical: '
      + r.still.map((p) => p.id).join(', '));
    out.push('      A frame that is right and stale passes every fixed sample, because every fixed '
      + 'sample is a constant. This is the check that sees it.');
    if (r.identicalFiles) {
      out.push('      The two files are byte for byte identical, so the same frame was posted twice.');
    }
  }
  return out.join('\n');
}

function printList(r) {
  const out = [];
  out.push('scenes in ' + r.scenesDir);
  if (r.scenes.length === 0) out.push('  none');
  for (const s of r.scenes) {
    if (!s.usable) {
      out.push('  ' + s.scene + '  UNUSABLE: ' + s.problem.split('\n')[0]);
      continue;
    }
    out.push('  ' + s.scene.padEnd(16) + s.width + ' by ' + s.height
      + '  ' + s.samples + ' sample(s), ' + s.movement + ' movement point(s)'
      + '  shot: ' + (s.shotExists ? s.shot + ', ' + s.shotBytes + ' bytes' : 'none yet'));
  }
  out.push('');
  out.push('shots in ' + r.shotsDir + ': ' + (r.shots.length ? r.shots.join(', ') : 'none yet'));
  return out.join('\n');
}

// ---- entry -------------------------------------------------------------------------------------

function main() {
  const argv = process.argv.slice(2);
  const json = argv.includes('--json');
  const args = argv.filter((a) => a !== '--json');

  const take = (flag) => {
    const i = args.indexOf(flag);
    return i === -1 ? null : args.slice(i + 1).filter((a) => !a.startsWith('--'));
  };

  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    process.stdout.write(usage() + '\n');
    process.exitCode = args.length === 0 ? 2 : 0;
    return;
  }

  if (args.includes('--name')) {
    process.stderr.write([
      '--name is not implemented, and this tool will not pretend it is.',
      'It is meant to ask the page for a frame, and no page exists in this repository yet.',
      'Today a frame arrives by being posted to the app server:',
      '  POST http://localhost:4281/__shot/<name>  with a PNG data URL or raw base64',
      'and this tool checks the file that lands in shots/.'
    ].join('\n') + '\n');
    process.exitCode = 2;
    return;
  }

  let result;
  try {
    if (args.includes('--list')) {
      result = listScenes();
    } else if (args.includes('--assert')) {
      const rest = take('--assert');
      if (!rest || rest.length < 1) throw new Error('--assert needs a scene name\n\n' + usage());
      const shotOverride = take('--shot');
      result = assertScene(rest[0], shotOverride && shotOverride.length ? shotOverride[0] : null);
    } else if (args.includes('--moved')) {
      const rest = take('--moved');
      if (!rest || rest.length < 3) {
        throw new Error('--moved needs a scene and two shots\n\n' + usage());
      }
      result = movedScene(rest[0], rest[1], rest[2]);
    } else {
      throw new Error('unknown arguments: ' + args.join(' ') + '\n\n' + usage());
    }
  } catch (err) {
    if (json) {
      process.stdout.write(JSON.stringify({ ok: false, error: String(err.message || err) }, null, 2) + '\n');
    } else {
      process.stderr.write(String(err.message || err) + '\n');
    }
    process.exitCode = 2;
    return;
  }

  if (json) {
    process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  } else {
    const text = result.mode === 'assert' ? printAssert(result)
      : result.mode === 'moved' ? printMoved(result)
        : printList(result);
    process.stdout.write(text + '\n');
  }
  process.exitCode = result.ok ? 0 : 1;
}

main();
