// Writing a PNG, minimally, so the tests have reference images.
//
// This exists for one reason: proving the screenshot instrument without a browser. A fault test
// needs a picture that is exactly right and a picture that is exactly wrong, and the only way to
// have both on demand is to build them here. It also gives the decoder in tools/png.mjs something
// to round trip against.
//
// What it writes: 8 bit RGBA, colour type 6, no interlacing, filter type 0 on every scanline.
// Filter type 0 means the scanline is stored as it is. The other four filters exist to make the
// deflate stream smaller and none of them changes what a decoder sees, so a writer whose job is
// correctness rather than file size has no reason to use them.
//
// The CRC comes from tools/png.mjs. One implementation, used both to write and to check, and the
// decoder checks it against PNGs written by other software, so a mistake in it cannot hide inside
// a round trip that only ever talks to itself.

import { deflateSync } from 'node:zlib';
import { crc32, PNG_SIGNATURE } from './png.mjs';

const BIT_DEPTH = 8;
const COLOUR_TYPE_RGBA = 6;

function chunk(type, data) {
  const out = Buffer.alloc(data.length + 12);
  out.writeUInt32BE(data.length, 0);
  out.write(type, 4, 4, 'latin1');
  data.copy(out, 8);
  out.writeUInt32BE(crc32(out, 4, 8 + data.length), 8 + data.length);
  return out;
}

/**
 * Encode raw RGBA bytes as a PNG.
 *
 * @param {object} img
 * @param {number} img.width
 * @param {number} img.height
 * @param {Buffer|Uint8Array|number[]} img.rgba width by height by 4 bytes, top row first
 * @param {number} [img.level] deflate level, 9 by default
 * @returns {Buffer} the whole file
 */
export function encodePng({ width, height, rgba, level = 9 }) {
  if (!Number.isInteger(width) || !Number.isInteger(height) || width <= 0 || height <= 0) {
    throw new Error('encodePng needs positive integer width and height, got ' + width + ' by ' + height);
  }
  const pixels = Buffer.isBuffer(rgba) ? rgba : Buffer.from(rgba);
  const needed = width * height * 4;
  if (pixels.length !== needed) {
    throw new Error('encodePng got ' + pixels.length + ' bytes of pixel data and ' + width + ' by '
      + height + ' RGBA needs ' + needed);
  }

  const stride = width * 4;
  const raw = Buffer.alloc(height * (stride + 1));
  for (let y = 0; y < height; y++) {
    raw[y * (stride + 1)] = 0; // filter type 0, stored as it is
    pixels.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = BIT_DEPTH;
  ihdr[9] = COLOUR_TYPE_RGBA;
  ihdr[10] = 0; // deflate
  ihdr[11] = 0; // adaptive filtering, which with filter type 0 everywhere means no filtering
  ihdr[12] = 0; // no interlacing

  return Buffer.concat([
    PNG_SIGNATURE,
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

/**
 * A blank canvas of one colour, as RGBA bytes. Every reference image in this repository starts as
 * one of these and then has rectangles painted onto it.
 *
 * @param {number} width
 * @param {number} height
 * @param {[number, number, number]|[number, number, number, number]} colour
 * @returns {Buffer}
 */
export function solidRgba(width, height, colour) {
  const [r, g, b, a = 255] = colour;
  const buf = Buffer.alloc(width * height * 4);
  for (let i = 0; i < buf.length; i += 4) {
    buf[i] = r;
    buf[i + 1] = g;
    buf[i + 2] = b;
    buf[i + 3] = a;
  }
  return buf;
}

/**
 * Paint a half open rectangle onto RGBA bytes: x from x0 up to but not including x1, the same for
 * y. Half open is the convention the scene files use, so that two rectangles sharing an edge do
 * not overlap on it and nobody has to argue about which one owns the pixel.
 */
export function fillRect(rgba, width, height, x0, y0, x1, y1, colour) {
  const [r, g, b, a = 255] = colour;
  const left = Math.max(0, x0);
  const top = Math.max(0, y0);
  const right = Math.min(width, x1);
  const bottom = Math.min(height, y1);
  for (let y = top; y < bottom; y++) {
    for (let x = left; x < right; x++) {
      const i = (y * width + x) * 4;
      rgba[i] = r;
      rgba[i + 1] = g;
      rgba[i + 2] = b;
      rgba[i + 3] = a;
    }
  }
  return rgba;
}
