#!/usr/bin/env node
// The determinism instrument: run the world twice from one seed and name what moved.
//
//     node tools/determinism.mjs --ticks 5000
//     node tools/determinism.mjs --ticks 5000 --shuffle
//     node tools/determinism.mjs --ticks 5000 --fixtures --checkpoints 20 --json
//
// The requirement, from docs/STAGE-0.md and from the failure that produced it: the first build could
// tell you two runs differed and not which system moved, so a determinism failure there was a day of
// bisecting by hand. NAMING THE SYSTEM IS THE WHOLE POINT OF THIS FILE.
//
// It is possible because the kernel hashes per system rather than per world: `world.hashes()` gives
// one hash for each system's own state and its own named random stream, plus `_store` and `_clock`.
// So this instrument never compares two world hashes and then guesses. It compares the per system
// table, and the keys that differ are the answer.
//
// How it works, in three steps:
//
//   1. Both runs step forward together and their hash tables are compared at checkpoints. Cheap:
//      the cost is two runs plus a hash per checkpoint.
//   2. On the first checkpoint that differs, the interval since the last matching checkpoint is
//      bisected. Each probe rebuilds both worlds from the seed and steps to the midpoint, so the
//      probe is a full replay and carries no state from the comparison run. The loop keeps `lo`
//      identical and `hi` different, so what it returns is exact: the two runs agree at the tick
//      before it and differ at it.
//   3. Both worlds are rebuilt to that tick and the drifting system's state is diffed field by
//      field, along with its random stream, because a system that drew a number and discarded it
//      has moved even when every field it owns still reads the same.
//
// --shuffle registers the systems in a different order in the second run. The kernel sorts systems
// by their declared integer order and breaks ties by name, so registration order must not be able
// to change a single number. A shuffled run that matches is the proof of that rule.
//
// --fixtures adds tools/fixtures/spin.js, three synthetic systems that exercise the store, the
// events and the streams far harder than stage 0's two real systems do. They are not part of the
// island and no code under src/ imports them.
//
// Exit code is 1 on any divergence, 2 on a usage error, 0 otherwise.

import { buildIslandWith, STAGE_0_PACKS } from '../src/world/island.js';
import { loadPacks, loadSourceIds, validatePacks } from '../src/world/data.js';
import { ACTIVE_FAULT, faultBanner } from '../src/kernel/faults.js';

function usage() {
  return [
    'node tools/determinism.mjs [--ticks N] [--shuffle] [--fixtures] [--json] [--checkpoints N]',
    '',
    '  --ticks N        island minutes to run in each of the two runs, default 5000',
    '  --shuffle        register the systems in a different order in the second run',
    '  --fixtures       add the synthetic test systems from tools/fixtures/spin.js',
    '  --json           machine readable output on stdout, nothing else',
    '  --checkpoints N  how many times to compare the two runs, default 20',
    '',
    'Exit code 1 on divergence.'
  ].join('\n');
}

function parseArgs(argv) {
  const opts = { ticks: 5000, shuffle: false, fixtures: false, json: false, checkpoints: 20, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--shuffle') opts.shuffle = true;
    else if (a === '--fixtures') opts.fixtures = true;
    else if (a === '--json') opts.json = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--ticks') opts.ticks = Number(argv[++i]);
    else if (a.startsWith('--ticks=')) opts.ticks = Number(a.slice(8));
    else if (a === '--checkpoints') opts.checkpoints = Number(argv[++i]);
    else if (a.startsWith('--checkpoints=')) opts.checkpoints = Number(a.slice(14));
    else throw new Error('unknown argument: ' + a + '\n\n' + usage());
  }
  if (!Number.isInteger(opts.ticks) || opts.ticks < 1) {
    throw new Error('--ticks needs a whole number of ticks, at least 1\n\n' + usage());
  }
  if (!Number.isInteger(opts.checkpoints) || opts.checkpoints < 1) {
    throw new Error('--checkpoints needs a whole number, at least 1\n\n' + usage());
  }
  return opts;
}

/** Checkpoint ticks, evenly spaced, always including 0 so a divergence at boot is caught. */
function checkpointTicks(ticks, count) {
  const out = new Set([0]);
  for (let i = 1; i <= count; i++) out.add(Math.round((ticks * i) / count));
  out.add(ticks);
  return [...out].sort((a, b) => a - b);
}

/** Keys whose hash differs, in the table's own order, which is declared tick order. */
function differingKeys(a, b) {
  const keys = [...new Set([...Object.keys(a), ...Object.keys(b)])];
  return keys.filter((k) => a[k] !== b[k]);
}

/** Every leaf of a state object, keyed by a path, so two states can be diffed without recursion. */
function flatten(value, prefix, out) {
  if (value === null || typeof value !== 'object') {
    out.set(prefix, value);
    return out;
  }
  if (ArrayBuffer.isView(value)) {
    out.set(prefix, Array.from(value).join(','));
    return out;
  }
  if (Array.isArray(value)) {
    out.set(prefix + '.length', value.length);
    value.forEach((v, i) => flatten(v, prefix + '[' + i + ']', out));
    return out;
  }
  for (const k of Object.keys(value).sort()) flatten(value[k], prefix ? prefix + '.' + k : k, out);
  return out;
}

const show = (v) => (v === undefined ? 'absent' : typeof v === 'string' ? JSON.stringify(v) : String(v));

/** Fields that differ between two states, capped, with a count of the rest. */
function fieldDiff(stateA, stateB, limit = 12) {
  const a = flatten(stateA, '', new Map());
  const b = flatten(stateB, '', new Map());
  const keys = [...new Set([...a.keys(), ...b.keys()])].sort();
  const rows = [];
  let more = 0;
  for (const k of keys) {
    if (Object.is(a.get(k), b.get(k))) continue;
    if (rows.length < limit) rows.push({ field: k, a: show(a.get(k)), b: show(b.get(k)) });
    else more++;
  }
  return { rows, more };
}

async function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n');
    process.exitCode = 2;
    return;
  }
  if (opts.help) {
    process.stdout.write(usage() + '\n');
    return;
  }

  // The packs are read once and both runs are built from the same parsed objects, so a difference
  // between the runs can never be a difference between two reads of a file. Validation is the same
  // check buildIsland() runs, done here because the rebuilds below have to be synchronous.
  let packs;
  try {
    packs = await loadPacks(STAGE_0_PACKS);
    const problems = validatePacks(packs, await loadSourceIds());
    if (problems.length) throw new Error('the packs did not pass the record check:\n  ' + problems.join('\n  '));
  } catch (err) {
    process.stderr.write(String(err && err.message ? err.message : err) + '\n');
    process.exitCode = 1;
    return;
  }

  let registerFixtures = null;
  if (opts.fixtures) {
    ({ registerFixtures } = await import('./fixtures/spin.js'));
  }

  /**
   * A world built from scratch. Variant 'B' is the second run: it shuffles the registration order
   * when asked, and is otherwise identical to 'A' down to the seed.
   */
  const build = (variant) => {
    const shuffle = variant === 'B' && opts.shuffle;
    const world = buildIslandWith(packs, { boot: false, shuffle });
    if (registerFixtures) registerFixtures(world, { shuffle });
    world.boot();
    return world;
  };

  /** A fresh world stepped to a tick. Used by the bisection, so every probe is a full replay. */
  const hashesAt = (variant, tick) => {
    const w = build(variant);
    if (tick > 0) w.step(tick);
    return w.hashes();
  };

  let runA;
  let runB;
  try {
    runA = build('A');
    runB = build('B');
  } catch (err) {
    process.stderr.write('the island did not build:\n' + (err && err.stack ? err.stack : String(err)) + '\n');
    process.exitCode = 1;
    return;
  }

  const registrationA = runA.systems.map((s) => s.name);
  const registrationB = runB.systems.map((s) => s.name);
  const tickOrder = runA._sorted().map((s) => s.name);

  // ---- step both runs together, comparing at checkpoints -----------------------------------------

  const points = checkpointTicks(opts.ticks, opts.checkpoints);
  const checkpoints = [];
  let firstBad = null;
  let previousGood = 0;
  let at = 0;

  try {
    for (const point of points) {
      if (point > at) {
        runA.step(point - at);
        runB.step(point - at);
        at = point;
      }
      const ha = runA.hashes();
      const hb = runB.hashes();
      const diff = differingKeys(ha, hb);
      checkpoints.push({ tick: point, ok: diff.length === 0, differing: diff });
      if (diff.length) { firstBad = { tick: point, differing: diff, hashesA: ha, hashesB: hb }; break; }
      previousGood = point;
    }
  } catch (err) {
    // A system that throws is a different failure from a system that drifts, and this instrument
    // says which it saw rather than reporting a stack and letting the reader decide.
    process.stderr.write(
      'a system threw at tick ' + runA.clock.tick + ', so the two runs could not be compared:\n'
      + (err && err.stack ? err.stack : String(err)) + '\n'
    );
    process.exitCode = 1;
    return;
  }

  const out = {
    ok: firstBad === null,
    fault: ACTIVE_FAULT || null,
    seed: runA.seed,
    epoch: runA.clock.epochISO,
    ticks: opts.ticks,
    checkpointCount: points.length,
    fixtures: opts.fixtures,
    shuffle: opts.shuffle,
    hashedKeys: Object.keys(runA.hashes()),
    registrationOrder: { A: registrationA, B: registrationB },
    tickOrder,
    checkpoints,
    divergence: null
  };

  // ---- on a difference, bisect to the tick and diff the system ----------------------------------

  if (firstBad) {
    const probes = [];
    let firstTick;
    if (firstBad.tick === 0) {
      // The two runs already differed after boot, before a single tick ran.
      firstTick = 0;
    } else {
      let lo = previousGood;   // known identical
      let hi = firstBad.tick;  // known different
      while (hi - lo > 1) {
        const mid = lo + Math.floor((hi - lo) / 2);
        const diff = differingKeys(hashesAt('A', mid), hashesAt('B', mid));
        probes.push({ tick: mid, differs: diff.length > 0, differing: diff });
        if (diff.length) hi = mid; else lo = mid;
      }
      firstTick = hi;
    }

    const wa = build('A');
    const wb = build('B');
    if (firstTick > 0) { wa.step(firstTick); wb.step(firstTick); }
    const ha = wa.hashes();
    const hb = wb.hashes();
    const differing = differingKeys(ha, hb);

    // The systems, in declared tick order, before the shared _store and _clock rows. A system is a
    // name a person can act on; _store means several systems write the same arrays and the field
    // diff below is what says which rows moved.
    const drifted = differing.filter((k) => !k.startsWith('_'));
    const primary = (drifted.length ? drifted : differing)[0] || null;

    const detail = {
      system: primary, kind: null, fields: [], more: 0,
      streamA: null, streamB: null, streamMoved: null, unseededSource: false
    };
    if (primary && !primary.startsWith('_')) {
      detail.kind = 'system';
      const d = fieldDiff(wa.byName.get(primary).state, wb.byName.get(primary).state);
      detail.fields = d.rows;
      detail.more = d.more;
      detail.streamA = wa.streams.streams.has(primary) ? wa.streams.get(primary).state() : null;
      detail.streamB = wb.streams.streams.has(primary) ? wb.streams.get(primary).state() : null;
      detail.streamMoved = JSON.stringify(detail.streamA) !== JSON.stringify(detail.streamB);
      // State moved while the system's own stream sat still, at the same draw count in both runs.
      // The number that changed did not come from the seed. What it did come from depends on
      // whether the two runs were built the same way, which is what --shuffle changes, so the two
      // readings are kept apart rather than collapsed into one guess.
      detail.stateMovedWithoutTheStream = d.rows.length > 0 && detail.streamMoved === false;
    } else if (primary === '_store') {
      detail.kind = 'store';
      const d = fieldDiff(wa.store.hashInput(), wb.store.hashInput(), 20);
      detail.fields = d.rows;
      detail.more = d.more;
    } else if (primary === '_clock') {
      detail.kind = 'clock';
      detail.fields = [{ field: 'tick', a: String(wa.clock.tick), b: String(wb.clock.tick) }];
    }

    out.divergence = {
      firstDivergentTick: firstTick,
      islandTime: wa.clock.iso(),
      systemsThatDrifted: differing,
      system: primary,
      firstBadCheckpoint: firstBad.tick,
      lastGoodCheckpoint: firstBad.tick === 0 ? null : previousGood,
      bisection: probes,
      hashAtTick: differing.map((k) => ({ key: k, A: ha[k] ?? 'absent', B: hb[k] ?? 'absent' })),
      detail
    };
  }

  // ---- output -----------------------------------------------------------------------------------

  if (opts.json) {
    process.stdout.write(JSON.stringify(out, null, 2) + '\n');
  } else {
    const lines = [];
    const banner = faultBanner();
    if (banner) lines.push(banner, '');
    lines.push(`determinism: seed ${out.seed}, ${out.ticks} ticks, ${out.checkpointCount} checkpoints`
      + `, fixtures ${out.fixtures ? 'on' : 'off'}, shuffle ${out.shuffle ? 'on' : 'off'}`);
    lines.push('  run A registration order: ' + registrationA.join(', '));
    lines.push('  run B registration order: ' + registrationB.join(', '));
    lines.push('  tick order in both runs:  ' + tickOrder.join(', '));
    lines.push('  hashed each checkpoint:   ' + out.hashedKeys.join(', '));
    lines.push('');
    for (const c of checkpoints) {
      lines.push('  checkpoint ' + String(c.tick).padStart(7) + (c.ok ? '  identical' : '  DIFFERS: ' + c.differing.join(', ')));
    }

    if (out.divergence) {
      const d = out.divergence;
      lines.push('');
      lines.push('DIVERGENCE');
      lines.push('  first checkpoint that differed: tick ' + d.firstBadCheckpoint
        + (d.lastGoodCheckpoint === null ? ' (at boot, before any tick ran)' : ', last identical checkpoint tick ' + d.lastGoodCheckpoint));
      if (d.bisection.length) {
        lines.push('  bisecting that interval, each probe a full replay of both runs:');
        for (const p of d.bisection) {
          lines.push('    tick ' + String(p.tick).padStart(7) + (p.differs ? '  differs' : '  identical'));
        }
      }
      lines.push('');
      lines.push('  FIRST DIVERGENT TICK: ' + d.firstDivergentTick + '   (island time ' + d.islandTime + ')');
      lines.push('  SYSTEM THAT DRIFTED:  ' + (d.system || 'none identified'));
      if (d.systemsThatDrifted.length > 1) {
        lines.push('  everything that differs at that tick: ' + d.systemsThatDrifted.join(', '));
      }
      lines.push('');
      for (const h of d.hashAtTick) lines.push('    hash ' + h.key.padEnd(18) + ' A ' + h.A + '   B ' + h.B);
      lines.push('');
      if (d.detail.fields.length) {
        lines.push('  diverging ' + (d.detail.kind === 'system' ? 'state fields' : d.detail.kind + ' fields') + ' at tick ' + d.firstDivergentTick + ':');
        const w = Math.max(...d.detail.fields.map((f) => f.field.length));
        for (const f of d.detail.fields) lines.push('    ' + f.field.padEnd(w) + '   A ' + f.a + '   B ' + f.b);
        if (d.detail.more) lines.push('    ... and ' + d.detail.more + ' more fields');
      } else if (d.detail.kind === 'system') {
        lines.push('  no state field differs, so the difference is in the random stream alone:');
        lines.push('  a system that drew a number and discarded it has still moved.');
      }
      if (d.detail.streamA || d.detail.streamB) {
        lines.push('    stream ' + d.detail.system + '  A ' + JSON.stringify(d.detail.streamA) + '   B ' + JSON.stringify(d.detail.streamB) + '   [a, b, c, d, draws]');
      }
      if (d.detail.stateMovedWithoutTheStream || out.shuffle) {
        lines.push('');
        lines.push('  What this points at:');
        if (d.detail.stateMovedWithoutTheStream) {
          lines.push('    The state moved but the stream did not, and its draw count is the same in both');
          lines.push('    runs, so the number that changed did not come from ' + d.detail.system + "'s own stream.");
        }
        if (out.shuffle) {
          lines.push('    The two runs were built identically except for the order the systems were');
          lines.push('    registered in, which the kernel promises cannot matter. Re-run without');
          lines.push('    --shuffle: if that passes, this system reads registration order somewhere.');
        } else {
          lines.push('    The two runs were built identically, same seed and same registration order,');
          lines.push('    so the difference came from outside the seed.');
        }
      }
    }

    lines.push('');
    lines.push(out.ok
      ? 'PASS: ' + out.ticks + ' ticks, ' + out.checkpointCount + ' checkpoints, '
        + out.hashedKeys.length + ' hashes identical in both runs'
        + (out.shuffle ? '. Registration order was different in run B and changed nothing.' : '')
      : 'FAIL: the two runs diverged at tick ' + out.divergence.firstDivergentTick
        + ' in ' + (out.divergence.system || 'an unidentified place'));
    process.stdout.write(lines.join('\n') + '\n');
  }

  process.exitCode = out.ok ? 0 : 1;
}

main();
