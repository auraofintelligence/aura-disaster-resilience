// The OpenStreetMap connector: real building outlines and roads for this island.
//
//   node tools/ingest/osm.mjs --fetch       one Overpass query, raw response staged with a receipt
//   node tools/ingest/osm.mjs --compare     the first build's bounding box, counted, nothing else
//   node tools/ingest/osm.mjs --summarise   counts by type from the staged raw file, no network
//   node tools/ingest/osm.mjs --derive      a provenanced pack into ingest-inbox/derived/
//
// Why this file exists at all. The founding prompt, section 2: "about 1,059 real outlines exist for
// this island, and the first build invented 1,922 boxes while they sat unused". That is the failure
// this repository was started to correct, so the correction cannot itself be a number nobody
// opened. --fetch and --summarise are how the figure gets checked rather than repeated.
//
// WHERE THE OUTPUT GOES, AND WHY IT IS NOT data/.
// Everything this tool writes lands under ingest-inbox/, which .gitignore seals and
// tools/gate/sealed.mjs proves sealed by asking git. The ODbL share-alike question against
// LICENCE.md is unresolved: board note 007, and docs/INGEST-STATUS.md's last table. Until the owner
// settles it, the connector is committed and the pack it produces is not. That is deliberate and
// this tool must not be changed to write into data/ without that decision landing first.
//
// HOW THE ISLAND IS BOUNDED, AND WHY NOT BY A BOX.
// The query is bounded by relation 5911994, which OpenStreetMap tags place=island,
// type=multipolygon, name "North Stradbroke Island", name:aus "Minjerribah". A bounding box around
// this island also contains the Southern Moreton Bay Islands and the northern end of South
// Stradbroke Island, all of which carry mapped buildings of their own. The island's own polygon
// does not, so the count this tool prints is a count of buildings on this island.
//
// BEING A GOOD CITIZEN OF A FREE PUBLIC SERVICE.
// One query per mode. The raw response is cached under ingest-inbox/osm/ and --summarise and
// --derive never touch the network, so a critic can re-read the same bytes as many times as they
// like. --fetch refuses to overwrite a raw file that already exists unless --force is given.

import { mkdirSync, readFileSync, writeFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { request } from 'node:https';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkRecord } from '../../src/kernel/record.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const INBOX = path.join(ROOT, 'ingest-inbox');
const RAW_DIR = path.join(INBOX, 'osm');
const DERIVED_DIR = path.join(INBOX, 'derived');

const ENDPOINT = { hostname: 'overpass-api.de', path: '/api/interpreter' };
const AGENT = 'second-island/0.1 ingest connector (Minjerribah twin, one query per run)';

/** The island, in OpenStreetMap's own words. Discovered by a place=island query over Moreton Bay. */
export const ISLAND = {
  osmType: 'relation',
  osmId: 5911994,
  name: 'North Stradbroke Island',
  nameAus: 'Minjerribah',
  wikidata: 'Q1546321'
};

/**
 * The one query. Five result sets, one round trip.
 *
 * `out meta geom` is asked for on purpose: `geom` gives the real coordinates rather than bare node
 * ids, and `meta` gives each element's own OSM timestamp, which is what a derived record's
 * validFrom is allowed to be. Without `meta` every record would have to fall back to the extract
 * date, and the pack would be weaker for no reason.
 */
export const QUERY = [
  '[out:json][timeout:240];',
  `rel(${ISLAND.osmId})->.islandRel;`,
  '.islandRel map_to_area -> .island;',
  '.islandRel out meta;',
  '( way["building"](area.island); rel["building"](area.island); )->.buildings;',
  '.buildings out meta geom;',
  'way["highway"](area.island)->.roads;',
  '.roads out meta geom;',
  'node["place"](area.island)->.places;',
  '.places out meta;',
  'rel["boundary"="administrative"]["admin_level"~"^(9|10)$"](area.island)->.localities;',
  '.localities out meta geom;'
].join('\n');

/**
 * The first build's query, from minjerribah-living-twin/docs/BUILDINGS.md lines 59 to 62, which is
 * where the 1,059 figure comes from. Counted rather than downloaded: `out count` returns a handful
 * of bytes, so checking their bound costs the public server almost nothing.
 */
export const FIRST_BUILD_QUERY = [
  '[out:json][timeout:120];',
  '(way["building"](-27.76,153.35,-27.37,153.56););',
  'out count;'
].join('\n');

/**
 * The independent cross-check on the island bound, and why it is worth one more query.
 *
 * The island count is only as good as the polygon it is bounded by, and a clipped polygon would
 * produce a confident, wrong, smaller number: exactly the failure this repository exists to catch,
 * turned inside out. So this fetches every building in the first build's bounding box with its
 * geometry and asks a different question with different machinery. The island count came from a
 * server-side area filter over the coastline relation. This one is decided in this file, by point
 * in polygon against the four Queensland locality boundaries, which are drawn by different mappers
 * for a different purpose than a coastline is. Two bounds, two mechanisms, one answer, or the
 * figure is not yet a fact.
 *
 * It deliberately does not use map_to_area. Overpass answers that from a separate areas dispatcher
 * which returned HTTP 504 twice on 19 August 2026 while plain queries went through in under two
 * seconds, so the cross-check is built to not need the busy half of the service.
 */
export const CROSSCHECK_QUERY = [
  '[out:json][timeout:180];',
  'way["building"](-27.76,153.35,-27.37,153.56);',
  'out geom;'
].join('\n');

// ---------------------------------------------------------------------------------------------
// Island civil time. tools/ is not under the no-wallclock rule, but the pack has to carry a date
// that means something, so the clock is read once here and converted to UTC+10 rather than left as
// whatever the host thinks local time is.
// ---------------------------------------------------------------------------------------------

/** Today in island civil time, YYYY-MM-DD. */
export function islandToday(nowMs = Date.now()) {
  return new Date(nowMs + 10 * 3600 * 1000).toISOString().slice(0, 10);
}

/** An OSM timestamp such as 2019-03-04T11:22:33Z, as an island civil date. Null when unusable. */
export function osmDate(timestamp) {
  if (typeof timestamp !== 'string') return null;
  const ms = Date.parse(timestamp);
  if (!Number.isFinite(ms)) return null;
  return islandToday(ms);
}

// ---------------------------------------------------------------------------------------------
// Fetch
// ---------------------------------------------------------------------------------------------

function post(body, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = request({
      ...ENDPOINT,
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Content-Length': Buffer.byteLength(body),
        'User-Agent': AGENT,
        'Accept-Encoding': 'identity'
      }
    }, (res) => {
      const chunks = [];
      res.on('data', (d) => chunks.push(d));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`no response from ${ENDPOINT.hostname} within ${Math.round(timeoutMs / 1000)} s`));
    });
    req.end(body);
  });
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex');
}

async function fetchOne({ query, name, force, timeoutMs }) {
  mkdirSync(RAW_DIR, { recursive: true });
  const day = islandToday();
  const rawPath = path.join(RAW_DIR, `${name}-${day}.json`);
  const receiptPath = path.join(RAW_DIR, `${name}-${day}.receipt.json`);

  if (existsSync(rawPath) && !force) {
    console.log(`already staged, not refetching: ${path.relative(ROOT, rawPath)}`);
    console.log('pass --force to replace it. --summarise and --derive read this file and never fetch.');
    return { rawPath, receiptPath, refetched: false };
  }

  console.log(`POST https://${ENDPOINT.hostname}${ENDPOINT.path}`);
  console.log(query.split('\n').map((l) => '  ' + l).join('\n'));
  const startedAt = new Date().toISOString();
  const t0 = Date.now();
  let res;
  try {
    res = await post(query, timeoutMs);
  } catch (err) {
    console.error(`FETCH FAILED: ${err.message}`);
    console.error('Nothing was written. Record the failure in docs/INGEST-STATUS.md as it happened.');
    process.exitCode = 1;
    return null;
  }
  const elapsedMs = Date.now() - t0;

  if (res.status !== 200) {
    console.error(`FETCH FAILED: HTTP ${res.status} after ${elapsedMs} ms`);
    console.error(res.body.toString('utf8').slice(0, 1000));
    process.exitCode = 1;
    return null;
  }

  let parsed = null;
  try {
    parsed = JSON.parse(res.body.toString('utf8'));
  } catch (err) {
    console.error(`FETCH FAILED: response was not JSON: ${err.message}`);
    process.exitCode = 1;
    return null;
  }
  if (parsed.remark) {
    console.error(`OVERPASS REMARK: ${parsed.remark}`);
    console.error('A remark is how Overpass reports a runtime error inside a 200 response. Not staged.');
    process.exitCode = 1;
    return null;
  }

  writeFileSync(rawPath, res.body);
  const receipt = {
    tool: 'tools/ingest/osm.mjs --fetch',
    endpoint: `https://${ENDPOINT.hostname}${ENDPOINT.path}`,
    query,
    requestedAt: startedAt,
    elapsedMs,
    httpStatus: res.status,
    bytes: res.body.length,
    sha256: sha256(res.body),
    elements: Array.isArray(parsed.elements) ? parsed.elements.length : 0,
    osm3s: parsed.osm3s || null,
    generator: parsed.generator || null,
    rawFile: path.relative(ROOT, rawPath).split(path.sep).join('/'),
    licence: 'Open Database Licence (ODbL), OpenStreetMap contributors. Not committable here: board note 007.'
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');

  console.log(`HTTP ${res.status}, ${res.body.length} bytes, ${elapsedMs} ms, ${receipt.elements} elements`);
  console.log(`sha256 ${receipt.sha256}`);
  console.log(`staged  ${receipt.rawFile}`);
  console.log(`receipt ${path.relative(ROOT, receiptPath).split(path.sep).join('/')}`);
  return { rawPath, receiptPath, refetched: true };
}

// ---------------------------------------------------------------------------------------------
// Reading the staged file
// ---------------------------------------------------------------------------------------------

/** The newest staged raw file whose name starts with `prefix`, or null when none is staged. */
export function newestRaw(prefix = 'overpass-island') {
  if (!existsSync(RAW_DIR)) return null;
  const files = readdirSync(RAW_DIR)
    .filter((f) => f.startsWith(prefix) && f.endsWith('.json') && !f.endsWith('.receipt.json'))
    .sort();
  if (!files.length) return null;
  return path.join(RAW_DIR, files[files.length - 1]);
}

function loadRaw(prefix) {
  const file = newestRaw(prefix);
  if (!file) {
    console.error(`nothing staged under ${path.relative(ROOT, RAW_DIR).split(path.sep).join('/')}/`);
    console.error('run: node tools/ingest/osm.mjs --fetch');
    process.exitCode = 1;
    return null;
  }
  const bytes = readFileSync(file);
  return { file, bytes, doc: JSON.parse(bytes.toString('utf8')) };
}

// ---------------------------------------------------------------------------------------------
// Geometry, kept small and explicit
// ---------------------------------------------------------------------------------------------

const R_EARTH_M = 6371008.8;
const rad = (d) => (d * Math.PI) / 180;

/** Great circle distance in metres between two lon lat points. */
export function haversineM(aLon, aLat, bLon, bLat) {
  const dLat = rad(bLat - aLat);
  const dLon = rad(bLon - aLon);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R_EARTH_M * Math.asin(Math.min(1, Math.sqrt(s)));
}

/** Length in metres along an ordered list of {lat, lon}. */
export function lineLengthM(geometry) {
  let m = 0;
  for (let i = 1; i < geometry.length; i++) {
    const a = geometry[i - 1];
    const b = geometry[i];
    if (!a || !b) continue;
    m += haversineM(a.lon, a.lat, b.lon, b.lat);
  }
  return m;
}

/**
 * The mean of a ring's distinct vertices. This is a vertex mean, not an area centroid, and it is
 * named that way because it is used only to ask which locality a building sits in. For a building
 * footprint of a few tens of metres the two agree to well inside any locality boundary.
 */
export function vertexMean(geometry) {
  let lon = 0, lat = 0, n = 0;
  const last = geometry.length - 1;
  const closed = last > 0
    && geometry[0] && geometry[last]
    && geometry[0].lat === geometry[last].lat && geometry[0].lon === geometry[last].lon;
  const upto = closed ? last : geometry.length;
  for (let i = 0; i < upto; i++) {
    const p = geometry[i];
    if (!p || typeof p.lat !== 'number' || typeof p.lon !== 'number') continue;
    lon += p.lon; lat += p.lat; n++;
  }
  return n ? { lon: lon / n, lat: lat / n, vertices: n } : null;
}

/** A relation's geometry, flattened to the coordinates of its way members that carry geometry. */
function relationGeometry(el) {
  const out = [];
  for (const m of el.members || []) {
    if (Array.isArray(m.geometry)) out.push(...m.geometry);
  }
  return out;
}

const key = (p) => `${p.lon.toFixed(7)},${p.lat.toFixed(7)}`;

/**
 * Stitch a multipolygon relation's way members into closed rings, per role.
 *
 * Overpass returns a multipolygon as a bag of open ways, so a boundary is only a polygon after its
 * pieces are joined end to end. Rings that will not close are returned as well, marked, because a
 * silently dropped ring is a silently wrong answer about which township a building is in.
 */
export function assembleRings(el, role) {
  const segs = (el.members || [])
    .filter((m) => m.type === 'way' && Array.isArray(m.geometry) && m.geometry.length > 1
      && ((m.role || 'outer') === role || (role === 'outer' && m.role === '')))
    .map((m) => m.geometry.slice());
  const rings = [];
  const open = [];
  const used = new Array(segs.length).fill(false);

  for (let i = 0; i < segs.length; i++) {
    if (used[i]) continue;
    used[i] = true;
    let ring = segs[i].slice();
    let grew = true;
    while (grew) {
      grew = false;
      if (key(ring[0]) === key(ring[ring.length - 1])) break;
      for (let j = 0; j < segs.length; j++) {
        if (used[j]) continue;
        const s = segs[j];
        if (key(ring[ring.length - 1]) === key(s[0])) { ring = ring.concat(s.slice(1)); used[j] = true; grew = true; break; }
        if (key(ring[ring.length - 1]) === key(s[s.length - 1])) { ring = ring.concat(s.slice().reverse().slice(1)); used[j] = true; grew = true; break; }
        if (key(ring[0]) === key(s[s.length - 1])) { ring = s.slice(0, -1).concat(ring); used[j] = true; grew = true; break; }
        if (key(ring[0]) === key(s[0])) { ring = s.slice().reverse().slice(0, -1).concat(ring); used[j] = true; grew = true; break; }
      }
    }
    if (key(ring[0]) === key(ring[ring.length - 1]) && ring.length > 3) rings.push(ring);
    else open.push(ring);
  }
  return { rings, open };
}

/** Ray casting on lon lat. The ring is a closed list of {lat, lon}. */
export function pointInRing(lon, lat, ring) {
  let inside = false;
  for (let i = 0, j = ring.length - 1; i < ring.length; j = i++) {
    const xi = ring[i].lon, yi = ring[i].lat;
    const xj = ring[j].lon, yj = ring[j].lat;
    const straddles = (yi > lat) !== (yj > lat);
    if (straddles && lon < ((xj - xi) * (lat - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

function bboxOf(rings) {
  let minLon = Infinity, minLat = Infinity, maxLon = -Infinity, maxLat = -Infinity;
  for (const r of rings) for (const p of r) {
    if (p.lon < minLon) minLon = p.lon;
    if (p.lon > maxLon) maxLon = p.lon;
    if (p.lat < minLat) minLat = p.lat;
    if (p.lat > maxLat) maxLat = p.lat;
  }
  return { minLon, minLat, maxLon, maxLat };
}

/**
 * The locality polygons in the extract, each with its assembled outer and inner rings and a
 * bounding box for a cheap reject. Localities are how OpenStreetMap distinguishes the townships in
 * Queensland: they are boundary=administrative at admin_level 10.
 */
export function localitiesFrom(doc) {
  const out = [];
  for (const el of doc.elements) {
    if (el.type !== 'relation') continue;
    const t = el.tags || {};
    if (t.boundary !== 'administrative') continue;
    const outer = assembleRings(el, 'outer');
    const inner = assembleRings(el, 'inner');
    if (!outer.rings.length) continue;
    out.push({
      osmId: el.id,
      name: t.name || `(unnamed relation ${el.id})`,
      adminLevel: t.admin_level || null,
      rings: outer.rings,
      holes: inner.rings,
      openRings: outer.open.length,
      bbox: bboxOf(outer.rings)
    });
  }
  return out.sort((a, b) => (a.name < b.name ? -1 : 1));
}

/** The locality a point sits in, by name, or null. */
export function localityAt(lon, lat, localities) {
  for (const loc of localities) {
    const b = loc.bbox;
    if (lon < b.minLon || lon > b.maxLon || lat < b.minLat || lat > b.maxLat) continue;
    let hit = false;
    for (const ring of loc.rings) if (pointInRing(lon, lat, ring)) { hit = !hit; }
    if (!hit) continue;
    let inHole = false;
    for (const hole of loc.holes) if (pointInRing(lon, lat, hole)) { inHole = true; break; }
    if (!inHole) return loc.name;
  }
  return null;
}

// ---------------------------------------------------------------------------------------------
// Summarise
// ---------------------------------------------------------------------------------------------

/**
 * The three townships, and the one place this file has to be careful about a name.
 *
 * OpenStreetMap calls the settlement at the north-west point "Amity Point" on its village node and
 * "Amity" on the locality polygon that contains it. Both names are OpenStreetMap's, not this
 * build's, and neither is invented here. The locality name is what a building is counted against,
 * because the locality is the polygon; the township name is what the founding prompt asks for. So
 * the mapping is written out rather than either name being quietly rewritten into the other.
 */
const TOWNSHIPS = [
  { township: 'Dunwich', locality: 'Dunwich' },
  { township: 'Amity Point', locality: 'Amity' },
  { township: 'Point Lookout', locality: 'Point Lookout' }
];

function tally(map, k) { map.set(k, (map.get(k) || 0) + 1); }

function sortedCounts(map) {
  return [...map.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
}

function classify(doc) {
  const localities = localitiesFrom(doc);
  const buildings = [];
  const roads = [];
  const places = [];
  let islandRel = null;

  for (const el of doc.elements) {
    const t = el.tags || {};
    if (el.type === 'relation' && el.id === ISLAND.osmId) { islandRel = el; continue; }
    if (t.building) {
      const geom = el.type === 'way' ? (el.geometry || []) : relationGeometry(el);
      buildings.push({ el, geom });
      continue;
    }
    if (el.type === 'way' && t.highway) { roads.push({ el, geom: el.geometry || [] }); continue; }
    if (el.type === 'node' && t.place) { places.push(el); continue; }
  }
  return { localities, buildings, roads, places, islandRel };
}

function summarise({ json }) {
  const raw = loadRaw('overpass-island');
  if (!raw) return;
  const { localities, buildings, roads, places, islandRel } = classify(raw.doc);

  const byBuildingTag = new Map();
  const byBuildingType = new Map();
  const byTownship = new Map();
  const byLocality = new Map();
  let named = 0;
  let noTimestamp = 0;
  let noGeometry = 0;

  for (const b of buildings) {
    tally(byBuildingTag, b.el.tags.building);
    tally(byBuildingType, b.el.type);
    if (b.el.tags.name) named++;
    if (!b.el.timestamp) noTimestamp++;
    const c = b.geom.length ? vertexMean(b.geom) : null;
    if (!c) { noGeometry++; continue; }
    const loc = localityAt(c.lon, c.lat, localities);
    tally(byLocality, loc || '(no locality polygon covers it)');
    const t = TOWNSHIPS.find((x) => x.locality === loc);
    if (t) tally(byTownship, t.township);
  }

  const byHighway = new Map();
  const lengthByHighway = new Map();
  let roadMetres = 0;
  let namedRoads = 0;
  for (const r of roads) {
    tally(byHighway, r.el.tags.highway);
    if (r.el.tags.name) namedRoads++;
    const m = lineLengthM(r.geom);
    roadMetres += m;
    lengthByHighway.set(r.el.tags.highway, (lengthByHighway.get(r.el.tags.highway) || 0) + m);
  }

  const result = {
    rawFile: path.relative(ROOT, raw.file).split(path.sep).join('/'),
    bytes: raw.bytes.length,
    sha256: sha256(raw.bytes),
    extractTimestamp: raw.doc.osm3s ? raw.doc.osm3s.timestamp_osm_base : null,
    bound: {
      osm: `${ISLAND.osmType}/${ISLAND.osmId}`,
      name: ISLAND.name,
      relationPresent: Boolean(islandRel),
      relationTimestamp: islandRel ? islandRel.timestamp || null : null
    },
    buildings: {
      total: buildings.length,
      byElementType: sortedCounts(byBuildingType),
      byTag: sortedCounts(byBuildingTag),
      named,
      withoutOwnTimestamp: noTimestamp,
      withoutGeometry: noGeometry
    },
    townships: TOWNSHIPS.map((t) => ({
      name: t.township, osmLocality: t.locality, buildings: byTownship.get(t.township) || 0
    })),
    localities: sortedCounts(byLocality),
    localityPolygons: localities.map((l) => ({
      name: l.name, adminLevel: l.adminLevel, osmId: l.osmId,
      rings: l.rings.length, holes: l.holes.length, unclosedRings: l.openRings
    })),
    roads: {
      total: roads.length,
      named: namedRoads,
      totalKm: Number((roadMetres / 1000).toFixed(1)),
      byClassification: sortedCounts(byHighway).map(([k, n]) => ({
        highway: k, ways: n, km: Number(((lengthByHighway.get(k) || 0) / 1000).toFixed(1))
      }))
    },
    placeNodes: places.map((p) => ({
      osmId: p.id, name: p.tags.name || null, place: p.tags.place, lat: p.lat, lon: p.lon
    })).sort((a, b) => (String(a.name) < String(b.name) ? -1 : 1))
  };

  if (json) { console.log(JSON.stringify(result, null, 2)); return; }

  const say = (s) => console.log(s);
  say(`raw     ${result.rawFile}`);
  say(`bytes   ${result.bytes}, sha256 ${result.sha256}`);
  say(`extract ${result.extractTimestamp}`);
  say(`bound   ${result.bound.osm}, ${result.bound.name}, present in extract: ${result.bound.relationPresent}`);
  say('');
  say(`BUILDINGS  ${result.buildings.total} total, ${result.buildings.named} carrying a name`);
  say(`           by element type: ${result.buildings.byElementType.map(([k, n]) => `${k} ${n}`).join(', ')}`);
  say(`           without their own OSM timestamp: ${result.buildings.withoutOwnTimestamp}`);
  say(`           without geometry in this extract: ${result.buildings.withoutGeometry}`);
  say('           by building tag value:');
  for (const [k, n] of result.buildings.byTag) say(`             ${String(n).padStart(5)}  ${k}`);
  say('');
  say('TOWNSHIPS  buildings whose vertex mean falls inside the locality polygon');
  for (const t of result.townships) {
    const via = t.osmLocality === t.name ? '' : `  (OpenStreetMap locality "${t.osmLocality}")`;
    say(`             ${String(t.buildings).padStart(5)}  ${t.name}${via}`);
  }
  say('           every locality in the extract:');
  for (const [k, n] of result.localities) say(`             ${String(n).padStart(5)}  ${k}`);
  say('');
  say(`ROADS      ${result.roads.total} ways, ${result.roads.named} carrying a name, ${result.roads.totalKm} km of centreline`);
  for (const r of result.roads.byClassification) {
    say(`             ${String(r.ways).padStart(5)}  ${r.highway.padEnd(16)} ${String(r.km).padStart(7)} km`);
  }
  say('');
  say(`PLACE NODES ${result.placeNodes.length}`);
  for (const p of result.placeNodes) say(`             ${p.place.padEnd(10)} ${p.name || '(unnamed)'}`);
}

// ---------------------------------------------------------------------------------------------
// Derive
// ---------------------------------------------------------------------------------------------

const SOURCE_ID = 'osm-overpass';

/**
 * One derived record. The eight provenance fields are not decoration here.
 *
 *   source        an id in data/_sources.json, never free text
 *   locator       the OSM element type and id, and the URL that opens it. One step to check.
 *   validFrom     the element's own OSM timestamp, as an island civil date, when it has one. That
 *                 is the date the outline was last asserted by a mapper, NOT the date the building
 *                 was built, and the pack says so in its own about field rather than leaving a
 *                 reader to assume. When the element carries no timestamp, validFrom falls back to
 *                 the extract date and confidence drops to low with the reason on the record.
 *   confidence    medium as a baseline: one source, volunteer contributed, not checked on the
 *                 ground by anybody here. The first build's places pack reserved high for "two
 *                 independent sources agree within about 50 m" and no second source has been
 *                 opened, so high is not available to this pack.
 *   register      known. The geometry is a real record of a real thing, not a model of one.
 */
function provenance(el, extractDay, today) {
  const own = osmDate(el.timestamp);
  const base = {
    source: SOURCE_ID,
    locator: `OpenStreetMap ${el.type} ${el.id}, https://www.openstreetmap.org/${el.type}/${el.id}`,
    validFrom: own || extractDay,
    validTo: null,
    recordedAt: today,
    recordedUntil: null,
    confidence: own ? 'medium' : 'low',
    register: 'known'
  };
  base.provenanceNote = own
    ? `validFrom is this element's own OpenStreetMap timestamp ${el.timestamp}, which is when a `
      + 'mapper last asserted it, not when the thing was built. It is the earliest date on which '
      + 'this build can evidence the outline was claimed. Confidence is medium because one source '
      + 'says so and nobody here has checked it on the ground.'
    : 'This element carried no timestamp in the extract, so validFrom falls back to the date of the '
      + 'extract itself and confidence is lowered to low. The date says when the twin saw the '
      + 'feature, and nothing at all about when the feature became true of the island.';
  if (typeof el.version === 'number') base.osmVersion = el.version;
  return base;
}

function derive({ json }) {
  const raw = loadRaw('overpass-island');
  if (!raw) return;
  const today = islandToday();
  const extractDay = raw.doc.osm3s && raw.doc.osm3s.timestamp_osm_base
    ? osmDate(raw.doc.osm3s.timestamp_osm_base) || today
    : today;
  const { localities, buildings, roads } = classify(raw.doc);

  const buildingRecords = [];
  for (const b of buildings) {
    const c = b.geom.length ? vertexMean(b.geom) : null;
    const t = b.el.tags;
    buildingRecords.push({
      id: `osm-${b.el.type}-${b.el.id}`,
      kind: 'building',
      buildingTag: t.building,
      name: t.name || null,
      levels: t['building:levels'] || null,
      locality: c ? localityAt(c.lon, c.lat, localities) : null,
      centreLon: c ? Number(c.lon.toFixed(7)) : null,
      centreLat: c ? Number(c.lat.toFixed(7)) : null,
      outline: b.geom.map((p) => [Number(p.lon.toFixed(7)), Number(p.lat.toFixed(7))]),
      crs: 'WGS84 decimal degrees, lon lat',
      ...provenance(b.el, extractDay, today)
    });
  }

  const roadRecords = [];
  for (const r of roads) {
    const t = r.el.tags;
    roadRecords.push({
      id: `osm-${r.el.type}-${r.el.id}`,
      kind: 'road',
      highway: t.highway,
      name: t.name || null,
      surface: t.surface || null,
      lengthM: Number(lineLengthM(r.geom).toFixed(1)),
      centreline: r.geom.map((p) => [Number(p.lon.toFixed(7)), Number(p.lat.toFixed(7))]),
      crs: 'WGS84 decimal degrees, lon lat',
      ...provenance(r.el, extractDay, today)
    });
  }

  const about = 'Derived from one Overpass query bounded by the OpenStreetMap relation for this '
    + 'island. NOT COMMITTABLE. It lives under ingest-inbox/, which .gitignore seals and '
    + 'tools/gate/sealed.mjs proves sealed by asking git, because the ODbL share-alike question '
    + 'against LICENCE.md is unresolved: board note 007. Every validFrom on a record here is the '
    + "date a mapper last asserted the feature in OpenStreetMap, not the date the feature became "
    + 'true of the island, and no record in this pack should ever be read as a construction date. '
    + 'Contributor names and user ids from the extract are not carried into these records.';

  const attribution = 'Map data from OpenStreetMap, copyright OpenStreetMap contributors, available '
    + 'under the Open Database Licence (ODbL). https://www.openstreetmap.org/copyright';

  const packs = [
    {
      file: `osm-buildings-${today}.json`,
      doc: {
        pack: 'osm-buildings',
        version: '0.1.0',
        about,
        attribution,
        bound: `${ISLAND.osmType}/${ISLAND.osmId}, ${ISLAND.name}`,
        extractTimestamp: raw.doc.osm3s ? raw.doc.osm3s.timestamp_osm_base : null,
        rawFile: path.relative(ROOT, raw.file).split(path.sep).join('/'),
        rawSha256: sha256(raw.bytes),
        count: buildingRecords.length,
        buildings: buildingRecords
      }
    },
    {
      file: `osm-roads-${today}.json`,
      doc: {
        pack: 'osm-roads',
        version: '0.1.0',
        about,
        attribution,
        bound: `${ISLAND.osmType}/${ISLAND.osmId}, ${ISLAND.name}`,
        extractTimestamp: raw.doc.osm3s ? raw.doc.osm3s.timestamp_osm_base : null,
        rawFile: path.relative(ROOT, raw.file).split(path.sep).join('/'),
        rawSha256: sha256(raw.bytes),
        count: roadRecords.length,
        roads: roadRecords
      }
    }
  ];

  // Every record is put through the same validator the gate uses, against the same source ids, so
  // this pack is proven to pass the rule it will one day be committed under rather than assumed to.
  let sourceIds = null;
  try {
    sourceIds = new Set(Object.keys(JSON.parse(readFileSync(path.join(ROOT, 'data', '_sources.json'), 'utf8'))));
  } catch (err) {
    console.error(`could not read data/_sources.json: ${err.message}`);
  }
  const problems = [];
  for (const rec of [...buildingRecords, ...roadRecords]) {
    for (const p of checkRecord(rec, sourceIds ? { sourceIds, where: rec.id } : { where: rec.id })) problems.push(p);
  }

  mkdirSync(DERIVED_DIR, { recursive: true });
  const written = [];
  for (const p of packs) {
    const abs = path.join(DERIVED_DIR, p.file);
    writeFileSync(abs, JSON.stringify(p.doc, null, 1) + '\n');
    written.push({ file: path.relative(ROOT, abs).split(path.sep).join('/'), bytes: statSync(abs).size, records: p.doc.count });
  }

  const result = {
    written,
    recordsChecked: buildingRecords.length + roadRecords.length,
    sourceIdsRead: sourceIds ? sourceIds.size : 0,
    provenanceProblems: problems
  };
  if (json) { console.log(JSON.stringify(result, null, 2)); }
  else {
    for (const w of written) console.log(`wrote ${w.file}  ${w.records} records, ${w.bytes} bytes`);
    console.log(`checked ${result.recordsChecked} records with src/kernel/record.js against ${result.sourceIdsRead} source ids`);
    console.log(problems.length ? `PROVENANCE PROBLEMS: ${problems.length}` : 'provenance: 0 problems');
    for (const p of problems.slice(0, 20)) console.log('  ' + p);
  }
  if (problems.length) process.exitCode = 1;
}

// ---------------------------------------------------------------------------------------------
// Compare, which is the whole reason the founding prompt's figure gets checked rather than repeated
// ---------------------------------------------------------------------------------------------

function countIn(prefix) {
  const file = newestRaw(prefix);
  if (!file) return { file: null, ways: null };
  const doc = JSON.parse(readFileSync(file, 'utf8'));
  const c = doc.elements.find((e) => e.type === 'count');
  return {
    file: path.relative(ROOT, file).split(path.sep).join('/'),
    ways: c ? Number(c.tags.ways) : null
  };
}

const ISLAND_LOCALITIES = ['Dunwich', 'Amity', 'Point Lookout', 'North Stradbroke Island'];

function compare() {
  const island = loadRaw('overpass-island');
  if (!island) return;
  const { buildings, localities } = classify(island.doc);
  const onIsland = buildings.length;
  const bbox = countIn('overpass-firstbuild-bbox');
  const crossFile = newestRaw('overpass-crosscheck-bbox');

  console.log('The founding prompt, section 2 and section 5: "about 1,059 real outlines exist for this island".');
  console.log('Its origin: minjerribah-living-twin/docs/BUILDINGS.md line 44, counted by Overpass on 10 August 2026,');
  console.log('with the query at lines 59 to 62 of that file, which is a bounding box, not the island.');
  console.log('');
  console.log(`island polygon, ${ISLAND.osmType}/${ISLAND.osmId}, server side:  ${onIsland} buildings`);
  console.log(bbox.ways === null
    ? "first build's bounding box, out count:                 not counted. add --fetch"
    : `first build's bounding box, out count:                 ${bbox.ways} ways  [${bbox.file}]`);

  if (!crossFile) {
    console.log('cross-check, locality polygons decided here:           not fetched. add --fetch');
    return;
  }

  const doc = JSON.parse(readFileSync(crossFile, 'utf8'));
  const inBox = doc.elements.filter((e) => e.type === 'way' && e.tags && e.tags.building);
  const inIslandArea = new Set(buildings.filter((b) => b.el.type === 'way').map((b) => b.el.id));
  const byLocality = new Map();
  const disagreements = [];
  let onIslandByLocality = 0;
  let offIsland = 0;
  let noGeom = 0;
  for (const el of inBox) {
    const c = Array.isArray(el.geometry) && el.geometry.length ? vertexMean(el.geometry) : null;
    if (!c) { noGeom++; continue; }
    const loc = localityAt(c.lon, c.lat, localities);
    const byLoc = Boolean(loc && ISLAND_LOCALITIES.includes(loc));
    if (byLoc) { onIslandByLocality++; tally(byLocality, loc); } else offIsland++;
    const byArea = inIslandArea.has(el.id);
    // Naming what moved is this repository's rule for its determinism instrument, and it is the
    // same rule here. A bound that disagrees by a number nobody can open is not a finding.
    if (byLoc !== byArea) {
      disagreements.push({
        id: el.id,
        onlyIn: byLoc ? 'the locality polygon' : 'the coastline polygon',
        locality: loc,
        name: el.tags.name || null,
        tags: el.tags,
        lon: Number(c.lon.toFixed(6)),
        lat: Number(c.lat.toFixed(6))
      });
    }
  }

  console.log(`cross-check, locality polygons decided here:           ${onIslandByLocality} ways  [${path.relative(ROOT, crossFile).split(path.sep).join('/')}]`);
  console.log('');
  if (!disagreements.length) {
    console.log('THE TWO BOUNDS AGREE EXACTLY. One was decided by Overpass against the coastline relation,');
    console.log('the other here by point in polygon against four locality boundaries. Neither is clipping');
    console.log('the other, so the island figure is a measurement and not an artefact of one polygon.');
  } else {
    console.log(`THE TWO BOUNDS DISAGREE ON ${disagreements.length}, and here is each one, by name.`);
    console.log('A count that differs by a number nobody can open is not a finding, so they are listed:');
    for (const d of disagreements) {
      console.log(`  way ${d.id}  ${d.name || '(unnamed)'}`);
      console.log(`    inside ${d.onlyIn} only, locality ${d.locality || 'none'}, at ${d.lat}, ${d.lon}`);
      console.log(`    tags ${JSON.stringify(d.tags)}`);
      console.log(`    https://www.openstreetmap.org/way/${d.id}`);
    }
    console.log('  A structure standing over the water on a jetty sits outside a coastline polygon and');
    console.log('  inside the locality that owns the jetty. Both bounds are right about what they measure.');
  }
  console.log('');
  console.log(`Of the ${inBox.length} buildings in that bounding box, ${offIsland} are not on this island`
    + (noGeom ? `, and ${noGeom} carried no geometry` : '') + '.');
  console.log('The box runs from -27.76 to -27.37 latitude and 153.35 to 153.56 longitude, so it also holds');
  console.log('Russell, Macleay, Karragarra, Lamb, Perulpa and Coochiemudlo Islands and the northern end of');
  console.log('South Stradbroke Island. Their buildings are real; they are just not this island\'s.');
  console.log('');
  console.log('on-island split, by locality, decided here:');
  for (const [k, n] of sortedCounts(byLocality)) console.log(`  ${String(n).padStart(5)}  ${k}`);
}

// ---------------------------------------------------------------------------------------------

const USAGE = `node tools/ingest/osm.mjs <mode>

  --fetch        one Overpass query bounded by ${ISLAND.osmType}/${ISLAND.osmId}, staged raw with a receipt
  --compare      the island count against the first build's bounding box, and against an
                 independent cross-check bound by the four locality polygons.
                 add --fetch to count those two first: both are count only, a few hundred bytes each
  --summarise    counts by type from the staged raw file. No network
  --derive       a provenanced pack into ingest-inbox/derived/. No network

  --force        allow --fetch to replace a raw file already staged for today
  --json         machine readable output for --summarise and --derive

Nothing this tool writes is committable. ingest-inbox/ is sealed: board note 007.
`;

async function main(argv) {
  const has = (f) => argv.includes(f);
  if (!argv.length || has('--help') || has('-h')) { console.log(USAGE); return; }

  const json = has('--json');
  const force = has('--force');

  if (has('--compare') && has('--fetch')) {
    await fetchOne({ query: FIRST_BUILD_QUERY, name: 'overpass-firstbuild-bbox', force, timeoutMs: 140000 });
    await fetchOne({ query: CROSSCHECK_QUERY, name: 'overpass-crosscheck-bbox', force, timeoutMs: 200000 });
    compare();
    return;
  }
  if (has('--fetch')) {
    await fetchOne({ query: QUERY, name: 'overpass-island', force, timeoutMs: 260000 });
    return;
  }
  if (has('--compare')) { compare(); return; }
  if (has('--summarise')) { summarise({ json }); return; }
  if (has('--derive')) { derive({ json }); return; }

  console.error(`unknown mode: ${argv.join(' ')}`);
  console.error(USAGE);
  process.exitCode = 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2));
}
