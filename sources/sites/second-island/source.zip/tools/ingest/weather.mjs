#!/usr/bin/env node
// Open-Meteo archive, ERA5 reanalysis: the first real past for the bitemporal store.
//
//     node tools/ingest/weather.mjs --fetch        one bounded year, staged raw with a receipt
//     node tools/ingest/weather.mjs --summarise    what the staged year holds. No network
//     node tools/ingest/weather.mjs --derive       a provenanced pack into ingest-inbox/derived/
//     node tools/ingest/weather.mjs --fetch --start 2024-08-01 --end 2025-07-31
//     node tools/ingest/weather.mjs --summarise --json
//
// WHY THIS LANE, AND WHY IT IS SMALL ON PURPOSE. The founding prompt's stage 3 is the bitemporal
// spine and its section 5 asks for "real past weather for the bitemporal store". A record with two
// times needs a real past to be true of, and until this lane ran there was none: every record in
// data/ was either physics or a carried coordinate. A year of daily reanalysis is the smallest thing
// that is still a real history, and a century of it would prove nothing a year does not.
//
// WHAT A REANALYSIS IS, AND WHAT IT IS NOT. ERA5 is a model run backwards over assimilated
// observations. It is not an observation of this island. The nearest thing to an observation is the
// Bureau of Meteorology's registered data service, which this repository has not registered for, and
// the undocumented api.weather.bom.gov.au is prohibited by its own terms and is not an option. So
// every record this lane derives carries register "modelled", not "known", and confidence "medium".
// Calling a reanalysis an observation is the kind of quiet promotion the source ladder exists to
// prevent, and the ladder's rule is that the bottom rung never wins in live mode.
//
// THE GRID CELL IS NOT THE TOWNSHIP. ERA5 is published on a 0.25 degree grid. The request carries
// the Dunwich coordinate from data/tide.json and the API answers from the cell that contains it,
// which it names in the response. This tool prints the requested point and the answered cell centre
// side by side and the distance between them, because a reader who is not told will assume the
// figure is for the place they asked about. It is not: it is for a cell about 25 km across.
//
// LICENCE AND ATTRIBUTION. Open-Meteo publishes its API data under Attribution 4.0 International,
// CC BY 4.0, and its licence page adds a specific display obligation: a link next to any location
// the data are shown. The underlying reanalysis is Copernicus Climate Change Service material under
// the Licence to Use Copernicus Products. Both are recorded in data/_sources.json under
// open-meteo-archive, and the attribution string travels inside every pack this tool writes so it
// cannot be separated from the numbers. No player facing surface exists yet to carry it, and that
// is a gap named in docs/INGEST-STATUS.md rather than a thing this tool can fix.
//
// NOTHING DERIVED IS COMMITTED THIS WAVE. Everything written lands under ingest-inbox/, which
// .gitignore seals and tools/gate/sealed.mjs proves sealed by asking git. CC BY is not the licence
// that blocks this lane; the blanket hold on derived packs is, and it lifts when the owner settles
// board note 007.
//
// This file may read a wall clock. The ban in gate/no-wallclock covers src/kernel, src/systems and
// src/world, because a world whose state depends on when it ran cannot be diffed against itself.
// The date a file was downloaded is not world state, it is the receipt.

import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { checkRecord } from '../../src/kernel/record.js';
import { SITE_DUNWICH, sunEvents, daysInYear } from '../../src/systems/solar.js';
import { daysFromCivil, civilFromDays } from '../../src/kernel/clock.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const INBOX = path.join(ROOT, 'ingest-inbox');
const RAW_DIR = path.join(INBOX, 'weather');
const DERIVED_DIR = path.join(INBOX, 'derived');

const ENDPOINT = 'https://archive-api.open-meteo.com/v1/archive';
const AGENT = 'second-island/0.1 ingest connector (Minjerribah twin, one bounded window per run)';
const SOURCE_ID = 'open-meteo-archive';

/**
 * The window, pinned rather than relative, so two runs a month apart can be compared.
 *
 * Twelve whole months ending before the month this lane was first run. The archive lags real time:
 * on 19 August 2026 the last day carrying values was 13 August 2026, six days back, and a window
 * that ran to "today" would have ended in a tail of nulls that a later reader would read as a
 * finding. Override with --start and --end when a different window is wanted.
 */
export const DEFAULT_WINDOW = { start: '2025-08-01', end: '2026-07-31' };

/**
 * The site. Read from data/tide.json at run time rather than typed in here, because that record is
 * the island reference site the solar system already uses and a second copy of a coordinate is a
 * second thing to keep true. Its own provenance says the coordinate came from OpenStreetMap through
 * the first build's places pack, and that provenance travels with it.
 */
export function readSite() {
  const pack = JSON.parse(readFileSync(path.join(ROOT, 'data', 'tide.json'), 'utf8'));
  const p = pack.port;
  return {
    id: p.id, name: p.name, lat: p.lat, lon: p.lon, crs: p.crs,
    source: p.source, locator: p.locator
  };
}

/**
 * The daily fields. Every one is a field the archive publishes for this window; nothing is computed
 * here that the API can be asked for directly.
 *
 * sunrise and sunset are asked for on purpose and are not used as data. They are the independent
 * witness against src/systems/solar.js, which implements the NOAA equations for this same site. Two
 * mechanisms, one answer, or the sun in this world is not yet checked against anything outside it.
 */
export const DAILY_FIELDS = [
  'temperature_2m_max', 'temperature_2m_min', 'temperature_2m_mean',
  'apparent_temperature_max', 'apparent_temperature_min',
  'precipitation_sum', 'rain_sum', 'precipitation_hours',
  'windspeed_10m_max', 'windgusts_10m_max', 'winddirection_10m_dominant',
  'shortwave_radiation_sum', 'et0_fao_evapotranspiration',
  'sunrise', 'sunset'
];

export const HOURLY_FIELDS = [
  'temperature_2m', 'relativehumidity_2m', 'precipitation',
  'windspeed_10m', 'winddirection_10m', 'pressure_msl', 'cloudcover'
];

/**
 * The models fetched, and why more than one.
 *
 * era5 is the 0.25 degree global reanalysis and is the lane the founding prompt names. era5_land is
 * published on a finer grid, so asking for both is a cheap test of whether the finer grid resolves
 * this island separately from the sea around it. The answer is printed rather than assumed: if both
 * resolve to the same cell centre, this is not an independent check and --summarise says so.
 */
export const MODELS = ['era5', 'era5_land'];

// ---------------------------------------------------------------------------------------------
// Island civil time. tools/ is not under the no-wallclock rule, but a receipt needs a date that
// means something, so the clock is read once and converted to UTC+10 rather than left as whatever
// the host thinks local time is.
// ---------------------------------------------------------------------------------------------

export function islandToday(nowMs = Date.now()) {
  return new Date(nowMs + 10 * 3600 * 1000).toISOString().slice(0, 10);
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex');
}

const rel = (p) => path.relative(ROOT, p).split(path.sep).join('/');

// ---------------------------------------------------------------------------------------------
// Fetch
// ---------------------------------------------------------------------------------------------

function url(params) {
  const q = new URLSearchParams(params);
  return ENDPOINT + '?' + q.toString();
}

async function fetchOne({ name, params, force }) {
  mkdirSync(RAW_DIR, { recursive: true });
  const day = islandToday();
  const rawPath = path.join(RAW_DIR, `${name}-${day}.json`);
  const receiptPath = path.join(RAW_DIR, `${name}-${day}.receipt.json`);

  if (existsSync(rawPath) && !force) {
    console.log(`already staged, not refetching: ${rel(rawPath)}`);
    console.log('pass --force to replace it. --summarise and --derive read this file and never fetch.');
    return { rawPath, refetched: false };
  }

  const u = url(params);
  console.log(`GET ${u}`);
  const startedAt = new Date().toISOString();
  const t0 = Date.now();
  let res, body;
  try {
    res = await fetch(u, { redirect: 'follow', headers: { 'User-Agent': AGENT } });
    body = Buffer.from(await res.arrayBuffer());
  } catch (err) {
    console.error(`FETCH FAILED: ${err.message}`);
    console.error('Nothing was written. Record the failure in docs/INGEST-STATUS.md as it happened.');
    process.exitCode = 1;
    return null;
  }
  const elapsedMs = Date.now() - t0;

  if (res.status !== 200) {
    console.error(`FETCH FAILED: HTTP ${res.status} after ${elapsedMs} ms`);
    console.error(body.toString('utf8').slice(0, 800));
    process.exitCode = 1;
    return null;
  }

  let parsed = null;
  try {
    parsed = JSON.parse(body.toString('utf8'));
  } catch (err) {
    console.error(`FETCH FAILED: response was not JSON: ${err.message}`);
    process.exitCode = 1;
    return null;
  }
  // Open-Meteo reports a bad request inside a 200 in some paths, so the body is checked and not
  // only the status line. A staged file that holds an error object is worse than no staged file.
  if (parsed.error) {
    console.error(`OPEN-METEO ERROR: ${parsed.reason || '(no reason given)'}`);
    console.error('Not staged.');
    process.exitCode = 1;
    return null;
  }

  writeFileSync(rawPath, body);
  const receipt = {
    tool: 'tools/ingest/weather.mjs --fetch',
    endpoint: ENDPOINT,
    url: u,
    requestedAt: startedAt,
    elapsedMs,
    httpStatus: res.status,
    bytes: body.length,
    sha256: sha256(body),
    requestedLat: Number(params.latitude),
    requestedLon: Number(params.longitude),
    answeredLat: parsed.latitude,
    answeredLon: parsed.longitude,
    answeredElevationM: parsed.elevation,
    utcOffsetSeconds: parsed.utc_offset_seconds,
    generationTimeMs: parsed.generationtime_ms,
    days: parsed.daily && parsed.daily.time ? parsed.daily.time.length : null,
    hours: parsed.hourly && parsed.hourly.time ? parsed.hourly.time.length : null,
    rawFile: rel(rawPath),
    licence: 'CC BY 4.0 per https://open-meteo.com/en/licence. Underlying reanalysis is Copernicus '
      + 'Climate Change Service material under the Licence to Use Copernicus Products. Not '
      + 'committable this wave: the blanket hold on derived packs, board note 007.'
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');

  console.log(`HTTP ${res.status}, ${body.length} bytes, ${elapsedMs} ms, `
    + `${receipt.days === null ? receipt.hours + ' hours' : receipt.days + ' days'}`);
  console.log(`sha256 ${receipt.sha256}`);
  console.log(`grid    requested ${receipt.requestedLat}, ${receipt.requestedLon} `
    + `-> answered ${receipt.answeredLat}, ${receipt.answeredLon}, elevation ${receipt.answeredElevationM} m`);
  console.log(`staged  ${receipt.rawFile}`);
  console.log(`receipt ${rel(receiptPath)}`);
  return { rawPath, refetched: true };
}

async function doFetch({ start, end, checkDay, force }) {
  const site = readSite();
  console.log(`site    ${site.name}, ${site.lat}, ${site.lon}, from data/tide.json port record`);
  console.log(`window  ${start} to ${end}, island civil dates`);
  console.log('');
  const common = {
    latitude: String(site.lat),
    longitude: String(site.lon),
    start_date: start,
    end_date: end,
    timezone: 'Australia/Brisbane'
  };
  for (const model of MODELS) {
    await fetchOne({
      name: `archive-daily-${model}`,
      params: { ...common, daily: DAILY_FIELDS.join(','), models: model },
      force
    });
    console.log('');
  }
  await fetchOne({
    name: 'archive-hourly-checkday',
    params: {
      latitude: String(site.lat), longitude: String(site.lon),
      start_date: checkDay, end_date: checkDay,
      timezone: 'Australia/Brisbane',
      hourly: HOURLY_FIELDS.join(','), models: 'era5'
    },
    force
  });
}

// ---------------------------------------------------------------------------------------------
// Reading the staged files
// ---------------------------------------------------------------------------------------------

export function newestRaw(prefix) {
  if (!existsSync(RAW_DIR)) return null;
  const files = readdirSync(RAW_DIR)
    .filter((f) => f.startsWith(prefix + '-') && f.endsWith('.json') && !f.endsWith('.receipt.json'))
    .sort();
  return files.length ? path.join(RAW_DIR, files[files.length - 1]) : null;
}

function loadRaw(prefix, { required = true } = {}) {
  const file = newestRaw(prefix);
  if (!file) {
    if (required) {
      console.error(`nothing staged for ${prefix} under ${rel(RAW_DIR)}/`);
      console.error('run: node tools/ingest/weather.mjs --fetch');
      process.exitCode = 1;
    }
    return null;
  }
  const bytes = readFileSync(file);
  return { file, bytes, doc: JSON.parse(bytes.toString('utf8')) };
}

// ---------------------------------------------------------------------------------------------
// Geometry and time, kept small
// ---------------------------------------------------------------------------------------------

const R_EARTH_M = 6371008.8;
const rad = (d) => (d * Math.PI) / 180;

export function haversineM(aLon, aLat, bLon, bLat) {
  const dLat = rad(bLat - aLat);
  const dLon = rad(bLon - aLon);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(rad(aLat)) * Math.cos(rad(bLat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R_EARTH_M * Math.asin(Math.min(1, Math.sqrt(s)));
}

/** Day of year, 1 based, for an island civil date. */
export function dayOfYear(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return daysFromCivil(y, m, d) - daysFromCivil(y, 1, 1) + 1;
}

/** "2026-01-01T05:45" as minutes from midnight island civil time, or null. */
export function minuteOfDay(isoLocal) {
  if (typeof isoLocal !== 'string') return null;
  const m = /T(\d{2}):(\d{2})/.exec(isoLocal);
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
}

const hhmm = (min) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(Math.round(min) % 60).padStart(2, '0')}`;

// ---------------------------------------------------------------------------------------------
// Summarise
// ---------------------------------------------------------------------------------------------

function series(doc, field) {
  return doc.daily && Array.isArray(doc.daily[field]) ? doc.daily[field] : null;
}

function extremes(times, values) {
  let hi = null, lo = null;
  for (let i = 0; i < times.length; i++) {
    const v = values[i];
    if (v === null || v === undefined || !Number.isFinite(v)) continue;
    if (hi === null || v > hi.value) hi = { date: times[i], value: v };
    if (lo === null || v < lo.value) lo = { date: times[i], value: v };
  }
  return { highest: hi, lowest: lo };
}

function sumOf(values) {
  let total = 0, counted = 0, missing = 0;
  for (const v of values) {
    if (v === null || v === undefined || !Number.isFinite(v)) { missing++; continue; }
    total += v; counted++;
  }
  return { total, counted, missing };
}

/**
 * The sun check. Open-Meteo returns a sunrise and a sunset for every day in the window, computed by
 * somebody else's code from the same geometry this repository implements in src/systems/solar.js.
 * Comparing them is the only external witness the solar system has ever had.
 *
 * The two are not expected to agree to the minute and it would be dishonest to present a threshold
 * as a pass mark. What is reported is the distribution of the difference, so a reader can see
 * whether it is a constant offset, which is a definition difference, or a drift, which is a defect.
 */
function sunCheck(doc, site) {
  const times = series(doc, 'time');
  const sunrise = series(doc, 'sunrise');
  const sunset = series(doc, 'sunset');
  if (!times || !sunrise || !sunset) return null;
  const solarSite = { ...SITE_DUNWICH, lat: site.lat, lon: site.lon };
  const rows = [];
  for (let i = 0; i < times.length; i++) {
    const apiRise = minuteOfDay(sunrise[i]);
    const apiSet = minuteOfDay(sunset[i]);
    if (apiRise === null || apiSet === null) continue;
    // The third argument is days in the year, 365 or 366, not the calendar year. Passing the
    // calendar year here silently produces sunrise times up to 78 minutes out, which is exactly
    // wrong enough to look like a finding about the solar system. It was one, briefly, until the
    // signature was read.
    const [y] = times[i].split('-').map(Number);
    const ev = sunEvents(solarSite, dayOfYear(times[i]), daysInYear(y));
    if (ev.sunriseMinute === null) continue;
    rows.push({
      date: times[i],
      riseDiffMin: ev.sunriseMinute - apiRise,
      setDiffMin: ev.sunsetMinute - apiSet,
      apiRise, apiSet,
      ourRise: ev.sunriseMinute, ourSet: ev.sunsetMinute
    });
  }
  if (!rows.length) return null;
  const stat = (key) => {
    const v = rows.map((r) => r[key]).sort((a, b) => a - b);
    return {
      min: Number(v[0].toFixed(2)),
      median: Number(v[Math.floor(v.length / 2)].toFixed(2)),
      max: Number(v[v.length - 1].toFixed(2))
    };
  };
  return {
    days: rows.length,
    sunriseDiffMinutes: stat('riseDiffMin'),
    sunsetDiffMinutes: stat('setDiffMin'),
    worstSunrise: rows.slice().sort((a, b) => Math.abs(b.riseDiffMin) - Math.abs(a.riseDiffMin))[0],
    note: 'Positive means this repository puts the event later than Open-Meteo does. Both use the '
      + 'same site coordinate and the same fixed UTC+10 offset. A constant offset is a definition '
      + 'difference about the refracted horizon; a drift across the year is not.'
  };
}

function summarise({ json, checkDay }) {
  const site = readSite();
  const primary = loadRaw('archive-daily-era5');
  if (!primary) return;
  const secondary = loadRaw('archive-daily-era5_land', { required: false });
  const hourly = loadRaw('archive-hourly-checkday', { required: false });

  const doc = primary.doc;
  const times = series(doc, 'time') || [];
  const tmax = series(doc, 'temperature_2m_max') || [];
  const tmin = series(doc, 'temperature_2m_min') || [];
  const rain = series(doc, 'precipitation_sum') || [];
  const gust = series(doc, 'windgusts_10m_max') || [];

  const gridOffsetM = haversineM(site.lon, site.lat, doc.longitude, doc.latitude);

  let missingDays = 0;
  for (const v of tmax) if (v === null || v === undefined) missingDays++;

  const rainTotal = sumOf(rain);
  const wetDays = rain.filter((v) => Number.isFinite(v) && v >= 1).length;
  const dryDays = rain.filter((v) => Number.isFinite(v) && v < 0.2).length;

  const checkIndex = times.indexOf(checkDay);
  const checkRow = checkIndex < 0 ? null : Object.fromEntries(
    DAILY_FIELDS.filter((f) => Array.isArray(doc.daily[f])).map((f) => [f, doc.daily[f][checkIndex]])
  );

  // The second model, compared field by field on the days both carry. If the two resolve to one
  // cell this is not an independent check and the summary must say so rather than imply otherwise.
  let modelCompare = null;
  if (secondary) {
    const s = secondary.doc;
    const sameCell = s.latitude === doc.latitude && s.longitude === doc.longitude;
    const st = series(s, 'time') || [];
    const smax = series(s, 'temperature_2m_max') || [];
    let compared = 0, identical = 0, biggest = null;
    for (let i = 0; i < times.length; i++) {
      const j = st.indexOf(times[i]);
      if (j < 0) continue;
      const a = tmax[i], b = smax[j];
      if (!Number.isFinite(a) || !Number.isFinite(b)) continue;
      compared++;
      const d = Math.abs(a - b);
      if (d === 0) identical++;
      if (biggest === null || d > biggest.diff) biggest = { date: times[i], era5: a, era5Land: b, diff: Number(d.toFixed(3)) };
    }
    // The reading is decided by whether the numbers differ, not by whether the reported cell
    // centre differs. Those are two different questions and the API answered them differently:
    // it named the same cell centre for both models and returned different values.
    const differs = compared > 0 && identical < compared;
    modelCompare = {
      secondModel: 'era5_land',
      answeredCell: { lat: s.latitude, lon: s.longitude },
      reportsTheSameCellCentre: sameCell,
      valuesDiffer: differs,
      daysCompared: compared,
      daysIdenticalOnTmax: identical,
      biggestTmaxDifference: biggest,
      reading: differs
        ? 'The API reports the same cell centre for both models and returns different values, so the '
          + 'coordinate it echoes back is not a full description of what was sampled. The spread '
          + 'below is between two reanalyses of the same place and is the closest thing this lane '
          + 'has to an error bar on a daily figure. It is not a check against an observation: '
          + 'neither model is one.'
        : 'Every compared value is identical, so this is one number fetched twice and not a second '
          + 'opinion. The absence of an independent check is a fact about this lane rather than a '
          + 'thing to leave unstated.'
    };
  }

  const result = {
    site,
    licence: LICENCE,
    rawFiles: {
      era5: rel(primary.file),
      era5_land: secondary ? rel(secondary.file) : null,
      hourlyCheckDay: hourly ? rel(hourly.file) : null
    },
    sha256: { era5: sha256(primary.bytes) },
    grid: {
      requested: { lat: site.lat, lon: site.lon },
      answered: { lat: doc.latitude, lon: doc.longitude },
      answeredElevationM: doc.elevation,
      offsetKm: Number((gridOffsetM / 1000).toFixed(2)),
      note: 'ERA5 is published on a 0.25 degree grid. The figure is for the cell, not for the '
        + 'township, and a cell at this latitude is about 25 km across.'
    },
    window: { start: times[0] || null, end: times[times.length - 1] || null, days: times.length, daysWithNoValue: missingDays },
    temperature: {
      maxC: extremes(times, tmax),
      minC: extremes(times, tmin),
      unit: doc.daily_units ? doc.daily_units.temperature_2m_max : null
    },
    precipitation: {
      totalMm: Number(rainTotal.total.toFixed(1)),
      daysCounted: rainTotal.counted,
      daysMissing: rainTotal.missing,
      wettestDay: extremes(times, rain).highest,
      daysAtOrAbove1mm: wetDays,
      daysBelow02mm: dryDays,
      unit: doc.daily_units ? doc.daily_units.precipitation_sum : null
    },
    wind: { strongestGust: extremes(times, gust).highest, unit: doc.daily_units ? doc.daily_units.windgusts_10m_max : null },
    checkDay: { date: checkDay, present: checkIndex >= 0, values: checkRow },
    checkDayHourly: hourly ? hourlySummary(hourly.doc) : null,
    modelCompare,
    sunCheck: sunCheck(doc, site)
  };

  if (json) { console.log(JSON.stringify(result, null, 2)); return result; }

  const say = (s) => console.log(s);
  say(`raw     ${result.rawFiles.era5}`);
  say(`bytes   ${primary.bytes.length}, sha256 ${result.sha256.era5}`);
  say(`site    ${site.name}, requested ${site.lat}, ${site.lon}`);
  say(`grid    answered ${result.grid.answered.lat}, ${result.grid.answered.lon}, `
    + `elevation ${result.grid.answeredElevationM} m, ${result.grid.offsetKm} km from the requested point`);
  say('');
  say(`WINDOW     ${result.window.start} to ${result.window.end}, ${result.window.days} days, `
    + `${result.window.daysWithNoValue} with no value`);
  say('');
  say('TEMPERATURE');
  say(`  hottest day      ${result.temperature.maxC.highest.value} ${result.temperature.unit} on ${result.temperature.maxC.highest.date}`);
  say(`  coldest night    ${result.temperature.minC.lowest.value} ${result.temperature.unit} on ${result.temperature.minC.lowest.date}`);
  say('');
  say('RAIN');
  say(`  year total       ${result.precipitation.totalMm} ${result.precipitation.unit} over ${result.precipitation.daysCounted} days`);
  say(`  wettest day      ${result.precipitation.wettestDay.value} ${result.precipitation.unit} on ${result.precipitation.wettestDay.date}`);
  say(`  days 1 mm or more ${result.precipitation.daysAtOrAbove1mm}, days under 0.2 mm ${result.precipitation.daysBelow02mm}`);
  say('');
  say('WIND');
  say(`  strongest gust   ${result.wind.strongestGust.value} ${result.wind.unit} on ${result.wind.strongestGust.date}`);
  say('');
  say(`CHECK DAY  ${checkDay}${result.checkDay.present ? '' : '  NOT IN THE STAGED WINDOW'}`);
  if (result.checkDay.values) {
    for (const [k, v] of Object.entries(result.checkDay.values)) {
      const unit = doc.daily_units && doc.daily_units[k] ? ' ' + doc.daily_units[k] : '';
      say(`  ${k.padEnd(28)} ${v}${/sunrise|sunset/.test(k) ? '' : unit}`);
    }
  }
  if (result.checkDayHourly) {
    say(`  hourly: ${result.checkDayHourly.hours} hours staged, `
      + `air temperature ${result.checkDayHourly.tempMin} to ${result.checkDayHourly.tempMax} degC, `
      + `rain total ${result.checkDayHourly.rainMm} mm`);
    say(`  midday reading: ${JSON.stringify(result.checkDayHourly.midday)}`);
  }
  say('');
  if (modelCompare) {
    say('SECOND MODEL, era5_land');
    say(`  answered cell ${modelCompare.answeredCell.lat}, ${modelCompare.answeredCell.lon}, `
      + `same cell centre reported as era5: ${modelCompare.reportsTheSameCellCentre}`);
    say(`  ${modelCompare.daysCompared} days compared on daily maximum temperature, `
      + `${modelCompare.daysIdenticalOnTmax} identical to the digit`);
    if (modelCompare.biggestTmaxDifference) {
      const b = modelCompare.biggestTmaxDifference;
      say(`  biggest difference ${b.diff} degC on ${b.date}: era5 ${b.era5}, era5_land ${b.era5Land}`);
    }
    say(`  ${modelCompare.reading}`);
    say('');
  }
  if (result.sunCheck) {
    const s = result.sunCheck;
    say('SUN CHECK, this repository against Open-Meteo, same site, same offset');
    say(`  ${s.days} days compared`);
    say(`  sunrise difference  min ${s.sunriseDiffMinutes.min}, median ${s.sunriseDiffMinutes.median}, max ${s.sunriseDiffMinutes.max} minutes`);
    say(`  sunset  difference  min ${s.sunsetDiffMinutes.min}, median ${s.sunsetDiffMinutes.median}, max ${s.sunsetDiffMinutes.max} minutes`);
    say(`  worst sunrise day ${s.worstSunrise.date}: ours ${hhmm(s.worstSunrise.ourRise)}, Open-Meteo ${hhmm(s.worstSunrise.apiRise)}`);
    say(`  ${s.note}`);
    say('');
  }
  say('ATTRIBUTION REQUIRED BY THE LICENCE');
  for (const line of LICENCE.attributionLines) say('  ' + line);
  return result;
}

function hourlySummary(doc) {
  const t = doc.hourly && doc.hourly.time ? doc.hourly.time : [];
  const temp = doc.hourly && doc.hourly.temperature_2m ? doc.hourly.temperature_2m : [];
  const rain = doc.hourly && doc.hourly.precipitation ? doc.hourly.precipitation : [];
  const finite = temp.filter((v) => Number.isFinite(v));
  const i12 = t.findIndex((x) => x.endsWith('T12:00'));
  return {
    hours: t.length,
    tempMin: finite.length ? Math.min(...finite) : null,
    tempMax: finite.length ? Math.max(...finite) : null,
    rainMm: Number(rain.filter((v) => Number.isFinite(v)).reduce((a, b) => a + b, 0).toFixed(2)),
    midday: i12 < 0 ? null : Object.fromEntries(
      HOURLY_FIELDS.filter((f) => Array.isArray(doc.hourly[f])).map((f) => [f, doc.hourly[f][i12]])
    )
  };
}

// ---------------------------------------------------------------------------------------------
// Licence, carried as data so it travels inside every pack
// ---------------------------------------------------------------------------------------------

export const LICENCE = {
  id: 'CC-BY-4.0',
  name: 'Creative Commons Attribution 4.0 International',
  statedAt: 'https://open-meteo.com/en/licence',
  readOn: '2026-08-19',
  attributionLines: [
    'Weather data by Open-Meteo.com, licensed CC BY 4.0, https://open-meteo.com/en/licence',
    'Reanalysis: ERA5 from the Copernicus Climate Change Service, under the Licence to Use',
    '  Copernicus Products, https://climate.copernicus.eu',
    'The licence page requires a link next to any location the data are displayed, and requires',
    '  that changes be indicated. Every figure in a derived pack here is aggregated or compared,',
    '  so "changes were made" is true of it and must be said on screen when it is shown.'
  ],
  obligationsNotYetMet: 'No player facing surface exists in this repository, so the display link '
    + 'obligation cannot be met yet. It is recorded here and in docs/INGEST-STATUS.md so that the '
    + 'first panel that shows a weather figure carries it.'
};

// ---------------------------------------------------------------------------------------------
// Derive
// ---------------------------------------------------------------------------------------------

/**
 * One derived record's provenance. The eight fields are not decoration.
 *
 *   source        open-meteo-archive, an id in data/_sources.json
 *   locator       the exact request and the day inside it. One step to check: paste the URL.
 *   validFrom     the island civil date the weather was true of, which for a daily record is the
 *                 day itself, and validTo is the day after, because a daily aggregate stops being
 *                 true of the island at midnight and a null validTo would say it never stopped.
 *   recordedAt    the date this lane fetched it.
 *   confidence    medium. It is a reanalysis of a 25 km cell, not a reading from a gauge on this
 *                 island. No station observation has been obtained to check it against.
 *   register      modelled. This is the field that stops a reanalysis being read as an observation.
 */
function provenance(day, requestUrl, today) {
  const [y, m, d] = day.split('-').map(Number);
  const next = civilFromDays(daysFromCivil(y, m, d) + 1);
  const nextIso = `${String(next.year).padStart(4, '0')}-${String(next.month).padStart(2, '0')}-${String(next.day).padStart(2, '0')}`;
  return {
    source: SOURCE_ID,
    locator: `daily record for ${day} in ${requestUrl}`,
    validFrom: day,
    validTo: nextIso,
    recordedAt: today,
    recordedUntil: null,
    confidence: 'medium',
    register: 'modelled'
  };
}

function derive({ json, checkDay }) {
  const site = readSite();
  const primary = loadRaw('archive-daily-era5');
  if (!primary) return;
  const doc = primary.doc;
  const today = islandToday();
  const times = series(doc, 'time') || [];
  const receipt = (() => {
    const p = primary.file.replace(/\.json$/, '.receipt.json');
    try { return JSON.parse(readFileSync(p, 'utf8')); } catch { return null; }
  })();
  const requestUrl = receipt ? receipt.url : ENDPOINT + ' (receipt not staged, URL unknown)';

  const days = [];
  for (let i = 0; i < times.length; i++) {
    const rec = { id: `weather-era5-${times[i]}`, kind: 'daily-weather', date: times[i] };
    for (const f of DAILY_FIELDS) {
      if (!Array.isArray(doc.daily[f])) continue;
      if (f === 'sunrise' || f === 'sunset') continue;
      rec[f] = doc.daily[f][i];
    }
    rec.gridLat = doc.latitude;
    rec.gridLon = doc.longitude;
    rec.gridElevationM = doc.elevation;
    rec.model = 'era5';
    Object.assign(rec, provenance(times[i], requestUrl, today));
    days.push(rec);
  }

  const about = 'One year of ERA5 daily reanalysis for the grid cell containing the Dunwich '
    + 'coordinate, which is this build\'s island reference site. NOT COMMITTABLE: it lives under '
    + 'ingest-inbox/, which .gitignore seals and tools/gate/sealed.mjs proves sealed by asking git. '
    + 'Every record carries register "modelled" because a reanalysis is a model run over assimilated '
    + 'observations and is not an observation of this island. The nearest observation rung is the '
    + 'Bureau of Meteorology registered data service, which this repository has not registered for. '
    + 'The figures are for a grid cell about 25 km across, not for a township, and a panel that '
    + 'shows one without saying so is making a claim this pack does not support.';

  const pack = {
    pack: 'weather-era5-daily',
    version: '0.1.0',
    about,
    attribution: LICENCE.attributionLines.join(' '),
    licence: LICENCE,
    site,
    grid: { lat: doc.latitude, lon: doc.longitude, elevationM: doc.elevation, resolutionDeg: 0.25 },
    units: doc.daily_units || null,
    requestUrl,
    rawFile: rel(primary.file),
    rawSha256: sha256(primary.bytes),
    checkDay,
    count: days.length,
    days
  };

  let sourceIds = null;
  try {
    sourceIds = new Set(Object.keys(JSON.parse(readFileSync(path.join(ROOT, 'data', '_sources.json'), 'utf8'))));
  } catch (err) {
    console.error(`could not read data/_sources.json: ${err.message}`);
  }
  const problems = [];
  for (const rec of days) {
    for (const p of checkRecord(rec, sourceIds ? { sourceIds, where: rec.id } : { where: rec.id })) problems.push(p);
  }

  mkdirSync(DERIVED_DIR, { recursive: true });
  const abs = path.join(DERIVED_DIR, `weather-era5-daily-${today}.json`);
  writeFileSync(abs, JSON.stringify(pack, null, 1) + '\n');

  const result = {
    written: rel(abs),
    bytes: statSync(abs).size,
    records: days.length,
    sourceIdsRead: sourceIds ? sourceIds.size : 0,
    provenanceProblems: problems
  };
  if (json) console.log(JSON.stringify(result, null, 2));
  else {
    console.log(`wrote ${result.written}  ${result.records} records, ${result.bytes} bytes`);
    console.log(`checked ${result.records} records with src/kernel/record.js against ${result.sourceIdsRead} source ids`);
    console.log(problems.length ? `PROVENANCE PROBLEMS: ${problems.length}` : 'provenance: 0 problems');
    for (const p of problems.slice(0, 20)) console.log('  ' + p);
    console.log('NOT COMMITTABLE: ingest-inbox/ is sealed and stays sealed this wave.');
  }
  if (problems.length) process.exitCode = 1;
  return result;
}

// ---------------------------------------------------------------------------------------------

const USAGE = `node tools/ingest/weather.mjs <mode>

  --fetch        one bounded window of ERA5 daily reanalysis for the island reference site, two
                 models, plus one day of hourly values. Staged raw with a receipt
  --summarise    the staged year: extremes, totals, the check day, the second model and the sun
                 check against src/systems/solar.js. No network
  --derive       a provenanced pack into ingest-inbox/derived/. No network

  --start DATE   window start, island civil date. Default ${DEFAULT_WINDOW.start}
  --end DATE     window end, island civil date. Default ${DEFAULT_WINDOW.end}
  --check DATE   the day whose values are printed in full. Default ${DEFAULT_WINDOW.end}
  --force        allow --fetch to replace a raw file already staged for today
  --json         machine readable output for --summarise and --derive

Nothing this tool writes is committable. ingest-inbox/ is sealed: board note 007.
`;

async function main(argv) {
  const has = (f) => argv.includes(f);
  const val = (f, dflt) => {
    const i = argv.indexOf(f);
    return i >= 0 && argv[i + 1] ? argv[i + 1] : dflt;
  };
  if (!argv.length || has('--help') || has('-h')) { console.log(USAGE); return; }

  const json = has('--json');
  const force = has('--force');
  const start = val('--start', DEFAULT_WINDOW.start);
  const end = val('--end', DEFAULT_WINDOW.end);
  const checkDay = val('--check', end);

  if (has('--fetch')) { await doFetch({ start, end, checkDay, force }); return; }
  if (has('--summarise') || has('--summarize')) { summarise({ json, checkDay }); return; }
  if (has('--derive')) { derive({ json, checkDay }); return; }

  console.error(`unknown mode: ${argv.join(' ')}`);
  console.error(USAGE);
  process.exitCode = 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2));
}

export { summarise, derive };
