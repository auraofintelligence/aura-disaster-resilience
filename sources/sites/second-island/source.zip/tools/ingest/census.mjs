#!/usr/bin/env node
// ABS Census 2021 DataPacks: the people lane, at SA1 and not only at the island SA2.
//
//     node tools/ingest/census.mjs --fetch        the Queensland DataPacks, staged with receipts
//     node tools/ingest/census.mjs --summarise    the island SA2, its SA1s and the townships
//     node tools/ingest/census.mjs --derive       a provenanced pack into ingest-inbox/derived/
//     node tools/ingest/census.mjs --fetch --geography SA1
//     node tools/ingest/census.mjs --summarise --json
//
// THE QUESTION THIS LANE WAS SENT TO ANSWER. The founding prompt, section 5: "ABS Census DataPacks
// at SA1 level for the three townships, not just the island SA2." The reason is that one island
// figure hides the thing the twin is for. Dunwich, Amity Point and Point Lookout are three
// settlements with different ages, different tenure and different distances from the barge, and a
// single number for the island cannot answer a question about any of them.
//
// WHAT WAS FOUND, STATED HERE SO THE NEXT AGENT DOES NOT HAVE TO RE-RUN IT TO KNOW.
//   1. The SA1 pack IS reachable with no account, no key and no login. HTTP 200, 80,450,253 bytes.
//   2. The island is SA2 301021550, and it holds eight SA1s.
//   3. SA1s have no names. The ASGS gives them codes only, so the DataPack alone cannot say which
//      SA1 covers which township. That is a real loss and it is not the loss the founding prompt
//      was worried about, so it is stated separately rather than folded into a summary.
//   4. Suburbs and Localities, the SAL geography, DOES carry the three townships by name, so the
//      township question the founding prompt actually asked has an answer at a named geography.
//      The SAL pack is fetched beside the SA1 pack for that reason and neither replaces the other:
//      SA1 is finer, SAL is named, and both are coarser than a person.
//
// PERTURBATION, WHICH IS NOT AN ERROR. The ABS randomly adjusts small counts so that a person
// cannot be identified from a table. The consequence is that parts do not sum to their whole, and
// the difference is a property of the published data rather than a defect in this reader. This tool
// measures that difference rather than describing it: --summarise prints the sum of the eight SA1
// counts beside the SA2 count for the same population.
//
// NOTHING DERIVED IS COMMITTED THIS WAVE. Everything written lands under ingest-inbox/, which
// .gitignore seals and tools/gate/sealed.mjs proves sealed by asking git. The licence here is CC BY
// 4.0, which is not what blocks this lane; the blanket hold on derived packs is, and it lifts when
// the owner settles board note 007.
//
// This file may read a wall clock. The ban in gate/no-wallclock covers src/kernel, src/systems and
// src/world. The date a file was downloaded is not world state, it is the receipt.

import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { openZip } from '../zip.mjs';
import { checkRecord } from '../../src/kernel/record.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const INBOX = path.join(ROOT, 'ingest-inbox');
const RAW_DIR = path.join(INBOX, 'census');
const DERIVED_DIR = path.join(INBOX, 'derived');

const AGENT = 'second-island/0.1 ingest connector (Minjerribah twin)';
const SOURCE_ID = 'abs-census-2021-datapacks';
const BASE = 'https://www.abs.gov.au/census/find-census-data/datapacks/download/';

/**
 * The three geographies, each with the reason it is here.
 *
 * They are three answers to one question at three grains, and the point of fetching all three is
 * that the differences between them are the finding. A lane that fetched only SA2 would have
 * reported the island figure the founding prompt named as the failure.
 */
export const PACKS = {
  SA1: {
    file: '2021_GCP_SA1_for_QLD_short-header.zip',
    why: 'Statistical Area 1, the finest geography the DataPacks publish. What the founding prompt '
      + 'asked for. Codes only: an SA1 has no name.'
  },
  SA2: {
    file: '2021_GCP_SA2_for_QLD_short-header.zip',
    why: 'Statistical Area 2. One area covers this whole island, which is the figure the founding '
      + 'prompt says hides what the twin is for. Fetched so the hiding can be measured rather than '
      + 'asserted.'
  },
  SAL: {
    file: '2021_GCP_SAL_for_QLD_short-header.zip',
    why: 'Suburbs and Localities. This is the geography that carries Dunwich, Amity Point and Point '
      + 'Lookout by name, so it is the one that answers the township question the SA1 codes cannot.'
  }
};

export const DEFAULT_GEOGRAPHIES = ['SA1', 'SA2', 'SAL'];

/**
 * The island, in the ABS's own words. Found by searching the geography descriptor shipped inside
 * the DataPack rather than typed in from anywhere else, and re-found on every run: SA2_NAME is what
 * this tool matches on, and the code below is what it expects to find, so a change at either end is
 * a loud failure rather than a quiet one.
 */
export const ISLAND_SA2 = { code: '301021550', name: 'North Stradbroke Island' };

/**
 * The three townships, and the one place this file has to be careful about a name.
 *
 * The ABS calls the locality at the north-west point "Amity". The founding prompt, the island's
 * signage and OpenStreetMap's village node all call the settlement "Amity Point", and
 * OpenStreetMap's locality polygon calls it "Amity", which is the same split. Two independent
 * sources naming the locality one thing and the settlement another is a finding rather than a
 * nuisance, so the mapping is written out here and neither name is quietly rewritten into the
 * other. The ABS name is what a row is matched on, because the ABS is the publisher; the township
 * name is what the founding prompt asks for.
 *
 * A search on "Amity Point" returns nothing from this pack, which is how the split was found.
 */
export const TOWNSHIPS = [
  { township: 'Dunwich', salName: 'Dunwich' },
  { township: 'Amity Point', salName: 'Amity' },
  { township: 'Point Lookout', salName: 'Point Lookout' }
];

/**
 * The rest of the island is itself a named locality, so the four SALs together are the island and
 * the townships are not a sample of it. Fetched so the reconciliation can be complete rather than
 * partial: three townships and a remainder, not three townships and a gap.
 */
export const ISLAND_REMAINDER_SAL = 'North Stradbroke Island';

/** Fields taken from the two summary tables. Named, so nothing arrives by accident. */
export const G01_FIELDS = [
  'Tot_P_M', 'Tot_P_F', 'Tot_P_P',
  'Age_0_4_yr_P', 'Age_5_14_yr_P', 'Age_15_19_yr_P', 'Age_20_24_yr_P', 'Age_25_34_yr_P',
  'Age_35_44_yr_P', 'Age_45_54_yr_P', 'Age_55_64_yr_P', 'Age_65_74_yr_P', 'Age_75_84_yr_P',
  'Age_85ov_P',
  'Indigenous_P_Tot_P', 'Birthplace_Australia_P', 'Australian_citizen_P',
  'High_yr_schl_comp_Yr_12_eq_P',
  'Count_psns_occ_priv_dwgs_P', 'Count_Persons_other_dwgs_P'
];

export const G02_FIELDS = [
  'Median_age_persons', 'Median_mortgage_repay_monthly', 'Median_tot_prsnl_inc_weekly',
  'Median_rent_weekly', 'Median_tot_fam_inc_weekly', 'Average_num_psns_per_bedroom',
  'Median_tot_hhd_inc_weekly', 'Average_household_size'
];

// ---------------------------------------------------------------------------------------------

export function islandToday(nowMs = Date.now()) {
  return new Date(nowMs + 10 * 3600 * 1000).toISOString().slice(0, 10);
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex');
}

const rel = (p) => path.relative(ROOT, p).split(path.sep).join('/');

// ---------------------------------------------------------------------------------------------
// Fetch
// ---------------------------------------------------------------------------------------------

async function fetchOne(geo, force) {
  const spec = PACKS[geo];
  mkdirSync(RAW_DIR, { recursive: true });
  const dest = path.join(RAW_DIR, spec.file);
  const receiptPath = path.join(RAW_DIR, spec.file.replace(/\.zip$/, '.receipt.json'));
  const u = BASE + spec.file;

  if (existsSync(dest) && !force) {
    console.log(`already staged, not refetching: ${rel(dest)}  (${statSync(dest).size} bytes)`);
    return { dest, refetched: false };
  }

  console.log(`GET ${u}`);
  const startedAt = new Date().toISOString();
  const t0 = Date.now();
  let res, body;
  try {
    res = await fetch(u, { redirect: 'follow', headers: { 'User-Agent': AGENT } });
    body = Buffer.from(await res.arrayBuffer());
  } catch (err) {
    console.error(`FETCH FAILED: ${err.message}`);
    console.error('Nothing was written. Record the failure in docs/INGEST-STATUS.md as it happened.');
    process.exitCode = 1;
    return null;
  }
  const elapsedMs = Date.now() - t0;

  if (res.status !== 200) {
    console.error(`FETCH FAILED: HTTP ${res.status} after ${elapsedMs} ms`);
    console.error(body.toString('utf8').slice(0, 400));
    process.exitCode = 1;
    return null;
  }
  // A login wall answers 200 with HTML. The magic bytes are what says this is a zip.
  if (!(body[0] === 0x50 && body[1] === 0x4b)) {
    console.error('FETCH FAILED: the response is not a zip. First bytes: '
      + body.slice(0, 16).toString('hex'));
    console.error('An account wall usually answers 200 with HTML, so status alone does not prove a download.');
    process.exitCode = 1;
    return null;
  }

  writeFileSync(dest, body);
  const zip = openZip(body);
  const receipt = {
    tool: 'tools/ingest/census.mjs --fetch',
    geography: geo,
    url: u,
    requestedAt: startedAt,
    elapsedMs,
    httpStatus: res.status,
    bytes: body.length,
    sha256: sha256(body),
    zipEntries: zip.names().length,
    accountRequired: false,
    accountNote: 'No account, no key, no cookie and no referer were sent. The request carried a '
      + 'User-Agent and nothing else.',
    rawFile: rel(dest),
    licence: 'CC BY 4.0, stated in Readme/CreativeCommons_Licensing_readme.txt inside this zip. '
      + 'Derived material must be attributed "Based on Australian Bureau of Statistics data".'
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');

  console.log(`HTTP ${res.status}, ${body.length} bytes, ${elapsedMs} ms, ${receipt.zipEntries} zip entries`);
  console.log(`sha256 ${receipt.sha256}`);
  console.log(`staged  ${receipt.rawFile}`);
  console.log(`receipt ${rel(receiptPath)}`);
  return { dest, refetched: true };
}

// ---------------------------------------------------------------------------------------------
// A very small xlsx reader, because the geography names are only published in a spreadsheet
// ---------------------------------------------------------------------------------------------

/**
 * Read one sheet of an xlsx as rows of strings.
 *
 * An xlsx is a zip of XML, so tools/zip.mjs already does the hard half. What is left is two files:
 * xl/sharedStrings.xml, where every distinct string in the workbook is stored once, and the sheet
 * itself, where a cell either holds a number inline or an index into that table. This reader
 * handles those two cases and nothing else, which is all the ABS descriptor uses. It is deliberately
 * not a spreadsheet library: formulas, dates, styles and inline strings are out of scope and a cell
 * this reader cannot understand comes back as its raw value rather than as a guess.
 */
export function readXlsxSheet(xlsxBuffer, sheetPath) {
  const x = openZip(xlsxBuffer);
  const shared = [];
  if (x.names().includes('xl/sharedStrings.xml')) {
    const s = x.text('xl/sharedStrings.xml');
    for (const m of s.matchAll(/<si>([\s\S]*?)<\/si>/g)) {
      const parts = [...m[1].matchAll(/<t[^>]*>([\s\S]*?)<\/t>/g)].map((p) => p[1]);
      shared.push(unescapeXml(parts.join('')));
    }
  }
  const sheet = x.text(sheetPath);
  const rows = [];
  for (const r of sheet.matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
    const cells = [];
    for (const c of r[1].matchAll(/<c[^>]*?r="([A-Z]+)\d+"([^>]*)>([\s\S]*?)<\/c>/g)) {
      const v = (/<v>([\s\S]*?)<\/v>/.exec(c[3]) || [, ''])[1];
      cells.push(/t="s"/.test(c[2]) ? shared[Number(v)] : unescapeXml(v));
    }
    rows.push(cells);
  }
  return rows;
}

function unescapeXml(s) {
  return s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'");
}

/** The workbook's sheets, as {name, path}, in the order the workbook declares them. */
export function xlsxSheets(xlsxBuffer) {
  const x = openZip(xlsxBuffer);
  const rels = new Map();
  if (x.names().includes('xl/_rels/workbook.xml.rels')) {
    for (const m of x.text('xl/_rels/workbook.xml.rels').matchAll(/Id="([^"]+)"[^>]*Target="([^"]+)"/g)) {
      rels.set(m[1], 'xl/' + m[2].replace(/^\.\//, ''));
    }
  }
  const out = [];
  for (const m of x.text('xl/workbook.xml').matchAll(/<sheet name="([^"]+)"[^>]*r:id="([^"]+)"/g)) {
    const p = rels.get(m[2]);
    if (p) out.push({ name: unescapeXml(m[1]), path: p });
  }
  return out;
}

/**
 * Every geography in the descriptor, as {sheet, structure, code, name, areaSqKm}.
 *
 * EVERY sheet, not the first one. The descriptor splits the ASGS across seven sheets and the main
 * structures sheet holds SA1 to SA4 and nothing else. Suburbs and Localities live on the non-ABS
 * structures sheet, so a reader that opened sheet one and stopped would report that this island has
 * no townships, which is what this reader did on its first run. The sheet a row came from is kept
 * on the row, because it is half of the locator that lets somebody check the value.
 *
 * The descriptor's own header row names the columns, and this reader finds them by name rather than
 * by position, so a column added upstream moves nothing here.
 */
export function readGeographies(zipBuffer) {
  const z = openZip(zipBuffer);
  const name = z.names().find((n) => /Metadata\/.*geog_desc.*\.xlsx$/i.test(n));
  if (!name) return { file: null, sheets: [], rows: [] };
  const xlsx = z.read(name);
  const sheets = xlsxSheets(xlsx);
  const out = [];
  let header = null;
  for (const sheet of sheets) {
    const rows = readXlsxSheet(xlsx, sheet.path);
    if (!rows.length) continue;
    const head = rows[0].map((h) => String(h).trim());
    const iStruct = head.findIndex((h) => /ASGS_Structure/i.test(h));
    const iCode = head.findIndex((h) => /Census_Code/i.test(h));
    const iName = head.findIndex((h) => /Census_Name/i.test(h));
    const iArea = head.findIndex((h) => /Area/i.test(h));
    if (iStruct < 0 || iCode < 0 || iName < 0) continue;
    header = head;
    for (let i = 1; i < rows.length; i++) {
      const r = rows[i];
      if (!r.length) continue;
      out.push({
        sheet: sheet.name,
        structure: r[iStruct],
        code: String(r[iCode]),
        name: String(r[iName]),
        areaSqKm: iArea >= 0 && r[iArea] !== undefined ? Number(r[iArea]) : null
      });
    }
  }
  return { file: name, sheets: sheets.map((s) => s.name), header, rows: out };
}

// ---------------------------------------------------------------------------------------------
// CSV, the DataPack's own format
// ---------------------------------------------------------------------------------------------

/**
 * A DataPack CSV as a Map from the first column's value to a row object.
 *
 * The DataPacks are plain comma separated with no quoted fields in the tables this lane reads, so
 * the parser is a split. It checks that assumption instead of relying on it: a line whose field
 * count differs from the header's is reported rather than silently reshaped.
 */
export function readTable(zip, entryName) {
  const text = zip.text(entryName);
  const lines = text.split(/\r?\n/).filter((l) => l.length);
  const header = lines[0].split(',');
  const rows = new Map();
  const ragged = [];
  for (let i = 1; i < lines.length; i++) {
    const parts = lines[i].split(',');
    if (parts.length !== header.length) { ragged.push(i + 1); continue; }
    const o = {};
    for (let j = 0; j < header.length; j++) o[header[j]] = parts[j];
    rows.set(parts[0], o);
  }
  return { header, rows, ragged, keyColumn: header[0] };
}

function openPack(geo) {
  const p = path.join(RAW_DIR, PACKS[geo].file);
  if (!existsSync(p)) return null;
  const bytes = readFileSync(p);
  const zip = openZip(bytes);
  const g01 = zip.names().find((n) => new RegExp(`2021Census_G01_QLD_${geo}\\.csv$`).test(n));
  const g02 = zip.names().find((n) => new RegExp(`2021Census_G02_QLD_${geo}\\.csv$`).test(n));
  return { path: p, bytes, zip, g01, g02 };
}

const num = (v) => (v === undefined || v === '' ? null : Number(v));

function pick(row, fields) {
  const o = {};
  for (const f of fields) o[f] = row ? num(row[f]) : null;
  return o;
}

// ---------------------------------------------------------------------------------------------
// Summarise
// ---------------------------------------------------------------------------------------------

function summarise({ json, silent = false }) {
  const sa1 = openPack('SA1');
  const sa2 = openPack('SA2');
  const sal = openPack('SAL');
  if (!sa2) {
    console.error(`nothing staged under ${rel(RAW_DIR)}/`);
    console.error('run: node tools/ingest/census.mjs --fetch');
    process.exitCode = 1;
    return null;
  }

  const geo = readGeographies(sa2.bytes);
  const sa2Row = geo.rows.find((r) => r.structure === 'SA2' && r.name === ISLAND_SA2.name);
  const sa3Row = sa2Row ? geo.rows.find((r) => r.structure === 'SA3' && sa2Row.code.startsWith(r.code)) : null;

  // The SA1s of an SA2, by the ASGS rule that an SA1 code is its SA2's nine digits plus two more.
  // The rule is checked rather than trusted: the eight areas must sum to the SA2's own area, and
  // when they do not the summary says so instead of printing a list that looks right.
  const sa1Rows = sa2Row
    ? geo.rows.filter((r) => r.structure === 'SA1' && r.code.startsWith(sa2Row.code)).sort((a, b) => (a.code < b.code ? -1 : 1))
    : [];
  const areaSum = sa1Rows.reduce((a, r) => a + (r.areaSqKm || 0), 0);
  const areaAgrees = sa2Row ? Math.abs(areaSum - sa2Row.areaSqKm) < 0.001 : false;

  // The descriptor is national and the CSV tables are Queensland only, so a locality name that
  // exists in two states matches twice here and only one of the two is on this island. Membership
  // of the Queensland table is what decides it, and a name that matches more than one Queensland
  // row is reported rather than resolved by taking the first.
  const salTableCodes = sal ? new Set(readTable(sal.zip, sal.g01).rows.keys()) : new Set();
  const wantedSals = [
    ...TOWNSHIPS.map((t) => ({ township: t.township, salName: t.salName, role: 'township' })),
    { township: ISLAND_REMAINDER_SAL, salName: ISLAND_REMAINDER_SAL, role: 'remainder' }
  ];
  const salRows = wantedSals.map((w) => {
    const all = geo.rows.filter((r) => r.structure === 'SAL' && r.name === w.salName);
    const inQueensland = all.filter((r) => salTableCodes.has(r.code));
    return { ...w, matchesNationally: all.length, matches: inQueensland };
  });

  const readGeo = (pack, code) => {
    if (!pack) return null;
    const t1 = readTable(pack.zip, pack.g01);
    const t2 = readTable(pack.zip, pack.g02);
    return {
      g01: pick(t1.rows.get(code), G01_FIELDS),
      g02: pick(t2.rows.get(code), G02_FIELDS),
      present: t1.rows.has(code),
      raggedLines: t1.ragged.length + t2.ragged.length
    };
  };

  const islandAtSa2 = sa2Row ? readGeo(sa2, sa2Row.code) : null;

  const sa1Data = [];
  if (sa1) {
    const t1 = readTable(sa1.zip, sa1.g01);
    const t2 = readTable(sa1.zip, sa1.g02);
    for (const r of sa1Rows) {
      sa1Data.push({
        code: r.code,
        areaSqKm: r.areaSqKm,
        present: t1.rows.has(r.code),
        g01: pick(t1.rows.get(r.code), G01_FIELDS),
        g02: pick(t2.rows.get(r.code), G02_FIELDS)
      });
    }
  }

  const townships = [];
  if (sal) {
    const t1 = readTable(sal.zip, sal.g01);
    const t2 = readTable(sal.zip, sal.g02);
    for (const s of salRows) {
      for (const m of s.matches) {
        townships.push({
          township: s.township,
          role: s.role,
          salName: m.name,
          nameDiffers: s.township !== m.name,
          code: m.code,
          areaSqKm: m.areaSqKm,
          matchedNationally: s.matchesNationally,
          matchedInQueensland: s.matches.length,
          present: t1.rows.has(m.code),
          g01: pick(t1.rows.get(m.code), G01_FIELDS),
          g02: pick(t2.rows.get(m.code), G02_FIELDS)
        });
      }
      if (!s.matches.length) {
        townships.push({
          township: s.township, role: s.role, salName: s.salName, code: null, notFound: true,
          matchedNationally: s.matchesNationally
        });
      }
    }
  }

  const sa1PopSum = sa1Data.reduce((a, r) => a + (r.g01.Tot_P_P || 0), 0);
  const townshipPopSum = townships
    .filter((r) => r.role === 'township')
    .reduce((a, r) => a + ((r.g01 && r.g01.Tot_P_P) || 0), 0);
  const salPopSum = townships.reduce((a, r) => a + ((r.g01 && r.g01.Tot_P_P) || 0), 0);
  const salAreaSum = townships.reduce((a, r) => a + (r.areaSqKm || 0), 0);
  const islandPop = islandAtSa2 ? islandAtSa2.g01.Tot_P_P : null;

  const result = {
    staged: {
      SA1: sa1 ? { file: rel(sa1.path), bytes: sa1.bytes.length, sha256: sha256(sa1.bytes) } : null,
      SA2: { file: rel(sa2.path), bytes: sa2.bytes.length, sha256: sha256(sa2.bytes) },
      SAL: sal ? { file: rel(sal.path), bytes: sal.bytes.length, sha256: sha256(sal.bytes) } : null
    },
    geographyDescriptor: geo.file,
    island: {
      sa2: sa2Row,
      sa3: sa3Row,
      expectedCode: ISLAND_SA2.code,
      codeAsExpected: Boolean(sa2Row) && sa2Row.code === ISLAND_SA2.code
    },
    sa1s: {
      count: sa1Rows.length,
      areaSumSqKm: Number(areaSum.toFixed(4)),
      sa2AreaSqKm: sa2Row ? sa2Row.areaSqKm : null,
      areaCheckPasses: areaAgrees,
      named: false,
      namedNote: 'An SA1 carries no name in the ASGS. The DataPack alone cannot say which SA1 covers '
        + 'which township, and nothing in this repository invents one.',
      rows: sa1Data
    },
    townships: { geography: 'SAL', rows: townships },
    islandFigureAtSa2: islandAtSa2,
    reconciliation: {
      sa2Population: islandPop,
      sa2AreaSqKm: sa2Row ? sa2Row.areaSqKm : null,
      sa1PopulationSum: sa1PopSum,
      sa1MinusSa2: islandPop === null ? null : sa1PopSum - islandPop,
      townshipPopulationSum: townshipPopSum,
      townshipShareOfIsland: islandPop ? Number((townshipPopSum / islandPop).toFixed(3)) : null,
      allFourSalPopulationSum: salPopSum,
      allFourSalMinusSa2: islandPop === null ? null : salPopSum - islandPop,
      allFourSalAreaSqKm: Number(salAreaSum.toFixed(4)),
      note: 'The ABS randomly adjusts small counts so a person cannot be identified from a table, so '
        + 'parts are not expected to sum to their whole exactly. Both differences are measured here '
        + 'rather than described. The three townships do not cover the whole island: the rest of it '
        + 'is a fourth locality of the same name as the island, which is why the four are summed '
        + 'separately from the three.'
    }
  };

  if (silent) return result;
  if (json) { console.log(JSON.stringify(result, null, 2)); return result; }

  const say = (s) => console.log(s);
  for (const g of DEFAULT_GEOGRAPHIES) {
    const s = result.staged[g];
    say(`${g.padEnd(4)} ${s ? `${s.file}  ${s.bytes} bytes  sha256 ${s.sha256}` : 'not staged'}`);
  }
  say(`geog ${result.geographyDescriptor}`);
  say('');
  say('THE ISLAND, AS THE ABS NAMES IT');
  if (!sa2Row) { say('  SA2 not found by name. Nothing below can be trusted.'); return result; }
  say(`  SA3  ${sa3Row ? sa3Row.code + '  ' + sa3Row.name : '(not found)'}`);
  say(`  SA2  ${sa2Row.code}  ${sa2Row.name}  ${sa2Row.areaSqKm} sq km`);
  say(`  code matches the constant in this file: ${result.island.codeAsExpected}`);
  say('');
  say(`SA1s UNDER THAT SA2: ${result.sa1s.count}`);
  say(`  area check: ${result.sa1s.areaSumSqKm} sq km summed against the SA2's ${result.sa1s.sa2AreaSqKm} sq km, agrees: ${result.sa1s.areaCheckPasses}`);
  say('  code          area sq km   persons   median age   median weekly household income');
  for (const r of sa1Data) {
    say(`  ${r.code}  ${String(r.areaSqKm).padStart(10)}  ${String(r.g01.Tot_P_P).padStart(7)}`
      + `  ${String(r.g02.Median_age_persons).padStart(10)}   ${r.g02.Median_tot_hhd_inc_weekly}`);
  }
  say('  An SA1 has no name. Which of these is Dunwich is not in this pack and is not guessed here.');
  say('');
  say('THE TOWNSHIPS, AT THE NAMED GEOGRAPHY (SAL)');
  say('  township          ABS name           code       area sq km   persons   median age   median weekly household income');
  for (const t of townships) {
    if (t.notFound) {
      say(`  ${t.township.padEnd(16)}  NOT FOUND. ${t.matchedNationally} rows nationally carry the name "${t.salName}", none of them in the Queensland table`);
      continue;
    }
    say(`  ${t.township.padEnd(16)}  ${t.salName.padEnd(17)}  ${t.code.padEnd(9)}  ${String(t.areaSqKm).padStart(10)}  ${String(t.g01.Tot_P_P).padStart(7)}`
      + `  ${String(t.g02.Median_age_persons).padStart(10)}   ${t.g02.Median_tot_hhd_inc_weekly}`);
  }
  for (const t of townships) {
    if (t.nameDiffers) {
      say(`  The ABS calls "${t.township}" the locality "${t.salName}". Both names are somebody else's, `
        + 'and neither is rewritten into the other here.');
    }
    if (t.matchedNationally > t.matchedInQueensland) {
      say(`  "${t.salName}" matches ${t.matchedNationally} localities nationally and ${t.matchedInQueensland} in the Queensland table, `
        + 'which is what decides which one is this island\'s.');
    }
  }
  say('');
  say('WHAT THE ISLAND FIGURE HIDES');
  say(`  SA2, the whole island:            ${result.reconciliation.sa2Population} persons over ${result.reconciliation.sa2AreaSqKm} sq km`);
  say(`  the eight SA1s, summed:           ${result.reconciliation.sa1PopulationSum} persons `
    + `(${result.reconciliation.sa1MinusSa2 >= 0 ? '+' : ''}${result.reconciliation.sa1MinusSa2} against the SA2)`);
  say(`  the three townships, summed:      ${result.reconciliation.townshipPopulationSum} persons, `
    + `${Math.round((result.reconciliation.townshipShareOfIsland || 0) * 100)} per cent of the island figure`);
  say(`  all four localities, summed:      ${result.reconciliation.allFourSalPopulationSum} persons `
    + `(${result.reconciliation.allFourSalMinusSa2 >= 0 ? '+' : ''}${result.reconciliation.allFourSalMinusSa2} against the SA2) `
    + `over ${result.reconciliation.allFourSalAreaSqKm} sq km`);
  say(`  ${result.reconciliation.note}`);
  say('');
  say('ATTRIBUTION REQUIRED BY THE LICENCE');
  for (const line of ATTRIBUTION) say('  ' + line);
  return result;
}

export const ATTRIBUTION = [
  'Based on Australian Bureau of Statistics data. Census of Population and Housing 2021, General',
  '  Community Profile DataPacks, accessed 19 August 2026.',
  'ABS data used with permission from the Australian Bureau of Statistics.',
  'https://www.abs.gov.au',
  'The DataPack readme draws a line between material used as supplied, attributed "Source:',
  '  Australian Bureau of Statistics", and derived material, attributed "Based on Australian',
  '  Bureau of Statistics data". Everything here is derivation, so the second form is the one owed.'
];

// ---------------------------------------------------------------------------------------------
// Derive
// ---------------------------------------------------------------------------------------------

/**
 * Provenance for a census record.
 *
 *   validFrom     2021-08-10, Census night. That is the moment the counts were true of the island,
 *                 and it is not the date the file was published or downloaded. A twin that used the
 *                 download date here would put 2021 people in a 2026 island and call it current.
 *   validTo       null. No later census has superseded these counts, so they are still the best
 *                 published account of that population. That is a statement about the record, not a
 *                 claim that the island has not changed since.
 *   confidence    high for the counts, which are a national census, with the perturbation caveat
 *                 carried on the pack rather than hidden in a lower confidence.
 *   register      known.
 */
function provenance(locator, today) {
  return {
    source: SOURCE_ID,
    locator,
    validFrom: '2021-08-10',
    validTo: null,
    recordedAt: today,
    recordedUntil: null,
    confidence: 'high',
    register: 'known'
  };
}

function derive({ json }) {
  const s = summarise({ json: false, silent: true });
  if (!s) return;
  const today = islandToday();
  const records = [];

  if (s.island.sa2 && s.islandFigureAtSa2) {
    records.push({
      id: `census2021-sa2-${s.island.sa2.code}`,
      kind: 'census-area',
      geography: 'SA2',
      code: s.island.sa2.code,
      name: s.island.sa2.name,
      areaSqKm: s.island.sa2.areaSqKm,
      ...s.islandFigureAtSa2.g01,
      ...s.islandFigureAtSa2.g02,
      ...provenance(`2021Census_G01_QLD_SA2.csv and G02, row SA2_CODE_2021 ${s.island.sa2.code}, in ${PACKS.SA2.file}`, today)
    });
  }

  for (const r of s.sa1s.rows) {
    records.push({
      id: `census2021-sa1-${r.code}`,
      kind: 'census-area',
      geography: 'SA1',
      code: r.code,
      name: null,
      nameNote: 'SA1s carry no name in the ASGS. Which township this SA1 covers is not in the '
        + 'DataPack and is not inferred here.',
      areaSqKm: r.areaSqKm,
      ...r.g01,
      ...r.g02,
      ...provenance(`2021Census_G01_QLD_SA1.csv and G02, row SA1_CODE_2021 ${r.code}, in ${PACKS.SA1.file}`, today)
    });
  }

  for (const t of s.townships.rows) {
    if (t.notFound) continue;
    records.push({
      id: `census2021-sal-${t.code}`,
      kind: 'census-area',
      geography: 'SAL',
      code: t.code,
      name: t.salName,
      townshipName: t.township,
      nameNote: t.nameDiffers
        ? `The ABS names this locality "${t.salName}". The settlement on it is called "${t.township}" `
          + 'by the founding prompt and by OpenStreetMap\'s village node. Both names are recorded and '
          + 'neither is rewritten into the other.'
        : null,
      role: t.role,
      areaSqKm: t.areaSqKm,
      ...t.g01,
      ...t.g02,
      ...provenance(`2021Census_G01_QLD_SAL.csv and G02, row SAL_CODE_2021 ${t.code}, in ${PACKS.SAL.file}`, today)
    });
  }

  const pack = {
    pack: 'census-2021-island',
    version: '0.1.0',
    about: 'Census 2021 counts for this island at three geographies: the island SA2, the eight SA1s '
      + 'inside it and the three named townships in the Suburbs and Localities geography. NOT '
      + 'COMMITTABLE: it lives under ingest-inbox/, which .gitignore seals and tools/gate/sealed.mjs '
      + 'proves sealed by asking git. Counts are as at Census night, 10 August 2021, and every '
      + 'record says so in validFrom rather than in a note. The ABS randomly adjusts small counts, so '
      + 'parts do not sum to their whole and the measured difference is recorded on this pack. No '
      + 'record here is about a person: the finest geography in it holds hundreds of people.',
    attribution: ATTRIBUTION.join(' '),
    censusNight: '2021-08-10',
    perturbation: s.reconciliation,
    geographiesIncluded: ['SA2', 'SA1', 'SAL'],
    sa1NamingGap: s.sa1s.namedNote,
    count: records.length,
    areas: records
  };

  let sourceIds = null;
  try {
    sourceIds = new Set(Object.keys(JSON.parse(readFileSync(path.join(ROOT, 'data', '_sources.json'), 'utf8'))));
  } catch (err) {
    console.error(`could not read data/_sources.json: ${err.message}`);
  }
  const problems = [];
  for (const rec of records) {
    for (const p of checkRecord(rec, sourceIds ? { sourceIds, where: rec.id } : { where: rec.id })) problems.push(p);
  }

  mkdirSync(DERIVED_DIR, { recursive: true });
  const abs = path.join(DERIVED_DIR, `census-2021-island-${today}.json`);
  writeFileSync(abs, JSON.stringify(pack, null, 1) + '\n');

  const result = {
    written: rel(abs),
    bytes: statSync(abs).size,
    records: records.length,
    byGeography: { SA2: 1, SA1: s.sa1s.rows.length, SAL: s.townships.rows.filter((t) => !t.notFound).length },
    sourceIdsRead: sourceIds ? sourceIds.size : 0,
    provenanceProblems: problems
  };
  if (json) console.log(JSON.stringify(result, null, 2));
  else {
    console.log(`wrote ${result.written}  ${result.records} records, ${result.bytes} bytes`);
    console.log(`  by geography: SA2 ${result.byGeography.SA2}, SA1 ${result.byGeography.SA1}, SAL ${result.byGeography.SAL}`);
    console.log(`checked ${result.records} records with src/kernel/record.js against ${result.sourceIdsRead} source ids`);
    console.log(problems.length ? `PROVENANCE PROBLEMS: ${problems.length}` : 'provenance: 0 problems');
    for (const p of problems.slice(0, 20)) console.log('  ' + p);
    console.log('NOT COMMITTABLE: ingest-inbox/ is sealed and stays sealed this wave.');
  }
  if (problems.length) process.exitCode = 1;
  return result;
}

// ---------------------------------------------------------------------------------------------

const USAGE = `node tools/ingest/census.mjs <mode>

  --fetch        the Queensland DataPacks for SA1, SA2 and SAL, staged with receipts
  --summarise    the island SA2, the SA1s inside it, the three named townships, and what the
                 island figure hides. No network
  --derive       a provenanced pack into ingest-inbox/derived/. No network

  --geography G  fetch one of ${DEFAULT_GEOGRAPHIES.join(', ')} rather than all three
  --force        allow --fetch to replace a file already staged
  --json         machine readable output for --summarise and --derive

Nothing this tool writes is committable. ingest-inbox/ is sealed: board note 007.
`;

async function main(argv) {
  const has = (f) => argv.includes(f);
  const val = (f) => {
    const i = argv.indexOf(f);
    return i >= 0 ? argv[i + 1] : null;
  };
  if (!argv.length || has('--help') || has('-h')) { console.log(USAGE); return; }

  const json = has('--json');
  const force = has('--force');
  const one = val('--geography');
  if (one && !PACKS[one]) {
    console.error(`unknown geography: ${one}. Known: ${DEFAULT_GEOGRAPHIES.join(', ')}`);
    process.exitCode = 2;
    return;
  }

  if (has('--fetch')) {
    for (const g of one ? [one] : DEFAULT_GEOGRAPHIES) {
      console.log(`--- ${g}: ${PACKS[g].why}`);
      await fetchOne(g, force);
      console.log('');
    }
    return;
  }
  if (has('--summarise') || has('--summarize')) { summarise({ json }); return; }
  if (has('--derive')) { derive({ json }); return; }

  console.error(`unknown mode: ${argv.join(' ')}`);
  console.error(USAGE);
  process.exitCode = 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2));
}

export { summarise, derive };
