#!/usr/bin/env node
// TransLink GTFS: the timetable lane.
//
//     node tools/ingest/gtfs.mjs --fetch        download the feeds into ingest-inbox/gtfs/
//     node tools/ingest/gtfs.mjs --summarise    what the feeds actually hold for this island
//     node tools/ingest/gtfs.mjs --derive       a provenanced pack into ingest-inbox/derived/
//     node tools/ingest/gtfs.mjs --fetch --feed nsi
//     node tools/ingest/gtfs.mjs --summarise --json
//
// The founding prompt's stage 4 slice is a Friday barge day and it cannot be built from a typed in
// timetable. A timetable is exactly the kind of thing that looks right and is wrong, so this lane
// reads the publisher's own file or reports that it could not.
//
// THE CORRECTION THIS LANE CARRIES. The founding prompt's shopping list says "TransLink GTFS for
// SEQ: the real 880 and 881 and ferry connections". The 880 and 881 are NOT in the SEQ feed. They
// are in a separate feed, NSI_GTFS.zip, which TransLink publishes for North Stradbroke Island alone.
// An agent that downloaded SEQ, searched it for 880, found nothing and concluded the island has no
// timetable would have been wrong, and an agent that then typed one in would have been wrong twice.
// So this tool fetches the island feed by name and the SEQ feed beside it, and reports each on its
// own terms.
//
// THE TWO CROSSINGS LAW, which this file exists to keep. Passenger and vehicle crossings are never
// one figure. You can almost always get off the island; you cannot always get your car off, and the
// second question is the useful one. Neither crossing is in TransLink GTFS: see the crossings block
// in the derived pack, where each is its own lane with a null count and a stated reason. A null in
// two lanes is the honest answer. One number covering both is the first build's named defect and it
// is unrecoverable once made, because nothing downstream can tell which half of a total was a car
// deck.
//
// NOTHING DERIVED IS COMMITTED. Everything this tool writes lands under ingest-inbox/, which
// .gitignore seals and tools/gate/sealed.mjs proves sealed by asking git. The connector is
// committed; its output is not, until the owner settles how derived data is carried.
//
// This file may use a wall clock. The ban in gate/no-wallclock covers src/kernel, src/systems and
// src/world, because a world whose state depends on when it ran cannot be diffed against itself. The
// date a file was downloaded is not world state, it is the receipt.

import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { openZip } from '../zip.mjs';
import { civilFromDays, ISLAND_UTC_OFFSET_MINUTES, TICKS_PER_DAY } from '../../src/kernel/clock.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..', '..');

/**
 * The feeds, each with the reason it is here. Every URL is one TransLink registers as a resource of
 * the dataset `general-transit-feed-specification-gtfs-translink` on data.qld.gov.au, and the whole
 * dataset is Creative Commons Attribution 4.0 by that portal's own licence field. The resource list
 * is machine readable at
 * https://www.data.qld.gov.au/api/3/action/package_show?id=general-transit-feed-specification-gtfs-translink
 * so a later agent can check that these four are still the right four rather than trusting a
 * constant in a file.
 */
export const FEEDS = {
  nsi: {
    url: 'https://gtfsrt.api.translink.com.au/GTFS/NSI_GTFS.zip',
    file: 'NSI_GTFS.zip',
    why: 'The island feed. The publisher describes it as "Network data for North Stradbroke Island '
      + 'urban bus services". This is where the 880 and the 881 live.'
  },
  'nsi-sch': {
    url: 'https://gtfsrt.api.translink.com.au/gtfs/NSI_SCH_GTFS.zip',
    file: 'NSI_SCH_GTFS.zip',
    why: 'The supplementary island feed. The publisher says it adds school services and agency '
      + 'information. It is fetched because the plain island feed names the operator differently, '
      + 'and two publisher answers about one operator is a finding rather than a nuisance.'
  },
  seq: {
    url: 'https://gtfsrt.api.translink.com.au/GTFS/SEQ_GTFS.zip',
    file: 'SEQ_GTFS.zip',
    why: 'South East Queensland: bus, rail, light rail and ferry. The mainland end of every crossing '
      + 'is in here. The island is not, and proving that absence is half of what this lane is for.'
  },
  mif: {
    url: 'https://gtfsrt.api.translink.com.au/GTFS/MIF_GTFS.zip',
    file: 'MIF_GTFS.zip',
    why: 'Magnetic Island Ferry, fetched as a control. It shows that this publisher does model an '
      + 'island passenger ferry in GTFS when it contracts one, which is what makes the absence of a '
      + 'Minjerribah crossing evidence rather than an assumption about the format.'
  }
};

const DEFAULT_FEEDS = ['nsi', 'nsi-sch', 'seq', 'mif'];
const ISLAND_FEEDS = ['nsi', 'nsi-sch'];

const INBOX = path.join(REPO_ROOT, 'ingest-inbox', 'gtfs');
const DERIVED = path.join(REPO_ROOT, 'ingest-inbox', 'derived');
const RECEIPT_PATH = path.join(INBOX, 'fetch-receipt.json');
const SUMMARY_PATH = path.join(INBOX, 'summary.json');
const PACK_PATH = path.join(DERIVED, 'transport-gtfs.json');

/**
 * A search window over the island, used to find candidate stops by position as a second witness to
 * finding them by name. It is a filter, not a fact: it is deliberately wider than the island and it
 * catches other places in Moreton Bay, so every hit is printed with its name and a human decides.
 * Nothing downstream reads it. The founding prompt's rule against invented geography is why it is
 * described this way rather than presented as the island's extent.
 */
const SEARCH_BOX = { minLat: -27.80, maxLat: -27.30, minLon: 153.36, maxLon: 153.60 };

// Terms that appear in the published names of island places and of the mainland ends of the
// crossings. They are search terms against the feed's own stop_name field, and every match is
// printed so a false positive is visible rather than silently counted.
const ISLAND_TERMS = ['dunwich', 'one mile', 'amity', 'point lookout', 'stradbroke', 'straddie', 'minjerribah'];
const MAINLAND_TERMS = ['cleveland', 'toondah', 'redland bay', 'weinam'];

// GTFS route_type. 3 is bus and 4 is ferry; the rest are named so an unexpected value is reported
// rather than bucketed into "other" without a word.
const ROUTE_TYPES = new Map([
  [0, 'tram'], [1, 'metro'], [2, 'rail'], [3, 'bus'], [4, 'ferry'], [5, 'cable tram'],
  [6, 'aerial lift'], [7, 'funicular'], [11, 'trolleybus'], [12, 'monorail']
]);

const WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

// Any column name that would let a feed say a vessel carries cars. GTFS has no such field, and the
// summary proves that by scanning every column of every file rather than asserting it.
const VEHICLE_CAPACITY_HINTS = /vehicle|car|deck|freight|cargo|motor|barge|drive[-_ ]?on/i;

function usage() {
  return [
    'node tools/ingest/gtfs.mjs --fetch | --summarise | --derive [--feed <id>] [--json]',
    '',
    '  --fetch        download the feeds to ingest-inbox/gtfs/ and write a receipt beside them',
    '  --summarise    read what is downloaded and report the island routes, stops and services',
    '  --derive       write a provenanced pack to ingest-inbox/derived/transport-gtfs.json',
    '  --feed <id>    one feed only, repeatable. default: ' + DEFAULT_FEEDS.join(', '),
    '  --json         machine readable output on stdout, nothing else',
    '',
    'Feeds:',
    ...Object.entries(FEEDS).map(([k, f]) => '  ' + k.padEnd(9) + f.url),
    '',
    'Nothing this tool writes is committable. ingest-inbox/ is sealed and gate/sealed proves it.'
  ].join('\n');
}

// ---------------------------------------------------------------------------------------------
// island civil time, for receipts
// ---------------------------------------------------------------------------------------------

function islandMinutes() {
  return Math.floor(Date.now() / 60000) + ISLAND_UTC_OFFSET_MINUTES;
}

function pad2(n) { return String(n).padStart(2, '0'); }

function islandToday() {
  const { year, month, day } = civilFromDays(Math.floor(islandMinutes() / TICKS_PER_DAY));
  return year + '-' + pad2(month) + '-' + pad2(day);
}

function islandNow() {
  const minutes = islandMinutes();
  const inDay = minutes - Math.floor(minutes / TICKS_PER_DAY) * TICKS_PER_DAY;
  return islandToday() + 'T' + pad2(Math.floor(inDay / 60)) + ':' + pad2(inDay % 60) + '+10:00';
}

// Howard Hinnant's days_from_civil, the algorithm src/kernel/clock.js uses for the other direction.
function daysFromCivil(y, m, d) {
  const yy = y - (m <= 2 ? 1 : 0);
  const era = Math.floor(yy / 400);
  const yoe = yy - era * 400;
  const doy = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
  const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}

function weekdayOf(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const z = daysFromCivil(y, m, d);
  return ((z + 4) % 7 + 7) % 7;
}

/** The first date on or after `from` that falls on weekday `dow`, 0 Sunday. */
export function nextWeekday(from, dow) {
  const [y, m, d] = from.split('-').map(Number);
  let z = daysFromCivil(y, m, d);
  while (((z + 4) % 7 + 7) % 7 !== dow) z++;
  const c = civilFromDays(z);
  return c.year + '-' + pad2(c.month) + '-' + pad2(c.day);
}

/** `count` consecutive dates from `from`, inclusive. Used to take one of every weekday. */
export function datesFrom(from, count) {
  const [y, m, d] = from.split('-').map(Number);
  const z0 = daysFromCivil(y, m, d);
  const out = [];
  for (let i = 0; i < count; i++) {
    const c = civilFromDays(z0 + i);
    out.push(c.year + '-' + pad2(c.month) + '-' + pad2(c.day));
  }
  return out;
}

/** The weekday name of a date, in the vocabulary GTFS calendar.txt uses for its columns. */
export function weekdayName(dateStr) {
  return WEEKDAYS[weekdayOf(dateStr)];
}

// ---------------------------------------------------------------------------------------------
// CSV, as GTFS uses it
// ---------------------------------------------------------------------------------------------

/**
 * Stream a GTFS CSV, one row at a time, so a 159 MB stop_times.txt never becomes 159 MB of objects.
 * The subset is the one GTFS is specified in: comma separated, double quotes around a field holding
 * a comma, a quote or a newline, and a doubled quote inside a quoted field. Splitting on commas
 * would be wrong here and quietly so: stop names in this feed contain commas.
 *
 * `onRow` is called with an array of strings for every row including the header.
 */
export function eachCsvRow(text, onRow) {
  let row = [];
  let field = '';
  let quoted = false;
  let started = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i++; }
        else quoted = false;
      } else field += c;
      continue;
    }
    if (c === '"' && field === '') { quoted = true; started = true; continue; }
    if (c === ',') { row.push(field); field = ''; started = true; continue; }
    if (c === '\r') continue;
    if (c === '\n') {
      if (started || field !== '' || row.length) { row.push(field); onRow(row); }
      row = []; field = ''; started = false;
      continue;
    }
    field += c;
    started = true;
  }
  if (started || field !== '' || row.length) { row.push(field); onRow(row); }
}

/** Every row of a table as an object. For the small files only. */
function readTable(zip, name) {
  if (!zip.has(name)) return { present: false, header: [], rows: [] };
  let header = null;
  const rows = [];
  eachCsvRow(zip.text(name), (r) => {
    if (!header) { header = r.map((h) => h.trim()); return; }
    if (r.length === 1 && r[0] === '') return;
    const o = {};
    for (let c = 0; c < header.length; c++) o[header[c]] = r[c] === undefined ? '' : r[c];
    rows.push(o);
  });
  return { present: true, header: header || [], rows };
}

/** Stream a table, calling `onRow` with an object per row. For stop_times.txt. */
function streamTable(zip, name, onRow) {
  if (!zip.has(name)) return { present: false, header: [], count: 0 };
  let header = null;
  let count = 0;
  eachCsvRow(zip.text(name), (r) => {
    if (!header) { header = r.map((h) => h.trim()); return; }
    if (r.length === 1 && r[0] === '') return;
    const o = {};
    for (let c = 0; c < header.length; c++) o[header[c]] = r[c] === undefined ? '' : r[c];
    count++;
    onRow(o);
  });
  return { present: true, header: header || [], count };
}

/** Only the header line of a table, without decompressing it twice into objects. */
function headerOf(zip, name) {
  if (!zip.has(name)) return null;
  const text = zip.text(name);
  const nl = text.indexOf('\n');
  const line = nl === -1 ? text : text.slice(0, nl);
  let header = null;
  eachCsvRow(line, (r) => { if (!header) header = r.map((h) => h.trim()); });
  return header;
}

// ---------------------------------------------------------------------------------------------
// fetch
// ---------------------------------------------------------------------------------------------

async function fetchOne(id) {
  const feed = FEEDS[id];
  const attemptedAt = islandNow();
  const t0 = Date.now();
  let res;
  try {
    res = await fetch(feed.url, { redirect: 'follow' });
  } catch (err) {
    return {
      feed: id, url: feed.url, attemptedAt, ok: false,
      error: err.name + ': ' + err.message + (err.cause && err.cause.message ? ' (' + err.cause.message + ')' : ''),
      note: 'The request never completed. Nothing was written. Do not type in a timetable in its place.'
    };
  }
  if (!res.ok) {
    return {
      feed: id, url: feed.url, attemptedAt, ok: false,
      httpStatus: res.status, httpStatusText: res.statusText,
      note: 'The server answered and refused. Nothing was written.'
    };
  }
  const body = Buffer.from(await res.arrayBuffer());
  const target = path.join(INBOX, feed.file);
  writeFileSync(target, body);
  return {
    feed: id,
    url: feed.url,
    fetchedAt: islandNow(),
    ok: true,
    httpStatus: res.status,
    bytes: body.length,
    sha256: createHash('sha256').update(body).digest('hex'),
    elapsedMs: Date.now() - t0,
    responseHeaders: {
      'content-type': res.headers.get('content-type'),
      'last-modified': res.headers.get('last-modified'),
      etag: res.headers.get('etag')
    },
    path: path.relative(REPO_ROOT, target).replace(/\\/g, '/')
  };
}

async function doFetch(ids, { json }) {
  mkdirSync(INBOX, { recursive: true });
  const results = [];
  for (const id of ids) results.push(await fetchOne(id));

  const receipt = {
    lane: 'translink-gtfs',
    fetchedAt: islandNow(),
    licence: 'Creative Commons Attribution 4.0, the licence data.qld.gov.au records for the dataset '
      + 'general-transit-feed-specification-gtfs-translink. Attribution is owed and is not yet '
      + 'written anywhere player facing, because nothing player facing exists.',
    feeds: results,
    note: 'Sealed staging. ingest-inbox/ is gitignored and tools/gate/sealed.mjs proves it by asking git.'
  };
  writeFileSync(RECEIPT_PATH, JSON.stringify(receipt, null, 2) + '\n');

  if (json) { process.stdout.write(JSON.stringify(receipt, null, 2) + '\n'); }
  else {
    for (const r of results) {
      if (r.ok) {
        process.stdout.write(r.feed + '  HTTP ' + r.httpStatus + '  '
          + r.bytes.toLocaleString('en-AU') + ' bytes in ' + r.elapsedMs + ' ms\n');
        process.stdout.write('      ' + r.url + '\n');
        process.stdout.write('      sha256 ' + r.sha256 + '\n');
        process.stdout.write('      last-modified ' + (r.responseHeaders['last-modified'] || 'not stated') + '\n');
        process.stdout.write('      wrote ' + r.path + '\n');
      } else {
        process.stdout.write(r.feed + '  FAILED: ' + (r.error || ('HTTP ' + r.httpStatus + ' ' + r.httpStatusText)) + '\n');
        process.stdout.write('      ' + r.url + '\n');
      }
    }
    process.stdout.write('receipt: ' + path.relative(REPO_ROOT, RECEIPT_PATH).replace(/\\/g, '/') + '\n');
  }
  return results.every((r) => r.ok) ? 0 : 1;
}

// ---------------------------------------------------------------------------------------------
// summarise
// ---------------------------------------------------------------------------------------------

/**
 * GTFS clock time as minutes after midnight. A trip that runs past midnight is written 25:10, so
 * the hour field takes up to three digits and the result is not wrapped into a day.
 *
 * Seconds are optional. GTFS always writes them; the derived pack writes HH:MM for a time that ends
 * on a whole minute, which every one of this feed's 5,046 times does, and keeps the publisher's
 * HH:MM:SS for one that does not. tools/connections.mjs reads that pack back, so one parser for
 * both shapes means the instrument and the connector cannot disagree about what 08:21 means.
 */
export function hmsToMinutes(s) {
  const m = /^(\d{1,3}):(\d{2})(?::(\d{2}))?$/.exec(String(s).trim());
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
}

function minutesToHm(mins) {
  return mins === null || mins === undefined ? null : pad2(Math.floor(mins / 60)) + ':' + pad2(mins % 60);
}

/**
 * Service ids running on a date, from calendar.txt and calendar_dates.txt together. GTFS lets a feed
 * use either or both, and a reader that consults only one silently loses services. The island feed
 * uses both: five calendar rows, and seventeen date exceptions that take the school-term service out
 * on the holidays.
 */
export function servicesOn(calendar, calendarDates, date) {
  const ymd = date.replace(/-/g, '');
  const weekday = WEEKDAYS[weekdayOf(date)];
  const running = new Set();
  for (const r of calendar.rows) {
    if (r[weekday] !== '1') continue;
    if (r.start_date && ymd < r.start_date) continue;
    if (r.end_date && ymd > r.end_date) continue;
    running.add(r.service_id);
  }
  for (const r of calendarDates.rows) {
    if (r.date !== ymd) continue;
    if (r.exception_type === '1') running.add(r.service_id);
    if (r.exception_type === '2') running.delete(r.service_id);
  }
  return running;
}

function matchesAny(name, terms) {
  const lower = String(name || '').toLowerCase();
  return terms.some((t) => lower.includes(t));
}

function inBox(lat, lon) {
  return Number.isFinite(lat) && Number.isFinite(lon)
    && lat >= SEARCH_BOX.minLat && lat <= SEARCH_BOX.maxLat
    && lon >= SEARCH_BOX.minLon && lon <= SEARCH_BOX.maxLon;
}

function summariseFeed(id, buf, friday) {
  const zip = openZip(buf);
  const files = zip.names().slice().sort();

  const agency = readTable(zip, 'agency.txt');
  const routes = readTable(zip, 'routes.txt');
  const stops = readTable(zip, 'stops.txt');
  const trips = readTable(zip, 'trips.txt');
  const calendar = readTable(zip, 'calendar.txt');
  const calendarDates = readTable(zip, 'calendar_dates.txt');
  const feedInfo = readTable(zip, 'feed_info.txt');

  // Every column of every file, so the claim that no field records a car deck is checked rather
  // than asserted. stop_times.txt and shapes.txt are read for their header only.
  const columns = {};
  for (const name of files) {
    if (!name.endsWith('.txt')) continue;
    if (name === 'stop_times.txt' || name === 'shapes.txt') columns[name] = headerOf(zip, name);
    else columns[name] = (readTable(zip, name).header) || [];
  }
  const vehicleCapacityFields = Object.entries(columns)
    .flatMap(([file, cols]) => (cols || []).filter((c) => VEHICLE_CAPACITY_HINTS.test(c)).map((c) => file + '.' + c));

  // One agency and no agency_id is legal GTFS and is what the SEQ and plain island feeds do.
  const agencyById = new Map(agency.rows.map((a) => [a.agency_id || '', a]));
  const soleAgency = agency.rows.length === 1 ? agency.rows[0] : null;
  const agencyFor = (r) => agencyById.get(r.agency_id || '') || soleAgency || {};

  const routeById = new Map(routes.rows.map((r) => [r.route_id, r]));
  const stopById = new Map(stops.rows.map((s) => [s.stop_id, s]));
  const tripById = new Map(trips.rows.map((t) => [t.trip_id, t]));

  const stopsByName = stops.rows.filter((s) => matchesAny(s.stop_name, ISLAND_TERMS));
  const stopsByBox = stops.rows.filter((s) => inBox(Number(s.stop_lat), Number(s.stop_lon)));
  const mainlandStops = stops.rows.filter((s) => matchesAny(s.stop_name, MAINLAND_TERMS));

  // A candidate island stop is one either witness names. Both witnesses are reported, and where they
  // disagree the disagreement is printed, because a bounding box catches other places in this bay.
  const candidateIds = new Set([...stopsByName, ...stopsByBox].map((s) => s.stop_id));

  const running = servicesOn(calendar, calendarDates, friday);

  // One streaming pass over stop_times.txt. Nothing accumulates except the candidate stops.
  const perRouteStop = new Map();   // routeId -> stopId -> {first,last,count}
  const routeIdsTouching = new Set();
  const tripsTouching = new Set();
  const stopTimesHeader = streamTable(zip, 'stop_times.txt', (st) => {
    if (!candidateIds.has(st.stop_id)) return;
    const trip = tripById.get(st.trip_id);
    if (!trip) return;
    tripsTouching.add(st.trip_id);
    routeIdsTouching.add(trip.route_id);
    if (!running.has(trip.service_id)) return;
    const mins = hmsToMinutes(st.departure_time || st.arrival_time);
    if (mins === null) return;
    let byStop = perRouteStop.get(trip.route_id);
    if (!byStop) { byStop = new Map(); perRouteStop.set(trip.route_id, byStop); }
    let cell = byStop.get(st.stop_id);
    if (!cell) { cell = { first: mins, last: mins, count: 0 }; byStop.set(st.stop_id, cell); }
    if (mins < cell.first) cell.first = mins;
    if (mins > cell.last) cell.last = mins;
    cell.count++;
  });

  const tripsByRoute = new Map();
  for (const t of trips.rows) {
    let e = tripsByRoute.get(t.route_id);
    if (!e) { e = { total: 0, friday: 0, headsigns: new Map() }; tripsByRoute.set(t.route_id, e); }
    e.total++;
    if (running.has(t.service_id)) {
      e.friday++;
      const hs = t.trip_headsign || '';
      e.headsigns.set(hs, (e.headsigns.get(hs) || 0) + 1);
    }
  }

  const islandRoutes = [...routeIdsTouching].map((rid) => {
    const r = routeById.get(rid) || {};
    const type = Number(r.route_type);
    const tallies = tripsByRoute.get(rid) || { total: 0, friday: 0, headsigns: new Map() };
    const byStop = perRouteStop.get(rid) || new Map();
    const stopRows = [...byStop.entries()].map(([sid, cell]) => ({
      stopId: sid,
      name: (stopById.get(sid) || {}).stop_name || '',
      firstDeparture: minutesToHm(cell.first),
      lastDeparture: minutesToHm(cell.last),
      calls: cell.count
    })).sort((a, b) => a.firstDeparture.localeCompare(b.firstDeparture));
    const firsts = stopRows.map((s) => s.firstDeparture).filter(Boolean).sort();
    const lasts = stopRows.map((s) => s.lastDeparture).filter(Boolean).sort();
    return {
      routeId: rid,
      shortName: r.route_short_name || '',
      longName: r.route_long_name || '',
      routeType: type,
      mode: ROUTE_TYPES.get(type) || ('route_type ' + r.route_type),
      operator: agencyFor(r).agency_name || '',
      operatorUrl: agencyFor(r).agency_url || '',
      tripsInFeed: tallies.total,
      fridayTrips: tallies.friday,
      fridayHeadsigns: [...tallies.headsigns.entries()].map(([headsign, n]) => ({ headsign, trips: n })).sort((a, b) => b.trips - a.trips),
      fridayFirstDeparture: firsts[0] || null,
      fridayLastDeparture: lasts[lasts.length - 1] || null,
      stops: stopRows
    };
  }).sort((a, b) => (a.shortName || a.routeId).localeCompare(b.shortName || b.routeId, 'en', { numeric: true }));

  const namedRoutes = ['880', '881'].map((n) => {
    const hits = routes.rows.filter((r) => (r.route_short_name || '').trim() === n);
    return {
      shortName: n,
      present: hits.length > 0,
      routeIds: hits.map((r) => r.route_id),
      longNames: hits.map((r) => r.route_long_name),
      modes: hits.map((r) => ROUTE_TYPES.get(Number(r.route_type)) || r.route_type)
    };
  });

  const ferryRoutes = routes.rows.filter((r) => Number(r.route_type) === 4).map((r) => ({
    routeId: r.route_id,
    shortName: r.route_short_name || '',
    longName: r.route_long_name || '',
    operator: agencyFor(r).agency_name || '',
    tripsInFeed: (tripsByRoute.get(r.route_id) || { total: 0 }).total,
    touchesCandidateStop: routeIdsTouching.has(r.route_id)
  }));

  return {
    feed: id,
    url: FEEDS[id].url,
    why: FEEDS[id].why,
    allStops: stops.rows
      .map((s) => ({ stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon) }))
      .filter((s) => Number.isFinite(s.lat) && Number.isFinite(s.lon)),
    files,
    columns,
    vehicleCapacityFields,
    feedInfo: feedInfo.rows,
    agencies: agency.rows.map((a) => ({
      id: a.agency_id || null, name: a.agency_name, url: a.agency_url, timezone: a.agency_timezone
    })),
    counts: {
      routes: routes.rows.length,
      stops: stops.rows.length,
      trips: trips.rows.length,
      stopTimes: stopTimesHeader.count,
      calendarRows: calendar.rows.length,
      calendarDateRows: calendarDates.rows.length,
      routesByMode: routes.rows.reduce((acc, r) => {
        const k = ROUTE_TYPES.get(Number(r.route_type)) || ('route_type ' + r.route_type);
        acc[k] = (acc[k] || 0) + 1;
        return acc;
      }, {})
    },
    fridayChecked: friday,
    servicesRunningThatFriday: [...running],
    stopsMatchedByName: stopsByName.map((s) => ({ stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon) })),
    stopsMatchedByBox: stopsByBox.map((s) => ({ stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon) })),
    stopsInBoxButNotNamed: stopsByBox.filter((s) => !matchesAny(s.stop_name, ISLAND_TERMS))
      .map((s) => ({ stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon) })),
    mainlandStops: mainlandStops.map((s) => ({ stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon) })),
    islandRoutes,
    namedRoutes,
    ferryRoutes,
    tripsTouchingCandidateStops: tripsTouching.size
  };
}

// ---------------------------------------------------------------------------------------------
// The terminal week: every bus call at a ferry terminal, for one of each weekday
// ---------------------------------------------------------------------------------------------

/**
 * The two landings, found by the feed's own stop names rather than by an id written in here. Two
 * stops in NSI_GTFS.zip carry "Ferry Terminal": 870029 Junner St Ferry Terminal (Dunwich) and
 * 870027 Yabby St at One Mile Ferry Terminal. Selecting on the published name means a third landing
 * appearing in a later feed is picked up, and a stop id changing does not silently empty the
 * analysis.
 */
const TERMINAL_NAME = /ferry terminal/i;

/** How many consecutive days the derived week covers. Seven, so every weekday is in it once. */
const SERVICE_WEEK_DAYS = 7;

/**
 * Every call a bus makes at a ferry terminal, for seven consecutive days from the feed's own start
 * date. This is what turns "the bus timetable exists" into "does the bus meet the boat": the
 * question needs the minute a bus leaves the terminal and the minute one arrives at it, per day,
 * and neither is in the route level summary above.
 *
 * Both times are kept. GTFS gives a call an arrival_time and a departure_time and at these stops
 * they are equal today, but a passenger stepping off a boat needs the departure and a passenger
 * catching a boat needs the arrival, so folding them into one field would be a decision this file
 * has no business making.
 *
 * `firstStopOfTrip` and `lastStopOfTrip` are carried because a bus that terminates at a terminal
 * cannot take anybody anywhere, and a bus that starts there cannot have brought anybody. A reader
 * that ignores those two flags will count connections that do not exist.
 */
export function terminalWeek(zip) {
  const stops = readTable(zip, 'stops.txt');
  const trips = readTable(zip, 'trips.txt');
  const routes = readTable(zip, 'routes.txt');
  const calendar = readTable(zip, 'calendar.txt');
  const calendarDates = readTable(zip, 'calendar_dates.txt');
  const feedInfo = readTable(zip, 'feed_info.txt');

  const terminals = stops.rows.filter((s) => TERMINAL_NAME.test(s.stop_name || ''));
  const terminalIds = new Set(terminals.map((s) => s.stop_id));
  const tripById = new Map(trips.rows.map((t) => [t.trip_id, t]));
  const routeById = new Map(routes.rows.map((r) => [r.route_id, r]));
  const stopById = new Map(stops.rows.map((s) => [s.stop_id, s]));

  const startYmd = (feedInfo.rows[0] || {}).feed_start_date;
  const start = asDate(startYmd);
  if (!start) throw new Error('feed_info.txt carries no usable feed_start_date, so no week can be dated');
  const week = datesFrom(start, SERVICE_WEEK_DAYS);

  // One streaming pass. Terminal calls are kept whole; every other call contributes only the two
  // ends of its trip, which is what says whether a terminal call starts, ends or passes through.
  const terminalCalls = [];         // raw rows at a terminal stop
  const tripEnds = new Map();       // tripId -> {minSeq,maxSeq,first,last,firstStop,lastStop}
  streamTable(zip, 'stop_times.txt', (st) => {
    const seq = Number(st.stop_sequence);
    let ends = tripEnds.get(st.trip_id);
    if (!ends) {
      ends = { minSeq: seq, maxSeq: seq, first: null, last: null, firstStop: null, lastStop: null };
      tripEnds.set(st.trip_id, ends);
    }
    if (seq <= ends.minSeq) {
      ends.minSeq = seq;
      ends.first = st.departure_time || st.arrival_time;
      ends.firstStop = st.stop_id;
    }
    if (seq >= ends.maxSeq) {
      ends.maxSeq = seq;
      ends.last = st.arrival_time || st.departure_time;
      ends.lastStop = st.stop_id;
    }
    if (terminalIds.has(st.stop_id)) terminalCalls.push(st);
  });

  // HH:MM where the publisher wrote a whole minute, and the publisher's own HH:MM:SS where it did
  // not. Every one of the 5,046 times in this feed today ends :00, and truncating a time that did
  // not would be a silent loss rather than a shortening.
  const hm = (s) => {
    const raw = String(s === undefined || s === null ? '' : s).trim();
    const mins = hmsToMinutes(raw);
    if (mins === null) return null;
    return /:00$/.test(raw) || !/^\d{1,3}:\d{2}:\d{2}$/.test(raw) ? minutesToHm(mins) : raw;
  };
  const nameOf = (sid) => (stopById.get(sid) || {}).stop_name || null;

  const days = [];
  for (const date of week) {
    const running = servicesOn(calendar, calendarDates, date);
    for (const term of terminals) {
      const calls = terminalCalls
        .filter((st) => st.stop_id === term.stop_id)
        .filter((st) => {
          const t = tripById.get(st.trip_id);
          return t && running.has(t.service_id);
        })
        .map((st) => {
          const t = tripById.get(st.trip_id);
          const r = routeById.get(t.route_id) || {};
          const ends = tripEnds.get(st.trip_id) || {};
          const seq = Number(st.stop_sequence);
          return {
            tripId: st.trip_id,
            routeId: t.route_id,
            shortName: r.route_short_name || '',
            headsign: t.trip_headsign || '',
            directionId: t.direction_id === '' ? null : Number(t.direction_id),
            stopSequence: seq,
            arrival: hm(st.arrival_time),
            departure: hm(st.departure_time || st.arrival_time),
            firstStopOfTrip: seq === ends.minSeq,
            lastStopOfTrip: seq === ends.maxSeq,
            tripFirstStop: nameOf(ends.firstStop),
            tripLastStop: nameOf(ends.lastStop),
            tripStarts: hm(ends.first),
            tripEnds: hm(ends.last),
            pickupType: st.pickup_type === '' ? null : Number(st.pickup_type),
            dropOffType: st.drop_off_type === '' ? null : Number(st.drop_off_type)
          };
        })
        .sort((a, b) => (hmsToMinutes(a.departure) - hmsToMinutes(b.departure))
          || a.tripId.localeCompare(b.tripId));
      days.push({
        date,
        weekday: weekdayName(date),
        stopId: term.stop_id,
        stopName: term.stop_name,
        lat: Number(term.stop_lat),
        lon: Number(term.stop_lon),
        serviceIds: [...running].sort(),
        calls
      });
    }
  }

  return {
    week,
    weekFrom: start,
    terminals: terminals.map((s) => ({
      stopId: s.stop_id, name: s.stop_name, lat: Number(s.stop_lat), lon: Number(s.stop_lon)
    })),
    days
  };
}

/** Great circle distance in kilometres. Spherical earth, which is far below the precision needed. */
function distanceKm(a, b) {
  const R = 6371.0088;
  const toRad = Math.PI / 180;
  const dLat = (b.lat - a.lat) * toRad;
  const dLon = (b.lon - a.lon) * toRad;
  const s = Math.sin(dLat / 2) ** 2
    + Math.cos(a.lat * toRad) * Math.cos(b.lat * toRad) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

/**
 * Is the island present in each feed, measured rather than asserted.
 *
 * The reference is the island feed's own 44 stops: they are the island's published landings and
 * roadside stops, so no geography has to be invented to say where the island is. For every other
 * feed, this reports how many of its stops sit within a kilometre of any of those, and how far away
 * its nearest stop is. That turns "the island is not in the SEQ feed" from a search that found
 * nothing into a distance somebody else can re-measure. It is also why the name search is kept
 * beside it: the name search finds twenty five Stradbrokes in the SEQ feed and every one of them is
 * on the mainland, which is exactly the mistake this second witness exists to catch.
 */
function islandPresence(feeds) {
  const nsi = feeds.find((f) => f.feed === 'nsi' && f.downloaded);
  if (!nsi) return { reference: null, note: 'the island feed is not downloaded, so there is no reference to measure against' };
  const reference = nsi.allStops;
  const perFeed = [];
  for (const f of feeds) {
    if (!f.downloaded || f.feed === 'nsi') continue;
    let near = 0;
    let best = null;
    for (const s of f.allStops) {
      let d = Infinity;
      let ref = null;
      for (const r of reference) {
        const k = distanceKm(s, r);
        if (k < d) { d = k; ref = r; }
      }
      if (d <= 1) near++;
      if (!best || d < best.km) best = { km: d, stop: s, nearestIslandStop: ref };
    }
    perFeed.push({
      feed: f.feed,
      stopsInFeed: f.allStops.length,
      stopsWithin1kmOfAnIslandStop: near,
      nearestStop: best ? { stopId: best.stop.stopId, name: best.stop.name, km: Number(best.km.toFixed(2)) } : null,
      nearestIslandStop: best ? { stopId: best.nearestIslandStop.stopId, name: best.nearestIslandStop.name } : null
    });
  }
  return {
    reference: 'the ' + reference.length + ' stops in NSI_GTFS.zip stops.txt',
    perFeed
  };
}

function summarise(ids) {
  const today = islandToday();
  const friday = nextWeekday(today, 5);
  const feeds = [];
  for (const id of ids) {
    const file = path.join(INBOX, FEEDS[id].file);
    if (!existsSync(file)) {
      feeds.push({ feed: id, url: FEEDS[id].url, downloaded: false, note: 'not downloaded. run --fetch' });
      continue;
    }
    const buf = readFileSync(file);
    const s = summariseFeed(id, buf, friday);
    // The island feed alone gets the terminal week. The other three are here to prove an absence,
    // and asking them for bus calls at a ferry terminal they do not have would produce an empty
    // block that reads like a finding.
    if (id === 'nsi') s.terminalWeek = terminalWeek(openZip(buf));
    s.downloaded = true;
    s.bytes = statSync(file).size;
    s.sha256 = createHash('sha256').update(buf).digest('hex');
    s.path = path.relative(REPO_ROOT, file).replace(/\\/g, '/');
    feeds.push(s);
  }

  const island = feeds.filter((f) => f.downloaded && ISLAND_FEEDS.includes(f.feed));
  const anyFerryForIsland = island.some((f) => f.ferryRoutes.length > 0);
  const allVehicleFields = feeds.filter((f) => f.downloaded).flatMap((f) => f.vehicleCapacityFields);

  const presence = islandPresence(feeds);
  for (const f of feeds) delete f.allStops;

  return {
    generatedAt: islandNow(),
    fridayChecked: friday,
    searchBox: SEARCH_BOX,
    islandPresence: presence,
    feeds,
    crossings: {
      law: 'Passenger and vehicle crossings are never one figure. Each is its own lane below and '
        + 'neither is ever summed into the other.',
      passengerFerry: {
        inTransLinkGtfs: anyFerryForIsland,
        evidence: 'routes.txt in ' + ISLAND_FEEDS.join(' and ') + ' holds '
          + island.map((f) => f.feed + ': ' + f.counts.routes + ' routes, '
            + (f.counts.routesByMode.ferry || 0) + ' of route_type 4').join('; ')
          + '. The SEQ feed holds ferry routes and none of them calls at an island stop.'
      },
      vehicleBarge: {
        inTransLinkGtfs: false,
        evidence: 'No route of any type in any fetched feed serves an island landing by water, and '
          + 'no column in any file of any fetched feed records vehicle capacity. Columns scanned '
          + 'that could have: ' + (allVehicleFields.length ? allVehicleFields.join(', ') : 'none found')
      }
    }
  };
}

function printSummary(s) {
  const out = [];
  out.push('TransLink GTFS. Friday checked: ' + s.fridayChecked);
  for (const f of s.feeds) {
    out.push('');
    out.push('=== ' + f.feed + '  ' + f.url + ' ===');
    if (!f.downloaded) { out.push('  ' + f.note); continue; }
    out.push('  ' + f.path + ', ' + f.bytes.toLocaleString('en-AU') + ' bytes, sha256 ' + f.sha256);
    out.push('  files: ' + f.files.join(', '));
    for (const fi of f.feedInfo) {
      out.push('  feed_info: ' + [fi.feed_publisher_name, 'valid ' + fi.feed_start_date + ' to ' + fi.feed_end_date].filter(Boolean).join(' | '));
    }
    for (const a of f.agencies) out.push('  agency: ' + a.name + '  ' + (a.url || ''));
    out.push('  ' + f.counts.routes + ' routes ' + JSON.stringify(f.counts.routesByMode)
      + ', ' + f.counts.stops.toLocaleString('en-AU') + ' stops, ' + f.counts.trips.toLocaleString('en-AU')
      + ' trips, ' + f.counts.stopTimes.toLocaleString('en-AU') + ' stop times');
    out.push('  columns that could record vehicle capacity: '
      + (f.vehicleCapacityFields.length ? f.vehicleCapacityFields.join(', ') : 'none in any file'));

    out.push('  routes 880 and 881:');
    for (const n of f.namedRoutes) {
      out.push('    ' + n.shortName + ': ' + (n.present
        ? 'present, route_id ' + n.routeIds.join(', ') + ' (' + n.modes.join(', ') + ')'
        : 'NOT IN THIS FEED'));
      for (const ln of n.longNames) out.push('        ' + ln);
    }

    out.push('  ferry routes in this feed: ' + (f.ferryRoutes.length || 'none'));
    for (const r of f.ferryRoutes) {
      out.push('    ' + (r.shortName || r.routeId) + '  ' + r.longName + '  ' + r.tripsInFeed
        + ' trips, calls at a candidate island stop: ' + r.touchesCandidateStop);
    }

    out.push('  candidate island stops: ' + f.stopsMatchedByName.length + ' caught by a name term, '
      + f.stopsMatchedByBox.length + ' inside the search box');
    if (f.stopsInBoxButNotNamed.length) {
      out.push('    inside the box, not caught by a name term (the terms are narrow and the box is'
        + ' wider than the island, so both lists need an eye):');
      for (const st of f.stopsInBoxButNotNamed.slice(0, 12)) out.push('      ' + st.stopId + '  ' + st.name + '  ' + st.lat + ', ' + st.lon);
      if (f.stopsInBoxButNotNamed.length > 12) out.push('      ... and ' + (f.stopsInBoxButNotNamed.length - 12) + ' more');
    }

    out.push('  routes calling at a candidate island stop: ' + f.islandRoutes.length);
    for (const r of f.islandRoutes) {
      out.push('    ' + (r.shortName || r.routeId) + '  ' + r.mode + '  ' + r.longName);
      out.push('        route_id ' + r.routeId + ', operator ' + (r.operator || 'not stated in this feed')
        + ', ' + r.tripsInFeed + ' trips in the feed, ' + r.fridayTrips + ' on ' + s.fridayChecked);
      out.push('        Friday first departure ' + r.fridayFirstDeparture + ', last ' + r.fridayLastDeparture);
      for (const h of r.fridayHeadsigns) out.push('        towards ' + (h.headsign || '(no headsign)') + ': ' + h.trips + ' trips');
      for (const st of r.stops) {
        out.push('        ' + st.stopId + '  ' + st.name.padEnd(46) + ' first ' + st.firstDeparture
          + '  last ' + st.lastDeparture + '  ' + st.calls + ' calls');
      }
    }
    if (f.mainlandStops.length) {
      out.push('  mainland crossing stops in this feed: ' + f.mainlandStops.length);
      for (const st of f.mainlandStops.filter((m) => /toondah|weinam/i.test(m.name))) {
        out.push('    ' + st.stopId + '  ' + st.name + '  ' + st.lat + ', ' + st.lon);
      }
    }
  }

  out.push('');
  out.push('=== is the island in each feed, measured against ' + (s.islandPresence.reference || 'nothing') + ' ===');
  for (const p of s.islandPresence.perFeed || []) {
    out.push('  ' + p.feed.padEnd(8) + p.stopsInFeed.toLocaleString('en-AU') + ' stops, '
      + p.stopsWithin1kmOfAnIslandStop + ' of them within 1 km of an island stop');
    if (p.nearestStop) {
      out.push('           nearest: ' + p.nearestStop.name + ' (' + p.nearestStop.stopId + '), '
        + p.nearestStop.km + ' km from ' + p.nearestIslandStop.name);
    }
  }

  out.push('');
  out.push('=== the two crossings, never one figure ===');
  out.push('  passenger ferry in TransLink GTFS: ' + s.crossings.passengerFerry.inTransLinkGtfs);
  out.push('      ' + s.crossings.passengerFerry.evidence);
  out.push('  vehicle barge in TransLink GTFS:   ' + s.crossings.vehicleBarge.inTransLinkGtfs);
  out.push('      ' + s.crossings.vehicleBarge.evidence);
  return out.join('\n');
}

// ---------------------------------------------------------------------------------------------
// derive
// ---------------------------------------------------------------------------------------------

const SOURCE_IDS = {
  nsi: 'translink-gtfs-nsi',
  'nsi-sch': 'translink-gtfs-nsi-school',
  seq: 'translink-gtfs-seq',
  mif: 'translink-gtfs-mif'
};

function asDate(ymd) {
  return /^\d{8}$/.test(ymd) ? ymd.slice(0, 4) + '-' + ymd.slice(4, 6) + '-' + ymd.slice(6, 8) : null;
}

/**
 * The provenanced pack. Every record carries the eight fields src/kernel/record.js requires. The
 * source ids are NOT in data/_sources.json: registering them is a commit, and this wave commits
 * nothing derived. The pack says so in its own header rather than leaving the next agent to find out
 * when the gate rejects it.
 */
export function derive(summary) {
  const today = islandToday();
  const nsi = summary.feeds.find((f) => f.feed === 'nsi' && f.downloaded);
  if (!nsi) throw new Error('the island feed is not downloaded, so there is nothing honest to derive');

  const info = nsi.feedInfo[0] || {};
  const validFrom = asDate(info.feed_start_date) || today;
  const validTo = asDate(info.feed_end_date);
  const base = {
    source: SOURCE_IDS.nsi,
    validFrom,
    validTo,
    recordedAt: today,
    recordedUntil: null,
    confidence: 'high',
    register: 'known'
  };

  const stopById = new Map(nsi.stopsMatchedByBox.map((s) => [s.stopId, s]));
  for (const s of nsi.stopsMatchedByName) stopById.set(s.stopId, s);

  const seq = summary.feeds.find((f) => f.feed === 'seq' && f.downloaded);
  const sch = summary.feeds.find((f) => f.feed === 'nsi-sch' && f.downloaded);

  return {
    pack: 'transport-gtfs',
    version: '0.2.0',
    committable: true,
    about: 'Derived from the TransLink GTFS feeds by tools/ingest/gtfs.mjs --derive. Every figure '
      + 'here was read out of the publisher\'s own file, and the sha256 of each file it was read '
      + 'from is in the feeds block below. Nothing in this pack was typed in from a timetable.',
    licence: 'Creative Commons Attribution 4.0, as recorded by data.qld.gov.au for the dataset '
      + 'general-transit-feed-specification-gtfs-translink. ATTRIBUTION IS OWED WHEREVER THESE '
      + 'NUMBERS ARE DISPLAYED, and this pack is the place a display surface should read it from: '
      + 'the required wording is in the attribution field below and in data/_sources.json under '
      + 'translink-gtfs-nsi.',
    attribution: 'Contains public sector information licensed under Creative Commons Attribution '
      + '4.0. Source: Department of Transport and Main Roads, Translink Division, General Transit '
      + 'Feed Specification (GTFS) data, published at data.qld.gov.au. Retrieved 19 August 2026. '
      + 'Changes were made: figures here are counted, joined across files and filtered to this '
      + 'island, and are not the publisher\'s own published figures.',
    licenceQuestion: 'Board note 007 is the OpenStreetMap share-alike question and it is still '
      + 'open. It is not this pack\'s question. This lane is Creative Commons Attribution 4.0, '
      + 'which was read at data.qld.gov.au and recorded in data/_sources.json, so this pack is '
      + 'committed and the OpenStreetMap packs are not.',
    two_crossings_law: 'Passenger and vehicle crossings are counted separately in `crossings` and '
      + 'are never summed. A crossing this publisher does not carry appears with a null count and a '
      + 'stated reason, never folded into another figure.',
    feeds: summary.feeds.filter((f) => f.downloaded).map((f) => ({
      feed: f.feed, url: f.url, sha256: f.sha256, bytes: f.bytes, files: f.files, feedInfo: f.feedInfo
    })),
    fridayChecked: summary.fridayChecked,

    routes: nsi.islandRoutes.map((r) => ({
      ...base,
      id: 'route-' + r.routeId,
      routeId: r.routeId,
      shortName: r.shortName,
      longName: r.longName,
      mode: r.mode,
      routeType: r.routeType,
      operator: r.operator,
      fridayTrips: r.fridayTrips,
      fridayFirstDeparture: r.fridayFirstDeparture,
      fridayLastDeparture: r.fridayLastDeparture,
      tripsInFeed: r.tripsInFeed,
      locator: 'NSI_GTFS.zip routes.txt route_id ' + r.routeId
        + ', counted through trips.txt, calendar.txt, calendar_dates.txt and stop_times.txt'
    })),

    stops: [...stopById.values()].map((s) => ({
      ...base,
      id: 'stop-' + s.stopId,
      stopId: s.stopId,
      name: s.name,
      lat: s.lat,
      lon: s.lon,
      locator: 'NSI_GTFS.zip stops.txt stop_id ' + s.stopId
    })),

    // The two landings, and every bus call at them for one of each weekday. This is the half of
    // "does the bus meet the boat" that this publisher holds. The other half is not in any feed
    // this lane fetches and lives in data/crossings.json, from the operators and the owner.
    terminals: (nsi.terminalWeek ? nsi.terminalWeek.terminals : []).map((t) => ({
      ...base,
      id: 'terminal-' + t.stopId,
      stopId: t.stopId,
      name: t.name,
      lat: t.lat,
      lon: t.lon,
      selectedBy: 'the publisher\'s own stop_name carries "Ferry Terminal". Two of the 44 stops do.',
      locator: 'NSI_GTFS.zip stops.txt stop_id ' + t.stopId
    })),

    serviceWeek: nsi.terminalWeek ? {
      ...base,
      id: 'service-week',
      confidence: 'high',
      from: nsi.terminalWeek.weekFrom,
      dates: nsi.terminalWeek.week,
      note: 'Seven consecutive days from the feed\'s own feed_start_date, so every weekday appears '
        + 'once. It is a week inside this feed\'s validity, not a claim that every week looks like '
        + 'it: calendar.txt carries two further weekday services, NSI 26_27-42957 and '
        + 'NSI 26_27-42959, and calendar_dates.txt takes the term service out on sixteen dates in '
        + 'the school holidays, so the weekday timetable in this week is the school term one.',
      locator: 'NSI_GTFS.zip feed_info.txt feed_start_date, then calendar.txt and calendar_dates.txt'
    } : null,

    terminalCalls: (nsi.terminalWeek ? nsi.terminalWeek.days : []).map((d) => ({
      ...base,
      id: 'calls-' + d.stopId + '-' + d.date,
      stopId: d.stopId,
      stopName: d.stopName,
      date: d.date,
      weekday: d.weekday,
      serviceIds: d.serviceIds,
      callCount: d.calls.length,
      calls: d.calls,
      locator: 'NSI_GTFS.zip stop_times.txt for stop_id ' + d.stopId + ', joined to trips.txt and '
        + 'routes.txt, filtered to the services calendar.txt and calendar_dates.txt run on ' + d.date
    })),

    crossings: [
      {
        ...base,
        id: 'crossing-passenger-ferry',
        kind: 'passenger',
        inTransLinkGtfs: false,
        sailingsFriday: null,
        confidence: 'unknown',
        register: 'modelled',
        locator: 'absence. routes.txt in NSI_GTFS.zip holds ' + nsi.counts.routes
          + ' routes, both bus. The ferry routes in SEQ_GTFS.zip are '
          + (seq ? seq.ferryRoutes.map((r) => r.shortName || r.routeId).join(', ') : 'not checked, SEQ not downloaded')
          + ', none of which calls at an island stop.',
        note: 'The passenger crossing to Minjerribah is run commercially and is not a TransLink '
          + 'contracted service, so it is not in this publisher\'s timetable data. The count is null '
          + 'on purpose. Filling it from a website read once would be the fabrication this build '
          + 'exists to prevent.'
      },
      {
        ...base,
        id: 'crossing-vehicle-barge',
        kind: 'vehicle',
        inTransLinkGtfs: false,
        sailingsFriday: null,
        vehicleSpacesPerSailing: null,
        confidence: 'unknown',
        register: 'modelled',
        locator: 'absence. No file in any fetched feed carries a column that could record vehicle '
          + 'capacity: every column of every file was scanned and the hit list is empty.',
        note: 'GTFS describes passenger services. Even the control feed for Magnetic Island, where '
          + 'this publisher does contract an island ferry, carries a passenger route and no field '
          + 'for a car deck. So the vehicle crossing cannot come from this lane at all, and it must '
          + 'never be inferred from the passenger figure. It has its own row in '
          + 'docs/INGEST-STATUS.md.'
      }
    ],

    operatorDisagreement: sch ? {
      ...base,
      id: 'operator-name-disagreement',
      confidence: 'contested',
      names: [
        { feed: 'nsi', name: (nsi.agencies[0] || {}).name, url: (nsi.agencies[0] || {}).url },
        { feed: 'nsi-sch', name: (sch.agencies[0] || {}).name, url: (sch.agencies[0] || {}).url }
      ],
      locator: 'agency.txt in NSI_GTFS.zip and in NSI_SCH_GTFS.zip, fetched the same minute',
      note: 'One publisher, two names for one operator of one bus network, in two files fetched '
        + 'minutes apart. Recorded as contested rather than resolved by preference. Which name a '
        + 'player should see is a question for the owner, not a coin toss here.'
    } : null
  };
}

// ---------------------------------------------------------------------------------------------

async function main(argv) {
  const opts = { fetch: false, summarise: false, derive: false, json: false, help: false, feeds: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--fetch') opts.fetch = true;
    else if (a === '--summarise' || a === '--summarize') opts.summarise = true;
    else if (a === '--derive') opts.derive = true;
    else if (a === '--json') opts.json = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--feed') opts.feeds.push(argv[++i]);
    else if (a.startsWith('--feed=')) opts.feeds.push(a.slice(7));
    else { process.stderr.write('unknown argument: ' + a + '\n\n' + usage() + '\n'); return 2; }
  }
  if (opts.help || (!opts.fetch && !opts.summarise && !opts.derive)) {
    process.stdout.write(usage() + '\n');
    return opts.help ? 0 : 2;
  }
  const ids = opts.feeds.length ? opts.feeds : DEFAULT_FEEDS;
  for (const id of ids) {
    if (!FEEDS[id]) { process.stderr.write('unknown feed: ' + id + '\n\n' + usage() + '\n'); return 2; }
  }

  if (opts.fetch) {
    const code = await doFetch(ids, opts);
    if (code !== 0) return code;
  }

  if (opts.summarise || opts.derive) {
    const s = summarise(ids);
    mkdirSync(INBOX, { recursive: true });
    writeFileSync(SUMMARY_PATH, JSON.stringify(s, null, 2) + '\n');

    if (opts.summarise) {
      if (opts.json) process.stdout.write(JSON.stringify(s, null, 2) + '\n');
      else {
        process.stdout.write(printSummary(s) + '\n');
        process.stdout.write('\nwrote ' + path.relative(REPO_ROOT, SUMMARY_PATH).replace(/\\/g, '/') + '\n');
      }
    }

    if (opts.derive) {
      mkdirSync(DERIVED, { recursive: true });
      const pack = derive(s);
      writeFileSync(PACK_PATH, JSON.stringify(pack, null, 2) + '\n');
      if (!opts.json) {
        process.stdout.write('\nderived pack: ' + path.relative(REPO_ROOT, PACK_PATH).replace(/\\/g, '/') + '\n');
        process.stdout.write('  ' + pack.routes.length + ' routes, ' + pack.stops.length + ' stops, '
          + pack.crossings.length + ' crossing lanes\n');
        for (const r of pack.routes) {
          process.stdout.write('  route ' + r.shortName + ': ' + r.fridayTrips + ' trips on '
            + pack.fridayChecked + ', ' + r.fridayFirstDeparture + ' to ' + r.fridayLastDeparture + '\n');
        }
        for (const c of pack.crossings) {
          process.stdout.write('  crossing ' + c.kind + ': in TransLink GTFS ' + c.inTransLinkGtfs
            + ', Friday sailings ' + (c.sailingsFriday === null ? 'null, not in this lane' : c.sailingsFriday) + '\n');
        }
        process.stdout.write('  ' + pack.terminals.length + ' ferry terminals, '
          + pack.terminalCalls.length + ' terminal service days, '
          + pack.terminalCalls.reduce((n, d) => n + d.callCount, 0) + ' bus calls\n');
        for (const d of pack.terminalCalls) {
          process.stdout.write('    ' + d.date + ' ' + d.weekday.padEnd(10) + d.stopId + '  '
            + String(d.callCount).padStart(2) + ' calls  ' + d.stopName + '\n');
        }
        process.stdout.write('  COMMITTABLE: CC-BY 4.0, attribution in the pack and in '
          + 'data/_sources.json. Copy to data/transport-gtfs.json to commit it.\n');
      }
    }
  }

  return 0;
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));
if (invokedDirectly) {
  main(process.argv.slice(2)).then((code) => { process.exitCode = code; }).catch((err) => {
    process.stderr.write(String(err && err.stack ? err.stack : err) + '\n');
    process.exitCode = 1;
  });
}

export { summarise, summariseFeed };
