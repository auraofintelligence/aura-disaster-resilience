#!/usr/bin/env node
// Atlas of Living Australia: the living things lane.
//
//     node tools/ingest/ecology.mjs --fetch        occurrence records for three groups, staged raw
//     node tools/ingest/ecology.mjs --summarise    counts by species, dates, licences, townships
//     node tools/ingest/ecology.mjs --derive       a provenanced pack into ingest-inbox/derived/
//     node tools/ingest/ecology.mjs --fetch --group frogs
//     node tools/ingest/ecology.mjs --summarise --json
//
// WHAT THE FOUNDING PROMPT ASKED FOR AND WHAT THIS LANE DOES INSTEAD, ON PURPOSE.
// Section 5 names "real occurrence records for koalas, shorebirds and acid frogs". One of those
// three is a species, and the other two are group names that no source in this repository defines.
// "Shorebird" and "acid frog" are useful English and they are not taxonomy: a list of which species
// belong to either would be this agent deciding, and deciding is inventing. So this lane queries
// the two groups by a rank the Atlas itself indexes, order Charadriiformes and order Anura, and
// reports every species that has records, with its count and its family. The reader can then see
// which are waders and which are gulls, and no species is named here that this island has no
// records for. That is the rule this file is built around: a name that appears below appeared in
// the Atlas first.
//
// HOW THE ISLAND IS BOUNDED, IN TWO STEPS AND TWO MECHANISMS.
// Step one is a rectangle sent to the Atlas as WKT. A rectangle over Moreton Bay also holds Peel
// Island, the northern end of South Stradbroke and a good deal of open water, so it is a fetch
// bound and never a finding. Step two happens here: every record's own coordinate is tested against
// the four OpenStreetMap locality polygons for this island, which is the same mechanism the
// OpenStreetMap lane used to cross-check its building count, and it is the number this tool calls
// an island count. Both figures are printed. A count that came from a rectangle and was reported as
// an island is the exact shape of the 1,059 error this repository exists to correct.
//
// MEASURED LIMITS OF THE SERVICE, NOT DOCUMENTED ONES.
// pageSize above 100 answers HTTP 503. startIndex at 10,000 answers an empty page. Both were found
// by running them on 19 August 2026 and both are recorded here so the next agent does not rediscover
// them. The consequence is that a group with more than 10,000 records cannot be paged as one query,
// so this lane pages by species: it asks for the species facet first, then walks each species, which
// keeps every query inside the window and also makes the download resumable.
//
// LICENCE IS PER RECORD HERE, WHICH IS UNUSUAL AND MATTERS.
// An Atlas occurrence carries the licence of the data resource that supplied it, so this island's
// records are not under one licence. The connector facets on that field and prints the split, so
// the mix is measured. Nothing derived is committed while board note 007 stands, and the per
// resource licences are the thing to read before that changes.
//
// This file may read a wall clock. The ban in gate/no-wallclock covers src/kernel, src/systems and
// src/world. The date a file was downloaded is not world state, it is the receipt.

import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { checkRecord } from '../../src/kernel/record.js';
import { localitiesFrom, localityAt, newestRaw as newestOsmRaw } from './osm.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..', '..');
const INBOX = path.join(ROOT, 'ingest-inbox');
const RAW_DIR = path.join(INBOX, 'ecology');
const DERIVED_DIR = path.join(INBOX, 'derived');

const ENDPOINT = 'https://biocache-ws.ala.org.au/ws/occurrences/search';
const AGENT = 'second-island/0.1 ingest connector (Minjerribah twin, paced at one request per 1.2 s)';
const SOURCE_ID = 'ala-occurrences';

/** Measured on 19 August 2026, not read in a document. Both were found by asking for more. */
export const LIMITS = {
  maxPageSize: 100,
  maxStartIndex: 10000,
  howFound: 'pageSize 200 and 300 answered HTTP 503 while 100 answered 200. startIndex 10000 '
    + 'answered 200 with an empty occurrences array while the same query at 0 returned a full page.'
};

/**
 * The fetch bound: a rectangle, and it is never reported as an island count.
 *
 * Its corners are the bounding box of the four OpenStreetMap locality polygons for this island,
 * rounded outward to four decimal places, which is why they are the numbers they are. Rounding
 * outward matters: a rectangle rounded inward would clip real records off the edge of the island and
 * the loss would be invisible.
 */
export const BOX = { minLon: 153.3894, minLat: -27.7438, maxLon: 153.5466, maxLat: -27.3880 };

export function boxWkt(b = BOX) {
  return `POLYGON((${b.minLon} ${b.maxLat},${b.maxLon} ${b.maxLat},${b.maxLon} ${b.minLat},`
    + `${b.minLon} ${b.minLat},${b.minLon} ${b.maxLat}))`;
}

/**
 * The three groups. Each carries the query the Atlas is actually sent and the reason for its rank.
 *
 * The koala is a species because the founding prompt names a species. The other two are orders
 * because the founding prompt names groups that are not taxonomic ranks, and picking the member
 * species myself would be the invention this repository exists to prevent.
 */
export const GROUPS = {
  koala: {
    q: 'taxa:"Phascolarctos cinereus"',
    what: 'Koala, Phascolarctos cinereus. A species, because the founding prompt names one.',
    askedFor: 'koalas'
  },
  shorebirds: {
    q: 'order:Charadriiformes',
    what: 'Order Charadriiformes. The waders, and also the gulls, terns and skuas, which are in the '
      + 'same order and are not shorebirds in the sense the founding prompt means. The split by '
      + 'family is printed so a reader can see which is which, and no member list is asserted here.',
    askedFor: 'shorebirds'
  },
  frogs: {
    q: 'order:Anura',
    what: 'Order Anura, the frogs. The founding prompt asks for "acid frogs", which is a real term '
      + 'for the wallum species of coastal south-east Queensland and is not a rank the Atlas '
      + 'indexes. No source in this repository defines its membership, so every frog species with '
      + 'records here is listed and none is labelled an acid frog by this tool.',
    askedFor: 'acid frogs'
  }
};

export const DEFAULT_GROUPS = Object.keys(GROUPS);

/** The fields asked for on each record. Narrow on purpose: a smaller page is a kinder request. */
export const RECORD_FIELDS = [
  'id', 'species', 'scientificName', 'family', 'order', 'taxonConceptID',
  'decimalLatitude', 'decimalLongitude', 'coordinateUncertaintyInMeters',
  'eventDate', 'year', 'month', 'basisOfRecord', 'occurrenceStatus',
  'dataResourceName', 'dataResourceUid', 'license',
  'stateConservation', 'countryConservation'
];

/** The facets asked for once per group, which is where the exact counts come from. */
export const FACETS = ['species', 'family', 'year', 'dataResourceName', 'license', 'basisOfRecord'];

// ---------------------------------------------------------------------------------------------

export function islandToday(nowMs = Date.now()) {
  return new Date(nowMs + 10 * 3600 * 1000).toISOString().slice(0, 10);
}

function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex');
}

const rel = (p) => path.relative(ROOT, p).split(path.sep).join('/');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------------------------
// One paced, retried request
// ---------------------------------------------------------------------------------------------

const PACE_MS = 1200;
let lastRequestAt = 0;

/**
 * One GET, paced and retried.
 *
 * The Atlas is a free public service and this lane makes on the order of two hundred requests, so
 * the pacing is not politeness theatre: hammering it produced HTTP 503 within seconds on the first
 * attempt at this lane. A 503 here is a rate limit rather than an outage, so it is retried with a
 * widening gap, and a request that still fails after four tries is returned as a failure and
 * recorded, never silently dropped.
 */
async function get(url, { tries = 4 } = {}) {
  for (let attempt = 1; attempt <= tries; attempt++) {
    const wait = Math.max(0, PACE_MS - (Date.now() - lastRequestAt));
    if (wait) await sleep(wait);
    lastRequestAt = Date.now();
    let res, text;
    try {
      res = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': AGENT } });
      text = await res.text();
    } catch (err) {
      if (attempt === tries) return { ok: false, status: 0, error: err.message, attempts: attempt };
      await sleep(2000 * attempt);
      continue;
    }
    if (res.status === 200) {
      try {
        return { ok: true, status: 200, doc: JSON.parse(text), bytes: Buffer.byteLength(text), attempts: attempt };
      } catch (err) {
        return { ok: false, status: 200, error: 'response was not JSON: ' + err.message, attempts: attempt };
      }
    }
    if (attempt === tries) {
      return { ok: false, status: res.status, error: text.slice(0, 200).replace(/\s+/g, ' '), attempts: attempt };
    }
    await sleep(2500 * attempt);
  }
  return { ok: false, status: 0, error: 'unreachable', attempts: tries };
}

function searchUrl(params) {
  return ENDPOINT + '?' + new URLSearchParams(params).toString();
}

// ---------------------------------------------------------------------------------------------
// Fetch
// ---------------------------------------------------------------------------------------------

async function fetchGroup(groupId, force) {
  const group = GROUPS[groupId];
  mkdirSync(RAW_DIR, { recursive: true });
  const day = islandToday();
  const outPath = path.join(RAW_DIR, `${groupId}-${day}.json`);
  const receiptPath = path.join(RAW_DIR, `${groupId}-${day}.receipt.json`);

  if (existsSync(outPath) && !force) {
    console.log(`already staged, not refetching: ${rel(outPath)}`);
    console.log('pass --force to replace it. --summarise and --derive read this file and never fetch.');
    return { outPath, refetched: false };
  }

  const wkt = boxWkt();
  const startedAt = new Date().toISOString();
  const t0 = Date.now();
  const failures = [];

  // 1. The facets. One request, and the counts in it are computed by the Atlas over the whole
  //    matching set, so they are exact rather than a total of what this tool managed to download.
  const facetUrl = searchUrl({
    q: group.q, wkt, pageSize: '0', facets: FACETS.join(','), flimit: '-1'
  });
  console.log(`GET  facets      ${group.q}`);
  const facetRes = await get(facetUrl);
  if (!facetRes.ok) {
    console.error(`FETCH FAILED on the facet query: HTTP ${facetRes.status} ${facetRes.error}`);
    console.error('Nothing was written for this group. Record the failure in docs/INGEST-STATUS.md as it happened.');
    process.exitCode = 1;
    return null;
  }
  const total = facetRes.doc.totalRecords;
  const facets = {};
  for (const f of facetRes.doc.facetResults || []) {
    facets[f.fieldName] = f.fieldResult.map((r) => ({ label: r.label, count: r.count }));
  }
  const speciesFacet = facets.species || [];
  console.log(`     ${total} records in the rectangle, ${speciesFacet.length} species facet values`);

  // 2. The records, paged by species so that no single query has to reach past the 10,000 window.
  //    A species with more than 10,000 records in this box would still not fit, so the shortfall is
  //    measured per species and reported rather than assumed away.
  const records = [];
  const perSpecies = [];
  for (const s of speciesFacet) {
    const isNoValue = /^-species:\*$/.test(s.fq || '') || s.label === 'Not supplied';
    const fq = isNoValue ? '-species:*' : `species:"${s.label}"`;
    let got = 0;
    let truncated = false;
    for (let start = 0; start < s.count; start += LIMITS.maxPageSize) {
      if (start >= LIMITS.maxStartIndex) { truncated = true; break; }
      const u = searchUrl({
        q: group.q, wkt, fq, pageSize: String(LIMITS.maxPageSize), startIndex: String(start),
        fl: RECORD_FIELDS.join(','), sort: 'id', dir: 'asc'
      });
      const page = await get(u);
      if (!page.ok) {
        failures.push({ species: s.label, startIndex: start, status: page.status, error: page.error, attempts: page.attempts });
        continue;
      }
      const occ = page.doc.occurrences || [];
      for (const o of occ) records.push(o);
      got += occ.length;
      if (!occ.length) break;
    }
    perSpecies.push({ species: s.label, facetCount: s.count, downloaded: got, truncatedAt10000: truncated });
    process.stdout.write(`\r     downloaded ${records.length} of ${total}   `);
  }
  process.stdout.write('\n');

  const elapsedMs = Date.now() - t0;
  const doc = {
    tool: 'tools/ingest/ecology.mjs --fetch',
    group: groupId,
    query: group.q,
    what: group.what,
    askedFor: group.askedFor,
    endpoint: ENDPOINT,
    facetUrl,
    boundingBoxWkt: wkt,
    boundingBox: BOX,
    boundNote: 'This rectangle is a fetch bound and is not an island. Island membership is decided '
      + 'in --summarise by point in polygon against the OpenStreetMap locality boundaries.',
    limits: LIMITS,
    requestedAt: startedAt,
    elapsedMs,
    totalInBox: total,
    downloaded: records.length,
    perSpecies,
    facets,
    failures,
    records
  };
  const body = Buffer.from(JSON.stringify(doc, null, 1) + '\n');
  writeFileSync(outPath, body);

  const receipt = {
    tool: 'tools/ingest/ecology.mjs --fetch',
    group: groupId,
    query: group.q,
    facetUrl,
    requestedAt: startedAt,
    elapsedMs,
    totalInBox: total,
    downloaded: records.length,
    shortfall: total - records.length,
    failedPages: failures.length,
    bytes: body.length,
    sha256: sha256(body),
    rawFile: rel(outPath),
    licence: 'Per record. An Atlas occurrence carries the licence of the data resource that supplied '
      + 'it, and the split for this group is in the facet the Atlas spells license, inside the '
      + 'staged file.'
  };
  writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');

  console.log(`     ${records.length} downloaded of ${total} in the box, shortfall ${receipt.shortfall}, `
    + `${failures.length} failed pages, ${Math.round(elapsedMs / 1000)} s`);
  console.log(`sha256 ${receipt.sha256}`);
  console.log(`staged  ${receipt.rawFile}`);
  console.log(`receipt ${rel(receiptPath)}`);
  if (failures.length) {
    console.log('     failed pages, listed rather than hidden:');
    for (const f of failures.slice(0, 10)) console.log(`       ${f.species} at ${f.startIndex}: HTTP ${f.status} ${f.error}`);
  }
  return { outPath, refetched: true };
}

// ---------------------------------------------------------------------------------------------
// Reading the staged files
// ---------------------------------------------------------------------------------------------

export function newestRaw(groupId) {
  if (!existsSync(RAW_DIR)) return null;
  const files = readdirSync(RAW_DIR)
    .filter((f) => f.startsWith(groupId + '-') && f.endsWith('.json') && !f.endsWith('.receipt.json'))
    .sort();
  return files.length ? path.join(RAW_DIR, files[files.length - 1]) : null;
}

function loadGroup(groupId) {
  const file = newestRaw(groupId);
  if (!file) return null;
  const bytes = readFileSync(file);
  return { file, bytes, doc: JSON.parse(bytes.toString('utf8')) };
}

/**
 * The island boundary, borrowed from the OpenStreetMap lane's staged extract.
 *
 * This is a deliberate dependency between two connectors and not an accident. The OpenStreetMap
 * lane already fetched the four locality polygons, already assembled their rings, and already
 * cross-checked that bound against an independent one: it and the coastline relation disagreed on
 * exactly one building, a ferry terminal roof standing over water. Re-fetching the same polygons
 * here would be a second copy to keep true for no gain. When that extract is not staged, this
 * returns null and every island figure below is reported as unavailable rather than as a rectangle.
 */
function islandLocalities() {
  const file = newestOsmRaw('overpass-island');
  if (!file) return null;
  const doc = JSON.parse(readFileSync(file, 'utf8'));
  const localities = localitiesFrom(doc);
  return localities.length ? { file, localities } : null;
}

// ---------------------------------------------------------------------------------------------
// Summarise
// ---------------------------------------------------------------------------------------------

function tally(map, k) { map.set(k, (map.get(k) || 0) + 1); }
function sortedCounts(map) {
  return [...map.entries()].sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1));
}

/** ALA returns eventDate as epoch milliseconds. Null when absent or unparseable. */
export function eventDay(record) {
  const v = record.eventDate;
  if (typeof v === 'number' && Number.isFinite(v)) {
    return new Date(v + 10 * 3600 * 1000).toISOString().slice(0, 10);
  }
  if (typeof v === 'string') {
    const ms = Date.parse(v);
    if (Number.isFinite(ms)) return new Date(ms + 10 * 3600 * 1000).toISOString().slice(0, 10);
  }
  return null;
}

function summariseGroup(groupId, island) {
  const raw = loadGroup(groupId);
  if (!raw) return { group: groupId, staged: false };
  const doc = raw.doc;

  const bySpeciesBox = new Map();
  const bySpeciesIsland = new Map();
  const byFamilyIsland = new Map();
  const byLicence = new Map();
  const byResource = new Map();
  const byLocality = new Map();
  const speciesMeta = new Map();
  const dayResources = new Map();
  let onIsland = 0;
  let offIsland = 0;
  let noCoordinate = 0;
  let noDate = 0;
  let earliest = null, latest = null;
  let earliestIsland = null, latestIsland = null;

  for (const r of doc.records) {
    const sp = r.species || '(no species on the record)';
    tally(bySpeciesBox, sp);
    const day = eventDay(r);
    if (!day) noDate++;
    else {
      if (earliest === null || day < earliest) earliest = day;
      if (latest === null || day > latest) latest = day;
    }
    if (typeof r.decimalLatitude !== 'number' || typeof r.decimalLongitude !== 'number') {
      noCoordinate++;
      continue;
    }
    if (!island) continue;
    const loc = localityAt(r.decimalLongitude, r.decimalLatitude, island.localities);
    if (!loc) { offIsland++; continue; }
    onIsland++;
    if (day) {
      if (!dayResources.has(day)) dayResources.set(day, new Map());
      tally(dayResources.get(day), r.dataResourceName || '(no data resource on the record)');
    }
    tally(byLocality, loc);
    tally(bySpeciesIsland, sp);
    if (r.family) tally(byFamilyIsland, r.family);
    tally(byLicence, r.license || '(no licence on the record)');
    tally(byResource, r.dataResourceName || '(no data resource on the record)');
    if (!speciesMeta.has(sp)) {
      speciesMeta.set(sp, {
        scientificName: r.scientificName || null,
        family: r.family || null,
        taxonConceptID: r.taxonConceptID || null,
        stateConservation: r.stateConservation || null,
        countryConservation: r.countryConservation || null,
        firstDay: null, lastDay: null
      });
    }
    const meta = speciesMeta.get(sp);
    if (day) {
      if (meta.firstDay === null || day < meta.firstDay) meta.firstDay = day;
      if (meta.lastDay === null || day > meta.lastDay) meta.lastDay = day;
      if (earliestIsland === null || day < earliestIsland) earliestIsland = day;
      if (latestIsland === null || day > latestIsland) latestIsland = day;
    }
    if (r.stateConservation && !meta.stateConservation) meta.stateConservation = r.stateConservation;
    if (r.countryConservation && !meta.countryConservation) meta.countryConservation = r.countryConservation;
  }

  // Days, and what is on them. A date range is only as good as its endpoints, and an endpoint that
  // is shared by dozens of records from one supplier is either one operation on one day or a
  // sentinel value standing in for "date unknown". This tool cannot tell those apart and does not
  // guess: it reports the split and lets a reader decide. What it will not do is print an earliest
  // date without saying how many records sit on it and who supplied them.
  const describeDay = (day) => {
    const m = dayResources.get(day);
    if (!m) return null;
    const split = sortedCounts(m);
    return {
      day,
      records: split.reduce((a, [, n]) => a + n, 0),
      resources: split.map(([name, n]) => ({ dataResourceName: name, records: n })),
      singleResource: split.length === 1
    };
  };
  const repeatedDays = [...dayResources.entries()]
    .map(([day]) => describeDay(day))
    .sort((a, b) => b.records - a.records || (a.day < b.day ? -1 : 1))
    .slice(0, 8);

  return {
    group: groupId,
    staged: true,
    rawFile: rel(raw.file),
    sha256: sha256(raw.bytes),
    query: doc.query,
    what: doc.what,
    askedFor: doc.askedFor,
    fetchedAt: doc.requestedAt,
    box: { total: doc.totalInBox, downloaded: doc.downloaded, shortfall: doc.totalInBox - doc.downloaded, failedPages: doc.failures.length },
    truncatedSpecies: doc.perSpecies.filter((s) => s.truncatedAt10000),
    island: island ? {
      records: onIsland,
      offIsland,
      noCoordinate,
      dateRange: {
        earliest: earliestIsland,
        latest: latestIsland,
        earliestDay: earliestIsland ? describeDay(earliestIsland) : null,
        latestDay: latestIsland ? describeDay(latestIsland) : null
      },
      repeatedDays,
      byLocality: sortedCounts(byLocality),
      bySpecies: sortedCounts(bySpeciesIsland).map(([name, count]) => ({
        species: name, count, ...speciesMeta.get(name)
      })),
      byFamily: sortedCounts(byFamilyIsland),
      byLicence: sortedCounts(byLicence),
      byDataResource: sortedCounts(byResource)
    } : null,
    boxOnly: {
      bySpecies: sortedCounts(bySpeciesBox).slice(0, 10),
      dateRange: { earliest, latest },
      recordsWithNoDate: noDate
    }
  };
}

function summarise({ json, groups, silent = false }) {
  const island = islandLocalities();
  const result = {
    bound: {
      fetchRectangle: BOX,
      islandDecidedBy: island
        ? `point in polygon against ${island.localities.length} OpenStreetMap locality polygons, from ${rel(island.file)}`
        : null,
      islandBoundAvailable: Boolean(island),
      note: island ? null
        : 'The OpenStreetMap extract is not staged, so no island figure can be produced. Run '
          + 'node tools/ingest/osm.mjs --fetch first. Every count below is for the rectangle, which '
          + 'holds other islands and a lot of water, and a rectangle count is not an island count.'
    },
    limits: LIMITS,
    groups: groups.map((g) => summariseGroup(g, island))
  };

  if (silent) return result;
  if (json) { console.log(JSON.stringify(result, null, 2)); return result; }

  const say = (s) => console.log(s);
  say(`fetch rectangle  ${BOX.minLat} to ${BOX.maxLat} latitude, ${BOX.minLon} to ${BOX.maxLon} longitude`);
  say(`island bound     ${result.bound.islandDecidedBy || 'NOT AVAILABLE'}`);
  if (result.bound.note) say(`                 ${result.bound.note}`);
  say(`measured limits  pageSize ${LIMITS.maxPageSize}, startIndex window ${LIMITS.maxStartIndex}`);
  say('');

  for (const g of result.groups) {
    say('='.repeat(96));
    if (!g.staged) {
      say(`${g.group}: nothing staged. run node tools/ingest/ecology.mjs --fetch --group ${g.group}`);
      say('');
      continue;
    }
    say(`${g.group.toUpperCase()}   asked for as "${g.askedFor}", queried as ${g.query}`);
    say(`  ${g.what}`);
    say(`  raw ${g.rawFile}`);
    say(`  sha256 ${g.sha256}`);
    say(`  in the rectangle: ${g.box.total} records, ${g.box.downloaded} downloaded, `
      + `shortfall ${g.box.shortfall}, failed pages ${g.box.failedPages}`);
    for (const t of g.truncatedSpecies) {
      say(`  TRUNCATED: ${t.species} has ${t.facetCount} records in the box and the paging window `
        + `stops at ${LIMITS.maxStartIndex}, so ${t.downloaded} were taken.`);
    }
    if (!g.island) { say('  no island figure: the OpenStreetMap bound is not staged'); say(''); continue; }
    say('');
    say(`  ON THIS ISLAND: ${g.island.records} records`);
    say(`    not on this island but inside the rectangle: ${g.island.offIsland}`);
    say(`    with no usable coordinate: ${g.island.noCoordinate}`);
    say(`    date range on the island: ${g.island.dateRange.earliest || 'none dated'} to ${g.island.dateRange.latest || 'none dated'}`);
    const ed = g.island.dateRange.earliestDay;
    if (ed) {
      say(`      the earliest day carries ${ed.records} record${ed.records === 1 ? '' : 's'}`
        + `${ed.singleResource ? ', all from one supplier' : ` from ${ed.resources.length} suppliers`}:`);
      for (const r of ed.resources) say(`        ${String(r.records).padStart(5)}  ${r.dataResourceName}`);
      if (ed.singleResource && ed.records >= 10) {
        say('      A date shared by that many records from one supplier is either one operation on one');
        say('      day or a stand-in for "date unknown". This tool cannot tell those apart and does not');
        say('      guess. Read the endpoint before quoting the range.');
      }
    }
    say('    the eight most repeated days on the island, and who supplied them:');
    for (const d of g.island.repeatedDays) {
      say(`      ${d.day}  ${String(d.records).padStart(5)}  ${d.resources.map((r) => `${r.dataResourceName} ${r.records}`).join('; ')}`);
    }
    say('    by locality:');
    for (const [k, n] of g.island.byLocality) say(`      ${String(n).padStart(6)}  ${k}`);
    say('');
    say(`    BY SPECIES, ${g.island.bySpecies.length} with records on this island:`);
    say('      count  species                                    family              first        last         listed');
    for (const s of g.island.bySpecies) {
      const listed = [s.countryConservation, s.stateConservation].filter(Boolean).join(' / ');
      say(`      ${String(s.count).padStart(5)}  ${String(s.species).padEnd(42)} ${String(s.family || '').padEnd(19)} `
        + `${String(s.firstDay || '').padEnd(12)} ${String(s.lastDay || '').padEnd(12)} ${listed}`);
    }
    say('');
    say('    by family:');
    for (const [k, n] of g.island.byFamily) say(`      ${String(n).padStart(6)}  ${k}`);
    say('');
    say('    by licence on the record:');
    for (const [k, n] of g.island.byLicence) say(`      ${String(n).padStart(6)}  ${k}`);
    say('');
    say('    by data resource, the top ten:');
    for (const [k, n] of g.island.byDataResource.slice(0, 10)) say(`      ${String(n).padStart(6)}  ${k}`);
    say('');
  }
  say('='.repeat(96));
  say('ATTRIBUTION');
  for (const line of ATTRIBUTION) say('  ' + line);
  return result;
}

export const ATTRIBUTION = [
  'Occurrence records from the Atlas of Living Australia, https://www.ala.org.au, accessed 19',
  '  August 2026.',
  'The Atlas aggregates records from many data resources and each record carries its own licence.',
  '  The split for each group is measured and printed by --summarise, and every derived record',
  '  carries the licence and the data resource name that came with it.',
  'A count here is a count of records, which is a count of observations, and it is not a count of',
  '  animals. Two people who photograph the same koala on the same afternoon make two records.'
];

// ---------------------------------------------------------------------------------------------
// Derive
// ---------------------------------------------------------------------------------------------

/**
 * Provenance for one occurrence record.
 *
 *   validFrom     the day the observation was made, which is the day the animal was there. A record
 *                 with no date gets the fetch date and a lowered confidence, and says which.
 *   validTo       the day after. An occurrence is a sighting at a moment, not a standing fact about
 *                 the island, and a null validTo would say the animal is still at that coordinate.
 *   confidence    medium when the record carries a date and a coordinate, low when it does not.
 *                 Not high: an occurrence is one observer's word, unreviewed by anybody here, and
 *                 the Atlas mixes museum specimens with phone photographs in one index.
 *   register      known. It is a record of a real observation, not a model of one.
 */
function provenanceFor(rec, day, fetchDay, groupId) {
  const dated = Boolean(day);
  const next = dated ? new Date(Date.parse(day + 'T00:00:00Z') + 86400000).toISOString().slice(0, 10) : null;
  return {
    source: SOURCE_ID,
    locator: `Atlas of Living Australia occurrence ${rec.uuid || rec.id}, `
      + `https://biocache.ala.org.au/occurrences/${rec.uuid || rec.id}, fetched by group ${groupId}`,
    validFrom: dated ? day : fetchDay,
    validTo: dated ? next : null,
    recordedAt: fetchDay,
    recordedUntil: null,
    confidence: dated ? 'medium' : 'low',
    register: 'known',
    provenanceNote: dated
      ? 'validFrom is the observation date on the record. An occurrence is a sighting at a moment, '
        + 'so validTo is the next day: this record never said the animal stayed.'
      : 'The record carried no usable date, so validFrom is the date this lane fetched it and '
        + 'confidence is low. The date says when the twin saw the record and nothing about when the '
        + 'animal was there.'
  };
}

function derive({ json, groups }) {
  const island = islandLocalities();
  const today = islandToday();
  const out = [];
  const summary = summarise({ json: false, groups, silent: true });

  for (const groupId of groups) {
    const raw = loadGroup(groupId);
    if (!raw) continue;
    for (const r of raw.doc.records) {
      if (typeof r.decimalLatitude !== 'number' || typeof r.decimalLongitude !== 'number') continue;
      const loc = island ? localityAt(r.decimalLongitude, r.decimalLatitude, island.localities) : null;
      if (island && !loc) continue;
      const day = eventDay(r);
      out.push({
        id: `ala-${r.uuid || r.id}`,
        kind: 'occurrence',
        group: groupId,
        species: r.species || null,
        scientificName: r.scientificName || null,
        family: r.family || null,
        order: r.order || null,
        taxonConceptID: r.taxonConceptID || null,
        lat: r.decimalLatitude,
        lon: r.decimalLongitude,
        coordinateUncertaintyM: r.coordinateUncertaintyInMeters ?? null,
        crs: 'WGS84 decimal degrees',
        locality: loc,
        observedOn: day,
        basisOfRecord: r.basisOfRecord || null,
        dataResourceName: r.dataResourceName || null,
        recordLicence: r.license || null,
        stateConservation: r.stateConservation || null,
        countryConservation: r.countryConservation || null,
        ...provenanceFor(r, day, today, groupId)
      });
    }
  }

  const pack = {
    pack: 'ecology-ala-occurrences',
    version: '0.1.0',
    about: 'Atlas of Living Australia occurrence records whose own coordinate falls inside one of '
      + 'this island\'s four OpenStreetMap locality polygons. NOT COMMITTABLE: it lives under '
      + 'ingest-inbox/, which .gitignore seals and tools/gate/sealed.mjs proves sealed by asking '
      + 'git. A record here is one observation, not one animal, and the pack must never be summed '
      + 'into a population. Species names in this pack came from the Atlas and none was chosen '
      + 'here: the two group queries are by taxonomic order, because "shorebird" and "acid frog" '
      + 'are not ranks and picking their members would be inventing.',
    attribution: ATTRIBUTION.join(' '),
    licenceNote: 'Licence is per record. Every record carries the recordLicence and the '
      + 'dataResourceName that came with it, so nothing here is under one blanket licence.',
    bound: {
      fetchRectangle: BOX,
      islandDecidedBy: island ? rel(island.file) : null,
      islandBoundAvailable: Boolean(island)
    },
    groups: summary.groups.map((g) => ({
      group: g.group, query: g.query, askedFor: g.askedFor,
      inBox: g.staged ? g.box.total : null,
      downloaded: g.staged ? g.box.downloaded : null,
      onIsland: g.staged && g.island ? g.island.records : null
    })),
    count: out.length,
    occurrences: out
  };

  let sourceIds = null;
  try {
    sourceIds = new Set(Object.keys(JSON.parse(readFileSync(path.join(ROOT, 'data', '_sources.json'), 'utf8'))));
  } catch (err) {
    console.error(`could not read data/_sources.json: ${err.message}`);
  }
  const problems = [];
  for (const rec of out) {
    for (const p of checkRecord(rec, sourceIds ? { sourceIds, where: rec.id } : { where: rec.id })) problems.push(p);
  }

  mkdirSync(DERIVED_DIR, { recursive: true });
  const abs = path.join(DERIVED_DIR, `ecology-ala-occurrences-${today}.json`);
  writeFileSync(abs, JSON.stringify(pack, null, 1) + '\n');

  const result = {
    written: rel(abs),
    bytes: statSync(abs).size,
    records: out.length,
    byGroup: pack.groups,
    sourceIdsRead: sourceIds ? sourceIds.size : 0,
    provenanceProblems: problems
  };
  if (json) console.log(JSON.stringify(result, null, 2));
  else {
    console.log(`wrote ${result.written}  ${result.records} records, ${result.bytes} bytes`);
    for (const g of pack.groups) {
      console.log(`  ${g.group.padEnd(12)} ${g.inBox} in the rectangle, ${g.downloaded} downloaded, ${g.onIsland} on this island`);
    }
    console.log(`checked ${result.records} records with src/kernel/record.js against ${result.sourceIdsRead} source ids`);
    console.log(problems.length ? `PROVENANCE PROBLEMS: ${problems.length}` : 'provenance: 0 problems');
    for (const p of problems.slice(0, 20)) console.log('  ' + p);
    console.log('NOT COMMITTABLE: ingest-inbox/ is sealed and stays sealed this wave.');
  }
  if (problems.length) process.exitCode = 1;
  return result;
}

// ---------------------------------------------------------------------------------------------

const USAGE = `node tools/ingest/ecology.mjs <mode>

  --fetch        occurrence records for ${DEFAULT_GROUPS.join(', ')}, bounded by a rectangle over
                 this island, paged by species and staged raw with a receipt
  --summarise    counts by species, by family, by licence and by locality, with the island figure
                 decided by point in polygon rather than by the rectangle. No network
  --derive       a provenanced pack into ingest-inbox/derived/. No network

  --group G      one of ${DEFAULT_GROUPS.join(', ')} rather than all three
  --force        allow --fetch to replace a raw file already staged for today
  --json         machine readable output for --summarise and --derive

Nothing this tool writes is committable. ingest-inbox/ is sealed: board note 007.
`;

async function main(argv) {
  const has = (f) => argv.includes(f);
  const val = (f) => {
    const i = argv.indexOf(f);
    return i >= 0 ? argv[i + 1] : null;
  };
  if (!argv.length || has('--help') || has('-h')) { console.log(USAGE); return; }

  const json = has('--json');
  const force = has('--force');
  const one = val('--group');
  if (one && !GROUPS[one]) {
    console.error(`unknown group: ${one}. Known: ${DEFAULT_GROUPS.join(', ')}`);
    process.exitCode = 2;
    return;
  }
  const groups = one ? [one] : DEFAULT_GROUPS;

  if (has('--fetch')) {
    for (const g of groups) {
      console.log(`--- ${g}: ${GROUPS[g].what}`);
      await fetchGroup(g, force);
      console.log('');
    }
    return;
  }
  if (has('--summarise') || has('--summarize')) { summarise({ json, groups }); return; }
  if (has('--derive')) { derive({ json, groups }); return; }

  console.error(`unknown mode: ${argv.join(' ')}`);
  console.error(USAGE);
  process.exitCode = 2;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main(process.argv.slice(2));
}

export { summarise, derive };
