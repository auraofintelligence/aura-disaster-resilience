// TEST FIXTURES. These three systems are not part of the island and never will be.
//
// Nothing under src/ imports this file. It is loaded only when an instrument is asked for it with
// --fixtures, and it is loaded by a dynamic import so a plain run never even parses it. The systems
// here model nothing on Minjerribah, carry no provenance because they describe nothing real, and
// have names beginning `fixture.` so that a report which shows one is visibly a report about the
// instruments rather than about the island.
//
// Why they exist. An instrument cannot be validated against nothing, and stage 0's two real systems
// exercise very little of the kernel: solar writes nine numbers a tick and never touches the store,
// and tide is deliberately unfed and does no work at all. Neither creates an entity, neither has an
// event that anything listens to, and neither reads another system's state. A determinism
// instrument proven only against those two would be untested over most of what it is supposed to
// measure.
//
// Between them these three exercise:
//   entity create and destroy through the store   fixture.spawner
//   component writes into the dense typed arrays  fixture.spawner
//   an event emitted and an event listened to     fixture.spawner emits, fixture.tally listens
//   one system reading another's state            fixture.tally reads fixture.spawner
//   draws from a system's own named stream        fixture.spawner and fixture.jitter
//
// THE TWO FAULT HOOKS
//
// `nondeterminism`   fixture.jitter draws from Math.random instead of its own seeded stream. Two
//                    runs of the same seed then differ, and the difference is confined to that one
//                    system's own state and its own stream, so the instrument has exactly one name
//                    to report.
// `order-dependence` fixture.tally mixes the name of the system registered immediately before it
//                    into its accumulator. Registration order is the one thing the kernel promises
//                    cannot matter: systems tick in declared integer order, ties broken by name. So
//                    a run with the fixtures registered in a different order drifts, and only under
//                    --shuffle, which is what makes this fault the proof of the ordering rule
//                    rather than a second copy of the first fault.
// `fixture-throws`   fixture.spawner throws mid tick. Not in the stage 0 registry, and added here
//                    with that said out loud, because without it tools/headless.mjs has no fault
//                    that proves it and would be listed unproven: its claim to fail loudly when a
//                    system throws would rest on nobody having watched it. Whoever owns
//                    tools/faults.mjs should adopt this row or replace it with a better one.
//
// All three hooks are single branches on `faulty()`. With no fault set, `previousName` is never
// read, `Math.random` is never called and nothing throws, so behaviour is exactly what it would be
// if this comment block and those three branches were deleted.
//
// The stage 0 registry in docs/STAGE-0.md names src/systems/tide.js as the site of the
// `nondeterminism` fault. The tide is unfed by design: its tick returns on the first line and there
// is no draw there to corrupt, so a hook in that file would inject nothing and prove nothing. The
// hook lives here instead, on a system built to be broken.

import { faulty } from '../../src/kernel/faults.js';

/** In declared tick order. An instrument may print these to say what --fixtures added. */
export const FIXTURE_NAMES = ['fixture.spawner', 'fixture.tally', 'fixture.jitter'];

const C_DRIFT = 'fixture_drift';
const C_AGE = 'fixture_age';

/** Ceiling on live fixture entities. Reached only if the retirement age is raised a long way. */
const MAX_LIVE = 64;
/** Ticks an entity lives before it is retired, which is what makes destroy run every tick. */
const LIFESPAN_TICKS = 37;
/** Chance of a spawn on any tick, drawn from the spawner's own stream. */
const SPAWN_CHANCE = 0.35;
/** The tick the fixture-throws hook throws on. Early, so a short run reaches it. */
const THROW_TICK = 100;

/** FNV-1a over a string, so the order-dependence hook has a number to mix rather than a name. */
function nameMix(s) {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619) >>> 0;
  return h >>> 0;
}

/**
 * Register the three fixture systems.
 *
 * @param {import('../../src/kernel/world.js').World} world an unbooted world
 * @param {object} [opts]
 * @param {boolean} [opts.shuffle] register them in a different order. The declared orders do not
 *   change, so a healthy world must produce identical hashes either way. That equality is the
 *   proof of the ordering rule, and the `order-dependence` fault is what proves the proof can fail.
 * @returns {import('../../src/kernel/world.js').World} the same world
 */
export function registerFixtures(world, opts = {}) {
  const sequence = opts.shuffle
    ? ['jitter', 'tally', 'spawner']
    : ['spawner', 'tally', 'jitter'];
  for (const which of sequence) {
    if (which === 'spawner') registerSpawner(world);
    if (which === 'tally') registerTally(world, previousName(world));
    if (which === 'jitter') registerJitter(world);
  }
  return world;
}

/** The system registered immediately before this one, or '' on an empty world. */
function previousName(world) {
  return world.systems.length ? world.systems[world.systems.length - 1].name : '';
}

/**
 * Entities in and out of the store, and component writes through the dense arrays.
 *
 * Every ordering decision here is explicit, because the store's swap-with-last removal is only
 * deterministic if the removals are. Doomed entities are collected first and destroyed in entity id
 * order, so the free stack ends the tick in the same shape on every run.
 */
function registerSpawner(world) {
  world.system({
    name: 'fixture.spawner',
    order: 100,
    budgetMs: 2,
    emits: ['fixture.spawned', 'fixture.retired'],
    state: {
      live: 0,
      spawnedTotal: 0,
      retiredTotal: 0,
      lastSpawnTick: null,
      lastRetireTick: null,
      sumX: 0
    },

    boot(self, ctx) {
      ctx.store.defineComponent(C_DRIFT, { x: 'f64', y: 'f64', vx: 'f64', vy: 'f64' });
      ctx.store.defineComponent(C_AGE, { born: 'i32', ticks: 'i32' });
    },

    tick(self, ctx) {
      // The fixture-throws hook. With no fault set the first term is false and nothing else here
      // is evaluated.
      if (faulty('fixture-throws') && ctx.tick === THROW_TICK) {
        throw new Error('fixture.spawner threw on purpose at tick ' + ctx.tick + ', because ISLAND_FAULT is fixture-throws');
      }

      const store = ctx.store;

      // Move everything that exists, and wrap it, so the numbers stay bounded over a sim year.
      const drift = store.view(C_DRIFT);
      let sumX = 0;
      for (let i = 0; i < drift.count; i++) {
        drift.x[i] += drift.vx[i];
        drift.y[i] += drift.vy[i];
        if (drift.x[i] > 1) drift.x[i] -= 2;
        if (drift.x[i] < -1) drift.x[i] += 2;
        if (drift.y[i] > 1) drift.y[i] -= 2;
        if (drift.y[i] < -1) drift.y[i] += 2;
        sumX += drift.x[i];
      }
      self.sumX = sumX;

      const age = store.view(C_AGE);
      for (let i = 0; i < age.count; i++) age.ticks[i] += 1;

      const doomed = [];
      for (let i = 0; i < age.count; i++) {
        if (age.ticks[i] >= LIFESPAN_TICKS) doomed.push(age.entities[i]);
      }
      if (doomed.length) {
        doomed.sort((a, b) => a - b);
        for (const id of doomed) store.destroy(id);
        self.retiredTotal += doomed.length;
        self.lastRetireTick = ctx.tick;
        ctx.emit('fixture.retired', { tick: ctx.tick, count: doomed.length, entities: doomed });
      }

      // The draw happens on every tick whether or not it is used, so the number of draws this
      // system has made is a function of the tick count alone and nothing else.
      const roll = ctx.rng.float();
      const live = store.view(C_DRIFT).count;
      if (live < MAX_LIVE && roll < SPAWN_CHANCE) {
        const id = store.create();
        store.add(id, C_DRIFT, {
          x: ctx.rng.float() * 2 - 1,
          y: ctx.rng.float() * 2 - 1,
          vx: (ctx.rng.float() - 0.5) * 0.02,
          vy: (ctx.rng.float() - 0.5) * 0.02
        });
        store.add(id, C_AGE, { born: ctx.tick, ticks: 0 });
        self.spawnedTotal += 1;
        self.lastSpawnTick = ctx.tick;
        ctx.emit('fixture.spawned', { tick: ctx.tick, entity: id });
      }

      self.live = store.view(C_DRIFT).count;
    }
  });
}

/**
 * The listener, and the cross-system read.
 *
 * `backlog` is the interesting field: the world delivers an event at the start of the tick after it
 * was emitted, so a tally that counts events will sit one behind a spawner that counts spawns
 * whenever one lands. A number that is usually zero and sometimes one is a better fixture than a
 * number that is always zero.
 *
 * @param {string} registeredAfter the system registered immediately before this one. Read only by
 *   the order-dependence hook. With no fault set it is never read.
 */
function registerTally(world, registeredAfter) {
  const previous = String(registeredAfter || '');
  world.system({
    name: 'fixture.tally',
    order: 110,
    budgetMs: 2,
    listens: ['fixture.spawned', 'fixture.retired'],
    state: {
      spawnedSeen: 0,
      retiredSeen: 0,
      lastEventTick: null,
      lastEventType: null,
      liveSeen: 0,
      sumXSeen: 0,
      backlog: 0,
      mix: 0
    },

    onEvent(self, ev) {
      if (ev.type === 'fixture.spawned') self.spawnedSeen += 1;
      if (ev.type === 'fixture.retired') self.retiredSeen += ev.payload.count;
      self.lastEventTick = ev.tick;
      self.lastEventType = ev.type;
      if (faulty('order-dependence')) {
        self.mix = Math.imul(self.mix ^ nameMix(previous), 16777619) >>> 0;
      }
    },

    tick(self, ctx) {
      const spawner = ctx.read('fixture.spawner');
      self.liveSeen = spawner.live;
      self.sumXSeen = spawner.sumX;
      self.backlog = spawner.spawnedTotal - self.spawnedSeen;
    }
  });
}

/**
 * One draw a tick from its own named stream, and nothing else.
 *
 * Deliberately narrow. Its numbers reach no other system and never touch the store, so when the
 * nondeterminism hook is switched on there is exactly one system whose hash can move, and the
 * instrument either names it or is broken.
 */
function registerJitter(world) {
  world.system({
    name: 'fixture.jitter',
    order: 120,
    budgetMs: 2,
    state: { lastDraw: 0, sum: 0, aboveHalf: 0, draws: 0 },

    tick(self, ctx) {
      // The nondeterminism hook. With no fault set this is exactly `ctx.rng.float()`.
      const u = faulty('nondeterminism') ? Math.random() : ctx.rng.float();
      self.lastDraw = u;
      self.sum += u;
      self.draws += 1;
      if (u >= 0.5) self.aboveHalf += 1;
    }
  });
}
