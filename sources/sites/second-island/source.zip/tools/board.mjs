#!/usr/bin/env node
// The noticeboard. docs/CONTRACT.md section 6, and the founding prompt's board law.
//
// A finding that lives only in a transcript is treated as never made. Within a wave, agents speak
// only through the orchestrator's threading, and a full report can die with a session limit in
// transit. So a finding goes in a file, in the repository, where the next agent will find it whether
// or not this one gets to finish its sentence.
//
//     node tools/board.mjs read
//     node tools/board.mjs read --status open
//     node tools/board.mjs read --status open --full --json
//     node tools/board.mjs post --title "..." --status open --author "..." --body "..."
//     node tools/board.mjs post --title "..." --status open --author "..." --body-file out/note.txt
//     node tools/board.mjs set 003 --status resolved --note "what changed and where"
//
// The note shape is not defined here. It is defined by tools/gate/board.mjs, which validates it, and
// this tool is written to satisfy that check rather than to agree with it by coincidence. Front
// matter of three hyphens, then id, title, status, opened and author one per line, then three
// hyphens, then a body that says what was found, where, and what the next agent should do.
// `tags` and `resolved` are optional and are written after the five required fields.
//
// Ids are the note's number, zero padded to three digits. The next id is one past the highest this
// board has ever issued, and "ever issued" is asked of two witnesses: the files on disk now, and
// every note file git has ever seen added under docs/board/. A reply that lands on the wrong finding
// is worse than no reply, so a deleted note's number is not handed to something else. The residual
// gap is stated at idsGitHasSeen: a note created and deleted before it was ever committed is
// invisible to both witnesses.
//
// This file may use a wall clock. The ban in gate/no-wallclock covers src/kernel, src/systems and
// src/world, because a world whose state depends on when it ran cannot be diffed against itself. A
// note's opened date is not world state, it is the date a human wants to read. The date is computed
// in island civil time, UTC+10, from the same clock module the simulation uses, so a note posted by
// an agent on a machine set to another timezone still carries the island's date. `--opened` and
// `--resolved` override it, which is also what makes this tool testable.

import { readdirSync, readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { civilFromDays, ISLAND_UTC_OFFSET_MINUTES, TICKS_PER_DAY } from '../src/kernel/clock.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const BOARD_DIR = 'docs/board';

const STATUSES = ['open', 'taken', 'resolved', 'for-owner'];
// The order a person reads them in: what needs a human first, then what is live, then what is done.
const READ_ORDER = ['for-owner', 'open', 'taken', 'resolved'];
const REQUIRED = ['id', 'title', 'status', 'opened', 'author'];
const DATE = /^\d{4}-\d{2}-\d{2}$/;
const ID = /^\d{3,}$/;

function usage() {
  return [
    'node tools/board.mjs <command> [options]',
    '',
    'read                       every note, newest first, grouped by status',
    '  --status <s>             one of ' + STATUSES.join(', '),
    '  --full                   print each body in full instead of its first lines',
    '  --json                   machine readable output on stdout, nothing else',
    '',
    'post                       write a new note and print the path it landed at',
    '  --title <text>           required, one line',
    '  --status <s>             required, one of ' + STATUSES.join(', '),
    '  --author <text>          required, or set ISLAND_BOARD_AUTHOR',
    '  --body <text>            required unless --body-file is given. A literal \\n starts a new line',
    '  --body-file <path>       read the body from a file instead',
    '  --tags <a, b, c>         optional, comma separated, one line',
    '  --opened <YYYY-MM-DD>    optional, defaults to today in island civil time',
    '  --slug <text>            optional, defaults to a slug of the title',
    '',
    'set <id>                   change the status of an existing note',
    '  --status <s>             required, one of ' + STATUSES.join(', '),
    '  --note <text>            optional, appended to the body as a dated update',
    '  --title <text>           optional, replaces the title when a finding outgrows its heading.',
    '                           The file name does not change: it is the note\'s permanent handle',
    '  --resolved <YYYY-MM-DD>  optional, defaults to today in island civil time',
    '',
    'common',
    '  --root <dir>             the tree to work in, default the repository this file lives in',
    '',
    'Exit code is 0 on success, 2 on a usage or validation error.'
  ].join('\n');
}

// -------------------------------------------------------------------------------------------
// Arguments and dates
// -------------------------------------------------------------------------------------------

const VALUE_FLAGS = new Set([
  'status', 'title', 'author', 'body', 'body-file', 'tags', 'opened', 'slug', 'note', 'resolved', 'root'
]);
const BARE_FLAGS = new Set(['json', 'full', 'help', 'h']);

function parseArgs(argv) {
  const opts = { _: [], root: REPO_ROOT, json: false, full: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith('--')) { opts._.push(a); continue; }
    const eq = a.indexOf('=');
    const name = (eq === -1 ? a.slice(2) : a.slice(2, eq));
    if (BARE_FLAGS.has(name)) {
      if (eq !== -1) throw new Error('--' + name + ' takes no value');
      opts[name === 'h' ? 'help' : name] = true;
      continue;
    }
    if (!VALUE_FLAGS.has(name)) throw new Error('unknown option: ' + a);
    const value = eq === -1 ? argv[++i] : a.slice(eq + 1);
    if (value === undefined) throw new Error('--' + name + ' needs a value');
    opts[name] = value;
  }
  opts.root = path.resolve(opts.root);
  return opts;
}

/** Today in island civil time, UTC plus ten, as an island date string. */
function islandToday() {
  const minutes = Math.floor(Date.now() / 60000) + ISLAND_UTC_OFFSET_MINUTES;
  const days = Math.floor(minutes / TICKS_PER_DAY);
  const { year, month, day } = civilFromDays(days);
  return [String(year).padStart(4, '0'), String(month).padStart(2, '0'), String(day).padStart(2, '0')].join('-');
}

// -------------------------------------------------------------------------------------------
// Reading the board. The parser mirrors tools/gate/board.mjs on purpose: the check owns the shape,
// and a tool that parsed it more loosely would happily write notes the gate then rejects.
// -------------------------------------------------------------------------------------------

function boardPath(root) {
  return path.join(root, BOARD_DIR);
}

function listFiles(root) {
  try {
    return readdirSync(boardPath(root), { withFileTypes: true })
      .filter((e) => e.isFile())
      .map((e) => e.name)
      .sort();
  } catch {
    return null;
  }
}

function parseNote(text) {
  const lines = text.replace(/\r/g, '').split('\n');
  if (lines[0].trim() !== '---') return { ok: false, reason: 'the first line is not three hyphens' };
  let end = -1;
  for (let i = 1; i < lines.length; i++) {
    if (lines[i].trim() === '---') { end = i; break; }
  }
  if (end === -1) return { ok: false, reason: 'front matter is never closed' };
  const fields = new Map();
  const order = [];
  for (let i = 1; i < end; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    const m = /^([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*)$/.exec(line);
    if (!m) return { ok: false, reason: 'front matter line ' + (i + 1) + ' is not `key: value`' };
    fields.set(m[1], m[2].trim());
    order.push(m[1]);
  }
  return { ok: true, fields, order, body: lines.slice(end + 1).join('\n').trim() };
}

/** Every note on the board, with the ones that will not parse carried as problems rather than dropped. */
export function readBoard(root) {
  const names = listFiles(root);
  if (names === null) return { exists: false, notes: [], problems: [] };
  const notes = [];
  const problems = [];
  for (const name of names) {
    // README.md is the board's law rather than a finding. It carries front matter because
    // tools/gate/board.mjs validates every .md file in this directory, and it is left out of the
    // listing here because it is not a note anybody has to action.
    if (name.toLowerCase() === 'readme.md') continue;
    if (!name.toLowerCase().endsWith('.md')) {
      problems.push({ file: name, reason: 'not a .md note' });
      continue;
    }
    let text;
    try {
      text = readFileSync(path.join(boardPath(root), name), 'utf8');
    } catch (err) {
      problems.push({ file: name, reason: String(err.message) });
      continue;
    }
    const parsed = parseNote(text);
    if (!parsed.ok) { problems.push({ file: name, reason: parsed.reason }); continue; }
    const missing = REQUIRED.filter((k) => !parsed.fields.has(k) || !parsed.fields.get(k));
    if (missing.length) problems.push({ file: name, reason: 'missing ' + missing.join(', ') });
    notes.push({
      file: name,
      path: BOARD_DIR + '/' + name,
      id: parsed.fields.get('id') || '',
      title: parsed.fields.get('title') || '',
      status: parsed.fields.get('status') || '',
      opened: parsed.fields.get('opened') || '',
      author: parsed.fields.get('author') || '',
      tags: parsed.fields.get('tags') || '',
      resolved: parsed.fields.get('resolved') || '',
      body: parsed.body,
      fields: parsed.fields,
      order: parsed.order
    });
  }
  return { exists: true, notes, problems };
}

/**
 * Every note file git has ever seen added under docs/board/, whether or not it is still there.
 *
 * This exists because the first version of nextId counted only the files present, and the first
 * thing that was tried against it was deleting note 009 and posting again, which produced a second
 * note 009. Ids that can be reused mean a reply can land on a finding that is not the one it
 * answers, which is the failure the id is there to prevent.
 *
 * Read-only git, the same way gate/sealed asks git rather than believing a file. If git is not
 * there, or root is not a repository, this returns nothing and the caller falls back to the files on
 * disk. The residual gap, stated rather than hidden: a note created and deleted without ever being
 * committed is invisible to both witnesses and its number can still be reissued.
 */
export function idsGitHasSeen(root) {
  const out = [];
  let res;
  try {
    res = spawnSync('git', ['log', '--diff-filter=A', '--pretty=format:', '--name-only', '--', BOARD_DIR], {
      cwd: root, encoding: 'utf8', windowsHide: true
    });
  } catch {
    return out;
  }
  if (!res || res.status !== 0 || typeof res.stdout !== 'string') return out;
  for (const line of res.stdout.split('\n')) {
    const m = /(?:^|\/)(\d+)-[^/]*\.md$/.exec(line.trim());
    if (m) out.push(Number(m[1]));
  }
  return out;
}

/**
 * The next id. One past the highest number this board has ever issued: the files here now, the ids
 * in their front matter, and every note file git has ever seen added under docs/board/.
 */
export function nextId(root) {
  const names = listFiles(root) || [];
  let highest = 0;
  for (const name of names) {
    const m = /^(\d+)-/.exec(name);
    if (m) highest = Math.max(highest, Number(m[1]));
  }
  for (const note of readBoard(root).notes) {
    if (/^\d+$/.test(note.id)) highest = Math.max(highest, Number(note.id));
  }
  for (const seen of idsGitHasSeen(root)) highest = Math.max(highest, seen);
  return String(highest + 1).padStart(3, '0');
}

function slugify(text) {
  const s = String(text).toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48)
    .replace(/-+$/g, '');
  return s || 'note';
}

// -------------------------------------------------------------------------------------------
// post
// -------------------------------------------------------------------------------------------

function oneLine(value, what) {
  const v = String(value).replace(/\r/g, '').trim();
  if (!v) throw new Error(what + ' is empty. ' + what + ' is how this note is found again.');
  if (v.includes('\n')) throw new Error(what + ' must be one line: front matter is one key and value per line.');
  return v;
}

function renderNote({ id, title, status, opened, author, tags, resolved, body }) {
  const lines = ['---', 'id: ' + id, 'title: ' + title, 'status: ' + status, 'opened: ' + opened, 'author: ' + author];
  if (tags) lines.push('tags: ' + tags);
  if (resolved) lines.push('resolved: ' + resolved);
  lines.push('---', '', body.trim(), '');
  return lines.join('\n');
}

function cmdPost(opts) {
  const root = opts.root;
  const title = oneLine(opts.title ?? '', 'title');
  const author = oneLine(opts.author ?? process.env.ISLAND_BOARD_AUTHOR ?? '', 'author');
  const status = String(opts.status ?? '').trim();
  if (!STATUSES.includes(status)) {
    throw new Error('--status must be one of ' + STATUSES.join(', ') + ', got ' + JSON.stringify(status));
  }
  const opened = String(opts.opened ?? islandToday()).trim();
  if (!DATE.test(opened)) throw new Error('--opened must be an island date written 2026-08-18, got ' + opened);
  const tags = opts.tags ? oneLine(opts.tags, 'tags') : '';

  let body;
  if (opts['body-file']) {
    body = readFileSync(path.resolve(opts['body-file']), 'utf8');
  } else if (opts.body !== undefined) {
    body = String(opts.body).split('\\n').join('\n');
  } else {
    throw new Error('a note needs a body: pass --body or --body-file. A note with no body says a thing '
      + 'happened without saying what.');
  }
  body = body.replace(/\r/g, '').trim();
  if (!body) throw new Error('the body is empty. Write what was found, where, and what the next agent should do.');

  const id = nextId(root);
  const file = id + '-' + slugify(opts.slug ?? title) + '.md';
  const abs = path.join(boardPath(root), file);
  if (existsSync(abs)) {
    throw new Error(BOARD_DIR + '/' + file + ' already exists, which should be impossible with a fresh id. '
      + 'Nothing was written.');
  }
  mkdirSync(boardPath(root), { recursive: true });
  writeFileSync(abs, renderNote({ id, title, status, opened, author, tags, resolved: '', body }), 'utf8');
  return { id, file, path: BOARD_DIR + '/' + file, status, title };
}

// -------------------------------------------------------------------------------------------
// set
// -------------------------------------------------------------------------------------------

function cmdSet(opts) {
  const root = opts.root;
  const wanted = String(opts._[1] ?? '').trim();
  if (!wanted) throw new Error('set needs the id of a note, for example: node tools/board.mjs set 003 --status resolved');
  const status = String(opts.status ?? '').trim();
  if (!STATUSES.includes(status)) {
    throw new Error('--status must be one of ' + STATUSES.join(', ') + ', got ' + JSON.stringify(status));
  }

  const board = readBoard(root);
  if (!board.exists) throw new Error(BOARD_DIR + ' does not exist, so there is no note to change.');
  const padded = /^\d+$/.test(wanted) ? String(Number(wanted)).padStart(3, '0') : wanted;
  const matches = board.notes.filter((n) => n.id === wanted || n.id === padded);
  if (!matches.length) {
    throw new Error('no note has id ' + wanted + '. On the board: '
      + (board.notes.map((n) => n.id).join(', ') || 'nothing'));
  }
  if (matches.length > 1) {
    throw new Error('id ' + wanted + ' is claimed by ' + matches.map((n) => n.path).join(' and ')
      + '. Fix the duplicate before setting a status.');
  }
  const note = matches[0];
  const when = String(opts.resolved ?? islandToday()).trim();
  if (!DATE.test(when)) throw new Error('--resolved must be an island date written 2026-08-18, got ' + when);

  let body = note.body;
  if (opts.note !== undefined) {
    const update = String(opts.note).split('\\n').join('\n').replace(/\r/g, '').trim();
    if (!update) throw new Error('--note was given and is empty. Leave it off, or say what changed.');
    body = body + '\n\n**Update ' + when + ', status ' + status + '.** ' + update;
  }

  // A title may be replaced when the finding outgrows its heading. The file name is not, because it
  // is the handle every other note and every report already points at.
  const title = opts.title === undefined ? note.title : oneLine(opts.title, 'title');

  const before = note.status;
  const next = renderNote({
    id: note.id,
    title,
    status,
    opened: note.opened,
    author: note.author,
    tags: note.tags,
    // A resolved date belongs to a resolved note. Reopening a note takes it off again rather than
    // leaving a date that says the question is closed while the status says it is not.
    resolved: status === 'resolved' ? when : '',
    body
  });
  writeFileSync(path.join(boardPath(root), note.file), next, 'utf8');
  return { id: note.id, path: note.path, from: before, to: status, title };
}

// -------------------------------------------------------------------------------------------
// read
// -------------------------------------------------------------------------------------------

/** Newest first: by opened date descending, then by id descending, both as plain string compares. */
function newestFirst(a, b) {
  if (a.opened !== b.opened) return a.opened < b.opened ? 1 : -1;
  if (a.id !== b.id) return a.id < b.id ? 1 : -1;
  return a.file < b.file ? 1 : -1;
}

function firstLines(body, n = 3) {
  const lines = body.split('\n').map((l) => l.trim()).filter(Boolean);
  const head = lines.slice(0, n);
  return { head, more: Math.max(0, lines.length - head.length) };
}

function cmdRead(opts) {
  const root = opts.root;
  const board = readBoard(root);
  const filter = opts.status ? String(opts.status).trim() : null;
  if (filter && !STATUSES.includes(filter)) {
    throw new Error('--status must be one of ' + STATUSES.join(', ') + ', got ' + JSON.stringify(filter));
  }
  const notes = board.notes.filter((n) => !filter || n.status === filter).sort(newestFirst);

  if (opts.json) {
    return JSON.stringify({
      root: root.split('\\').join('/'),
      exists: board.exists,
      filter,
      counts: Object.fromEntries(STATUSES.map((s) => [s, board.notes.filter((n) => n.status === s).length])),
      problems: board.problems,
      notes: notes.map((n) => ({
        id: n.id, title: n.title, status: n.status, opened: n.opened, author: n.author,
        tags: n.tags, resolved: n.resolved, path: n.path, body: n.body
      }))
    }, null, 2);
  }

  const out = [];
  out.push('board: ' + path.join(root, BOARD_DIR).split('\\').join('/'));
  if (!board.exists) {
    out.push('');
    out.push(BOARD_DIR + ' does not exist. Read docs/board/README.md for what the board is for, then post.');
    return out.join('\n');
  }
  const counts = STATUSES.map((s) => s + ' ' + board.notes.filter((n) => n.status === s).length).join(', ');
  out.push('notes: ' + board.notes.length + ' (' + counts + ')' + (filter ? ', showing ' + filter : ''));

  for (const p of board.problems) {
    out.push('');
    out.push('  UNREADABLE  ' + BOARD_DIR + '/' + p.file);
    out.push('      ' + p.reason);
  }

  if (!notes.length) {
    out.push('');
    out.push(filter ? 'No note has status ' + filter + '.' : 'The board carries no notes.');
    return out.join('\n');
  }

  for (const status of READ_ORDER) {
    const group = notes.filter((n) => n.status === status);
    if (!group.length) continue;
    out.push('');
    out.push(status.toUpperCase() + ' (' + group.length + ')');
    for (const n of group) {
      out.push('');
      out.push('  ' + n.id + '  ' + n.title);
      out.push('      ' + n.opened + '  ' + n.author
        + (n.resolved ? '  resolved ' + n.resolved : '')
        + (n.tags ? '  [' + n.tags + ']' : ''));
      out.push('      ' + n.path);
      if (opts.full) {
        for (const line of n.body.split('\n')) out.push('      ' + line);
      } else {
        const { head, more } = firstLines(n.body);
        for (const line of head) out.push('      ' + line);
        if (more) out.push('      ... ' + more + ' more line(s), --full to read them');
      }
    }
  }
  return out.join('\n');
}

// -------------------------------------------------------------------------------------------

function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n\n' + usage() + '\n');
    process.exitCode = 2;
    return;
  }
  const command = opts._[0];
  if (opts.help || !command) {
    process.stdout.write(usage() + '\n');
    if (!command && !opts.help) process.exitCode = 2;
    return;
  }
  try {
    if (command === 'read') {
      process.stdout.write(cmdRead(opts) + '\n');
    } else if (command === 'post') {
      const r = cmdPost(opts);
      process.stdout.write('posted ' + r.id + ' [' + r.status + '] ' + r.title + '\n' + r.path + '\n');
    } else if (command === 'set') {
      const r = cmdSet(opts);
      process.stdout.write('set ' + r.id + ' from ' + r.from + ' to ' + r.to + '\n' + r.path + '\n');
    } else {
      throw new Error('unknown command: ' + command);
    }
  } catch (err) {
    process.stderr.write(String(err && err.message ? err.message : err) + '\n');
    process.exitCode = 2;
  }
}

// Run only when this file is the program. Importable otherwise, so a proof can call nextId and
// idsGitHasSeen against another tree without the module printing a usage message on import.
const invokedDirectly = process.argv[1]
  && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url;

if (invokedDirectly) main();
