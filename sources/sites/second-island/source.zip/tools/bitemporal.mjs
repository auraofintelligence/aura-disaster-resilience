#!/usr/bin/env node
// The bitemporal instrument: does the store actually hold two times, or only claim to.
//
//     node tools/bitemporal.mjs --check
//     node tools/bitemporal.mjs --check --json
//     node tools/bitemporal.mjs --check --fixtures tools/fixtures/bitemporal-records.json
//
// Stage 3 of the founding prompt is the largest architectural correction this build makes, and it
// is the kind of correction that is easy to claim and hard to hold. A store can pass every unit
// test of "records go in, records come out" and still be single time in the one place it matters:
// the read. So this instrument does not test the store's methods one at a time. It runs a small
// set of scenarios that only a genuinely bitemporal store can answer, and asserts the answers.
//
// The four hard cases, all in tools/fixtures/bitemporal-records.json:
//
//   a correction after the fact          what a decision made on the 13th could see is not what we
//                                        know now, and both are still readable
//   true then, not true now              two current beliefs about the same thing, at different
//                                        stretches of valid time, neither of them ever wrong
//   a belief superseded                  the old belief keeps its window and its value; only the
//                                        field that says when we stopped believing it changes
//   a field with no observation at all    the honest answer is "not known", dated, and it is an
//                                        answer rather than a gap
//
// EXIT CODE
//
//   0  every check passed
//   1  a check failed, and the failure names which one and what it wanted
//   2  a usage error
//
// It must be able to fail. tools/faults.mjs registers 'frozen-clock' and 'stale-wins' against it:
// the first makes a read ignore the cursor's valid time and answer at the last lived minute, which
// is the first build's exact bug, and the second lets the simulation rung win a live question
// against a stale official observation. Both are single branches in src/world/, and both are
// watched failing here.

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { BitemporalStore, MODES, READS } from '../src/world/bitemporal.js';
import { resolve, resolveFrom, isUnknown } from '../src/world/ladder.js';
import { faultBanner } from '../src/kernel/faults.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const DEFAULT_FIXTURES = path.join(HERE, 'fixtures', 'bitemporal-records.json');

// The moments the scenarios ask about. Written out rather than computed, because a fixture suite
// whose expectations are derived from the same arithmetic as the thing under test proves nothing.
const PRESENT = '2026-08-19T12:00+10:00';
const HIST_A = '2026-08-13T00:00+10:00';
const HIST_B = '2026-08-12T00:00+10:00';
const BELIEF_EARLY = '2026-08-12T12:00+10:00';
const BEFORE_ANY_BELIEF = '2026-08-11T00:00+10:00';
const AFTER_THE_CHANGE = '2026-08-16T00:00+10:00';
const JUST_AFTER_THE_SIM = '2026-08-19T11:56+10:00';
const NOT_YET = '2026-08-20T06:30+10:00';

function usage() {
  return [
    'node tools/bitemporal.mjs --check [--fixtures <path>] [--json]',
    '',
    '  --check          run the scenario suite over the fixture record set',
    '  --fixtures <p>   a different fixture file, default tools/fixtures/bitemporal-records.json',
    '  --json           machine readable output on stdout, nothing else',
    '',
    'Exit code 1 on a failed check, 2 on a usage error.'
  ].join('\n');
}

function parseArgs(argv) {
  const opts = { check: false, json: false, fixtures: DEFAULT_FIXTURES, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--check') opts.check = true;
    else if (a === '--json') opts.json = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--fixtures') opts.fixtures = argv[++i] ?? opts.fixtures;
    else if (a.startsWith('--fixtures=')) opts.fixtures = a.slice(11);
    else throw new Error('unknown argument: ' + a + '\n\n' + usage());
  }
  return opts;
}

// ---------------------------------------------------------------------------------------------
// Assertions. Every one of them returns a result rather than throwing, so a wrong answer is
// reported as a failed check and never as a crash. An instrument that falls over has not caught
// anything, it has been survived, and tools/selftest.mjs counts that as a wrong reason.
// ---------------------------------------------------------------------------------------------

function show(v) {
  if (v === undefined) return 'undefined';
  if (v === null) return 'null';
  if (Array.isArray(v)) return '[' + v.map(show).join(', ') + ']';
  if (typeof v === 'string') return v;
  return String(v);
}

function eq(want, got) {
  return { ok: show(want) === show(got), want: show(want), got: show(got) };
}

/** Expect a refusal whose message names `mustSay`. A silent acceptance is a failure. */
function refuses(fn, mustSay) {
  try {
    fn();
  } catch (err) {
    const msg = String(err && err.message ? err.message : err).split('\n').join(' ');
    return {
      ok: msg.includes(mustSay),
      want: 'a refusal naming ' + JSON.stringify(mustSay),
      got: msg.length > 160 ? msg.slice(0, 160) + '...' : msg
    };
  }
  return { ok: false, want: 'a refusal naming ' + JSON.stringify(mustSay), got: 'nothing was refused' };
}

/** A ladder result read the way a panel would have to read it, for either shape. */
function answerOf(result) {
  if (isUnknown(result)) return 'not known as at ' + result.asAt;
  return show(result && result.value);
}

function rungOf(result) {
  if (isUnknown(result)) return 'no rung answered';
  return String(result && result.rung);
}

function values(records) {
  return (records || []).map((r) => show(r.value));
}

// ---------------------------------------------------------------------------------------------
// The scenarios
// ---------------------------------------------------------------------------------------------

function buildChecks(fx) {
  const checks = [];
  let section = 'unsectioned';
  const at = (name) => { section = name; };
  const check = (id, asserts, where, fn) => checks.push({ id, section, asserts, where, fn });

  const loaded = () => {
    const store = new BitemporalStore();
    store.addAll(fx.records);
    store.setPresent(fx.present);
    return store;
  };

  // ------------------------------------------------------------- the record type at the door
  at('the record type at the door');

  check('refuses-a-record-without-provenance',
    'the store validates with checkRecord before it holds anything',
    'fixture-refused-no-provenance',
    () => refuses(() => loaded().add(fx.refusals['no-provenance']), 'missing source'));

  check('refuses-a-record-without-an-id',
    'a record in this store names the thing it is about, or there is no timeline',
    'a record with no id',
    () => refuses(() => loaded().add(fx.refusals['no-id']), 'needs a string id'));

  check('refuses-a-source-it-cannot-open',
    'with a source id set, a source that is free text is refused',
    'fixture-source-observation against data/_sources.json',
    () => refuses(() => {
      const strict = new BitemporalStore({ sourceIds: new Set(['noaa-solar-equations']) });
      strict.add(fx.records[0]);
    }, 'source not in data/_sources.json'));

  check('a-stored-record-cannot-be-edited',
    'nothing is ever overwritten, and the store does not rely on nobody reaching in',
    'fixture-a',
    () => eq(true, Object.isFrozen(loaded().timeline('fixture-a')[0])));

  // ------------------------------------------------------------------------- the two cursors
  at('the two cursors');

  check('live-reads-the-latest-belief',
    'live mode reads valid time then, belief time now, so it sees the correction',
    'fixture-a, field fixture.count, corrected on the 14th',
    () => eq(15, loaded().current(HIST_A, { id: 'fixture-a' })[0].value));

  check('as-believed-replays-the-belief-held-then',
    'auditing a past decision reads what the twin believed at the time, not what it knows now',
    'fixture-a, field fixture.count, as believed on the 13th',
    () => eq(12, loaded().asBelieved(HIST_A, HIST_A, { id: 'fixture-a' }).records[0].value));

  check('history-is-not-the-present',
    'a history read answers for the moment asked about, not for the last lived minute',
    'fixture-b, field fixture.status',
    () => eq('open', loaded().history(HIST_B, { id: 'fixture-b' }).records[0].value));

  check('live-shows-what-is-true-now',
    'the same store, the same id, a later valid time, a different true value',
    'fixture-b, field fixture.status',
    () => eq('closed', loaded().current(PRESENT, { id: 'fixture-b' })[0].value));

  check('the-two-axes-move-independently',
    'valid time and belief time are separate cursors, and moving one does not move the other',
    'fixture-a and fixture-b, as believed at midday on the 12th',
    () => eq(['12', 'open'], values(loaded().asBelieved(HIST_B, BELIEF_EARLY).records)));

  check('a-belief-not-yet-held-is-not-returned',
    'the twin cannot have known on the 11th what it learned on the 12th',
    'every record, as believed on the 11th',
    () => eq(0, loaded().asBelieved(PRESENT, BEFORE_ANY_BELIEF).records.length));

  check('the-two-past-reads-are-labelled-apart',
    'history and as believed are different questions and carry different labels',
    'READS.HISTORY against READS.AS_BELIEVED',
    () => {
      const store = loaded();
      const h = store.history(HIST_B, { id: 'fixture-b' });
      const b = store.asBelieved(HIST_B, BELIEF_EARLY, { id: 'fixture-b' });
      return eq([READS.HISTORY, READS.AS_BELIEVED], [h.readAs, b.readAs]);
    });

  check('the-id-index-and-the-full-scan-agree',
    'the bucket index changes the cost of a read and never its answer',
    'every id, at three cursor positions',
    () => {
      const store = loaded();
      const positions = [[PRESENT, PRESENT], [HIST_B, BELIEF_EARLY], [HIST_A, HIST_A]];
      const disagreed = [];
      for (const [v, k] of positions) {
        const all = store.asOf(v, k);
        for (const id of store.ids()) {
          const byId = store.asOf(v, k, { id });
          const scanned = all.filter((r) => r.id === id);
          if (JSON.stringify(byId) !== JSON.stringify(scanned)) disagreed.push(id + ' at ' + v);
        }
      }
      return eq([], disagreed);
    });

  // ---------------------------------------------------------------------------- corrections
  at('corrections, which are new beliefs');

  const corrected = () => {
    const store = loaded();
    const before = store.timeline('fixture-b')[1];
    const result = store.supersede('fixture-b', fx.corrections['fixture-b-correction']);
    return { store, before, result };
  };

  check('a-correction-closes-the-old-belief-and-opens-a-new-one',
    'supersede closes exactly the overlapping open belief, and adds rather than edits',
    'fixture-b, corrected at 13:00 on the 19th',
    () => {
      const { result } = corrected();
      return eq(['closed', '2026-08-19T13:00+10:00', 'closed for works'],
        [result.closed.length === 1 ? result.closed[0].value : 'closed ' + result.closed.length + ' beliefs',
          result.closed.length === 1 ? result.closed[0].recordedUntil : 'n/a',
          result.added.value]);
    });

  check('a-correction-does-not-close-a-belief-it-does-not-overlap',
    'correcting the state from the 15th leaves the state before the 15th alone',
    'fixture-b, the belief valid 10 to 15 August',
    () => {
      const { store } = corrected();
      const open = store.timeline('fixture-b').filter((r) => r.recordedUntil === null);
      return eq(['open', 'closed for works'], values(open));
    });

  check('the-old-belief-is-still-readable-after-the-correction',
    'a decision made before the correction can still be audited against what it could see',
    'fixture-b on the 16th, as believed at midday on the 19th',
    () => {
      const { store } = corrected();
      return eq('closed', store.asBelieved(AFTER_THE_CHANGE, PRESENT, { id: 'fixture-b' }).records[0].value);
    });

  check('after-the-correction-live-reads-the-new-belief',
    'the same valid time, the newest belief',
    'fixture-b on the 16th, live',
    () => {
      const { store } = corrected();
      return eq('closed for works', store.current(AFTER_THE_CHANGE, { id: 'fixture-b' })[0].value);
    });

  check('the-timeline-holds-every-belief-in-order',
    'every belief the twin has held about one thing, oldest first, a correction as two rows',
    'fixture-b',
    () => {
      const { store } = corrected();
      return eq(['open', 'closed', 'closed for works'], values(store.timeline('fixture-b')));
    });

  check('nothing-is-overwritten',
    'the record object held before the correction still reads exactly as it did',
    'fixture-b, the belief captured before supersede ran',
    () => {
      const { before } = corrected();
      return eq(['closed', 'null'], [before.value, show(before.recordedUntil)]);
    });

  check('supersede-refuses-a-correction-learned-too-early',
    'the twin cannot learn a correction before it learned the thing being corrected',
    'fixture-b, a correction recorded on the 11th',
    () => refuses(
      () => loaded().supersede('fixture-b', fx.corrections['fixture-b-correction-learned-too-early']),
      'cannot learn a correction before'));

  check('supersede-refuses-a-thing-the-store-has-never-held',
    'a first belief is add, not supersede, and the difference is not a detail',
    'fixture-never-held',
    () => refuses(() => {
      const store = loaded();
      const rec = { ...fx.corrections['fixture-b-correction'], id: 'fixture-never-held' };
      store.supersede('fixture-never-held', rec);
    }, 'has never held a belief about'));

  // ------------------------------------------------------------------------- the three modes
  at('the three modes as three cursor positions');

  check('live-refuses-a-moment-that-has-not-happened',
    'only a scenario cursor may run ahead of the present',
    'a live cursor at 06:30 on the 20th',
    () => refuses(() => loaded().cursor(MODES.LIVE, NOT_YET), MODES.SCENARIO));

  check('scenario-may-run-ahead-of-every-record',
    'a scenario cursor is built, and knows that it is ahead',
    'a scenario cursor at 06:30 on the 20th',
    () => eq([MODES.SCENARIO, true], (() => {
      const c = loaded().cursor(MODES.SCENARIO, NOT_YET);
      return [c.mode, c.ahead];
    })()));

  check('live-refuses-a-pinned-belief',
    'in live mode the belief cursor tracks the latest belief, always',
    'a live cursor pinned to the 13th',
    () => refuses(() => loaded().cursor(MODES.LIVE, PRESENT, HIST_A), 'tracks the latest belief'));

  check('history-refuses-the-present',
    'history reads the past, so a caller cannot get live behaviour by asking for history',
    'a history cursor at the present',
    () => refuses(() => loaded().cursor(MODES.HISTORY, PRESENT), 'reads the past'));

  check('an-unknown-mode-is-refused',
    'the three modes are a named type, so a fourth cannot be invented at a call site',
    'a cursor in mode projected',
    () => refuses(() => loaded().cursor('projected', PRESENT), 'live, history, scenario'));

  check('one-store-answers-three-cursors',
    'live, history and scenario are three positions over one set of records',
    'fixture-b, field fixture.status',
    () => {
      const store = loaded();
      const read = (mode, v) => {
        const recs = store.read(store.cursor(mode, v), { id: 'fixture-b' });
        return recs.length ? show(recs[0].value) : 'nothing';
      };
      return eq(['closed', 'open', 'closed'], [
        read(MODES.LIVE, PRESENT),
        read(MODES.HISTORY, HIST_B),
        read(MODES.SCENARIO, NOT_YET)
      ]);
    });

  // -------------------------------------------------------------------------- the source ladder
  at('the ranked source ladder');

  check('the-ladder-prefers-the-island-instrument',
    'instrument over official observation, both fresh',
    'fixture.reading',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.reading', store.cursor(MODES.LIVE, PRESENT));
      return eq(['21', 'instrument'], [answerOf(r), rungOf(r)]);
    });

  check('live-refuses-the-bottom-rung',
    'the simulation rung never wins a live question, even when it is the freshest thing there is',
    'fixture.level, a stale observation against a fresh simulation',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.level', store.cursor(MODES.LIVE, PRESENT));
      return eq(['1.4', 'observation'], [answerOf(r), rungOf(r)]);
    });

  check('freshness-demotes-one-rung',
    'a reading past its window ranks one rung lower and is marked stale, rather than being hidden',
    'fixture.level, an observation 30 hours past a 3 hour window',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.level', store.cursor(MODES.LIVE, PRESENT));
      return eq([true, 'model'], [isUnknown(r) ? 'not known' : r.stale, isUnknown(r) ? 'not known' : r.effectiveRung]);
    });

  check('a-stale-observation-still-outranks-a-fresh-simulation',
    'where the live floor does not apply, the ladder still decides, and freshness only demotes',
    'fixture.level, read one minute after the simulation was written',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.level', store.cursor(MODES.HISTORY, JUST_AFTER_THE_SIM));
      return eq(['1.4', 'observation'], [answerOf(r), rungOf(r)]);
    });

  check('not-known-is-an-answer',
    'when the only rung that can speak is the bottom one, live mode says not known, dated',
    'fixture.unfed, simulation only',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.unfed', store.cursor(MODES.LIVE, PRESENT));
      return eq('not known as at ' + PRESENT, answerOf(r));
    });

  check('a-field-with-no-candidate-is-not-known',
    'an empty ladder returns the dated unknown shape rather than undefined',
    'fixture.absent',
    () => {
      const store = loaded();
      const r = resolve('fixture.absent', [], store.cursor(MODES.LIVE, PRESENT));
      return eq([true, true], [isUnknown(r), Boolean(r.why && r.why.includes('no candidate'))]);
    });

  check('a-candidate-with-no-staleness-window-cannot-be-judged',
    'an undated reading treated as fresh forever is the bug the freshness rule exists to prevent',
    'fixture.level with the window stripped off',
    () => {
      const store = loaded();
      const cursor = store.cursor(MODES.LIVE, PRESENT);
      const bare = { ...store.asOf(PRESENT, PRESENT, { id: 'fixture-c-observation' })[0] };
      delete bare.staleAfterMinutes;
      const r = resolve('fixture.level', [bare], cursor);
      return eq([true, true], [isUnknown(r), Boolean(r.why && r.why.includes('staleness window'))]);
    });

  check('the-ladder-refuses-a-rung-it-does-not-have',
    'a rung invented at a call site is set aside with the reason, not quietly ranked last',
    'fixture.level at a rung called rumour',
    () => {
      const store = loaded();
      const cursor = store.cursor(MODES.LIVE, PRESENT);
      const odd = { ...store.asOf(PRESENT, PRESENT, { id: 'fixture-c-observation' })[0], rung: 'rumour' };
      const r = resolve('fixture.level', [odd], cursor);
      return eq([true, true], [isUnknown(r), Boolean(r.why && r.why.includes('is not on the ladder'))]);
    });

  check('scenario-reads-a-moment-that-has-not-happened',
    'the simulation rung answers exactly where nothing else can, which is ahead of the present',
    'fixture.projected at 06:30 on the 20th',
    () => {
      const store = loaded();
      const r = resolveFrom(store, 'fixture.projected', store.cursor(MODES.SCENARIO, NOT_YET));
      return eq(['3.2', 'simulation'], [answerOf(r), rungOf(r)]);
    });

  return checks;
}

// ---------------------------------------------------------------------------------------------
// Running and reporting
// ---------------------------------------------------------------------------------------------

function run(fx) {
  const checks = buildChecks(fx);
  const results = [];
  for (const c of checks) {
    let r;
    try {
      r = c.fn();
    } catch (err) {
      const msg = String(err && err.message ? err.message : err).split('\n')[0];
      r = { ok: false, want: 'the check to run', got: 'the check could not run: ' + msg };
    }
    results.push({
      id: c.id, section: c.section, asserts: c.asserts, where: c.where,
      ok: Boolean(r && r.ok), want: r ? r.want : '', got: r ? r.got : ''
    });
  }
  const failed = results.filter((r) => !r.ok);
  return { ok: failed.length === 0, checks: results, failed };
}

function report(out, fx, fixturesPath) {
  const lines = [];
  lines.push('bitemporal: the cursor semantics of src/world/bitemporal.js and the ladder in src/world/ladder.js');
  lines.push('fixtures:   ' + fixturesPath + ', ' + fx.records.length + ' records');
  lines.push('present:    ' + fx.present);
  const banner = faultBanner();
  if (banner) lines.push(banner);
  lines.push('');

  let section = null;
  for (const r of out.checks) {
    if (r.section !== section) {
      section = r.section;
      lines.push('  ' + section);
    }
    lines.push('    [' + (r.ok ? 'ok' : 'FAIL') + '] ' + r.id);
  }

  for (const r of out.failed) {
    lines.push('');
    lines.push('FAILED CHECK: ' + r.id);
    lines.push('  asserts: ' + r.asserts);
    lines.push('  where:   ' + r.where);
    lines.push('  wanted:  ' + r.want);
    lines.push('  got:     ' + r.got);
  }

  lines.push('');
  lines.push(out.ok
    ? 'PASS: ' + out.checks.length + ' checks over ' + fx.records.length + ' fixture records'
    : 'FAIL: ' + out.failed.length + ' of ' + out.checks.length + ' checks failed, first '
      + out.failed[0].id);
  return lines.join('\n');
}

function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n');
    process.exitCode = 2;
    return;
  }
  if (opts.help || !opts.check) {
    process.stdout.write(usage() + '\n');
    process.exitCode = opts.help ? 0 : 2;
    return;
  }

  const fixturesPath = path.resolve(opts.fixtures);
  let fx;
  try {
    fx = JSON.parse(readFileSync(fixturesPath, 'utf8'));
  } catch (err) {
    process.stderr.write('could not read the fixture set at ' + fixturesPath + ': '
      + String(err && err.message ? err.message : err) + '\n');
    process.exitCode = 2;
    return;
  }

  const out = run(fx);
  const shown = path.relative(REPO_ROOT, fixturesPath).split('\\').join('/') || fixturesPath;

  if (opts.json) {
    process.stdout.write(JSON.stringify({
      instrument: 'bitemporal',
      fixtures: shown,
      present: fx.present,
      fault: faultBanner() || null,
      ok: out.ok,
      counts: { checks: out.checks.length, failed: out.failed.length },
      checks: out.checks
    }, null, 2) + '\n');
  } else {
    process.stdout.write(report(out, fx, shown) + '\n');
  }

  process.exitCode = out.ok ? 0 : 1;
}

main();
