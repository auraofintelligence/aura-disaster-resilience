// The fault registry: every deliberate break, and the instrument that has to see it.
//
// An instrument nobody has watched fail is a rumour. This file is the list of things that get
// broken on purpose so that every instrument in tools/ has been watched failing at least once.
// tools/selftest.mjs reads it, breaks a copy of the repository with it, runs the instruments over
// the healthy tree and the broken one, and writes docs/JURISDICTION.md from what happened.
//
// The registry is data. It runs nothing itself, it imports nothing from src/, and it never touches
// this repository: every `apply` is handed the path of a throwaway copy under out/.
//
// AN ENTRY
//
//   id          the fault's name. For a runtime fault this is the exact string ISLAND_FAULT or
//               ?fault= is set to, and the string the matching faulty() call names.
//   breaks      one line, what the fault does to the build.
//   kind        'runtime'  a branch already in the source, switched on by ISLAND_FAULT or ?fault=
//               'tree'     a change made to a copy of the repository by `apply`
//   hookSites   for a runtime fault, the files whose faulty() calls name this id. For a tree fault,
//               the files `apply` writes. gate/instruments checks both directions against the source.
//   instrument  the instrument that MUST catch it. One name, so the row has an owner. A variant
//               that needs a different argument, such as determinism --shuffle, is its own column.
//   mode        'moved' for a fault only two frames at two ticks can show. Read by the shot column.
//   mustName    strings the failure output has to contain. A fault that fails an instrument without
//               naming what broke has taught the next person nothing.
//   apply       tree faults only. (root) => void, mutating the copy at `root`.
//   inverted    true when an instrument is required to MISS this fault. Only ui-text-change and the
//               declared blind spot use it, and both exist to prove a limit rather than a capability.
//   mustMiss    for an inverted row, the instrument that has to keep passing.
//   blindSpot   a reason string when no instrument catches this fault, or null. gate/instruments
//               fails on an uncaught fault that does not carry one.
//   evidence    for a fault that only shows in a browser: the recorded captures a Node instrument
//               can be pointed at, as { healthy, faulted } and optionally a scene or an expect
//               baseline. Without them on disk the row is honestly unproven.
//   missEvidence  the same, for the instrument named in mustMiss.
//   proven      the author's declaration, checked by tools/selftest.mjs against what actually
//               happened. `false` with a reason in `why` is an honest row. Claiming true is not a
//               way to make a row green: selftest overwrites the claim with the observation and
//               reports every disagreement.
//   why         the reason `proven` is false, or a note about the row.
//   origin      'stage-0' for the seventeen rows in docs/STAGE-0.md, 'second-island' for a row this
//               build added. The additions exist because gate/instruments fails when an instrument
//               has no fault that proves it, and three gate rules had none.
//
// WHY THE HOOK SITES MATTER
//
// A fault hook is a branch in shipping code. Left unlisted it becomes a back door, so
// gate/instruments reads this file and the source together and fails when they disagree in either
// direction: a declared hook site with no faulty() call in it, or a faulty() call in a file no
// entry declares.

import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import path from 'node:path';

// Spelled as a code point on purpose. A file that plants an em dash must not contain one.
const EM_DASH = String.fromCharCode(0x2014);

// ---------------------------------------------------------------------------------------------
// Small helpers for the tree faults. Each one is handed the copy, never this repository.
// ---------------------------------------------------------------------------------------------

function read(root, rel) {
  return readFileSync(path.join(root, rel), 'utf8');
}

function write(root, rel, text) {
  const abs = path.join(root, rel);
  mkdirSync(path.dirname(abs), { recursive: true });
  writeFileSync(abs, text, 'utf8');
}

/**
 * Put `lines` at the very top of a file. Blunt on purpose: two of the three simulation files this
 * registry writes into carry no import statement at all, so there is no import block to anchor to,
 * and an anchor that silently misses would produce a fault that is never injected. An ES module
 * hoists its imports, so a line above the header comment still loads.
 */
function prepend(root, rel, lines) {
  write(root, rel, lines.join('\n') + '\n' + read(root, rel));
}

/** Add a key to the top level of a JSON pack, keeping the file readable. */
function addTopLevelKey(root, rel, key, value) {
  const doc = JSON.parse(read(root, rel));
  doc[key] = value;
  write(root, rel, JSON.stringify(doc, null, 2) + '\n');
}

/** Parse a JSON pack in the copy, hand it to `edit`, and write back what comes out. */
function editJson(root, rel, edit) {
  const doc = JSON.parse(read(root, rel));
  edit(doc);
  write(root, rel, JSON.stringify(doc, null, 2) + '\n');
}

/** Add lines to the end of a text file in the copy. */
function append(root, rel, lines) {
  write(root, rel, read(root, rel).replace(/\s*$/, '\n') + lines.join('\n') + '\n');
}

/** The first banned token, read from the pack rather than quoted here. */
function firstBannedToken(root) {
  const lore = JSON.parse(read(root, 'data/lore.json'));
  const tokens = (lore.language && lore.language.banned_tokens && lore.language.banned_tokens.tokens) || [];
  const first = tokens[0];
  const token = typeof first === 'string' ? first : first && first.token;
  if (!token) throw new Error('data/lore.json carries no banned tokens, so this fault cannot be built');
  return token;
}

// A splice of two words the pack already publishes: the first six letters of the island's name and
// the last five of a place on it. It is not a word, it is not offered as one, it appears only in a
// throwaway copy under out/, and it exists so that `no-invented-language` can be watched catching
// the shape of an invented word. Constructing it this way rather than coining one is deliberate:
// no agent in this repository invents a word, not even to break something.
const SPLICE_PROBE = 'Minjeroomba';

// An Australian mobile number from the range ACMA reserves for fiction, so nothing here is a real
// person's number even inside a throwaway copy.
const FICTITIOUS_MOBILE = '0491 570 156';

// The first island's app port, built by arithmetic rather than written down. gate/ports treats the
// literal as blocking in any code file, including this one, so a registry that quoted it would fail
// the rule it exists to prove. tools/gate/ports.mjs exempts itself for the same reason.
const FIRST_ISLAND_PORT = String(4270 + 1);

// The pack id a connector under tools/ingest/ writes into ingest-inbox/derived/. Quoted here so the
// planted pack carries the mark gate/derived looks for. It is a pack id, not a place, a person or a
// word, and gate/derived reads the real list out of the connector source rather than out of here.
const CONNECTOR_PACK_NAME = 'osm-buildings';

// A geometry that is deliberately not a place: two identical points at zero. This registry invents
// no coordinate on this island, not even inside a throwaway copy under out/, for the same reason
// SPLICE_PROBE is a splice of two published words rather than a coined one.
const PROBE_OUTLINE = [[0, 0], [0, 0]];

/** A fully provenanced probe record, so the planted pack fails only the rule it is aimed at. */
function probeRecord(i, extra = {}) {
  return {
    id: 'fault-probe-feature-' + i,
    kind: 'building',
    buildingTag: 'house',
    name: null,
    outline: PROBE_OUTLINE,
    crs: 'WGS84 decimal degrees, lon lat',
    source: 'osm-overpass',
    locator: 'planted by tools/faults.mjs, not an OpenStreetMap element',
    validFrom: '2026-08-19',
    validTo: null,
    recordedAt: '2026-08-19',
    recordedUntil: null,
    confidence: 'medium',
    register: 'known',
    ...extra
  };
}

// The hook call that `undeclared-fault-hook` plants, assembled rather than written out. The scanner
// in tools/gate/instruments.mjs looks for exactly this shape, and a registry that spelled it out
// would report itself as an undeclared hook. Same reason as the port above.
const UNDECLARED_HOOK_CALL = 'faulty' + "('undeclared-probe')";

// ---------------------------------------------------------------------------------------------
// The crossing shapes, assembled rather than written out, for the fourth time in this file and for
// the same reason as the port and the hook call above: tools/gate/crossings.mjs scans tools/ as
// well, so a registry that spelled out the shapes it plants would fail the rule it is proving.
//
// Board note 032 landed a per-line `specimen` marker in that rule for documents that need to quote
// a refused shape. It was not used here, because this file already had the assembly convention and
// three uses of it, and a marker is an exemption while assembly is not. Every fragment below is
// joined at apply time and appears only inside a throwaway copy under out/.
// ---------------------------------------------------------------------------------------------

// Two constants a vehicle figure and a passenger figure could be added in. The names are what the
// rule reads: it tokenises an identifier and asks which class each side belongs to.
const VEHICLE_FIGURE = 'FAULT_' + 'VEHICLE';
const PASSENGER_FIGURE = 'FAULT_' + 'PASSENGER';
const SUMMED_EXPRESSION = [VEHICLE_FIGURE, PASSENGER_FIGURE].join(' + ');

// One name holding both classes and something countable, which is the second half of the same rule:
// not an addition, a field where the addition could live.
const MERGED_NAME = 'fault' + 'VehicleAnd' + 'PassengerCount';

// A count of departures and a count of vessel movements, neither of them saying which of the three
// services or which of the two landing points it belongs to. Both figures are real ones from
// data/crossings.json read the wrong way round, which is the point: the numbers are not wrong, the
// sentences are, and a reader cannot tell which service either one is about.
const SAILING_COUNT = 28;
const MOVEMENT_COUNT = 48;

// A third value for `carries`, which the schema has no room for. A vehicle sailing also carries
// people; what is refused is one value meaning both, because the moment one exists somebody writes
// one number for it.
const THIRD_CARRIES_VALUE = 'both';

// The sailing the timetable faults move, named once. It is a middle row of the Departs Cleveland
// column of the SeaLink vehicle timetable, chosen because the checks that already exist read the
// first and last row of a column and would not see it.
const DRIFT_SAILING_ID = 'sealink-vehicle-m2i-1030';
const DRIFT_SUPPLIED = '10:30';
const DRIFT_ALTERED = '10:35';

// ---------------------------------------------------------------------------------------------
// The instruments. A column of the jurisdiction matrix each.
// ---------------------------------------------------------------------------------------------

/**
 * `kind` says how tools/selftest.mjs runs it.
 *   'node'    a script in tools/, run in the tree under test, exit code 1 means it caught something
 *   'gate'    one rule module of tools/gate/, run from THIS repository against the tree under test
 *   'capture' a Node script pointed at a recorded browser artefact, because it cannot open a page
 *   'absent'  specified in docs/STAGE-0.md, not yet written, so every row it owns is unproven
 */
export const INSTRUMENTS = {
  headless: {
    kind: 'node',
    script: 'tools/headless.mjs',
    args: ['--ticks', '1440', '--fixtures'],
    owns: 'the island runs in Node with no browser: no system throws, no budget is overrun by a '
      + "system's own work, and the seams that never fire are named."
  },
  determinism: {
    kind: 'node',
    script: 'tools/determinism.mjs',
    args: ['--ticks', '2000', '--fixtures'],
    owns: 'two runs from one seed are identical, and on a difference the first divergent tick and '
      + 'the system that drifted are named.'
  },
  'determinism --shuffle': {
    kind: 'node',
    script: 'tools/determinism.mjs',
    args: ['--ticks', '2000', '--fixtures', '--shuffle'],
    owns: 'registration order changes nothing, because systems are sorted by their declared order.'
  },
  shot: {
    kind: 'capture',
    script: 'tools/shot.mjs',
    args: (abs, fault, ev) => (fault.mode === 'moved'
      ? ['--moved', ev.scene || 'calibration', abs[0], abs[1]]
      : ['--assert', ev.scene || 'calibration', '--shot', abs[0]]),
    owns: 'the pixels a scene file says should be there are there, and a frame drawn at a later '
      + 'tick differs from the earlier one at the declared movement points.'
  },
  bench: {
    kind: 'capture',
    script: 'tools/bench.mjs',
    args: (abs) => ['--assert', '--file', abs[0]],
    owns: 'p99 frame time against the budget, and the worst frame with the frame that produced it.'
  },
  uiprobe: {
    kind: 'capture',
    script: 'tools/uiprobe.mjs',
    args: (abs, fault, ev) => {
      const name = abs[0].split(/[\\/]/).pop().replace(/\.json$/, '');
      return ['--assert', name, '--probe', abs[0], ...(ev.expect ? ['--expect', ev.expect] : [])];
    },
    owns: 'every panel has a role and an accessible name, every displayed number carries data-prov, '
      + 'every data-prov resolves to a record that exists, and with a baseline, that no panel was '
      + 'quietly renamed.'
  },
  bitemporal: {
    kind: 'node',
    script: 'tools/bitemporal.mjs',
    args: ['--check'],
    owns: 'live, history and scenario are three cursor positions over one store: a read answers for '
      + 'the moment it was asked about, a correction is a new belief rather than an edit, and the '
      + 'bottom rung of the source ladder never wins a live question.'
  },
  'check-wiring': {
    kind: 'node',
    script: 'tools/check-wiring.mjs',
    args: [],
    owns: 'the record store is in the world rather than beside it, and every field the twin '
      + 'publishes is answered by asking the ladder over that store rather than by reading a '
      + "system's own state."
  },
  'gate/imports': { kind: 'gate', rule: 'imports', owns: 'simulation never imports the renderer or the UI, directly or through a helper.' },
  'gate/no-wallclock': { kind: 'gate', rule: 'no-wallclock', owns: 'no wall clock and no unseeded randomness under src/kernel, src/systems or src/world.' },
  'gate/lore': { kind: 'gate', rule: 'lore', owns: 'the cultural boundary: the allowlist, the banned tokens, and the cultural queue is not an approval.' },
  'gate/provenance': { kind: 'gate', rule: 'provenance', owns: 'every record in data/ carries its source, its locator and the two times.' },
  'gate/style': { kind: 'gate', rule: 'style', owns: 'no em dash, no en dash between words, Australian spelling.' },
  'gate/personal': { kind: 'gate', rule: 'personal', owns: 'no personal contact detail under data/, assets/ or docs/.' },
  'gate/sealed': { kind: 'gate', rule: 'sealed', owns: 'the staging trees are sealed, proven by asking git and by reading the tree\'s own .gitignore.' },
  'gate/derived': {
    kind: 'gate',
    rule: 'derived',
    owns: 'nothing derived is committed while the licence question is open, and every record a '
      + 'connector emitted into ingest-inbox/derived/ carries the eight provenance fields.'
  },
  'gate/crossings': {
    kind: 'gate',
    rule: 'crossings',
    owns: 'passenger and vehicle crossings are never one figure: no sum of the two classes, no name '
      + 'or enum value holding both, and no crossing count written without saying which of the '
      + 'three services or which of the two landing points it belongs to.'
  },
  'gate/ground-truth': {
    kind: 'gate',
    rule: 'ground-truth',
    owns: "the owner's supplied crossing timetable in data/crossings.json is the one he supplied: "
      + 'every departure time, vessel code and day rule still matches the transcription, and the '
      + 'sailing structure still matches its seal.'
  },
  'gate/ports': { kind: 'gate', rule: 'ports', owns: "the first build's two ports are never bound or written here." },
  'gate/board': { kind: 'gate', rule: 'board', owns: 'every note in docs/board/ has the front matter the board tool and the reader rely on.' },
  'gate/instruments': { kind: 'gate', rule: 'instruments', owns: 'this registry and the source agree: no undeclared hook, no unproven instrument, no unexplained blind spot.' }
};

// ---------------------------------------------------------------------------------------------
// The registry.
// ---------------------------------------------------------------------------------------------

export const FAULTS = [
  // ------------------------------------------------------------------ determinism and the kernel
  {
    id: 'nondeterminism',
    origin: 'stage-0',
    breaks: 'a fixture system draws from an unseeded source instead of its own named stream',
    kind: 'runtime',
    hookSites: ['tools/fixtures/spin.js'],
    instrument: 'determinism',
    mustName: ['FIRST DIVERGENT TICK', 'fixture.jitter'],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: 'docs/STAGE-0.md words this row as the tide system. The tide is unfed on purpose and holds '
      + 'no state that could drift, so the hook lives in tools/fixtures/spin.js, which exists to '
      + 'give the instruments something that exercises the kernel. The requirement the row is '
      + 'really about is that the failure names a system, and it does.'
  },
  {
    id: 'order-dependence',
    origin: 'stage-0',
    breaks: 'a system reads registration order instead of its declared integer order',
    kind: 'runtime',
    hookSites: ['tools/fixtures/spin.js'],
    instrument: 'determinism --shuffle',
    mustName: ['FIRST DIVERGENT TICK', 'fixture.tally'],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: ''
  },
  {
    id: 'fixture-throws',
    origin: 'second-island',
    breaks: 'a system throws part way through a run',
    kind: 'runtime',
    hookSites: ['tools/fixtures/spin.js'],
    instrument: 'headless',
    mustName: ['A SYSTEM THREW', 'fixture.spawner', 'tick 100'],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: 'Added by this build. The hook was already in tools/fixtures/spin.js with no registry row, '
      + 'which is exactly the undeclared hook gate/instruments exists to refuse. It is also the '
      + 'only fault that proves headless can fail at all.'
  },
  {
    id: 'sim-imports-render',
    origin: 'stage-0',
    breaks: 'a kernel file imports the renderer',
    kind: 'tree',
    hookSites: ['src/kernel/clock.js'],
    instrument: 'gate/imports',
    mustName: ['imports/sim-imports-render', 'src/kernel/clock.js', 'src/render/calibration.js'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      prepend(root, 'src/kernel/clock.js', [
        "import { RENDER_PATHS } from '../render/calibration.js';",
        'export const FAULT_RENDER_PATHS = RENDER_PATHS;'
      ]);
    },
    proven: true,
    why: 'docs/STAGE-0.md names headless as a second witness. It is not one, and the matrix says so '
      + 'rather than the row being quietly reworded: src/render/calibration.js has no browser '
      + 'reference in its module body, so importing it from the kernel loads cleanly in Node and a '
      + 'headless run still passes. gate/imports is the only witness this fault has.'
  },
  {
    id: 'wallclock',
    origin: 'stage-0',
    breaks: 'a system calls Date.now()',
    kind: 'tree',
    hookSites: ['src/systems/tide.js'],
    instrument: 'gate/no-wallclock',
    mustName: ['no-wallclock/date-now', 'src/systems/tide.js', 'Date.now'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      prepend(root, 'src/systems/tide.js', [
        'const FAULT_STAMP = Date.now();',
        'export function faultStamp() { return FAULT_STAMP; }'
      ]);
    },
    proven: true,
    why: ''
  },

  // ------------------------------------------------------------------------------ the renderer
  //
  // The captures named below were first taken on 18 August 2026 from the single page this build
  // had then, and retaken on 20 August 2026 from http://localhost:4281/lab.html with ?fault= set,
  // after the bench moved there and the front page became the page for a person. The method is the
  // same: open the lab page and call its own ISLAND.shot and
  // ISLAND.probe. Each capture carries the fault it was taken under: the PNG through the page's
  // ISLAND.info() at the moment it was posted, and the probe JSON in its own `fault` field. They
  // live under shots/ and out/probes/, which are gitignored, so a fresh clone has no captures and
  // tools/selftest.mjs reports these rows as not proven until somebody opens the page again. Saying
  // that plainly is the point: no Node script in this repository can open a page.
  {
    id: 'blank-render',
    origin: 'stage-0',
    breaks: 'the renderer clears the frame and draws nothing',
    kind: 'runtime',
    hookSites: ['src/render/calibration.js'],
    instrument: 'shot',
    mode: 'assert',
    evidence: { healthy: 'shots/selftest-healthy-t0.png', faulted: 'shots/selftest-blank-render.png', scene: 'calibration' },
    mustName: ['quadrant-top-left', 'marker-plate', 'background colour'],
    inverted: false,
    blindSpot: null,
    proven: null,
    why: 'Only ever provable from a browser. tools/shot.mjs cannot open a page, so the row is proven '
      + 'against captures a browser session posted to shots/, and shots/ is gitignored. In a fresh '
      + 'clone this row reports unproven until somebody runs the page again.'
  },
  {
    id: 'stale-frame',
    origin: 'stage-0',
    breaks: 'the renderer stops following the simulation tick and redraws the frame it already had',
    kind: 'runtime',
    hookSites: ['src/render/calibration.js'],
    instrument: 'shot',
    mode: 'moved',
    evidence: {
      healthy: ['shots/selftest-healthy-t0.png', 'shots/selftest-healthy-t720.png'],
      faulted: ['shots/selftest-stale-a.png', 'shots/selftest-stale-b.png'],
      scene: 'calibration'
    },
    mustName: ['tick-swatch-centre', 'identical'],
    inverted: false,
    blindSpot: null,
    proven: null,
    why: 'docs/STAGE-0.md gives this row to shot --assert. It is wrong, and the matrix shows why: a '
      + 'stale frame passes every fixed sample, because every fixed sample is a constant. Only '
      + 'shot --moved, over two frames at two ticks, can see it. The registry names --moved.'
  },
  {
    id: 'hitch',
    origin: 'stage-0',
    breaks: 'a 40 ms stall on every sixtieth frame',
    kind: 'runtime',
    hookSites: ['src/render/calibration.js'],
    instrument: 'bench',
    evidence: {
      healthy: 'out/probes/selftest-bench-healthy.json',
      faulted: 'out/probes/selftest-bench-hitch.json'
    },
    mustName: ['p99', 'budget', 'worst', 'frame 58'],
    inverted: false,
    blindSpot: null,
    proven: null,
    why: 'Two 600 frame series posted by lab.html on 20 August 2026, one clean and one under the '
      + 'fault. The clean one gives p99 0.385 ms; the faulted one gives p99 40.085 ms and a worst '
      + 'frame of 40.64 ms at frame 58, with ten frames over budget exactly sixty apart. mustName '
      + 'asks for the frame index because "the worst frame" without one is a number nobody can go '
      + 'and look at.'
  },

  // ------------------------------------------------------------------------------ the interface
  {
    id: 'ui-unlabelled',
    origin: 'stage-0',
    breaks: 'a panel loses its accessible name',
    kind: 'runtime',
    hookSites: ['src/ui/panel.js'],
    instrument: 'uiprobe',
    evidence: {
      healthy: 'out/probes/selftest-healthy.json',
      faulted: 'out/probes/selftest-ui-unlabelled.json',
      expect: 'tools/panels/calibration.json'
    },
    mustName: ['panel-name', '[data-panel="sun"]', 'accessibleName is empty'],
    inverted: false,
    blindSpot: null,
    proven: null,
    why: 'The difference between the two probes is one field: the sun panel\'s accessible name goes '
      + 'empty while its heading stays on screen, so the picture is unchanged and the tree is not.'
  },
  {
    id: 'ui-dangling-prov',
    origin: 'stage-0',
    breaks: 'a displayed number cites a record id that does not exist',
    kind: 'runtime',
    hookSites: ['src/ui/panel.js'],
    instrument: 'uiprobe',
    evidence: {
      healthy: 'out/probes/selftest-healthy.json',
      faulted: 'out/probes/selftest-ui-dangling-prov.json',
      expect: 'tools/panels/calibration.json'
    },
    mustName: ['prov-resolves', 'dunwich-tide-constituents', 'tide-height'],
    inverted: false,
    blindSpot: null,
    proven: null,
    why: 'The pair on disk differs in two fields: the tide row cites a record id that does not '
      + 'exist and its resolved flag goes false. No number changes, which is why a picture cannot '
      + 'show it either.'
  },
  {
    id: 'ui-text-change',
    origin: 'stage-0',
    breaks: 'a visible label changes its text',
    kind: 'runtime',
    hookSites: ['src/ui/panel.js'],
    instrument: 'uiprobe',
    mustMiss: 'shot',
    inverted: true,
    evidence: {
      healthy: 'out/probes/selftest-healthy.json',
      faulted: 'out/probes/selftest-ui-text-change.json',
      expect: 'tools/panels/calibration.json'
    },
    missEvidence: { healthy: 'shots/selftest-healthy-t0.png', faulted: 'shots/selftest-ui-text-change.png', scene: 'calibration' },
    mustName: ['matches-baseline', 'Clock, island time', 'Island clock'],
    blindSpot: null,
    proven: null,
    why: 'The row this whole exercise is for, and both halves are run over the same page at the '
      + 'same tick. tools/shot.mjs is pointed at a capture taken with the fault on and has to PASS. '
      + 'tools/uiprobe.mjs is pointed at the probe taken in the same session and has to FAIL. A '
      + 'renamed panel keeps its role, its citation and its register, so uiprobe only sees it '
      + 'against the declared baseline in tools/panels/calibration.json: without --expect this row '
      + 'is missed by both instruments, which is worth knowing.'
  },

  // ----------------------------------------------------------------------- the cultural boundary
  {
    id: 'banned-token',
    origin: 'stage-0',
    breaks: 'a banned word is written into a data file',
    kind: 'tree',
    hookSites: ['data/tide.json'],
    instrument: 'gate/lore',
    mustName: ['no-banned-tokens', 'data/tide.json'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      addTopLevelKey(root, 'data/tide.json', 'fault_probe_note', firstBannedToken(root));
    },
    proven: true,
    why: 'The token is read out of data/lore.json at apply time rather than quoted here, because '
      + 'the banned list covers tools/ as well and a registry that names a banned token fails the '
      + 'rule it is trying to prove.'
  },
  {
    id: 'invented-language',
    origin: 'stage-0',
    breaks: 'a plausible language word that is not on the allowlist, in a cultural position',
    kind: 'tree',
    hookSites: ['data/tide.json'],
    instrument: 'gate/lore',
    mustName: ['no-invented-language', 'data/tide.json', 'cultural position'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      addTopLevelKey(root, 'data/tide.json', 'traditional_name', SPLICE_PROBE);
    },
    proven: true,
    why: ''
  },
  {
    id: 'approval-claim',
    origin: 'stage-0',
    breaks: 'an open cultural question written up as settled rather than open',
    kind: 'tree',
    hookSites: ['docs/CULTURAL-QUEUE.md'],
    instrument: 'gate/lore',
    mustName: ['cultural-queue-is-not-an-approval', 'docs/CULTURAL-QUEUE.md'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      const rel = 'docs/CULTURAL-QUEUE.md';
      const claim = ['', '## Fault probe', '', 'QYAC has ' + 'appro' + 'ved every question on this page.', ''];
      write(root, rel, read(root, rel) + claim.join('\n'));
    },
    proven: true,
    why: 'The claim is assembled from fragments at apply time so that this file, which the same rule '
      + 'scans, does not itself carry the sentence it plants.'
  },

  // ------------------------------------------------------------------------------- the contract
  {
    id: 'missing-provenance',
    origin: 'stage-0',
    breaks: 'a record without its source, its locator and the two times',
    kind: 'tree',
    hookSites: ['data/tide.json'],
    instrument: 'gate/provenance',
    mustName: ['provenance/record', 'fault-probe-record', 'validFrom', 'recordedAt'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      addTopLevelKey(root, 'data/tide.json', 'fault_probe_record', {
        id: 'fault-probe-record',
        source: 'first-build-places-pack',
        confidence: 'high'
      });
    },
    proven: true,
    why: ''
  },
  {
    id: 'em-dash',
    origin: 'stage-0',
    breaks: 'an em dash in a document and in a code comment',
    kind: 'tree',
    hookSites: ['docs/CONTRACT.md', 'src/systems/solar.js'],
    instrument: 'gate/style',
    mustName: ['style/em-dash', 'docs/CONTRACT.md', 'src/systems/solar.js'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      write(root, 'docs/CONTRACT.md',
        read(root, 'docs/CONTRACT.md') + '\nA planted line ' + EM_DASH + ' with an em dash in it.\n');
      prepend(root, 'src/systems/solar.js', ['// A planted comment ' + EM_DASH + ' with an em dash in it.']);
    },
    proven: true,
    why: 'docs/STAGE-0.md words this row as a document, a comment and a commit message. Two of the '
      + 'three are planted here and caught. The third belongs to tools/hooks/commit-msg, which '
      + 'landed at commit d845a1d and was watched refusing a message carrying U+2014 and passing a '
      + 'clean one. It cannot become a row in this registry: .git/hooks is not tracked, the hook is '
      + 'installed per machine, and no agent in this repository runs a state changing git command, '
      + 'so no fault here can reach it. Said in full at the foot of docs/JURISDICTION.md rather than '
      + 'left as a gap.'
  },
  {
    id: 'personal-data',
    origin: 'stage-0',
    breaks: 'a mobile number in a file under docs/',
    kind: 'tree',
    hookSites: ['docs/INGEST-STATUS.md'],
    instrument: 'gate/personal',
    mustName: ['personal/mobile', 'docs/INGEST-STATUS.md', 'mobile number'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      write(root, 'docs/INGEST-STATUS.md',
        read(root, 'docs/INGEST-STATUS.md') + '\nContact for the pack: ' + FICTITIOUS_MOBILE + '\n');
    },
    proven: true,
    why: 'docs/STAGE-0.md words this row as a staged file. gate/personal does not scan the staging '
      + 'area, so this row plants the number where the check actually looks. The staged case is a '
      + 'separate row, personal-data-staged, and it is a declared blind spot.'
  },
  {
    id: 'oversize-unscanned',
    origin: 'second-island',
    breaks: 'a mobile number in a file too large for gate/personal to open',
    kind: 'tree',
    hookSites: ['docs/INGEST-STATUS.md'],
    instrument: 'gate/personal',
    mustName: ['personal/unreadable', 'docs/INGEST-STATUS.md', 'byte limit'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      // The same file the personal-data row uses, padded past the limit. Before 19 August 2026 the
      // rule returned quietly here and the gate printed clean, so a leak inside a large bulk import
      // was invisible. A critic found it by putting the same address in two files that differed
      // only in padding. The rule now reports that it declined to read, which is what this proves.
      const pad = '\n' + 'padding '.repeat(1200000) + '\n';
      write(root, 'docs/INGEST-STATUS.md',
        read(root, 'docs/INGEST-STATUS.md') + '\nContact for the pack: ' + FICTITIOUS_MOBILE + '\n' + pad);
    },
    proven: true,
    why: 'A rule that goes quiet is worse than a rule that is absent, because the gate prints clean '
      + 'either way and only one of them looks like coverage. tools/gate/style.mjs and '
      + 'tools/gate/ports.mjs were hardened in the same commit and report the same way, one '
      + 'severity lower, because an unreadable file is a style risk rather than a leak.'
  },
  {
    id: 'personal-data-staged',
    origin: 'second-island',
    breaks: 'a mobile number in the ingest inbox, which is where the first build found two of them',
    kind: 'tree',
    hookSites: ['ingest-inbox/fault-probe.txt'],
    instrument: null,
    mustName: [],
    inverted: true,
    mustMiss: 'gate/personal',
    blindSpot: 'gate/personal scans data/, assets/ and docs/ and skips ingest-inbox/ along with the '
      + 'other staging trees, so a contact detail sitting in the inbox is invisible to it. '
      + 'gate/sealed proves the inbox cannot be committed, which is a different claim: sealed says '
      + 'it will not reach git, not that nobody put a phone number in it. The first build found two '
      + 'mobile numbers exactly there. Closing this needs a scan of the inbox at ingest time, which '
      + 'belongs with the ingest lane in stage 2 and does not exist yet.',
    apply(root) {
      const abs = path.join(root, 'ingest-inbox');
      if (!existsSync(abs)) mkdirSync(abs, { recursive: true });
      write(root, 'ingest-inbox/fault-probe.txt',
        'raw import, nobody has judged this yet\ncontact ' + FICTITIOUS_MOBILE + '\n');
    },
    proven: null,
    why: 'An inverted row. It exists to make the gap executable: the whole gate has to stay clean '
      + 'with a phone number sitting in the inbox, and the day that changes this row changes with it.'
  },
  {
    id: 'unsealed-staging',
    origin: 'stage-0',
    breaks: 'the ingest inbox becomes committable again through a negation in .gitignore',
    kind: 'tree',
    hookSites: ['.gitignore'],
    instrument: 'gate/sealed',
    mustName: ['sealed/unsealed', 'ingest-inbox'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      write(root, '.gitignore', read(root, '.gitignore').replace(/\s*$/, '\n') + '!ingest-inbox/\n');
    },
    proven: true,
    why: 'The seal is decided on the .gitignore inside the tree under test. git itself answers about '
      + 'the enclosing repository when the tree sits under out/, and gate/sealed reports that as '
      + 'advisory context rather than a pass. Both witnesses appear in the output.'
  },

  // -------------------------------------------------- this build's rows, so no rule goes unproven
  {
    id: 'port-collision',
    origin: 'second-island',
    breaks: "a server binds the first build's port",
    kind: 'tree',
    hookSites: ['tools/serve.mjs'],
    instrument: 'gate/ports',
    mustName: ['ports/first-island-port', 'tools/serve.mjs', FIRST_ISLAND_PORT],
    inverted: false,
    blindSpot: null,
    apply(root) {
      prepend(root, 'tools/serve.mjs', ['const FAULT_PORT = ' + FIRST_ISLAND_PORT + ';', 'export { FAULT_PORT };']);
    },
    proven: true,
    why: 'Added by this build. gate/ports had no fault, and an instrument with no fault is an '
      + 'instrument nobody has watched work.'
  },
  {
    id: 'board-malformed',
    origin: 'second-island',
    breaks: 'a board note carries a status the board does not have',
    kind: 'tree',
    hookSites: ['docs/board/900-fault-probe.md'],
    instrument: 'gate/board',
    mustName: ['board/status', 'docs/board/900-fault-probe.md'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      write(root, 'docs/board/900-fault-probe.md', [
        '---',
        'id: 900',
        'title: A note with a status the board does not have',
        'status: bogus',
        'opened: 2026-08-18',
        'author: tools/faults.mjs',
        'tags: fault-probe',
        '---',
        '',
        'Planted by the fault registry so gate/board can be watched failing.',
        ''
      ].join('\n'));
    },
    proven: true,
    why: 'Added by this build. gate/board had no fault.'
  },
  {
    id: 'undeclared-fault-hook',
    origin: 'second-island',
    breaks: 'a faulty() branch appears in a file no registry entry declares',
    kind: 'tree',
    hookSites: ['src/systems/solar.js'],
    instrument: 'gate/instruments',
    mustName: ['instruments/undeclared-hook', 'src/systems/solar.js', 'undeclared-probe'],
    inverted: false,
    blindSpot: null,
    apply(root) {
      prepend(root, 'src/systems/solar.js', [
        "import { faulty } from '../kernel/faults.js';",
        'export const FAULT_PROBE = ' + UNDECLARED_HOOK_CALL + ';'
      ]);
    },
    proven: true,
    why: 'Added by this build. This is the fault that guards the registry itself: without it, a hook '
      + 'could be added to shipping code and nothing would notice.'
  },

  // ------------------------------------------------------------------------ the bitemporal spine
  //
  // Stage 3. Both rows arrived with the store and the ladder they break, in the same wave, because
  // gate/instruments refuses a faulty() branch in a file no entry declares and it is right to: a
  // hook nobody registered is a back door. The instrument that owns both is tools/bitemporal.mjs.
  {
    id: 'frozen-clock',
    origin: 'second-island',
    breaks: "a read ignores the cursor's valid time and answers at the last lived minute instead",
    kind: 'runtime',
    hookSites: ['src/world/bitemporal.js'],
    instrument: 'bitemporal',
    mustName: ['FAILED CHECK', 'history-is-not-the-present', 'fixture.status'],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: "The first build's exact bug, made injectable: a departure board followed the projected "
      + 'clock while the figure beside it stayed frozen at the last lived tick, and neither panel '
      + 'was wrong on its own terms. Four checks fail under it, and the first one names the read '
      + 'that went wrong rather than the store in general.'
  },
  {
    id: 'stale-wins',
    origin: 'second-island',
    breaks: 'the simulation rung wins in live mode against a stale official observation',
    kind: 'runtime',
    hookSites: ['src/world/ladder.js'],
    instrument: 'bitemporal',
    mustName: ['FAILED CHECK', 'live-refuses-the-bottom-rung', 'simulation'],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: 'The founding prompt says the bottom rung never wins in live mode and that the honest '
      + 'answer to a stale feed is not known, dated. Under this fault freshness outranks the '
      + "ladder, so the twin's own simulation answers a live question that a stale official "
      + 'observation should have answered, which is the shape of the first build\'s synthetic '
      + 'weather standing beside a free real feed with nothing on screen saying which was which.'
  },
  {
    id: 'correction-overwrites',
    origin: 'second-island',
    breaks: 'a correction replaces the old belief in its slot instead of opening a new one',
    kind: 'runtime',
    hookSites: ['src/world/bitemporal.js'],
    instrument: 'bitemporal',
    mustName: [
      'FAILED CHECK',
      'a-correction-closes-the-old-belief-and-opens-a-new-one',
      'the-timeline-holds-every-belief-in-order',
      'closed 0 beliefs'
    ],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: 'The write half of the spine, which had no fault. frozen-clock breaks a read and stale-wins '
      + 'breaks the ladder, and until this row nothing had been watched breaking the claim that a '
      + 'correction is a new belief rather than an edit. That claim is the whole reason the second '
      + 'time axis exists: a store that overwrites on correction can no longer answer what a past '
      + 'decision could see. Four checks fail under it. One does not, and that is worth knowing: '
      + 'nothing-is-overwritten holds a reference captured before the correction and still reads the '
      + 'old value, so it proves the stored object is not mutated and does not prove the store kept '
      + 'the belief. the-timeline-holds-every-belief-in-order is the check that sees this fault, and '
      + 'it names the missing row.'
  },

  // ---------------------------------------------------------------------- the derived data lane
  //
  // Stage 2 downloaded real ground and derived packs from it, and this wave commits none of it: the
  // ODbL share-alike question against LICENCE.md is open, board note 007. Two rows, both owned by
  // tools/gate/derived.mjs, which arrived with them.
  {
    id: 'unprovenanced-derive',
    origin: 'second-island',
    breaks: 'a connector emits a derived record without the eight provenance fields',
    kind: 'tree',
    hookSites: ['ingest-inbox/derived/fault-probe-pack.json'],
    instrument: 'gate/derived',
    mustName: [
      'derived/unprovenanced',
      'ingest-inbox/derived/fault-probe-pack.json',
      'fault-probe-unprovenanced',
      'missing validFrom',
      'missing recordedAt'
    ],
    inverted: false,
    blindSpot: null,
    apply(root) {
      write(root, 'ingest-inbox/derived/fault-probe-pack.json', JSON.stringify({
        pack: 'fault-probe',
        version: '0.1.0',
        about: 'Planted by tools/faults.mjs inside a throwaway copy under out/. It is not a pack of '
          + 'anything, no figure in it describes this island, and its geometry is two zeroes.',
        count: 2,
        features: [
          probeRecord(1),
          {
            id: 'fault-probe-unprovenanced',
            kind: 'building',
            outline: PROBE_OUTLINE,
            source: 'osm-overpass',
            confidence: 'medium'
          }
        ]
      }, null, 2) + '\n');
    },
    proven: true,
    why: 'The row is honest about what it proves and what it does not. gate/derived reads the pack '
      + 'the connector wrote, in the directory the connector writes to, so what is watched is the '
      + 'artefact rather than the act of emitting it. Running a connector inside the selftest would '
      + 'mean carrying its raw response, tens of megabytes of gitignored bytes, through a connector '
      + 'run in every copy of the repository this file makes. The planted record carries an id, a '
      + 'source and a confidence and nothing else, which is the shape a connector actually produces '
      + 'when one code path forgets to spread the provenance in: never nothing, always some of it.'
  },
  {
    id: 'derived-committed',
    origin: 'second-island',
    breaks: 'a derived pack appears under data/ instead of ingest-inbox/derived/',
    kind: 'tree',
    hookSites: ['data/osm-buildings-fault-probe.json'],
    instrument: 'gate/derived',
    mustName: [
      'derived/committed',
      'data/osm-buildings-fault-probe.json',
      'connector pack name',
      'ingest-inbox provenance',
      'self declared not committable',
      'bulk feature set'
    ],
    inverted: false,
    blindSpot: null,
    apply(root) {
      const features = [];
      for (let i = 0; i < 60; i++) features.push(probeRecord(i));
      write(root, 'data/osm-buildings-fault-probe.json', JSON.stringify({
        pack: CONNECTOR_PACK_NAME,
        version: '0.1.0',
        committable: false,
        about: 'Planted by tools/faults.mjs inside a throwaway copy under out/, to be a derived pack '
          + 'sitting where a derived pack may not sit. No figure in it describes this island and its '
          + 'geometry is two zeroes.',
        rawFile: 'ingest-inbox/osm/fault-probe-raw.json',
        count: features.length,
        buildings: features
      }, null, 2) + '\n');
    },
    proven: true,
    why: 'Every record in the planted pack passes gate/provenance, on purpose. A probe that also '
      + 'broke provenance would go green on the wrong instrument and prove nothing about this one. '
      + 'All four marks are planted in the one file and mustName asks for all four by name, so the '
      + 'row fails if any branch of the rule stops firing. The rule stands down by itself when board '
      + "note 007 reads resolved, which is the owner's decision to make and not this registry's."
  },

  // ---------------------------------------------------------------- the crossings, and the law
  //
  // Stage 2 again. Wave 6 landed data/crossings.json, src/systems/crossings.js and
  // tools/gate/crossings.mjs, and board note 032 said plainly what was owed: "gate/crossings has no
  // fault row, so it has no column in docs/JURISDICTION.md and the selftest does not prove it. It
  // was proved by hand this once, and a hand proof is a rumour by the second week." These three
  // rows are that proof, kept, one per rule the check carries.
  {
    id: 'crossings-summed',
    origin: 'second-island',
    breaks: 'a vehicle figure and a passenger figure are added, and a field is named that could hold both',
    kind: 'tree',
    hookSites: ['src/systems/crossings.js'],
    instrument: 'gate/crossings',
    mustName: ['crossings/summed', 'src/systems/crossings.js', SUMMED_EXPRESSION, MERGED_NAME],
    inverted: false,
    blindSpot: null,
    apply(root) {
      // Two constants and a sum, then a name holding both classes and a countable word. They are
      // inert: nothing imports them, and src/systems/crossings.js is not registered in the island
      // the instruments build, so this plant cannot move another instrument's numbers.
      prepend(root, 'src/systems/crossings.js', [
        'export const ' + VEHICLE_FIGURE + ' = 10;',
        'export const ' + PASSENGER_FIGURE + ' = ' + SAILING_COUNT + ';',
        'export const FAULT_TOTAL = ' + SUMMED_EXPRESSION + ';',
        'export const ' + MERGED_NAME + ' = FAULT_TOTAL;'
      ]);
    },
    proven: true,
    why: 'docs/CONTRACT.md section 6 carried this law as NOT YET CHECKED from the day it was '
      + 'written, with the reason that the check lands with transport data. The data landed, the '
      + 'check landed with it, and this row is the part that makes the check more than a claim. '
      + 'Both halves of the rule are planted in one file so the row fails if either stops firing: '
      + 'the addition, which is the mistake being made, and the merged name, which is the field '
      + 'where somebody would make it tomorrow.'
  },
  {
    id: 'crossing-unattributed',
    origin: 'second-island',
    breaks: 'a crossing figure and a movement figure written without saying which service or which landing point',
    kind: 'tree',
    hookSites: ['docs/INGEST-STATUS.md'],
    instrument: 'gate/crossings',
    mustName: [
      'crossings/unattributed',
      'docs/INGEST-STATUS.md',
      SAILING_COUNT + ' departures',
      MOVEMENT_COUNT + ' vessel movements'
    ],
    inverted: false,
    blindSpot: null,
    apply(root) {
      // Both figures are true of something. Neither sentence says of what, which is the whole
      // defect: the two passenger services run the same number of departures each way, and the two
      // landing points carry different totals, so a bare figure could be either.
      append(root, 'docs/INGEST-STATUS.md', [
        '',
        '## Fault probe',
        '',
        'The passenger timetable holds ' + SAILING_COUNT + ' departures a day off the island.',
        'The terminal handles ' + MOVEMENT_COUNT + ' vessel movements a day.'
      ]);
    },
    proven: true,
    why: 'The word "passenger" is in the planted line on purpose. It reads like attribution and is '
      + 'not: both passenger services run fourteen departures each way, so a figure that says only '
      + '"passenger" leaves the reader unable to tell which one. That is the case board note 032 '
      + 'called the one worth catching, and a row that planted an obviously bare figure would not '
      + 'have tested it.'
  },
  {
    id: 'crossing-carries-both',
    origin: 'second-island',
    breaks: 'a sailing declares a third value for what it carries, and another declares none at all',
    kind: 'tree',
    hookSites: ['data/crossings.json'],
    instrument: 'gate/crossings',
    mustName: [
      'crossings/carries-enum',
      'data/crossings.json',
      'carries is "' + THIRD_CARRIES_VALUE + '"',
      'a sailing with no carries field'
    ],
    inverted: false,
    blindSpot: null,
    apply(root) {
      editJson(root, 'data/crossings.json', (doc) => {
        const list = Array.isArray(doc.sailings) ? doc.sailings : [];
        if (list.length < 2) throw new Error('data/crossings.json holds fewer than two sailings, so this fault cannot be built');
        list[0].carries = THIRD_CARRIES_VALUE;
        delete list[1].carries;
      });
    },
    proven: true,
    why: 'The enum is where the two-crossings law stopped being a paragraph and became a type, so '
      + 'both ways of breaking the type are planted at once: a third value meaning both, and an '
      + 'absent value, which leaves a reader to guess whether a car can be on that boat. The seal '
      + 'in gate/ground-truth does not fire on this, and that is deliberate rather than lucky: the '
      + 'seal covers times, vessel codes and day rules, and what a boat carries is a different '
      + 'claim with a different rule.'
  },
  {
    id: 'timetable-drift',
    origin: 'second-island',
    breaks: "a departure time in the owner's supplied timetable is altered",
    kind: 'tree',
    hookSites: ['data/crossings.json'],
    instrument: 'gate/ground-truth',
    mustName: [
      'ground-truth/timetable-drift',
      'data/crossings.json',
      DRIFT_SAILING_ID,
      DRIFT_SUPPLIED,
      DRIFT_ALTERED,
      'ground-truth/seal'
    ],
    inverted: false,
    blindSpot: null,
    apply(root) {
      editJson(root, 'data/crossings.json', (doc) => {
        const list = Array.isArray(doc.sailings) ? doc.sailings : [];
        const s = list.find((x) => x && x.id === DRIFT_SAILING_ID);
        if (!s) throw new Error('data/crossings.json holds no sailing ' + DRIFT_SAILING_ID + ', so this fault cannot be built');
        const [hh, mm] = DRIFT_ALTERED.split(':').map(Number);
        s.departsLocal = DRIFT_ALTERED;
        s.departsMinuteOfDay = hh * 60 + mm;
      });
    },
    proven: true,
    why: 'The most valuable data in this repository is the one thing in it no connector can fetch '
      + 'again. The crossing timetables came from the owner on 19 August 2026 out of the two '
      + "operators' published timetables, board notes 029 and 030 carry them in his words, and "
      + 'nothing in the world can be asked whether a value in the pack has moved. Until this row '
      + 'nothing here could either. Five minutes was the whole margin: the same drift was planted '
      + 'in a copy of the tree and `node tools/check-crossings.mjs` reported all forty checks '
      + 'passing, because its window checks read the first and last row of a column, its rotation '
      + 'checks read vessel codes, and its movement checks are row counts. A middle row of a column '
      + 'is invisible to every one of them. mustName asks for both halves of the rule, the drift '
      + 'that names what moved and the seal that catches what a transcription cannot see.'
  },

  // -------------------------------------------------------------------------- the store, wired
  {
    id: 'store-unwired',
    origin: 'second-island',
    breaks: 'the world builds with no record store, no cursor and no field resolver, so the value a panel shows never went through the ladder',
    kind: 'runtime',
    hookSites: ['src/world/island.js'],
    instrument: 'check-wiring',
    mustName: [
      'FAILED CHECK',
      'the-world-carries-a-record-store',
      'the-answer-on-the-page-came-through-the-ladder',
      'no resolver was supplied'
    ],
    inverted: false,
    blindSpot: null,
    proven: true,
    why: 'Board note 018 described this state exactly: "Nothing is wired. src/world/island.js builds '
      + 'no store, no system reads one, no number on screen goes through the ladder." Board note 031 '
      + 'closed it and proved the closing with a script under out/, which is gitignored, so the '
      + 'proof went away with the agent that wrote it. This row is that proof kept, and it is a '
      + 'runtime branch rather than a tree edit because the failure is a wire that was never '
      + 'attached and not a line anybody typed. Ten of the thirteen checks fail under it. One that '
      + 'does not is worth reading: the-simulation-rung-is-not-the-answer passes, because with no '
      + 'answer at all nothing borrowed the simulation rung, and a row that counted it would be '
      + 'counting an absence as a pass. The half this cannot reach is a panel in a browser reading '
      + 'a value around the ladder, which needs a capture nobody has taken.'
  }
];

// ---------------------------------------------------------------------------------------------
// Derived views. gate/instruments and tools/selftest.mjs both read these rather than re-deriving.
// ---------------------------------------------------------------------------------------------

/** Every fault id, in registry order. */
export function faultIds() {
  return FAULTS.map((f) => f.id);
}

export function faultById(id) {
  return FAULTS.find((f) => f.id === id) || null;
}

/** Files a runtime fault says carry its faulty() call. Tree faults write files, they do not hook them. */
export function declaredHookFiles() {
  const files = new Map();
  for (const f of FAULTS) {
    if (f.kind !== 'runtime') continue;
    for (const site of f.hookSites) {
      if (!files.has(site)) files.set(site, []);
      files.get(site).push(f.id);
    }
  }
  return files;
}

/** Instruments some fault names as its owner, so gate/instruments can find the ones with none. */
export function provenInstruments() {
  const names = new Set();
  for (const f of FAULTS) {
    if (f.instrument) names.add(f.instrument);
    if (f.mustMiss) names.add(f.mustMiss);
  }
  return names;
}

export const REGISTRY_VERSION = '1';
