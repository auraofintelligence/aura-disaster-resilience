#!/usr/bin/env node
// The headless instrument: the whole island in Node, with no browser and no renderer.
//
//     node tools/headless.mjs --ticks 1440
//     node tools/headless.mjs --ticks 1440 --json
//     node tools/headless.mjs --ticks 1440 --fixtures
//     node tools/headless.mjs --ticks 1440 --system solar
//     node tools/headless.mjs --ticks 1440 --profile
//
// This is the instrument stage 0 builds first, and the reason it can exist at all is the contract's
// rule that simulation never imports the renderer or the UI. If a system could only run where a
// canvas exists then there would be nothing to run here, and determinism would be untestable.
//
// What it reports, and why each line is in it rather than in a comment somewhere:
//
//   ticks, wall seconds, ticks per second   the founding prompt expects a headless sim year to be
//                                           routine, and a number is the only way to know it is.
//   per system hash                         a system's own state and its own stream, which is what
//                                           lets tools/determinism.mjs name a drift.
//   per system milliseconds                 real, because the World takes a `now` function and this
//                                           file injects one. The kernel never reads a clock itself.
//   budget overruns                         a system over its declared per tick budget, at the tick
//                                           it happened. Blocking, because a budget nobody enforces
//                                           is a comment. See the note on garbage collection below.
//   the seams table                         who emits what and who listens.
//   DEAD SEAMS                              declared event types that never fired once. The first
//                                           build shipped forty-six clean systems with dead seams
//                                           between them, nine of eleven sentiment channels never
//                                           firing, and nobody could see that from inside. Here it
//                                           is a line in the report of every run.
//   unlistened types                        declared and emitted with nobody on the other end.
//
// Exit code is 1 when a system throws, when a budget is overrun by the system's own work, or when
// the world hash cannot be computed. It is 2 on a usage error. Otherwise 0.
//
// --fixtures loads tools/fixtures/spin.js, three synthetic systems that exist only to give the
// instruments something that exercises the kernel. They are not part of the island. The import is
// dynamic so that a plain run never loads them at all.
//
// GARBAGE COLLECTION, AND WHY THIS FILE MEASURES IT
//
// Written plainly because it is a deviation from the brief this file was built to, and a deviation
// nobody can see is a lie. The brief said: exit non-zero if a budget is overrun. Built that way,
// the instrument failed the healthy build. Solar declares a 0.5 ms budget and averages 0.004 ms,
// and about two runs in five of a single sim day still reported one tick over 0.5 ms. Over a sim
// year the healthy build reported sixteen.
//
// So the overruns were measured rather than argued about. This file subscribes to the runtime's
// garbage collection events and records the start and end of every timed sample, and in a sim year
// all nineteen samples over 0.4 ms had a collector pause inside them accounting for 95 to 99 per
// cent of the sample. The systems were never slow. The process stopped.
//
// The rule that follows from that measurement:
//
//   Every overrun is reported, always, with the collector milliseconds inside it named separately
//   from the system's own work. An overrun whose remaining work still exceeds the budget fails the
//   run. An overrun fully accounted for by a collector pause is reported and does not. If the
//   correlation cannot be established, every overrun fails, because an unexplained overrun is an
//   overrun. --strict-budgets restores the literal rule and fails on any overrun at all.
//
// An instrument that fails on a healthy build is worse than no instrument, because the next person
// learns to run it twice. The frame time question this leaves open belongs to tools/bench.mjs,
// where a collector pause inside a frame is a hitch a player feels and is counted as one.
//
// What is left, measured rather than assumed: twelve sim year runs on an idle machine reported no
// unexplained overrun. Two sim years started at the same moment produced one, a 0.73 ms sample with
// no collector pause anywhere inside it, which is the operating system taking the thread away. That
// is reported as unexplained and fails the run, which is the right answer: an instrument that
// cannot say where a stall came from must not say it was fine. Run the instruments one at a time.

import { PerformanceObserver } from 'node:perf_hooks';
import { buildIsland } from '../src/world/island.js';
import { ACTIVE_FAULT, faultBanner } from '../src/kernel/faults.js';

function usage() {
  return [
    'node tools/headless.mjs [--ticks N] [--json] [--fixtures] [--system <name>] [--profile]',
    '',
    '  --ticks N          island minutes to run, default 1440, which is one sim day',
    '  --json             machine readable output on stdout, nothing else',
    '  --fixtures         add the synthetic test systems from tools/fixtures/spin.js',
    '  --system <name>    focus the report on one system',
    '  --profile          step one tick at a time and report the per tick cost distribution',
    '  --strict-budgets   fail on any budget overrun, including one a collector pause explains',
    '',
    "Exit code 1 when a system throws, when a budget is overrun by the system's own work, or when",
    'the world hash cannot be computed.'
  ].join('\n');
}

function parseArgs(argv) {
  const opts = {
    ticks: 1440, json: false, fixtures: false, system: null, profile: false,
    strictBudgets: false, help: false
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--json') opts.json = true;
    else if (a === '--fixtures') opts.fixtures = true;
    else if (a === '--profile') opts.profile = true;
    else if (a === '--strict-budgets') opts.strictBudgets = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else if (a === '--ticks') opts.ticks = Number(argv[++i]);
    else if (a.startsWith('--ticks=')) opts.ticks = Number(a.slice(8));
    else if (a === '--system') opts.system = argv[++i] ?? null;
    else if (a.startsWith('--system=')) opts.system = a.slice(9);
    else throw new Error('unknown argument: ' + a + '\n\n' + usage());
  }
  if (!Number.isInteger(opts.ticks) || opts.ticks < 0) {
    throw new Error('--ticks needs a whole number of ticks, got ' + String(opts.ticks) + '\n\n' + usage());
  }
  return opts;
}

const round = (v, dp = 3) => (v === null || v === undefined ? null : Number(v.toFixed(dp)));

/** Nearest rank, so the reported figure is a tick that actually happened rather than an average. */
function percentile(sorted, p) {
  if (!sorted.length) return null;
  const i = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return sorted[i];
}

async function main() {
  let opts;
  try {
    opts = parseArgs(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err.message) + '\n');
    process.exitCode = 2;
    return;
  }
  if (opts.help) {
    process.stdout.write(usage() + '\n');
    return;
  }

  // Collector pauses, so an overrun can be attributed rather than guessed at. The entries arrive on
  // a later turn of the event loop, so they are collected after the run rather than during it.
  const gcPauses = [];
  let gcObserver = null;
  try {
    gcObserver = new PerformanceObserver((list) => {
      for (const e of list.getEntries()) {
        gcPauses.push({ start: e.startTime, end: e.startTime + e.duration, ms: e.duration, kind: e.detail ? e.detail.kind : null });
      }
    });
    gcObserver.observe({ entryTypes: ['gc'] });
  } catch {
    gcObserver = null; // no collector events available, so no overrun can be explained by one
  }

  // The timing function the World is given. The kernel calls it twice per system per tick, once
  // before the tick and once after, and never anywhere else, so pairing the calls reconstructs the
  // window every measurement was taken over. `slowWindows` keeps only the windows long enough to
  // possibly be an overrun, which in a sim year is about twenty of them.
  const slowWindows = [];
  let pendingStart = null;
  let pairingBroke = false;
  let windowThresholdMs = Infinity;
  const now = () => {
    const t = performance.now();
    if (pendingStart === null) {
      pendingStart = t;
    } else {
      const dt = t - pendingStart;
      if (dt > windowThresholdMs) slowWindows.push({ t0: pendingStart, t1: t, dt });
      pendingStart = null;
    }
    return t;
  };
  const wall = () => performance.now(); // never the injected one: an odd call would break the pairing

  // Built unbooted so the fixtures can register before boot. Everything else about the world is
  // exactly what src/world/island.js gives the page and the gate, which is the point of that file.
  let world;
  try {
    world = await buildIsland({ boot: false, now });
    if (opts.fixtures) {
      const { registerFixtures } = await import('./fixtures/spin.js');
      registerFixtures(world);
    }
    world.boot();
  } catch (err) {
    process.stderr.write('the island did not build:\n' + (err && err.stack ? err.stack : String(err)) + '\n');
    process.exitCode = 1;
    return;
  }

  if (opts.system && !world.byName.has(opts.system)) {
    process.stderr.write(
      '--system ' + opts.system + ' is not a registered system.\n'
      + 'registered: ' + world.systems.map((s) => s.name).sort().join(', ') + '\n'
    );
    process.exitCode = 2;
    return;
  }

  // ---- run ------------------------------------------------------------------------------------

  const names = world._sorted().map((s) => s.name);
  const perTick = opts.profile ? new Map(names.map((n) => [n, new Float64Array(opts.ticks)])) : null;
  const seen = new Map(names.map((n) => [n, 0]));

  // Only a sample longer than the smallest declared budget can be an overrun, so that is the point
  // at which a window is worth keeping. No budget declared anywhere means no overrun is possible.
  const budgets = world.systems.map((s) => s.budgetMs).filter((b) => typeof b === 'number');
  windowThresholdMs = budgets.length ? Math.min(...budgets) : Infinity;

  let thrown = null;
  const wall0 = wall();
  try {
    if (opts.profile) {
      for (let i = 0; i < opts.ticks; i++) {
        world.step(1);
        for (const n of names) {
          const total = world.cost.get(n) || 0;
          perTick.get(n)[i] = total - seen.get(n);
          seen.set(n, total);
        }
      }
    } else {
      world.step(opts.ticks);
    }
  } catch (err) {
    thrown = err;
  }
  const wallMs = wall() - wall0;
  if (pendingStart !== null) pairingBroke = true;

  // The collector events are delivered on a later turn of the event loop, so the run has to yield
  // before they can be read. This wait is outside the measured window and costs the report nothing.
  if (gcObserver) {
    await new Promise((resolve) => setTimeout(resolve, 25));
    gcObserver.disconnect();
  }

  // ---- report ---------------------------------------------------------------------------------

  let report = null;
  let hashError = null;
  try {
    report = world.report();
  } catch (err) {
    hashError = err;
  }

  const ticksRun = world.clock.tick;
  const wallSeconds = wallMs / 1000;
  const ticksPerSecond = wallSeconds > 0 ? ticksRun / wallSeconds : null;

  const systems = world._sorted().map((s) => {
    const total = world.cost.has(s.name) ? world.cost.get(s.name) : null;
    const row = {
      name: s.name,
      order: s.order,
      msTotal: total === null ? null : round(total, 3),
      msPerTick: total === null || ticksRun === 0 ? null : round(total / ticksRun, 6),
      budgetMs: s.budgetMs,
      hash: report ? report.hashes[s.name] : null,
      emits: s.emits,
      listens: s.listens
    };
    if (opts.profile && perTick && ticksRun > 0) {
      const sorted = Array.from(perTick.get(s.name).subarray(0, ticksRun)).sort((a, b) => a - b);
      row.profile = {
        minMs: round(sorted[0], 6),
        p50Ms: round(percentile(sorted, 50), 6),
        p95Ms: round(percentile(sorted, 95), 6),
        p99Ms: round(percentile(sorted, 99), 6),
        maxMs: round(sorted[sorted.length - 1], 6)
      };
    }
    return row;
  });

  // Each overrun matched back to the window it was measured over, and that window checked against
  // the collector pauses. The kernel's `ms` is `t1 - t0` from the same two floats this file paired,
  // so the match is on exact equality, scanning forward because both lists are chronological.
  let cursor = 0;
  const overruns = world.overruns.map((o) => {
    let window = null;
    if (!pairingBroke) {
      for (let i = cursor; i < slowWindows.length; i++) {
        if (slowWindows[i].dt === o.ms) { window = slowWindows[i]; cursor = i + 1; break; }
      }
    }
    let gcMs = null;
    let kinds = [];
    if (window) {
      gcMs = 0;
      for (const g of gcPauses) {
        const overlap = Math.min(g.end, window.t1) - Math.max(g.start, window.t0);
        if (overlap > 0) { gcMs += overlap; kinds.push(g.kind); }
      }
    }
    const workMs = gcMs === null ? null : o.ms - gcMs;
    return {
      system: o.system,
      tick: o.tick,
      ms: round(o.ms, 4),
      budgetMs: o.budgetMs,
      gcMs: gcMs === null ? null : round(gcMs, 4),
      workMs: workMs === null ? null : round(workMs, 4),
      gcKinds: kinds,
      explainedByGc: workMs !== null && workMs <= o.budgetMs
    };
  });

  const unexplained = overruns.filter((o) => !o.explainedByGc);
  const failingOverruns = opts.strictBudgets ? overruns : unexplained;

  const problems = [];
  if (thrown) problems.push('a system threw at tick ' + ticksRun + ': ' + (thrown && thrown.message ? thrown.message : String(thrown)));
  if (hashError) problems.push('the world hash could not be computed: ' + (hashError.message || String(hashError)));
  if (failingOverruns.length) {
    problems.push(failingOverruns.length + ' budget overrun(s) '
      + (opts.strictBudgets ? 'under --strict-budgets' : "not explained by a collector pause"));
  }

  const out = {
    ok: problems.length === 0,
    fault: ACTIVE_FAULT || null,
    seed: world.seed,
    epoch: world.clock.epochISO,
    fixtures: opts.fixtures,
    profile: opts.profile,
    ticksRequested: opts.ticks,
    ticksRun,
    endIslandTime: world.clock.iso(),
    wallSeconds: round(wallSeconds, 4),
    ticksPerSecond: ticksPerSecond === null ? null : Math.round(ticksPerSecond),
    registrationOrder: world.systems.map((s) => s.name),
    systems,
    hash: report ? report.hash : null,
    hashes: report ? report.hashes : null,
    store: report ? report.store : world.store.stats(),
    seams: report ? report.seams : world.seams(),
    deadSeams: report ? report.deadSeams : [],
    unlistenedEvents: report ? report.unlistenedEvents : [],
    overruns,
    gc: {
      observed: gcObserver !== null,
      pauses: gcPauses.length,
      totalMs: round(gcPauses.reduce((a, g) => a + g.ms, 0), 3),
      windowPairing: pairingBroke ? 'broken, so no overrun can be attributed' : 'sound'
    },
    strictBudgets: opts.strictBudgets,
    problems
  };
  if (thrown) out.error = { message: String(thrown && thrown.message ? thrown.message : thrown), stack: thrown && thrown.stack ? String(thrown.stack).split('\n').slice(0, 6) : [] };
  if (opts.system) {
    const s = world.byName.get(opts.system);
    out.focus = { name: s.name, state: s.state, stream: world.streams.streams.has(s.name) ? world.streams.get(s.name).state() : null };
  }

  if (opts.json) {
    process.stdout.write(JSON.stringify(out, null, 2) + '\n');
  } else {
    const lines = [];
    const banner = faultBanner();
    if (banner) lines.push(banner, '');
    lines.push(`headless: seed ${out.seed}, epoch ${out.epoch}`);
    lines.push(`run:      ${out.ticksRun} ticks to ${out.endIslandTime}, ${out.wallSeconds} s, ${out.ticksPerSecond} ticks per second`);
    lines.push(`systems:  ${systems.length} registered${opts.fixtures ? ', fixtures on' : ''}${opts.profile ? ', profiling on' : ''}`);
    lines.push('');

    const shown = opts.system ? systems.filter((s) => s.name === opts.system) : systems;
    lines.push('system            order    ms total   ms/tick   budget   hash');
    for (const s of shown) {
      lines.push(
        '  ' + s.name.padEnd(16)
        + String(s.order).padStart(5)
        + String(s.msTotal === null ? '-' : s.msTotal.toFixed(3)).padStart(12)
        + String(s.msPerTick === null ? '-' : s.msPerTick.toFixed(5)).padStart(10)
        + String(s.budgetMs === null ? '-' : s.budgetMs).padStart(9)
        + '   ' + (s.hash || 'not computed')
      );
      if (s.profile) {
        lines.push(
          '      per tick ms: min ' + s.profile.minMs.toFixed(5)
          + '  p50 ' + s.profile.p50Ms.toFixed(5)
          + '  p95 ' + s.profile.p95Ms.toFixed(5)
          + '  p99 ' + s.profile.p99Ms.toFixed(5)
          + '  max ' + s.profile.maxMs.toFixed(5)
        );
      }
    }
    if (out.hashes) {
      lines.push('  ' + '_store'.padEnd(16) + '    -'.padStart(5) + '           -' + '         -' + '        -' + '   ' + out.hashes._store);
      lines.push('  ' + '_clock'.padEnd(16) + '    -'.padStart(5) + '           -' + '         -' + '        -' + '   ' + out.hashes._clock);
    }
    lines.push('');
    lines.push('world hash: ' + (out.hash || 'NOT COMPUTED'));
    lines.push('store:      ' + JSON.stringify(out.store));

    if (opts.system) {
      lines.push('');
      lines.push('focus on ' + out.focus.name + ':');
      lines.push('  state:  ' + JSON.stringify(out.focus.state));
      lines.push('  stream: ' + JSON.stringify(out.focus.stream) + '  [a, b, c, d, draws]');
      const mine = out.seams.filter((s) => s.emitters.includes(out.focus.name) || s.listeners.includes(out.focus.name));
      lines.push('  seams:  ' + (mine.length ? '' : 'none'));
      for (const s of mine) {
        lines.push(`    ${s.type}: emitters [${s.emitters.join(', ')}], listeners [${s.listeners.join(', ')}], fired ${s.fired}`);
      }
    }

    lines.push('');
    lines.push('seams:');
    for (const s of out.seams) {
      lines.push(`  ${s.type.padEnd(18)} emitters [${s.emitters.join(', ')}]  listeners [${s.listeners.join(', ')}]  fired ${s.fired}`);
    }
    lines.push('DEAD SEAMS (declared, never fired): ' + (out.deadSeams.length ? out.deadSeams.join(', ') : 'none'));
    lines.push('unlistened types (declared, nobody listens): ' + (out.unlistenedEvents.length ? out.unlistenedEvents.join(', ') : 'none'));

    lines.push('');
    if (out.overruns.length === 0) {
      lines.push('budget overruns: none'
        + (out.gc.pauses ? `  (${out.gc.pauses} collector pauses in the run, ${out.gc.totalMs} ms total, none inside an overrun)` : ''));
    } else {
      lines.push('BUDGET OVERRUNS: ' + out.overruns.length
        + ', of which ' + unexplained.length + ' not explained by a collector pause');
      for (const o of out.overruns.slice(0, 20)) {
        lines.push(`  ${o.system} at tick ${o.tick}: ${o.ms} ms against a budget of ${o.budgetMs} ms`
          + (o.gcMs === null
            ? '   [sample not matched, so nothing is attributed]'
            : `   garbage collection inside the sample ${o.gcMs} ms, own work ${o.workMs} ms`
              + (o.explainedByGc ? ', within budget' : ', OVER BUDGET')));
      }
      if (out.overruns.length > 20) lines.push('  ... and ' + (out.overruns.length - 20) + ' more');
      lines.push('  collector pauses in the whole run: ' + out.gc.pauses + ', ' + out.gc.totalMs + ' ms total');
    }

    if (out.error) {
      lines.push('');
      lines.push('A SYSTEM THREW at tick ' + out.ticksRun + ':');
      lines.push('  ' + out.error.message);
      for (const l of out.error.stack) lines.push('  ' + l.trim());
    }

    lines.push('');
    lines.push(out.ok ? 'PASS' : 'FAIL: ' + problems.join('; '));
    process.stdout.write(lines.join('\n') + '\n');
  }

  process.exitCode = out.ok ? 0 : 1;
}

main();
