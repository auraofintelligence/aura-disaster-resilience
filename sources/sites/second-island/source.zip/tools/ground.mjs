// The objective function: wall casting and holding wet sand open. Not boring speed.
//
//   node tools/ground.mjs
//   node tools/ground.mjs --removal 200 --lining 40
//
// The owner named the objective on 19 August 2026 and this tool answers to it rather than to
// advance rate. Where an input belongs to this island and is not in the repository, it is reported
// as unknown rather than given a number.

import { PHYSICS, UNKNOWN_SITE_INPUTS, wallPerMetre, freezeEnergyPerMetre, advance, removalImpliedBy, buoyancyPerMetre } from '../src/world/ground.js';
import { BORE_BANDS, SANDWORM } from '../src/world/tunnels.js';

const args = process.argv.slice(2);
const num = (n, d) => { const i = args.indexOf('--' + n); return i < 0 ? d : Number(args[i + 1]); };
const removal = num('removal', 200);   // m3 an hour, a stated pump or conveyor throughput
const lining = num('lining', 40);      // m2 an hour of wall cast, a stated rate

console.log('WALL, WHICH IS THE OBJECTIVE FUNCTION\n');
console.log('  bore m'.padEnd(10) + 'wall m2/m'.padStart(12) + 'spoil m3/m'.padStart(13) + 'spoil per m2 of wall'.padStart(23));
for (const b of BORE_BANDS) {
  const w = wallPerMetre(b.m, 0.15);
  console.log('  ' + String(b.m).padEnd(8) + w.wallAreaM2PerM.toFixed(2).padStart(12)
    + w.spoilM3PerM.toFixed(2).padStart(13) + (w.spoilM3PerM / w.wallAreaM2PerM).toFixed(2).padStart(23));
}
console.log('\n  Wall goes as the bore, linear. Spoil goes as its square. So the material you get per');
console.log('  square metre of wall you have to cast rises with bore, and the earlier spoil-budget');
console.log('  comparison in tools/tunnel.mjs was measuring the by-product instead of the cost.');

console.log('\nADVANCE IS REMOVAL, NOT CUTTING\n');
console.log(`  at ${removal} m3 an hour removed and ${lining} m2 an hour of wall cast, 168 hours a week\n`);
console.log('  bore m'.padEnd(10) + 'removal m/h'.padStart(14) + 'lining m/h'.padStart(13) + 'binding'.padStart(10) + 'm/week'.padStart(11));
for (const b of BORE_BANDS) {
  const a = advance({ boreM: b.m, removalRateM3PerHour: removal, liningRateM2PerHour: lining });
  console.log('  ' + String(b.m).padEnd(8) + a.removalLimitedMPerHour.toFixed(1).padStart(14)
    + a.liningLimitedMPerHour.toFixed(1).padStart(13) + a.bindingConstraint.padStart(10)
    + Math.round(a.metresPerWeek).toLocaleString().padStart(11));
}
console.log('\n  Removal advantage scales as the square of the bore, lining advantage as the bore.');
console.log('  A small bore wins on both, and the constraint that bites is the wall in every row.');

const impl = removalImpliedBy({ boreM: 1.5, metresPerWeek: SANDWORM.advanceMetresPerWeek });
console.log(`\n  The declared ${SANDWORM.advanceMetresPerWeek} m a week at a 1.5 m bore implies only ${impl.m3PerHour.toFixed(1)} m3 an hour of removal,`);
console.log('  running continuously. That is a modest pump, which is consistent with removal not');
console.log('  being the thing that limits this.');

console.log('\nFREEZING THE WET SAND, per metre, across the porosity nobody has measured here\n');
console.log('  porosity'.padEnd(11) + 'water kg/m'.padStart(12) + 'heat kWh/m'.padStart(12) + 'latent share'.padStart(14));
for (const porosity of [0.30, 0.35, 0.40, 0.45]) {
  const f = freezeEnergyPerMetre({
    boreM: 2.5, freezeThicknessM: 1, porosity, saturation: 1,
    groundTempC: 22, targetTempC: -10, copRefrigeration: 1
  });
  console.log('  ' + String(porosity).padEnd(9) + Math.round(f.waterKgPerM).toLocaleString().padStart(12)
    + f.heatRemoved_kWh_per_m.toFixed(0).padStart(12) + (100 * f.latentShareOfHeat).toFixed(0).padStart(13) + '%');
}
console.log('\n  A 2.5 m bore with a 1 m frozen ring, ground at 22 C taken to -10 C, saturated.');
console.log('  Ground temperature, saturation and the ring thickness are all assumptions of this');
console.log('  illustration and not measurements of this island. The heat figure is the heat to');
console.log('  remove, not the electricity: divide by the plant coefficient of performance, which');
console.log('  at these temperatures is well under 1 for a single stage.');
console.log('\n  Forming the ring once is the smaller half. Holding it costs continuously against');
console.log('  heat conducted in from the surrounding ground and carried in by any groundwater');
console.log('  movement, until the lining is cast and cured.');

console.log('\nWHAT THIS ISLAND HAS NOT TOLD US, and it decides the answer\n');
for (const u of UNKNOWN_SITE_INPUTS) {
  console.log('  ' + u.id.padEnd(22) + u.what);
  if (u.note) console.log(' '.repeat(24) + u.note);
}
console.log('\n  Groundwater velocity is the one that can defeat a freeze outright: moving water');
console.log('  carries heat in faster than the plant takes it out, and the ring never closes.');
console.log('  Sandworm names groundwater as the enabling condition of the whole design, heat sink');
console.log('  and supply and shielding. It is also the thing that makes the ground want to close.');

console.log('\nAND IT ALL FLOATS. The island is an aquifer lens, so saturation is not a variable.\n');
console.log('  0.15 m lining at 2400 kg/m3, empty tube, below the water table\n');
console.log('  bore m'.padEnd(9) + 'outer m'.padStart(9) + 'uplift kN/m'.padStart(13) + 'lining kN/m'.padStart(13) + 'net kN/m'.padStart(11) + '   uplift / lining' + '   ballast kg/m');
for (const b of BORE_BANDS) {
  const x = buoyancyPerMetre({ boreM: b.m, liningThicknessM: 0.15, liningDensity_kg_per_m3: 2400 });
  console.log('  ' + String(b.m).padEnd(7) + x.outerDiameterM.toFixed(2).padStart(9)
    + x.upliftForce_kN_per_m.toFixed(1).padStart(13) + x.liningWeight_kN_per_m.toFixed(1).padStart(13)
    + x.netUplift_kN_per_m.toFixed(1).padStart(11)
    + (x.upliftForce_kN_per_m / x.liningWeight_kN_per_m).toFixed(2).padStart(18)
    + Math.round(x.ballastNeeded_kg_per_m).toLocaleString().padStart(16));
}
console.log('\n  Every bore floats, and it gets worse with size rather than better. Uplift goes as the');
console.log('  outer diameter squared and the lining that resists it goes as the diameter, so the');
console.log('  ratio worsens from 1.36 at 1.5 m to 3.79 at 5 m. 679 kg a metre of ballast is a track');
console.log('  slab. 16 tonnes a metre is a structural problem.');
console.log('\n  That leaves no dimension in this model where a larger bore is better, except carrying');
console.log('  plant that will not otherwise fit. Removal advantage as the square of the bore, lining');
console.log('  advantage as the bore, buoyancy as the square against it. Small wins three times.');
console.log('\n  Not included: the submerged weight and friction of the sand above the crown, which is');
console.log('  what actually holds a tunnel down. That is this island\'s geotechnics and it is the');
console.log('  gap the whole model now has, in exactly the shape of a bore log.');
