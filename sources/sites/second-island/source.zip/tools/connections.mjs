#!/usr/bin/env node
// Does the bus meet the boat.
//
//     node tools/connections.mjs --day friday
//     node tools/connections.mjs --day saturday --json
//     node tools/connections.mjs --date 2026-08-21
//     node tools/connections.mjs --day friday --scenario flyer-to-junner
//
// The first question this twin answers that a resident actually asks. It is answerable because both
// halves are now real: the bus half is TransLink's own file, read by tools/ingest/gtfs.mjs into
// data/transport-gtfs.json, and the crossing half is the two operators' published timetables and
// the owner's account of the structure, in data/crossings.json. Nothing here is typed in from
// memory and nothing here fills a gap with a plausible number.
//
// WHAT A CONNECTION IS, AND WHAT IT IS NOT
//
// A connection is not a connection if the bus leaves before the boat lands. Every wait below is
// non negative by construction, and a bus that departs one minute before a boat berths is counted
// as missed, not as a nought minute connection.
//
// No minimum transfer allowance is applied, because none is published. A wait of nought minutes is
// printed as nought minutes and it means the timetables coincide, not that a person could make it.
// The walk from a bus stop to a berth is not modelled: 870029 is at the Junner Street terminal and
// 870027 is a roadside stop in Yabby Street at the One Mile terminal, and neither distance is held.
//
// THE TWO CROSSINGS LAW, WHICH THIS FILE KEEPS BY REFUSING TO ADD
//
// Junner Street takes two service classes, the SeaLink vehicle barge and the SeaLink passenger
// ferry. They are reported as two columns and never as one. A walk-on passenger and a car driver
// standing at the same stop get different answers, and merging them would make the useful question
// unanswerable, which is the first build's named defect.
//
// WHERE THE ANALYSIS IS BOUNDED RATHER THAN COMPUTED, AND WHY THAT IS NOT A FAILURE
//
// To say when a boat lands you need a crossing time. SeaLink publishes 45 to 50 minutes for the
// vehicle ferry, so that half is computed twice, at both ends of the range, and reported as a
// range. No crossing time is published for either passenger service in anything this repository
// holds, so the landing minute of a passenger sailing IS NOT COMPUTED HERE AT ALL. What is reported
// for those is the part that holds whatever the crossing takes: a boat that leaves the mainland
// after the last bus has already left the island terminal cannot be met by a bus for any crossing
// time greater than nought, and that is a certainty rather than an estimate.
//
// The direction that needs no crossing time at all is the one a resident asks most: a bus arrives at
// the terminal and the next boat leaves. Both figures are published. That half is exact for all
// three services.

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { hmsToMinutes } from './ingest/gtfs.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const DATA = path.join(REPO_ROOT, 'data');

const WEEKDAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/**
 * The join between the two packs, asserted here and printed on every run.
 *
 * The two publishers share no identifier. TransLink names a bus stop and Gold Cats and SeaLink name
 * a jetty, and nothing in either file says they are the same place. So the join is a judgement, it
 * is made in one place, it is made on the publishers' own words, and the instrument prints it every
 * run so a reader can disagree with it instead of having to find it. If either side is renamed the
 * run fails loudly rather than analysing half a day.
 */
const JOIN = [
  {
    landingPointId: 'junner-street-dunwich',
    stopId: '870029',
    why: 'TransLink calls stop 870029 "Junner St Ferry Terminal (Dunwich)" and the owner calls the '
      + 'landing "junner street ferry terminal". Same street, same town, both say ferry terminal.'
  },
  {
    landingPointId: 'one-mile-dunwich',
    stopId: '870027',
    why: 'TransLink calls stop 870027 "Yabby St at One Mile Ferry Terminal" and the sign heads its '
      + 'second column "1 MILE JETTY DUNWICH". The stop is named for the terminal it stands at, '
      + 'which is a stop beside the jetty rather than the jetty itself.'
  }
];

/** The scenario in board note 029, run as a question and not as a proposal. */
const SCENARIOS = {
  'flyer-to-junner': {
    label: 'Gold Cats Flyer lands at Junner Street instead of One Mile',
    why: 'Redland City Council is seeking this consolidation and the island and the operator both '
      + 'oppose it, per the owner on 19 August 2026, board note 029. Nothing here takes a side. The '
      + 'scenario moves the landing point of every Gold Cats Flyer sailing and CHANGES NOTHING '
      + 'ELSE: same sailing times, same bus timetable, same berth count. Every one of those three '
      + 'is a thing that would really change and that this repository cannot say anything about.'
  }
};

// ---------------------------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------------------------

function pad2(n) { return String(n).padStart(2, '0'); }

/** Minutes after midnight back to a clock face. A time past midnight keeps its 24 or 25 hour. */
function hm(mins) {
  if (mins === null || mins === undefined) return null;
  return pad2(Math.floor(mins / 60)) + ':' + pad2(mins % 60);
}

function readPack(name) {
  const file = path.join(DATA, name);
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error('cannot read data/' + name + ': ' + (err && err.message ? err.message : err)
      + '. The bus half comes from tools/ingest/gtfs.mjs --derive and the crossing half is '
      + 'data/crossings.json. Neither is invented here, so without them there is no analysis.');
  }
}

function usage() {
  return [
    'node tools/connections.mjs [--day <weekday>] [--date <YYYY-MM-DD>] [--scenario <id>] [--json]',
    '',
    '  --day <weekday>   one of ' + WEEKDAY_NAMES.join(', ') + '. Default friday',
    '  --date <date>     a date the derived service week covers, instead of a weekday',
    '  --scenario <id>   ' + Object.keys(SCENARIOS).join(', '),
    '  --detail          every sailing and every bus, not only the summary',
    '  --json            machine readable output on stdout, nothing else',
    '',
    'Reads data/transport-gtfs.json and data/crossings.json. Fetches nothing.'
  ].join('\n');
}

// ---------------------------------------------------------------------------------------------
// the day
// ---------------------------------------------------------------------------------------------

/**
 * Which service day to analyse. The bus pack carries one of every weekday from the feed's own start
 * date; a weekday name resolves to that date. Asking for a date the pack does not carry is an error
 * rather than a nearest match, because a nearest match would silently answer a different question.
 */
function resolveDay(transport, { day, date }) {
  const days = transport.terminalCalls || [];
  const dates = [...new Set(days.map((d) => d.date))].sort();
  if (!dates.length) throw new Error('data/transport-gtfs.json carries no terminal service days');

  if (date) {
    if (!dates.includes(date)) {
      throw new Error('the derived service week does not cover ' + date + '. It covers '
        + dates.join(', ') + '. Re-run tools/ingest/gtfs.mjs --derive against a feed that does.');
    }
    const weekday = (days.find((d) => d.date === date) || {}).weekday;
    return { date, weekday, weekdayIndex: WEEKDAY_NAMES.indexOf(weekday) };
  }

  const wanted = String(day || 'friday').toLowerCase();
  if (!WEEKDAY_NAMES.includes(wanted)) {
    throw new Error('unknown weekday: ' + day + '. One of ' + WEEKDAY_NAMES.join(', '));
  }
  const hit = days.find((d) => d.weekday === wanted);
  if (!hit) {
    throw new Error('the derived service week carries no ' + wanted + '. It carries '
      + [...new Set(days.map((d) => d.weekday))].join(', '));
  }
  return { date: hit.date, weekday: wanted, weekdayIndex: WEEKDAY_NAMES.indexOf(wanted) };
}

// ---------------------------------------------------------------------------------------------
// the two halves, joined
// ---------------------------------------------------------------------------------------------

/**
 * A bus call a passenger stepping off a boat could board. The publisher's own pickup_type says so:
 * 1 means no pickup here. It agrees with lastStopOfTrip on every one of the calls in this pack, so
 * both witnesses are kept and a disagreement between them would show up as a count that moved.
 */
function boardable(call) {
  return call.pickupType !== 1 && !call.lastStopOfTrip;
}

/** A bus call a passenger heading for a boat could alight from. A trip's first stop is not one. */
function alighting(call) {
  return call.dropOffType !== 1 && !call.firstStopOfTrip;
}

function callLabel(call) {
  return call.shortName + ' to ' + (call.headsign || '(no headsign)');
}

/** The first boardable bus at or after `minute`. Null when the day has none left. */
function nextBusOut(calls, minute) {
  let best = null;
  for (const c of calls) {
    if (!boardable(c)) continue;
    const dep = hmsToMinutes(c.departure);
    if (dep === null || dep < minute) continue;
    if (!best || dep < best.minute) best = { minute: dep, call: c };
  }
  return best;
}

/** The latest bus that lands a passenger at the terminal at or before `minute`. */
function lastBusIn(calls, minute) {
  let best = null;
  for (const c of calls) {
    if (!alighting(c)) continue;
    const arr = hmsToMinutes(c.arrival || c.departure);
    if (arr === null || arr > minute) continue;
    if (!best || arr > best.minute) best = { minute: arr, call: c };
  }
  return best;
}

/**
 * Boat lands, next bus out. The direction that needs a crossing time, and the one where two of the
 * three services do not have one.
 */
function boatToBus(sailings, calls, service) {
  const min = service.tripMinutesMin;
  const max = service.tripMinutesMax;
  const known = Number.isFinite(min) && Number.isFinite(max);
  const boardableCalls = calls.filter(boardable);
  const lastOut = boardableCalls.reduce((acc, c) => {
    const dep = hmsToMinutes(c.departure);
    return dep !== null && (acc === null || dep > acc) ? dep : acc;
  }, null);

  const rows = sailings.map((s) => {
    const departs = s.departsMinuteOfDay;
    const row = {
      sailingId: s.id,
      departsLocal: s.departsLocal,
      vessel: s.vessel || null,
      arrivalEarly: null,
      arrivalLate: null,
      outcome: null,
      bus: null,
      busAlternative: null,
      waitMin: null,
      waitMax: null
    };

    if (!known) {
      // No published crossing time. Only the part that holds for every crossing time is stated.
      // A boat cannot be met by a bus that left before the boat even departed the mainland, so a
      // sailing that departs after the last bus out is stranded for certain, and a sailing with
      // buses still to come has met a necessary condition and nothing more.
      row.busesOutAfterDeparture = boardableCalls.filter((c) => {
        const dep = hmsToMinutes(c.departure);
        return dep !== null && dep >= departs;
      }).length;
      row.lastBusOut = lastOut === null ? null : hm(lastOut);
      // The bound the absent crossing time can still be turned into. A passenger catches some bus
      // if and only if the crossing takes no longer than the gap between leaving the mainland and
      // the last bus out of the terminal. That is arithmetic on two published figures, it needs no
      // assumption about how fast the boat is, and for the last sailings of the day it is the whole
      // question: on the early ones the bound is hours wide and says nothing.
      row.busStillThereIfCrossingUnderMinutes = lastOut === null ? null : Math.max(0, lastOut - departs);
      if (lastOut === null || departs >= lastOut) {
        row.outcome = 'no-bus-certain';
        row.note = 'the last bus out left at ' + (lastOut === null ? 'no time today' : hm(lastOut))
          + ', before this boat departs the mainland at ' + s.departsLocal
          + ', so no crossing time can produce a connection';
      } else {
        row.outcome = 'not-computable';
        row.note = row.busesOutAfterDeparture + ' buses still leave this terminal after '
          + s.departsLocal + ', the last at ' + hm(lastOut) + ', which is a necessary condition '
          + 'for a connection and not a connection';
      }
      return row;
    }

    const early = departs + min;
    const late = departs + max;
    row.arrivalEarly = hm(early);
    row.arrivalLate = hm(late);
    const busEarly = nextBusOut(calls, early);
    const busLate = nextBusOut(calls, late);

    if (!busEarly && !busLate) {
      row.outcome = 'no-bus';
      row.note = 'no bus leaves this terminal again today, whether the crossing takes ' + min
        + ' minutes or ' + max;
      return row;
    }
    if (busEarly && busLate && busEarly.call.tripId === busLate.call.tripId) {
      row.outcome = 'connects';
      row.bus = { departure: busLate.call.departure, label: callLabel(busLate.call), tripId: busLate.call.tripId };
      row.waitMin = busLate.minute - late;
      row.waitMax = busEarly.minute - early;
      return row;
    }
    // The two ends of the published crossing range catch different buses, so whether this
    // connection is made depends on where in that range the crossing actually falls.
    row.outcome = 'depends-on-crossing-time';
    row.bus = busEarly ? { departure: busEarly.call.departure, label: callLabel(busEarly.call), tripId: busEarly.call.tripId } : null;
    row.busAlternative = busLate ? { departure: busLate.call.departure, label: callLabel(busLate.call), tripId: busLate.call.tripId } : null;
    const waits = [];
    if (busEarly) waits.push(busEarly.minute - early);
    if (busLate) waits.push(busLate.minute - late);
    row.waitMin = Math.min(...waits);
    row.waitMax = Math.max(...waits);
    row.note = busLate
      ? 'a ' + min + ' minute crossing catches the ' + busEarly.call.departure + ' and a ' + max
        + ' minute crossing catches the ' + busLate.call.departure
      : 'a ' + min + ' minute crossing catches the ' + busEarly.call.departure + ' and a ' + max
        + ' minute crossing catches no bus at all today';
    return row;
  });

  return { crossingTimeKnown: known, tripMinutesMin: min ?? null, tripMinutesMax: max ?? null, rows };
}

/**
 * Bus arrives, next boat out. No crossing time is needed for this direction, so it is exact for
 * every service, and it is the question a resident on the island asks in the morning.
 */
function busToBoat(sailings, calls) {
  const rows = sailings.map((s) => {
    const departs = s.departsMinuteOfDay;
    const bus = lastBusIn(calls, departs);
    const row = {
      sailingId: s.id,
      departsLocal: s.departsLocal,
      vessel: s.vessel || null,
      bus: bus ? { arrival: bus.call.arrival, label: callLabel(bus.call), tripId: bus.call.tripId } : null,
      wait: bus ? departs - bus.minute : null,
      busesBefore: calls.filter((c) => {
        const a = hmsToMinutes(c.arrival || c.departure);
        return alighting(c) && a !== null && a <= departs;
      }).length,
      outcome: bus ? 'connects' : 'no-bus'
    };
    if (!bus) {
      row.note = 'no bus reaches this terminal before this sailing departs at ' + s.departsLocal;
    }
    return row;
  });
  return { rows };
}

/** Every bus arrival, and the next sailing of each service after it. The passenger's own view. */
function perBus(calls, sailingsByService, services) {
  return calls.filter(alighting).map((c) => {
    const arrive = hmsToMinutes(c.arrival || c.departure);
    const next = {};
    for (const svc of services) {
      const list = sailingsByService.get(svc.id) || [];
      let best = null;
      for (const s of list) {
        if (s.departsMinuteOfDay < arrive) continue;
        if (!best || s.departsMinuteOfDay < best.departsMinuteOfDay) best = s;
      }
      next[svc.id] = best
        ? { departsLocal: best.departsLocal, wait: best.departsMinuteOfDay - arrive, sailingId: best.id }
        : null;
    }
    return { arrival: c.arrival, label: callLabel(c), tripId: c.tripId, next };
  }).sort((a, b) => hmsToMinutes(a.arrival) - hmsToMinutes(b.arrival));
}

// ---------------------------------------------------------------------------------------------
// summaries
// ---------------------------------------------------------------------------------------------

function summarise(rows, waitOf) {
  const s = {
    sailings: rows.length,
    within15: 0, within30: 0, over30: 0,
    noBus: 0, dependsOnCrossingTime: 0, notComputable: 0,
    worst: null, stranded: []
  };
  for (const r of rows) {
    if (r.outcome === 'no-bus' || r.outcome === 'no-bus-certain') {
      s.noBus++;
      s.stranded.push({ departsLocal: r.departsLocal, sailingId: r.sailingId, certain: true, note: r.note || null });
      continue;
    }
    if (r.outcome === 'not-computable') { s.notComputable++; continue; }
    if (r.outcome === 'depends-on-crossing-time') { s.dependsOnCrossingTime++; }
    const w = waitOf(r);
    if (w === null || w === undefined) continue;
    if (w <= 15) s.within15++;
    if (w <= 30) s.within30++;
    else s.over30++;
    if (!s.worst || w > s.worst.wait) s.worst = { wait: w, departsLocal: r.departsLocal, sailingId: r.sailingId };
  }
  return s;
}

// ---------------------------------------------------------------------------------------------
// the analysis
// ---------------------------------------------------------------------------------------------

export function analyse({ transport, crossings, day, scenario = null }) {
  const services = crossings.services || [];
  const landings = crossings.landingPoints || [];
  const terminals = transport.terminals || [];
  const dayRecords = (transport.terminalCalls || []).filter((d) => d.date === day.date);

  // The join, checked rather than assumed. A rename on either side stops the run.
  const join = JOIN.map((j) => {
    const landing = landings.find((l) => l.id === j.landingPointId);
    const terminal = terminals.find((t) => t.stopId === j.stopId);
    if (!landing) throw new Error('data/crossings.json has no landing point ' + j.landingPointId);
    if (!terminal) throw new Error('data/transport-gtfs.json has no ferry terminal stop ' + j.stopId);
    return { ...j, landingName: landing.name, stopName: terminal.name, lat: terminal.lat, lon: terminal.lon };
  });

  // Sailings running on this weekday, then moved if a scenario says so.
  const running = (crossings.sailings || []).filter((s) => {
    const wd = s.days && Array.isArray(s.days.weekdays) ? s.days.weekdays : null;
    return wd ? wd.includes(day.weekdayIndex) : true;
  });
  // Where this day's answer rests on a record that is not high confidence. The four Gold Cats Flyer
  // sailings read as printed in red are the case that exists today: their departure times are as
  // well evidenced as every other row on the sign and only the red reading is uncertain, so they
  // change a Saturday and a Sunday and they cannot change a weekday, because red only ever removes
  // a service on a Saturday, a Sunday or a public holiday.
  const notHigh = (crossings.sailings || []).filter((s) => s.confidence !== 'high');
  const runsToday = (s) => {
    const wd = s.days && Array.isArray(s.days.weekdays) ? s.days.weekdays : null;
    return wd ? wd.includes(day.weekdayIndex) : true;
  };
  const dataConfidence = {
    sailingsBelowHigh: notHigh.length,
    excludedFromTodayBelowHigh: notHigh.filter((s) => !runsToday(s)).map((s) => s.id),
    runningTodayBelowHigh: notHigh.filter(runsToday).map((s) => s.id),
    note: null
  };
  dataConfidence.note = dataConfidence.excludedFromTodayBelowHigh.length
    ? 'This day leaves out ' + dataConfidence.excludedFromTodayBelowHigh.length + ' sailing(s) on a '
      + 'reading that is recorded as medium confidence, so this day\'s figures are medium '
      + 'confidence with it. A photograph of the sign settles it.'
    : 'No sailing is left out of this day on a reading below high confidence.';

  const moved = [];
  const sailings = running.map((s) => {
    if (scenario === 'flyer-to-junner' && s.serviceId === 'gold-cats-flyer-passenger-ferry'
      && s.islandPoint === 'one-mile-dunwich') {
      moved.push(s.id);
      return { ...s, islandPoint: 'junner-street-dunwich', movedByScenario: true };
    }
    return s;
  });

  const sailingsByService = new Map();
  for (const s of sailings) {
    if (!sailingsByService.has(s.serviceId)) sailingsByService.set(s.serviceId, []);
    sailingsByService.get(s.serviceId).push(s);
  }

  const points = join.map((j) => {
    const dayRec = dayRecords.find((d) => d.stopId === j.stopId);
    const calls = dayRec ? dayRec.calls : [];
    const here = sailings.filter((s) => s.islandPoint === j.landingPointId);
    const servicesHere = services.filter((svc) => here.some((s) => s.serviceId === svc.id));

    const perService = servicesHere.map((svc) => {
      const mine = here.filter((s) => s.serviceId === svc.id);
      const inbound = mine.filter((s) => s.direction === 'mainland-to-island')
        .sort((a, b) => a.departsMinuteOfDay - b.departsMinuteOfDay);
      const outbound = mine.filter((s) => s.direction === 'island-to-mainland')
        .sort((a, b) => a.departsMinuteOfDay - b.departsMinuteOfDay);
      const arrivals = boatToBus(inbound, calls, svc);
      const departures = busToBoat(outbound, calls);
      return {
        serviceId: svc.id,
        label: svc.label,
        movedByScenario: mine.some((s) => s.movedByScenario === true),
        operator: svc.operator,
        carries: svc.carries,
        timetableStatus: svc.timetableStatus,
        crossingTime: arrivals.crossingTimeKnown
          ? { min: arrivals.tripMinutesMin, max: arrivals.tripMinutesMax }
          : null,
        crossingTimeNote: svc.tripMinutesNote || null,
        movementsToday: { arriving: inbound.length, departing: outbound.length },
        boatToBus: { ...arrivals, summary: summarise(arrivals.rows, (r) => r.waitMax) },
        busToBoat: { ...departures, summary: summarise(departures.rows, (r) => r.wait) }
      };
    });

    const boardableCalls = calls.filter(boardable);
    const alightingCalls = calls.filter(alighting);
    return {
      landingPointId: j.landingPointId,
      landingName: j.landingName,
      stopId: j.stopId,
      stopName: j.stopName,
      lat: j.lat,
      lon: j.lon,
      bus: {
        calls: calls.length,
        boardable: boardableCalls.length,
        alighting: alightingCalls.length,
        firstDeparture: boardableCalls.length ? boardableCalls.map((c) => c.departure).sort()[0] : null,
        lastDeparture: boardableCalls.length ? boardableCalls.map((c) => c.departure).sort().slice(-1)[0] : null,
        firstArrival: alightingCalls.length ? alightingCalls.map((c) => c.arrival).sort()[0] : null,
        lastArrival: alightingCalls.length ? alightingCalls.map((c) => c.arrival).sort().slice(-1)[0] : null,
        serviceIds: dayRec ? dayRec.serviceIds : []
      },
      vesselMovements: here.length,
      services: perService,
      perBus: perBus(calls, sailingsByService, servicesHere)
    };
  });

  // Two vessels wanting the same landing in the same minute. This is exact for an island departure,
  // because both timetables are held and both name that minute, and it is NOT the same claim for a
  // mainland departure, because whether two boats leaving Cleveland together also reach Dunwich
  // together depends on two crossing times this repository does not hold. Computed for the day as
  // it is, and again for the day a scenario describes, so the scenario is a delta and not a mood.
  const islandIds = join.map((j) => j.landingPointId);
  const berthPressure = (list) => {
    const rows = [];
    for (const id of islandIds) {
      const byMinute = new Map();
      for (const s of list) {
        if (s.islandPoint !== id || s.direction !== 'island-to-mainland') continue;
        if (!byMinute.has(s.departsMinuteOfDay)) byMinute.set(s.departsMinuteOfDay, []);
        byMinute.get(s.departsMinuteOfDay).push(s);
      }
      for (const [minute, group] of [...byMinute.entries()].sort((a, b) => a[0] - b[0])) {
        if (group.length > 1) {
          rows.push({
            landingPointId: id,
            departsLocal: hm(minute),
            services: group.map((s) => s.serviceId),
            operators: [...new Set(group.map((s) => s.operator))]
          });
        }
      }
    }
    return rows;
  };
  const sameMinuteToday = berthPressure(running);

  // What a scenario did, in figures rather than in adjectives. Only the things the data can carry.
  // Everything a planner would actually change is in the refusal block at the end of the report.
  let scenarioEffects = null;
  if (scenario) {
    const countAt = (list, id) => list.filter((s) => s.islandPoint === id).length;
    const mainlandSameMinute = [];
    const byMinute = new Map();
    for (const s of sailings) {
      if (s.direction !== 'mainland-to-island' || s.islandPoint !== 'junner-street-dunwich') continue;
      if (s.carries !== 'passengers') continue;
      if (!byMinute.has(s.departsMinuteOfDay)) byMinute.set(s.departsMinuteOfDay, []);
      byMinute.get(s.departsMinuteOfDay).push(s);
    }
    for (const [minute, group] of [...byMinute.entries()].sort((a, b) => a[0] - b[0])) {
      if (group.length > 1) mainlandSameMinute.push({ departsLocal: hm(minute), services: group.map((s) => s.serviceId) });
    }
    scenarioEffects = {
      movementsBefore: Object.fromEntries(islandIds.map((id) => [id, countAt(running, id)])),
      movementsAfter: Object.fromEntries(islandIds.map((id) => [id, countAt(sailings, id)])),
      busCallsNowMeetingNoBoat: points.filter((pt) => !pt.services.length)
        .map((pt) => ({ landingPointId: pt.landingPointId, stopId: pt.stopId, calls: pt.bus.calls })),
      sameMinuteIslandDeparturesBefore: sameMinuteToday,
      sameMinuteIslandDeparturesAfter: berthPressure(sailings),
      sameMinuteMainlandDepartures: mainlandSameMinute,
      sameMinuteNote: 'An island departure in the same minute is exact: both timetables are held '
        + 'and both say that minute. A mainland departure in the same minute is not the same claim '
        + 'about the berth, because whether two boats leaving Cleveland together also arrive at '
        + 'Dunwich together depends on two crossing times this repository does not hold.'
    };
  }

  // The two windows, per the two crossings law: a vehicle figure and a passenger figure, never one.
  const offIsland = sailings.filter((s) => s.direction === 'island-to-mainland');
  const vehicleOut = offIsland.filter((s) => s.carries === 'vehicles').map((s) => s.departsMinuteOfDay).sort((a, b) => a - b);
  const passengerOut = offIsland.filter((s) => s.carries === 'passengers').map((s) => s.departsMinuteOfDay).sort((a, b) => a - b);
  const windows = {
    vehicle: vehicleOut.length ? { first: hm(vehicleOut[0]), last: hm(vehicleOut[vehicleOut.length - 1]), hours: Number(((vehicleOut[vehicleOut.length - 1] - vehicleOut[0]) / 60).toFixed(2)), sailings: vehicleOut.length } : null,
    passenger: passengerOut.length ? { first: hm(passengerOut[0]), last: hm(passengerOut[passengerOut.length - 1]), hours: Number(((passengerOut[passengerOut.length - 1] - passengerOut[0]) / 60).toFixed(2)), sailings: passengerOut.length } : null
  };
  if (windows.vehicle && windows.passenger) {
    const morning = (hmsToMinutes(windows.vehicle.first) - hmsToMinutes(windows.passenger.first)) / 60;
    const evening = (hmsToMinutes(windows.passenger.last) - hmsToMinutes(windows.vehicle.last)) / 60;
    windows.personCanLeaveVehicleCannot = {
      morningHours: Number(morning.toFixed(2)),
      eveningHours: Number(evening.toFixed(2)),
      totalHours: Number((morning + evening).toFixed(2)),
      note: 'Hours between the first passenger departure and the first vehicle departure, and '
        + 'between the last vehicle departure and the last passenger departure. Two separate '
        + 'figures that are never added to a vehicle count.'
    };
  }

  return {
    day,
    scenario: scenario ? { id: scenario, ...SCENARIOS[scenario], sailingsMoved: moved.length } : null,
    join,
    sources: {
      bus: {
        pack: transport.pack,
        version: transport.version,
        attribution: transport.attribution || null,
        serviceIds: [...new Set(dayRecords.flatMap((d) => d.serviceIds))],
        serviceWeekNote: transport.serviceWeek ? transport.serviceWeek.note : null
      },
      crossings: {
        pack: crossings.pack,
        version: crossings.version,
        sailingsRunningToday: sailings.length,
        sailingsInPack: (crossings.sailings || []).length
      }
    },
    windows,
    dataConfidence,
    sameMinuteIslandDepartures: sameMinuteToday,
    scenarioEffects,
    points
  };
}

// ---------------------------------------------------------------------------------------------
// printing
// ---------------------------------------------------------------------------------------------

function bar(ch, n) { return ch.repeat(n); }

function printAnalysis(a, { detail }) {
  const out = [];
  const p = (s) => out.push(s === undefined ? '' : s);

  p('DOES THE BUS MEET THE BOAT');
  p(bar('=', 78));
  p('day        ' + a.day.weekday + ' ' + a.day.date);
  p('bus        ' + a.sources.bus.pack + ' ' + a.sources.bus.version + ', service '
    + a.sources.bus.serviceIds.join(', '));
  p('crossings  ' + a.sources.crossings.pack + ' ' + a.sources.crossings.version + ', '
    + a.sources.crossings.sailingsRunningToday + ' of ' + a.sources.crossings.sailingsInPack
    + ' sailings run on this weekday');
  if (a.scenario) {
    p('SCENARIO   ' + a.scenario.label + ', ' + a.scenario.sailingsMoved + ' sailings moved');
    p('           ' + a.scenario.why);
  }
  p('join       ' + a.join.map((j) => j.stopId + ' = ' + j.landingPointId).join(', ')
    + '. Asserted in tools/connections.mjs and printed so it can be argued with.');
  p('confidence ' + a.dataConfidence.note);
  if (a.sources.bus.attribution) {
    p('');
    p('ATTRIBUTION, owed by the licence of the bus half:');
    p('  ' + a.sources.bus.attribution);
  }

  p('');
  p('THE DAY OFF THE ISLAND, two figures that are never one');
  if (a.windows.vehicle) {
    p('  vehicle    ' + a.windows.vehicle.sailings + ' sailings, ' + a.windows.vehicle.first
      + ' to ' + a.windows.vehicle.last + ', a window of ' + a.windows.vehicle.hours + ' hours');
  }
  if (a.windows.passenger) {
    p('  passenger  ' + a.windows.passenger.sailings + ' sailings, ' + a.windows.passenger.first
      + ' to ' + a.windows.passenger.last + ', a window of ' + a.windows.passenger.hours + ' hours');
  }
  if (a.windows.personCanLeaveVehicleCannot) {
    const w = a.windows.personCanLeaveVehicleCannot;
    p('  a person can leave and a vehicle cannot for ' + w.totalHours + ' hours: '
      + w.morningHours + ' in the morning and ' + w.eveningHours + ' in the evening');
  }
  if (a.sameMinuteIslandDepartures.length) {
    p('  two vessels leave the same island landing in the same minute '
      + a.sameMinuteIslandDepartures.length + ' time(s) today, as the timetables stand:');
    for (const c of a.sameMinuteIslandDepartures) {
      p('      ' + c.departsLocal + '  ' + c.landingPointId + '  ' + c.services.join(' and '));
    }
  }

  for (const pt of a.points) {
    p('');
    p(bar('-', 78));
    p(pt.landingName.toUpperCase());
    p('  bus stop ' + pt.stopId + ' "' + pt.stopName + '", ' + pt.bus.calls + ' calls today, '
      + pt.bus.boardable + ' you can board, ' + pt.bus.alighting + ' you can get off');
    p('  buses out ' + (pt.bus.firstDeparture || 'none') + ' to ' + (pt.bus.lastDeparture || 'none')
      + ', buses in ' + (pt.bus.firstArrival || 'none') + ' to ' + (pt.bus.lastArrival || 'none'));
    p('  ' + pt.vesselMovements + ' vessel movements today across ' + pt.services.length + ' service class(es)');
    if (!pt.services.length) {
      p('  NO SAILING OF ANY KIND CALLS HERE TODAY. Every bus call above meets no boat.');
      continue;
    }

    for (const svc of pt.services) {
      p('');
      p('  ' + svc.label + (svc.movedByScenario
        ? '   [MOVED HERE BY THE SCENARIO. The label is the operator\'s own and still names One Mile]'
        : ''));
      p('    carries ' + svc.carries + ', ' + svc.movementsToday.arriving + ' arriving and '
        + svc.movementsToday.departing + ' departing today, timetable ' + svc.timetableStatus);

      // ---- boat lands, next bus out
      const b = svc.boatToBus;
      p('');
      p('    BOAT LANDS, NEXT BUS OUT');
      if (b.crossingTimeKnown) {
        p('      crossing ' + b.tripMinutesMin + ' to ' + b.tripMinutesMax
          + ' minutes, so every landing below is a window and every wait is a range');
      } else {
        p('      NO CROSSING TIME IS PUBLISHED FOR THIS SERVICE, so no landing minute is computed');
        p('      and no wait is stated. What is stated is what holds for any crossing time.');
      }
      const bs = b.summary;
      if (b.crossingTimeKnown) {
        p('      of ' + bs.sailings + ' sailings: ' + bs.within15 + ' with a bus within 15 minutes, '
          + bs.within30 + ' within 30, ' + bs.noBus + ' with no bus at all'
          + (bs.dependsOnCrossingTime ? ', ' + bs.dependsOnCrossingTime
            + ' where the answer depends on where in the range the crossing falls' : ''));
        if (bs.worst) {
          p('      worst wait ' + bs.worst.wait + ' minutes, the ' + bs.worst.departsLocal + ' sailing');
        }
      } else {
        const withBuses = b.rows.filter((r) => r.outcome === 'not-computable');
        p('      of ' + bs.sailings + ' sailings: ' + withBuses.length + ' have buses still leaving '
          + 'this terminal after the boat leaves the mainland, which is a necessary');
        p('      condition for a connection and not a connection, and ' + bs.noBus
          + ' cannot be met by a bus whatever the crossing takes.');
        p('      No count of connections within 15 or 30 minutes can be given for this service.');
        const bounded = withBuses
          .filter((r) => Number.isFinite(r.busStillThereIfCrossingUnderMinutes))
          .sort((a, b) => a.busStillThereIfCrossingUnderMinutes - b.busStillThereIfCrossingUnderMinutes)
          .slice(0, 3);
        if (bounded.length) {
          p('      The absent crossing time still bounds the answer. A passenger catches some bus if');
          p('      the crossing takes no longer than the gap to the last bus out. Tightest today:');
          for (const r of bounded) {
            p('        the ' + r.departsLocal + ' sailing needs a crossing of '
              + r.busStillThereIfCrossingUnderMinutes + ' minutes or less, last bus out '
              + r.lastBusOut);
          }
        }
      }
      for (const s of bs.stranded) {
        p('      STRANDS: the ' + s.departsLocal + ' sailing, ' + (s.note || 'no bus at all'));
      }
      if (detail) {
        for (const r of b.rows) {
          const when = r.arrivalEarly ? r.arrivalEarly + ' to ' + r.arrivalLate : 'landing not known';
          const wait = r.waitMin === null ? ''
            : (r.waitMin === r.waitMax ? r.waitMin + ' min' : r.waitMin + ' to ' + r.waitMax + ' min');
          p('        ' + r.departsLocal + ' departs, lands ' + when.padEnd(18)
            + (r.bus ? 'bus ' + r.bus.departure + ' ' + r.bus.label : '-').padEnd(34)
            + wait.padEnd(14) + r.outcome);
          if (r.note) p('            ' + r.note);
        }
      }

      // ---- bus arrives, next boat out
      const d = svc.busToBoat;
      const ds = d.summary;
      p('');
      p('    BUS ARRIVES, NEXT BOAT OUT   (needs no crossing time, so this half is exact)');
      p('      of ' + ds.sailings + ' sailings: ' + ds.within15 + ' with a bus within 15 minutes, '
        + ds.within30 + ' within 30, ' + ds.noBus + ' with no bus at all');
      if (ds.worst) {
        p('      worst wait ' + ds.worst.wait + ' minutes, the ' + ds.worst.departsLocal + ' sailing');
      }
      for (const s of ds.stranded) {
        p('      NO BUS: the ' + s.departsLocal + ' sailing, ' + (s.note || 'no bus reaches it'));
      }
      if (detail) {
        for (const r of d.rows) {
          p('        ' + r.departsLocal + ' departs, '
            + (r.bus ? 'last bus in ' + r.bus.arrival + ' ' + r.bus.label : 'no bus in').padEnd(40)
            + (r.wait === null ? '' : r.wait + ' min wait'));
        }
      }
    }
  }

  if (a.scenarioEffects) {
    const e = a.scenarioEffects;
    p('');
    p(bar('=', 78));
    p('WHAT THE SCENARIO MOVED, IN FIGURES');
    for (const id of Object.keys(e.movementsAfter)) {
      p('  ' + id.padEnd(24) + ' vessel movements ' + e.movementsBefore[id] + ' -> ' + e.movementsAfter[id]);
    }
    for (const b of e.busCallsNowMeetingNoBoat) {
      p('  ' + b.landingPointId + ': ' + b.calls + ' bus calls at stop ' + b.stopId
        + ' now meet no boat of any kind');
    }
    p('  two or more vessels wanting one island landing in the same minute: '
      + e.sameMinuteIslandDeparturesBefore.length + ' -> ' + e.sameMinuteIslandDeparturesAfter.length
      + ' times today');
    for (const c of e.sameMinuteIslandDeparturesAfter) {
      p('      ' + c.departsLocal + '  ' + c.services.join(' and ') + '  operators: ' + c.operators.join(', '));
    }
    p('  the same two services leaving Cleveland in the same minute: '
      + e.sameMinuteMainlandDepartures.length + ' times today');
    p('      ' + e.sameMinuteNote);
  }

  p('');
  p(bar('=', 78));
  p('WHAT THIS CANNOT TELL YOU');
  p('  The crossing time for either passenger service. Neither operator publishes one in anything');
  p('  this repository holds, so half of the boat-to-bus question is bounded, not answered.');
  p('  The vehicle timetable is a BASE timetable. SeaLink adds services that appear only on its');
  p('  booking page, so a vehicle sailing count here is a floor and never the day.');
  p('  Whether a bus timetable would be rewritten under any scenario. Nothing in either pack says');
  p('  what a timetable planner would do, and this instrument does not guess.');
  p('  Public holidays. No calendar is fed, and four Gold Cats Flyer sailings stop on one.');
  p('  The walk from a stop to a berth, and whether a wait of a few minutes is enough to make it.');
  return out.join('\n');
}

// ---------------------------------------------------------------------------------------------

function main(argv) {
  const opts = { day: null, date: null, scenario: null, json: false, detail: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--day') opts.day = argv[++i];
    else if (a.startsWith('--day=')) opts.day = a.slice(6);
    else if (a === '--date') opts.date = argv[++i];
    else if (a.startsWith('--date=')) opts.date = a.slice(7);
    else if (a === '--scenario') opts.scenario = argv[++i];
    else if (a.startsWith('--scenario=')) opts.scenario = a.slice(11);
    else if (a === '--json') opts.json = true;
    else if (a === '--detail') opts.detail = true;
    else if (a === '--help' || a === '-h') opts.help = true;
    else { process.stderr.write('unknown argument: ' + a + '\n\n' + usage() + '\n'); return 2; }
  }
  if (opts.help) { process.stdout.write(usage() + '\n'); return 0; }
  if (opts.scenario && !SCENARIOS[opts.scenario]) {
    process.stderr.write('unknown scenario: ' + opts.scenario + '\n\n' + usage() + '\n');
    return 2;
  }

  const transport = readPack('transport-gtfs.json');
  const crossings = readPack('crossings.json');
  const day = resolveDay(transport, opts);
  const a = analyse({ transport, crossings, day, scenario: opts.scenario });

  if (opts.json) process.stdout.write(JSON.stringify(a, null, 2) + '\n');
  else process.stdout.write(printAnalysis(a, { detail: opts.detail }) + '\n');
  return 0;
}

const invokedDirectly = process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url));
if (invokedDirectly) {
  try {
    process.exitCode = main(process.argv.slice(2));
  } catch (err) {
    process.stderr.write(String(err && err.message ? err.message : err) + '\n');
    process.exitCode = 1;
  }
}
