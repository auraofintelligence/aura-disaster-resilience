#!/usr/bin/env node
// The static server for this repository, and the two sinks the instruments write through.
//
//     node tools/serve.mjs            serves the repository root on 4281
//     PORT=4283 node tools/serve.mjs  serves it somewhere else
//
// Port 4281 is this repository's app port. 4282 is its progress page. The two ports next to those
// belong to minjerribah-living-twin, which keeps running as the reference implementation, and
// tools/gate/ports.mjs fails the build if either of them is written down here.
//
// Three parts of this file are load bearing.
//
// The sinks. The browser pane in this environment does not reliably composite frames, so a
// screenshot cannot be taken by asking the compositor for one. Instead the page renders offscreen,
// encodes a PNG itself and POSTs it here, and this server writes it to shots/. The same applies to
// the interface: a canvas screenshot structurally cannot contain a DOM, so the page walks its own
// DOM, builds a structured report and POSTs it to out/probes/. Both sinks answer with the path
// they wrote and how many bytes landed there, so the caller can check the write rather than
// assume it. A sink that answers "ok" and writes nothing is exactly the kind of instrument this
// stage exists to catch.
//
// The isolation headers. Cross-Origin-Opener-Policy same-origin and Cross-Origin-Embedder-Policy
// require-corp are set on every response. They are what makes SharedArrayBuffer available, which
// is what a worker based simulation will need when the island stops being two systems. Setting
// them now costs nothing. Discovering later that every asset needs a header nobody set is a day.
//
// Path traversal. Every request path is resolved and then checked to be under the served root, and
// a path that is not is refused with 403 rather than 404, because pretending a file is missing
// when it is really forbidden is how a server ends up serving one by accident later.
//
// No dependencies, no build step, and nothing here writes to the repository except the two sinks.

import { createServer } from 'node:http';
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));

/** The repository root, resolved from this file rather than from a working directory. */
export const REPO_ROOT = path.resolve(HERE, '..');

/** This repository's app port. The progress page is on the next one, in tools/serve-progress.mjs. */
export const APP_PORT = 4281;

/** How much a sink will accept in one request. A shot of a 4K frame is about 30 MB of base64. */
export const MAX_BODY_BYTES = 64 * 1024 * 1024;

/** A sink name: lower case, digits, dot, underscore, hyphen. One path segment, never a path. */
export const SINK_NAME = /^[a-z0-9._-]+$/;

export const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.htm': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.geojson': 'application/geo+json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.wasm': 'application/wasm',
  '.glb': 'model/gltf-binary',
  '.gltf': 'model/gltf+json; charset=utf-8',
  '.bin': 'application/octet-stream',
  '.ktx2': 'application/octet-stream',
  '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.csv': 'text/csv; charset=utf-8',
  '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg',
  '.ogg': 'audio/ogg'
};

/** Set on every response, including errors, so nothing is served without them by accident. */
export function baseHeaders() {
  return {
    'Cache-Control': 'no-store, max-age=0',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Embedder-Policy': 'require-corp',
    // Under require-corp a subresource without this header is treated as same-origin only, which
    // is what we want here. It is stated rather than relied on.
    'Cross-Origin-Resource-Policy': 'same-origin',
    'X-Content-Type-Options': 'nosniff'
  };
}

function sendJson(res, status, value) {
  const body = Buffer.from(JSON.stringify(value, null, 2) + '\n', 'utf8');
  res.writeHead(status, {
    ...baseHeaders(),
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length
  });
  res.end(body);
}

function sendText(res, status, text, type = 'text/plain; charset=utf-8') {
  const body = Buffer.from(text, 'utf8');
  res.writeHead(status, { ...baseHeaders(), 'Content-Type': type, 'Content-Length': body.length });
  res.end(body);
}

/**
 * Resolve a URL path under a root, or return null when it escapes.
 *
 * Backslashes are folded to forward slashes first so that Windows and Linux refuse the same
 * requests: on Windows a backslash is a separator and on Linux it is a legal file name character,
 * and a server whose safety depends on which one it is running on is not safe.
 */
export function resolveUnder(root, urlPath) {
  if (urlPath.includes('\0')) return null;
  const cleaned = urlPath.split('\\').join('/').replace(/^\/+/, '');
  const abs = path.resolve(root, cleaned);
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (abs !== root && !abs.startsWith(rootWithSep)) return null;
  return abs;
}

function readBody(req, limit = MAX_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    const parts = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('body is larger than the ' + limit + ' byte limit'));
        req.destroy();
        return;
      }
      parts.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(parts)));
    req.on('error', reject);
  });
}

function relative(root, abs) {
  return path.relative(root, abs).split('\\').join('/');
}

const PNG_SIGNATURE = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);

/** A sink name that is safe to turn into one file name in one directory. */
function checkSinkName(name) {
  if (!SINK_NAME.test(name)) {
    return 'name must match ' + SINK_NAME.source + ', got ' + JSON.stringify(name);
  }
  if (name.includes('..')) return 'name must not contain two dots in a row, got ' + JSON.stringify(name);
  return null;
}

/**
 * Build the server. Exported so tools/serve-progress.mjs is the same server with a different root,
 * and so a test can start one on a port of its own.
 *
 * @param {object} opts
 * @param {string} opts.root        directory served
 * @param {number} opts.port
 * @param {string} opts.label       what it prints when it starts
 * @param {boolean} [opts.sinks]    accept POST /__shot/ and POST /__probe/
 * @param {string} [opts.sinkRoot]  where sinks write, the repository root by default
 * @param {Object<string, function>} [opts.routes] extra GET routes, path to handler(req, res)
 * @param {boolean} [opts.quiet]
 */
export function createIslandServer({
  root, port, label, sinks = false, sinkRoot = REPO_ROOT, routes = {}, quiet = false
}) {
  const servedRoot = path.resolve(root);
  const shotsDir = path.join(sinkRoot, 'shots');
  const probesDir = path.join(sinkRoot, 'out', 'probes');
  const log = (line) => { if (!quiet) process.stdout.write(line + '\n'); };

  const server = createServer((req, res) => {
    let urlPath;
    try {
      urlPath = decodeURIComponent((req.url || '/').split('?')[0].split('#')[0]);
    } catch {
      sendJson(res, 400, { ok: false, error: 'the request path is not valid percent encoding' });
      return;
    }

    if (sinks && req.method === 'POST' && (urlPath.startsWith('/__shot/') || urlPath.startsWith('/__probe/'))) {
      const isShot = urlPath.startsWith('/__shot/');
      const name = urlPath.slice(isShot ? '/__shot/'.length : '/__probe/'.length);
      const bad = checkSinkName(name);
      if (bad) {
        log('sink refused ' + urlPath + ': ' + bad);
        sendJson(res, 400, { ok: false, error: bad });
        return;
      }
      readBody(req).then((body) => {
        if (isShot) writeShot(name, body, shotsDir, sinkRoot, res, log);
        else writeProbe(name, body, probesDir, sinkRoot, res, log);
      }).catch((err) => {
        log('sink failed ' + urlPath + ': ' + err.message);
        sendJson(res, 413, { ok: false, error: String(err.message || err) });
      });
      return;
    }

    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { ok: false, error: req.method + ' is not served here', path: urlPath });
      return;
    }

    if (urlPath === '/__health') {
      sendJson(res, 200, {
        ok: true,
        port,
        label,
        root: servedRoot.split('\\').join('/'),
        sinks: sinks ? ['POST /__shot/<name>', 'POST /__probe/<name>'] : []
      });
      return;
    }

    const route = routes[urlPath];
    if (typeof route === 'function') {
      try {
        route(req, res, { sendJson, sendText, baseHeaders });
      } catch (err) {
        log('route ' + urlPath + ' threw: ' + err.message);
        sendJson(res, 500, { ok: false, error: String(err.message || err) });
      }
      return;
    }

    let target = resolveUnder(servedRoot, urlPath);
    if (target === null) {
      log('403 ' + urlPath);
      sendText(res, 403, 'forbidden: ' + urlPath + ' resolves outside the served root\n');
      return;
    }
    if (urlPath.endsWith('/')) target = path.join(target, 'index.html');
    try {
      if (statSync(target).isDirectory()) target = path.join(target, 'index.html');
    } catch {
      // Falls through to the read below, which reports the miss.
    }

    let data;
    try {
      data = readFileSync(target);
    } catch {
      log('404 ' + urlPath);
      sendText(res, 404, '404 ' + urlPath + '\n');
      return;
    }
    const headers = {
      ...baseHeaders(),
      'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream',
      'Content-Length': data.length
    };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') res.end();
    else res.end(data);
  });

  return {
    server,
    port,
    root: servedRoot,
    label,
    listen() {
      return new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(port, () => {
          log(label + ' on http://localhost:' + port + '  root ' + servedRoot.split('\\').join('/'));
          if (sinks) {
            log('  sinks: POST /__shot/<name> writes shots/<name>.png, '
              + 'POST /__probe/<name> writes out/probes/<name>.json');
          }
          resolve(server);
        });
      });
    }
  };
}

/**
 * A shot arrives as a data URL or as raw base64. It is decoded, checked to actually be a PNG, and
 * written. The PNG check is not fussiness: base64 decoding in Node never throws, it just drops
 * what it cannot read, so without a signature check a truncated or wrongly encoded upload lands on
 * disk as a file that no decoder can open and the sink still answers ok.
 */
function writeShot(name, body, shotsDir, sinkRoot, res, log) {
  const text = body.toString('utf8').trim();
  const base64 = text.replace(/^data:image\/[a-z+.-]+;base64,/i, '').replace(/\s+/g, '');
  const bytes = Buffer.from(base64, 'base64');
  if (bytes.length === 0) {
    sendJson(res, 400, { ok: false, error: 'the body decoded to zero bytes' });
    return;
  }
  if (!bytes.subarray(0, 8).equals(PNG_SIGNATURE)) {
    sendJson(res, 415, {
      ok: false,
      error: 'the decoded body is not a PNG: it starts with ' + [...bytes.subarray(0, 8)].join(',')
        + ' and a PNG starts with ' + [...PNG_SIGNATURE].join(',')
    });
    return;
  }
  const file = path.join(shotsDir, name.endsWith('.png') ? name : name + '.png');
  mkdirSync(shotsDir, { recursive: true });
  writeFileSync(file, bytes);
  const written = statSync(file).size;
  const rel = relative(sinkRoot, file);
  log('shot ' + rel + ' ' + written + ' bytes');
  sendJson(res, 200, { ok: true, path: rel, bytes: written });
}

/**
 * A probe arrives as JSON. It is parsed to prove it is JSON and then written exactly as it was
 * sent, so the file on disk is the page's own bytes and not this server's idea of them.
 */
function writeProbe(name, body, probesDir, sinkRoot, res, log) {
  const text = body.toString('utf8');
  try {
    JSON.parse(text);
  } catch (err) {
    sendJson(res, 400, { ok: false, error: 'the body is not valid JSON: ' + err.message });
    return;
  }
  const file = path.join(probesDir, name.endsWith('.json') ? name : name + '.json');
  mkdirSync(probesDir, { recursive: true });
  writeFileSync(file, text, 'utf8');
  const written = statSync(file).size;
  const rel = relative(sinkRoot, file);
  log('probe ' + rel + ' ' + written + ' bytes');
  sendJson(res, 200, { ok: true, path: rel, bytes: written });
}

/** True when this file is the script node was asked to run, rather than an import. */
export function isMain(url) {
  const entry = process.argv[1];
  if (!entry) return false;
  return path.resolve(entry) === path.resolve(fileURLToPath(url));
}

export async function main() {
  const port = Number(process.env.PORT || APP_PORT);
  if (!Number.isInteger(port) || port <= 0 || port > 65535) {
    process.stderr.write('PORT must be a port number, got ' + process.env.PORT + '\n');
    process.exitCode = 2;
    return;
  }
  const app = createIslandServer({ root: REPO_ROOT, port, label: 'second-island app', sinks: true });
  try {
    await app.listen();
  } catch (err) {
    if (err && err.code === 'EADDRINUSE') {
      process.stderr.write('port ' + port + ' is already in use. Stop the other server, or set PORT.\n');
    } else {
      process.stderr.write('could not listen on ' + port + ': ' + (err && err.message ? err.message : err) + '\n');
    }
    process.exitCode = 1;
  }
}

if (isMain(import.meta.url)) {
  if (!existsSync(REPO_ROOT)) {
    process.stderr.write('repository root not found at ' + REPO_ROOT + '\n');
    process.exitCode = 1;
  } else {
    main();
  }
}
