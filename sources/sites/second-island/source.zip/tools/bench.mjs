#!/usr/bin/env node
// The frame time instrument: the distribution, and never the average.
//
//     node tools/bench.mjs --assert [--file <path>] [--budgets <path>] [--json]
//     node tools/bench.mjs --show   [--file <path>] [--json]
//
// It reads a frame series the page posted, reports p50, p95, p99 and the worst frame, and fails
// against tools/budgets.json. There is no average in the output and there is no code here that
// computes one. That is the whole reason this tool is shaped the way it is: the first build carried
// a 1160 ms worst frame for a week behind an acceptable average, and nobody looked, because the one
// number on the dashboard was fine. An average is the shape of a lie about a hitch, so reporting it
// invites someone to quote it.
//
// Where the samples come from. ISLAND.bench(n) in the running page draws n frames and POSTs
// { frames, samples } to the app server, which writes out/probes/bench.json. That is the file this
// tool reads by default, and this tool never drives a browser.
//
// What a sample is, stated here rather than left for a reader to assume: the cost of building and
// submitting one frame, measured around the draw call in src/main.js. On the two GPU paths the
// GPU's own time is not in it, and the browser pane in this environment does not composite frames
// at all, so nothing here is a present to present measurement. A sample is therefore a floor on the
// real frame cost, not the real frame cost. The instrument says so on every run.
//
// The percentile method is nearest rank, on purpose. Sort ascending, take the sample at
// ceil(p / 100 * n), one based. No interpolation, so every number reported is a frame that actually
// happened and can be pointed at by index. An interpolated p99 is a frame nobody rendered.

import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const REPO_ROOT = path.resolve(HERE, '..');
const DEFAULT_SERIES = path.join(REPO_ROOT, 'out', 'probes', 'bench.json');
const DEFAULT_BUDGETS = path.join(HERE, 'budgets.json');

const SAMPLE_NOTE = 'A sample is the cost of building and submitting one frame, measured around the '
  + 'draw call in ISLAND.bench in src/main.js. The GPU time is not in it and neither is the '
  + 'compositor, which does not run in this environment, so a sample is a floor on the real frame '
  + 'cost rather than the real frame cost.';

function usage() {
  return [
    'node tools/bench.mjs --assert [--file <path>] [--budgets <path>] [--json]',
    'node tools/bench.mjs --show   [--file <path>] [--json]',
    '',
    '  --assert           check the series against tools/budgets.json, exit 1 when it is over',
    '  --show             print the distribution and give no verdict',
    '  --file <path>      a series other than out/probes/bench.json',
    '  --budgets <path>   a budgets file other than tools/budgets.json',
    '  --json             machine readable output on stdout, nothing else',
    '',
    'Exit code is 0 when every budget holds, 1 when one is broken, 2 on a usage or read error.'
  ].join('\n');
}

function rel(abs) {
  return path.relative(REPO_ROOT, abs).split('\\').join('/');
}

/**
 * A frame series. Two shapes are accepted: what the page posts, { frames, samples }, and a bare
 * array of numbers, which is what a hand written fixture is easiest to write as.
 */
export function loadSeries(file) {
  let raw;
  try {
    raw = readFileSync(file, 'utf8');
  } catch (err) {
    throw new Error('the frame series ' + rel(file) + ' could not be read: '
      + String((err && err.message) || err)
      + '\nThe running page writes it: ISLAND.bench(600) posts to the app server on 4281.');
  }
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch (err) {
    throw new Error(rel(file) + ' is not valid JSON: ' + String((err && err.message) || err));
  }

  const samples = Array.isArray(parsed) ? parsed : parsed && parsed.samples;
  if (!Array.isArray(samples)) {
    throw new Error(rel(file) + ' has no samples array. Expected { "frames": n, "samples": [ms, ...] }.');
  }
  if (samples.length === 0) {
    throw new Error(rel(file) + ' holds an empty samples array, so there is nothing to measure.');
  }
  const bad = samples.findIndex((s) => typeof s !== 'number' || !Number.isFinite(s) || s < 0);
  if (bad !== -1) {
    throw new Error(rel(file) + ' sample ' + bad + ' is ' + JSON.stringify(samples[bad])
      + ', which is not a frame time in milliseconds.');
  }

  const declared = Array.isArray(parsed) ? samples.length : Number(parsed.frames);
  return {
    file,
    samples,
    declaredFrames: Number.isFinite(declared) ? declared : samples.length,
    countMatchesDeclared: !Number.isFinite(declared) || declared === samples.length
  };
}

export function loadBudgets(file) {
  let parsed;
  try {
    parsed = JSON.parse(readFileSync(file, 'utf8'));
  } catch (err) {
    throw new Error('the budgets file ' + rel(file) + ' could not be read: '
      + String((err && err.message) || err));
  }
  const frame = parsed && parsed.frameMs;
  if (!frame || typeof frame.p99 !== 'number' || typeof frame.worst !== 'number') {
    throw new Error(rel(file) + ' needs frameMs.p99 and frameMs.worst, both numbers in milliseconds.');
  }
  return { file, p99: frame.p99, worst: frame.worst, note: typeof parsed.note === 'string' ? parsed.note : '' };
}

/**
 * Nearest rank percentile. Returns the sample and the index it holds in the original series, so a
 * reported number can always be pointed at.
 */
export function nearestRank(samples, p) {
  const order = samples.map((ms, index) => ({ ms, index }))
    .sort((a, b) => (a.ms - b.ms) || (a.index - b.index));
  const rank = Math.min(order.length, Math.max(1, Math.ceil((p / 100) * order.length)));
  return order[rank - 1];
}

export function distribution(series) {
  const { samples } = series;
  const p50 = nearestRank(samples, 50);
  const p95 = nearestRank(samples, 95);
  const p99 = nearestRank(samples, 99);
  const p100 = nearestRank(samples, 100);
  return { frames: samples.length, p50, p95, p99, worst: p100 };
}

export function measure({ file = DEFAULT_SERIES, budgetsFile = DEFAULT_BUDGETS, verdict = true } = {}) {
  const series = loadSeries(file);
  const dist = distribution(series);
  const result = {
    mode: verdict ? 'assert' : 'show',
    file: rel(series.file),
    frames: dist.frames,
    declaredFrames: series.declaredFrames,
    countMatchesDeclared: series.countMatchesDeclared,
    method: 'nearest rank, one based, no interpolation',
    sampleNote: SAMPLE_NOTE,
    p50: dist.p50.ms,
    p95: dist.p95.ms,
    p99: { ms: dist.p99.ms, frame: dist.p99.index },
    worst: { ms: dist.worst.ms, frame: dist.worst.index },
    budgets: null,
    checks: [],
    over: [],
    ok: true
  };

  if (!verdict) return result;

  const budgets = loadBudgets(budgetsFile);
  result.budgets = { file: rel(budgets.file), p99: budgets.p99, worst: budgets.worst, note: budgets.note };
  result.checks = [
    { id: 'p99', ms: dist.p99.ms, budgetMs: budgets.p99, frame: dist.p99.index, ok: dist.p99.ms <= budgets.p99 },
    { id: 'worst', ms: dist.worst.ms, budgetMs: budgets.worst, frame: dist.worst.index, ok: dist.worst.ms <= budgets.worst }
  ];
  result.over = series.samples
    .map((ms, frame) => ({ frame, ms }))
    .filter((s) => s.ms > budgets.p99);
  result.ok = result.checks.every((c) => c.ok);
  return result;
}

function ms(value) {
  return value.toFixed(3).padStart(9) + ' ms';
}

function print(result) {
  const lines = [];
  lines.push('frame time from ' + result.file + ', ' + result.frames + ' samples, '
    + result.method + '.');
  if (!result.countMatchesDeclared) {
    lines.push('  NOTE  the file declares ' + result.declaredFrames + ' frames and carries '
      + result.frames + ' samples. The samples are what is measured.');
  }
  lines.push('');
  lines.push('  p50   ' + ms(result.p50));
  lines.push('  p95   ' + ms(result.p95));

  const verdictFor = (id) => {
    const c = result.checks.find((x) => x.id === id);
    if (!c) return '';
    return '   budget ' + c.budgetMs.toFixed(3) + ' ms   ' + (c.ok ? 'PASS' : 'FAIL');
  };

  lines.push('  p99   ' + ms(result.p99.ms) + '   at frame ' + result.p99.frame + verdictFor('p99'));
  lines.push('  worst ' + ms(result.worst.ms) + '   at frame ' + result.worst.frame + verdictFor('worst'));
  lines.push('');

  if (result.mode === 'assert') {
    if (result.over.length === 0) {
      lines.push('  No frame is over the p99 budget of ' + result.budgets.p99 + ' ms.');
    } else {
      lines.push('  ' + result.over.length + ' frame' + (result.over.length === 1 ? '' : 's')
        + ' over the p99 budget of ' + result.budgets.p99 + ' ms: '
        + result.over.map((s) => s.frame + ' (' + s.ms + ' ms)').join(', '));
    }
    lines.push('');
  }

  lines.push('  ' + result.sampleNote);
  lines.push('  No average is reported. A hitch hides behind one, which is the point of this tool.');
  lines.push('');

  if (result.mode !== 'assert') {
    lines.push('SHOW: no verdict. Run --assert to check against tools/budgets.json.');
    return lines.join('\n');
  }

  const failed = result.checks.filter((c) => !c.ok);
  if (failed.length === 0) {
    lines.push('PASS: p99 ' + result.p99.ms + ' ms within ' + result.budgets.p99 + ' ms, worst '
      + result.worst.ms + ' ms within ' + result.budgets.worst + ' ms.');
  } else {
    lines.push('FAIL: ' + failed.map((c) => c.id + ' ' + c.ms + ' ms over the budget of '
      + c.budgetMs + ' ms, at frame ' + c.frame).join('; ') + '.');
  }
  return lines.join('\n');
}

function main() {
  const argv = process.argv.slice(2);
  const json = argv.includes('--json');
  const args = argv.filter((a) => a !== '--json');

  const value = (flag) => {
    const i = args.indexOf(flag);
    if (i === -1) return null;
    const next = args[i + 1];
    return next && !next.startsWith('--') ? next : null;
  };

  if (args.length === 0 || args.includes('--help') || args.includes('-h')) {
    process.stdout.write(usage() + '\n');
    process.exitCode = args.length === 0 ? 2 : 0;
    return;
  }

  const wantsAssert = args.includes('--assert');
  const wantsShow = args.includes('--show');
  if (!wantsAssert && !wantsShow) {
    process.stderr.write('unknown arguments: ' + args.join(' ') + '\n\n' + usage() + '\n');
    process.exitCode = 2;
    return;
  }

  let result;
  try {
    result = measure({
      file: value('--file') ? path.resolve(value('--file')) : DEFAULT_SERIES,
      budgetsFile: value('--budgets') ? path.resolve(value('--budgets')) : DEFAULT_BUDGETS,
      verdict: wantsAssert
    });
  } catch (err) {
    if (json) {
      process.stdout.write(JSON.stringify({ ok: false, error: String(err.message || err) }, null, 2) + '\n');
    } else {
      process.stderr.write(String(err.message || err) + '\n');
    }
    process.exitCode = 2;
    return;
  }

  if (json) process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  else process.stdout.write(print(result) + '\n');
  process.exitCode = result.mode === 'assert' && !result.ok ? 1 : 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === path.resolve(fileURLToPath(import.meta.url))) {
  main();
}
