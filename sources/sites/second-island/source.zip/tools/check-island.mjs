// Build the island, run two sim days, and check the sun against physics rather than against
// itself. Kept runnable so the numbers in any report about this stage can be reproduced in one
// command instead of trusted.
//
//   node tools/check-island.mjs
//   node tools/check-island.mjs --ticks 2880 --json
//
// The checks below are the honest kind: each one is a fact about the sky that holds independently
// of the model, computed here and compared to what the running world says. The declination series
// has to reach the Earth's axial tilt at a solstice and pass through zero at an equinox. Solar noon
// has to sit four minutes east of twelve o'clock for every degree the site is east of the time
// zone's meridian, plus the equation of time. Sunrise and sunset have to be symmetric about solar
// noon. Peak elevation has to be ninety degrees less the angle between the site's latitude and the
// sun's declination. A model can be wrong in a way that still looks like a sun; it cannot be wrong
// in a way that satisfies all of these.

import { buildIsland } from '../src/world/island.js';
import { sunAt, sunEvents, solarBasics, daysInYear, SITE_DUNWICH } from '../src/systems/solar.js';

const args = process.argv.slice(2);
const flag = (name, fallback) => {
  const i = args.indexOf('--' + name);
  return i === -1 ? fallback : args[i + 1];
};
const TICKS = Number(flag('ticks', 2880));
const JSON_OUT = args.includes('--json');

const pad = (n) => String(n).padStart(2, '0');
const hhmm = (minutes) => {
  if (minutes === null || minutes === undefined) return 'none';
  const m = Math.round(minutes);
  return `${pad(Math.floor(m / 60))}:${pad(((m % 60) + 60) % 60)}`;
};
const round = (v, dp = 3) => (v === null || v === undefined ? null : Number(v.toFixed(dp)));

const world = await buildIsland();
const site = { lat: world.state.solar.siteLat, lon: world.state.solar.siteLon, utcOffsetMinutes: 600 };

// ---- run -------------------------------------------------------------------------------------

const days = new Map(); // island date to that day's samples
const events = [];
const seen = new Set();
for (let t = 0; t < TICKS; t++) {
  world.step(1);
  const c = world.clock.civil(t);
  const key = `${c.year}-${pad(c.month)}-${pad(c.day)}`;
  if (!days.has(key)) {
    days.set(key, {
      date: key, dayOfYear: world.clock.dayOfYear(t), peakElevationDeg: -Infinity, peakMinute: null,
      peakAzimuthDeg: null, peakDeclinationDeg: null,
      noonElevationDeg: null, noonDeclinationDeg: null, noonEquationOfTimeMin: null,
      firstDaylightMinute: null, lastDaylightMinute: null,
      sunriseMinute: null, sunsetMinute: null, solarNoonMinute: null
    });
  }
  const d = days.get(key);
  const s = world.state.solar;
  if (s.elevationDeg > d.peakElevationDeg) {
    d.peakElevationDeg = s.elevationDeg;
    d.peakMinute = c.minuteOfDay;
    d.peakAzimuthDeg = s.azimuthDeg;
    d.peakDeclinationDeg = s.declinationDeg;
  }
  // The declination and the equation of time are sampled at twelve o'clock island time, because
  // that is the hour the source document evaluates them at for sunrise, sunset and solar noon.
  // Sampling them at any other minute would compare two slightly different days.
  if (c.minuteOfDay === 720) {
    d.noonElevationDeg = s.elevationDeg;
    d.noonDeclinationDeg = s.declinationDeg;
    d.noonEquationOfTimeMin = s.equationOfTimeMin;
  }
  if (s.isDaylight) {
    if (d.firstDaylightMinute === null) d.firstDaylightMinute = c.minuteOfDay;
    d.lastDaylightMinute = c.minuteOfDay;
  }
  d.sunriseMinute = s.sunriseMinute;
  d.sunsetMinute = s.sunsetMinute;
  d.solarNoonMinute = s.solarNoonMinute;

  // Events emitted during the tick just run are in the inbox; they move to pending on the next
  // tick and are gone after that, so they are read here rather than at the end.
  for (const ev of world.inbox) {
    const id = ev.type + '@' + ev.tick;
    if (seen.has(id)) continue;
    seen.add(id);
    events.push({ type: ev.type, tick: ev.tick, islandTime: ev.payload.islandTime, minuteOfDay: ev.payload.minuteOfDay });
  }
}
const fullDays = [...days.values()].filter((d) => d.noonDeclinationDeg !== null && d.sunriseMinute !== null);

// ---- checks against physics, not against the model -------------------------------------------

const OBLIQUITY_DEG = 23.44; // Earth's axial tilt: the largest declination the sun can reach.
const checks = [];
const check = (name, pass, detail) => checks.push({ name, pass, detail });

// 1. The declination series must reach the axial tilt at the solstices and cross zero at the
//    equinoxes. 2026 is not a leap year: 21 June is day 172, 21 December is day 355, 20 March is
//    day 79 and 23 September is day 266.
const inYear = daysInYear(2026);
const declOn = (doy) => (solarBasics(doy, 12, inYear).declRad * 180) / Math.PI;
const junSolstice = declOn(172);
const decSolstice = declOn(355);
const marEquinox = declOn(79);
const sepEquinox = declOn(266);
check('June solstice declination is the axial tilt north',
  Math.abs(junSolstice - OBLIQUITY_DEG) < 0.5,
  `${junSolstice.toFixed(3)} deg, expected about +${OBLIQUITY_DEG}`);
check('December solstice declination is the axial tilt south',
  Math.abs(decSolstice + OBLIQUITY_DEG) < 0.5,
  `${decSolstice.toFixed(3)} deg, expected about -${OBLIQUITY_DEG}`);
check('declination crosses zero at the equinoxes',
  Math.abs(marEquinox) < 0.6 && Math.abs(sepEquinox) < 0.6,
  `March ${marEquinox.toFixed(3)} deg, September ${sepEquinox.toFixed(3)} deg, expected about 0`);

// 2. Late August sits between the June solstice and the September equinox, so the declination must
//    be north of the equator and falling.
const first = fullDays[0];
check('late August declination is north of the equator and falling',
  first.noonDeclinationDeg > 0 && first.noonDeclinationDeg < OBLIQUITY_DEG
    && declOn(first.dayOfYear + 1) < first.noonDeclinationDeg,
  `${first.noonDeclinationDeg.toFixed(3)} deg on day ${first.dayOfYear}, next day ${declOn(first.dayOfYear + 1).toFixed(3)} deg`);

// 3. Peak elevation is ninety degrees less the angle between latitude and declination.
for (const d of fullDays) {
  const expected = 90 - Math.abs(site.lat - d.peakDeclinationDeg);
  check(`peak elevation on ${d.date} matches 90 minus the latitude to declination angle`,
    Math.abs(d.peakElevationDeg - expected) < 0.05,
    `world ${d.peakElevationDeg.toFixed(3)} deg, geometry ${expected.toFixed(3)} deg`);
}

// 4. Solar noon: four minutes per degree east of the time zone meridian, plus the equation of time.
const ZONE_MERIDIAN_DEG = 150; // AEST is UTC+10, so its meridian is 150 east.
for (const d of fullDays) {
  const expected = 720 - 4 * (site.lon - ZONE_MERIDIAN_DEG) - d.noonEquationOfTimeMin;
  check(`solar noon on ${d.date} matches the longitude and equation of time correction`,
    Math.abs(d.solarNoonMinute - expected) < 0.001,
    `world ${hhmm(d.solarNoonMinute)}, arithmetic ${hhmm(expected)}`);
}

// 5. Sunrise and sunset are symmetric about solar noon.
for (const d of fullDays) {
  const gapRise = d.solarNoonMinute - d.sunriseMinute;
  const gapSet = d.sunsetMinute - d.solarNoonMinute;
  check(`sunrise and sunset on ${d.date} are symmetric about solar noon`,
    Math.abs(gapRise - gapSet) < 0.001,
    `${gapRise.toFixed(3)} min before, ${gapSet.toFixed(3)} min after`);
}

// 6. Day length in late August is longer than at the winter solstice and shorter than the twelve
//    hours of an equinox, because the site is south of the equator and the sun is north of it.
const winterDayLength = (() => {
  const e = sunEvents(SITE_DUNWICH, 172, inYear);
  return e.sunsetMinute - e.sunriseMinute;
})();
for (const d of fullDays) {
  const len = d.sunsetMinute - d.sunriseMinute;
  check(`day length on ${d.date} sits between the winter solstice and twelve hours`,
    len > winterDayLength && len < 720,
    `${(len / 60).toFixed(3)} h, winter solstice ${(winterDayLength / 60).toFixed(3)} h`);
}

// 7. The daylight flag and the predicted sunrise agree. The tolerance is two minutes, not zero:
//    the flag is sampled on whole minutes, and the predicted time is computed with the day's
//    declination taken at twelve o'clock while the flag crosses on the declination at dawn. Both
//    are correct readings of the same source document and they differ by a fraction of a minute.
for (const d of fullDays) {
  if (d.firstDaylightMinute === null) continue;
  check(`the daylight flag on ${d.date} turns on within two minutes of predicted sunrise`,
    Math.abs(d.firstDaylightMinute - d.sunriseMinute) <= 2.0,
    `flag ${hhmm(d.firstDaylightMinute)}, predicted ${hhmm(d.sunriseMinute)}, difference ${(d.firstDaylightMinute - d.sunriseMinute).toFixed(3)} min`);
}

// 8. At solar noon in the southern hemisphere with the sun north of the equator, the sun bears due
//    north.
for (const d of fullDays) {
  const az = sunAt(site, d.dayOfYear, d.solarNoonMinute, inYear).azimuthDeg;
  const offNorth = Math.min(Math.abs(az - 0), Math.abs(az - 360));
  check(`the sun bears due north at solar noon on ${d.date}`, offNorth < 0.5,
    `azimuth ${az.toFixed(3)} deg clockwise from north`);
}

// 9. The tide must be unfed while the pack has no constituents, and must not be holding a number.
const tide = world.state.tide;
check('the tide reports itself unfed rather than drawing a curve',
  tide.fed === false && tide.heightM === null && tide.risingFalling === null,
  `fed ${tide.fed}, heightM ${tide.heightM}, risingFalling ${tide.risingFalling}, constituents ${tide.constituentCount}`);
check('no tide turn was announced by an unfed tide',
  events.filter((e) => e.type.startsWith('tide.')).length === 0,
  `${events.filter((e) => e.type.startsWith('tide.')).length} tide events in ${TICKS} ticks`);

// ---- output ----------------------------------------------------------------------------------

const report = world.report();
const summary = {
  epoch: world.clock.epochISO,
  seed: world.seed,
  ticks: TICKS,
  endIslandTime: world.clock.iso(),
  site: { ...site, source: world.state.solar.siteSource, locator: SITE_DUNWICH.locator },
  days: [...days.values()].map((d) => ({
    date: d.date,
    dayOfYear: d.dayOfYear,
    declinationAtNoonDeg: round(d.noonDeclinationDeg),
    equationOfTimeAtNoonMin: round(d.noonEquationOfTimeMin),
    sunrise: hhmm(d.sunriseMinute),
    solarNoon: hhmm(d.solarNoonMinute),
    sunset: hhmm(d.sunsetMinute),
    sunriseMinute: round(d.sunriseMinute, 2),
    solarNoonMinute: round(d.solarNoonMinute, 2),
    sunsetMinute: round(d.sunsetMinute, 2),
    dayLengthHours: round((d.sunsetMinute - d.sunriseMinute) / 60, 3),
    elevationAtLocalNoonDeg: round(d.noonElevationDeg),
    peakElevationDeg: round(d.peakElevationDeg),
    peakAt: hhmm(d.peakMinute),
    azimuthAtPeakDeg: round(d.peakAzimuthDeg),
    firstDaylightMinute: hhmm(d.firstDaylightMinute),
    lastDaylightMinute: hhmm(d.lastDaylightMinute)
  })),
  tide: { ...tide },
  events,
  seams: report.seams,
  deadSeams: report.deadSeams,
  hashes: report.hashes,
  hash: report.hash,
  checks
};

if (JSON_OUT) {
  console.log(JSON.stringify(summary, null, 2));
} else {
  console.log(`island: epoch ${summary.epoch}, seed ${summary.seed}, ${TICKS} ticks to ${summary.endIslandTime}`);
  console.log(`site:   ${site.lat}, ${site.lon} (${summary.site.source}: ${summary.site.locator})`);
  console.log('');
  for (const d of summary.days) {
    console.log(`${d.date}  day ${d.dayOfYear} of the year`);
    console.log(`  declination at noon ${d.declinationAtNoonDeg} deg, equation of time ${d.equationOfTimeAtNoonMin} min`);
    console.log(`  sunrise ${d.sunrise}   solar noon ${d.solarNoon}   sunset ${d.sunset}   day length ${d.dayLengthHours} h`);
    console.log(`  elevation at 12:00 island time ${d.elevationAtLocalNoonDeg} deg`);
    console.log(`  peak elevation ${d.peakElevationDeg} deg at ${d.peakAt}, azimuth ${d.azimuthAtPeakDeg} deg clockwise from north`);
    console.log(`  daylight flag on from ${d.firstDaylightMinute} to ${d.lastDaylightMinute}`);
  }
  console.log('');
  console.log('tide:');
  console.log(`  port ${tide.port}`);
  console.log(`  fed ${tide.fed}, constituents ${tide.constituentCount}`);
  console.log(`  heightM ${tide.heightM}, risingFalling ${tide.risingFalling}`);
  console.log(`  reason: ${tide.reason}`);
  console.log('');
  console.log('events fired:');
  for (const e of events) console.log(`  ${e.type} at tick ${e.tick}, ${e.islandTime}`);
  console.log('');
  console.log('seams:');
  for (const s of report.seams) {
    console.log(`  ${s.type}: emitters [${s.emitters}], listeners [${s.listeners}], fired ${s.fired}`);
  }
  console.log(`  dead seams: ${report.deadSeams.length ? report.deadSeams.join(', ') : 'none'}`);
  console.log('');
  console.log('world hash: ' + report.hash);
  console.log('');
  console.log('checks against physics:');
  for (const c of checks) console.log(`  ${c.pass ? 'pass' : 'FAIL'}  ${c.name}: ${c.detail}`);
}

const failed = checks.filter((c) => !c.pass);
if (failed.length) {
  console.error(`\n${failed.length} of ${checks.length} checks failed`);
  process.exit(1);
}
if (!JSON_OUT) console.log(`\nall ${checks.length} checks passed`);
