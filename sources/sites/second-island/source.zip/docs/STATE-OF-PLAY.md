# State of play

Newest first. Each dated section is a snapshot and is not rewritten when a later one is added.

---

## 20 August 2026: the front page is for people, the bench is at lab.html, and the instruments follow the bench

Written by the wave 9 instrument repointing agent, after the front page split. The one thing this
section is for: **the page split landed in wave 9, every instrument that drives a page now points
at the page its target actually lives on, and the whole witness set was recaptured from the new
pages rather than carried over from the old one.**

### Why the split happened

The owner looked at the live front page and asked what all the nonsense on it was. The page had
been built as the stage 0 instrument bench and pushed live unchanged, so a visitor arriving at the
site met a calibration checkerboard, a tick counter and paragraphs of the build explaining its own
discipline to itself. His standing rule is that process narration never goes on a front page.
Board note 037 carries the split itself; this section carries the instruments following it.

- `index.html` is the page for a person: the name, one plain sentence, the Acknowledgement of
  Country at load, and the everyday crossings answers. The provenance chips stay on every value.
- `lab.html` is the bench, moved not deleted: the calibration scene, the island clock, the sun and
  tide panels, the step controls, and the instrument narration.
- `src/main.js` boots both pages from one world, decided by the markup. The lab carries the full
  `ISLAND` surface; the front page carries probe, step, info and provenance, and answers shot and
  bench with a refusal. Neither page's boot touches a POST sink, so GitHub Pages serves both.

### What was repointed, and the three items board note 037 flagged are all closed

- `tools/panels/calibration.json` now says its panels live on lab.html, in `page` and in its own
  `_what` and `_why` lines. The panel declarations themselves did not change, because the bench
  panels moved unrenamed, and a fresh lab capture passes against them.
- `tools/panels/front.json` is NEW: a declared baseline for the front page's eight panels and 28
  values, written by hand from `src/ui/crossings-view.js` and `index.html`. Until it existed a
  quietly renamed panel on the front page was invisible to every instrument. Rows whose citation
  is honestly dynamic, meaning the record of whichever sailing or bus call answers at that minute,
  omit `prov` in the baseline and pin `register`; every static citation is pinned.
- `tools/uicompare.mjs` now tells a capture session to open `http://localhost:4281/lab.html` for
  the bench and names the front page as a second capture target.
- `tools/selftest.mjs` writes the lab URL into the generated `docs/JURISDICTION.md` footer, and the
  regenerated file on disk carries it.
- `tools/faults.mjs` records that the browser evidence was retaken from lab.html on 20 August 2026,
  and the hitch row's `why` carries the fresh capture's numbers.
- `tools/gate/crossings.mjs` SCAN_FILES is now `['index.html', 'lab.html']`, so the lab page is
  inside the two-crossings rule's scan set. It carries no crossing figures today; now that is
  checked rather than assumed.
- `tools/faults.mjs` hookSites needed no change: the fault hooks live in `src/render/calibration.js`
  and `src/ui/panel.js`, which moved pages without moving files, and `gate/instruments` agrees.

### The witness set, recaptured from the running pages on 20 August 2026

Every recorded browser capture the selftest points at was retaken from `lab.html` on 4281, not
carried over from the old single page: `shots/calibration.png`, `shots/selftest-healthy-t0.png`,
`shots/selftest-healthy-t720.png`, `shots/selftest-blank-render.png`, `shots/selftest-stale-a.png`,
`shots/selftest-stale-b.png`, `shots/selftest-ui-text-change.png`, `out/probes/calibration.json`,
`out/probes/selftest-healthy.json`, the three faulted probes, and both bench series. Each was
verified with the instrument that owns it before the selftest ran:

    node tools/shot.mjs --assert calibration                        PASS: 6 of 6 samples
    node tools/shot.mjs --moved calibration <healthy t0> <t720>     PASS: the tick swatch differs
                                                                    between the two frames
    <blank-render shot>                                             FAIL: 5 of 6 wrong, every failing
                                                                    sample holds the background colour
    <stale pair>                                                    FAIL: tick-swatch-centre identical,
                                                                    byte for byte the same frame
    <ui-text-change shot>                                           PASS, as the registry requires
    node tools/uiprobe.mjs --assert calibration --expect tools/panels/calibration.json
                                                                    PASS: 10 rules over 5 panels
    node tools/uiprobe.mjs --assert front --expect tools/panels/front.json
                                                                    PASS: 10 rules over 8 panels,
                                                                    28 values, at tick 1081 and again
                                                                    at tick 360, two different minutes
    node tools/bench.mjs --assert --file out/probes/selftest-bench-healthy.json
                                                                    PASS: p99 0.385 ms
    node tools/bench.mjs --assert --file out/probes/selftest-bench-hitch.json
                                                                    FAIL: worst 40.64 ms at frame 58,
                                                                    ten frames over budget, sixty apart

The second witness was retaken too: `out/probes/calibration.axtree.json` is now a read_page capture
of lab.html at tick 720, and `node tools/uicompare.mjs --assert calibration` reads PASS, five panel
names agreeing, with the two advisory landmarks it always reports on this page, the scene section
and the footer, neither of which carries a data value.

### The suite, run on 20 August 2026 after the repointing

    node tools/gate.mjs                          PASS: 0 blocking, 15 advisory, all pre-existing
    node tools/check-island.mjs                  all 18 checks passed
    node tools/check-crossings.mjs               all 40 checks passed
    node tools/determinism.mjs --ticks 2000      PASS, 21 checkpoints, 4 hashes identical
    node tools/selftest.mjs                      PASS: 33 of 33 rows green, 0 not proven,
                                                 0 missed or caught for the wrong reason
                                                 wrote docs/JURISDICTION.md
                                                 git status: unchanged apart from that file

The `acknowledgement-present` rule is green on `index.html`, where it looks.

### What this section does not claim

- **The browser rows still depend on captures that are not in git.** Nothing about the split
  changes that. A fresh clone reports those rows not proven until somebody opens
  `http://localhost:4281/lab.html` and posts captures again, and the regenerated
  `docs/JURISDICTION.md` says so with the right URL now.
- **The front baseline pins what is honestly pinnable and no more.** Ten of its 28 values omit
  `prov` because the citation is the record of whichever sailing or bus call answers at that
  minute, which is the page being right, not the baseline being lax. A renamed panel, a dropped
  value, a changed register or a drifted static citation all fail it; a dynamic citation swapping
  between two real sailing records does not, and cannot honestly be made to.
- **The non-owning `caught` cells in the fresh matrix are the same three as the 19 August run**:
  `nondeterminism` under determinism with shuffle, and `fixture-throws` under both determinism
  columns. Structural, not flakes. Two headless flakes during the run were retried once, passed,
  and are printed in the run log.
- **uicompare still cannot settle accessible names.** The fresh capture carries the same limits as
  the old one, written in the file itself.
- **Nothing here is committed or pushed.** No agent in this wave runs a state changing git command.

Written by the wave 6 fault registry agent, at the end of the wave that turned the owner's crossing
timetables into a pack, a system and a check, and that wired the record store into the world. The one
thing this section is for: **everything wave 6 landed has now been watched failing, and the one piece
of data in this repository that no connector can fetch again has a guard on it.**

### The registry now

`tools/faults.mjs` holds **33 faults against 21 instrument columns**, up from 28 against 18 at the
end of wave 5. The run on disk is the one that generated `docs/JURISDICTION.md`:

    node tools/selftest.mjs                                                    22:18, 2m06s
      PASS: 33 of 33 rows green, 0 not proven, 0 missed or caught for the wrong reason.
      wrote docs/JURISDICTION.md
      git status --porcelain: unchanged apart from docs/JURISDICTION.md.

Six rows are new and each one is a thing that could not be seen before:

| row | breaks | caught by |
| --- | --- | --- |
| `crossings-summed` | a vehicle figure added to a passenger figure, and a field named so both could live in it | `gate/crossings` |
| `crossing-unattributed` | a departure count and a movement count written without saying which service or which landing point | `gate/crossings` |
| `crossing-carries-both` | a third value for what a boat carries, and another boat declaring none | `gate/crossings` |
| `timetable-drift` | a departure time altered from the one the owner supplied | `gate/ground-truth` |
| `store-unwired` | the world built with no record store, no cursor and no field resolver | `check-wiring` |
| plus three new columns | `gate/crossings`, `gate/ground-truth` and `check-wiring` had no column before | |

`gate/crossings` had been proved by hand once, in the wave that wrote it, and board note 032 said
what that is worth: "a hand proof is a rumour by the second week". It has three rows now, one per
rule it carries.

### The seal on the owner's timetable, and why it needed its own rule

`tools/gate/ground-truth.mjs` is new. It holds a second copy of the crossing departure times,
transcribed from the owner's supply rather than read back out of the pack, plus a digest over the
sailing structure: service, direction, departure minute, published clock time, vessel code and day
rule. A change to any of those is a blocking finding that names what moved. It covers nothing else,
on purpose: the notes and locators around the timetable are this repository's writing about it and
should be free to improve.

**The transcription agreed with `data/crossings.json` on the first run, in all seventy six
departures.** That is worth writing down, because the transcription was made from the owner's own
words in the task brief and board notes 029 and 030, and a disagreement would have meant one of the
two was wrong.

**Why an existing check was not enough, measured rather than argued.** A copy of the tree was taken
and one middle row of the SeaLink vehicle Departs Cleveland column was moved from 10:30 to 10:35.

    cd out/drift-tree && node tools/check-crossings.mjs
      all 40 checks passed
    node tools/gate.mjs --root out/drift-tree
      FAIL: 2 blocking
      ground-truth/timetable-drift  data/crossings.json:366
        sealink-vehicle-barge mainland-to-island departure 5 (sealink-vehicle-m2i-1030):
        the owner supplied 10:30 and this pack says 10:35
      ground-truth/seal  data/crossings.json
        the sailing structure no longer matches its seal

Nothing else in the gate saw it either. `tools/check-crossings.mjs` is a good instrument and this is
not a defect in it: its window checks read the first and last row of a column, its rotation checks
read vessel codes, and its movement checks are row counts, so a middle row is invisible to all forty.
The drift would have shipped.

### The wiring instrument, and the proof that was thrown away

`tools/check-wiring.mjs` is new. It builds the island the way every other instrument builds it and
asks thirteen questions of the result: is there a store on the world, does the load report agree with
it, is a quarantined record named rather than skipped, are the three cursors there, does the store's
present follow the world clock, does every field the twin declares resolve to one of the ladder's two
shapes, does an absence carry the record that explains it, and is the value a panel shows the
ladder's answer at that cursor rather than a second opinion beside it.

    node tools/check-wiring.mjs
      store:  3 records from tide
      fields: tide.heightM
      PASS: 13 checks over a world built the way every instrument builds it

Board note 031 already proved the wiring, with a script under `out/`, which is gitignored, so the
proof went away with the agent that wrote it. This is that proof kept. Under `store-unwired` ten of
the thirteen checks fail. One that does not is worth reading: `the-simulation-rung-is-not-the-answer`
passes, because with no answer at all nothing borrowed the simulation rung, and a row that counted
that as a pass would be counting an absence.

### Every instrument, run at 22:16

    node tools/gate.mjs                          PASS: 0 blocking, 13 advisory
    node tools/headless.mjs --ticks 1440         PASS
    node tools/determinism.mjs --ticks 5000      PASS, 21 checkpoints, 4 hashes identical
    node tools/determinism.mjs --ticks 5000 --shuffle
                                                 PASS, registration order changed nothing
    node tools/bitemporal.mjs --check            PASS, 35 checks over 10 fixture records
    node tools/check-island.mjs                  all 18 checks passed
    node tools/check-crossings.mjs               all 40 checks passed
    node tools/check-wiring.mjs                  PASS, 13 checks
    node tools/selftest.mjs                      PASS: 33 of 33 rows green

The 13 advisories are the same manual and carried-pack ones as before, plus the three `specimen`
lines board note 032's escape hatch prints on every run so an exemption cannot be quiet.

### What this section does not claim

- **Three tools under `tools/` are instruments with no column, and they are named rather than left
  to be found.** `check-island.mjs`, `check-crossings.mjs` and `connections.mjs`. Board note 033
  already names the fault that would prove the third: a bus call whose `pickupType` says no pickup
  counted as a connection. `uicompare.mjs` is a fourth and cannot get a row, because the fault that
  would prove it is a page that lies about itself and no Node script can inject that.
  `docs/JURISDICTION.md` carries all four.
- **The seal proves the timetable is the one supplied, not that it is right.** Correctness belongs
  to the operators and to the owner. If SeaLink republishes tomorrow, the gate will block until
  somebody changes the pack, the transcription and the digest and says on the board who read the new
  timetable and when. That is the intended cost.
- **`store-unwired` reaches the Node half of its own description and not the browser half.** The
  world building without a store is injectable and watched. A panel in a browser reading a value
  around the ladder is not, and would need a capture nobody has taken.
- **The matrix on disk is one run, and a cell outside the owning column can move between runs.** An
  earlier run this evening wrote `caught` into the `headless` column on `stale-frame` and
  `port-collision`, two rows headless does not own and structurally cannot see: one hooks the
  renderer and the other writes `tools/serve.mjs`, and headless loads neither. It is the budget
  overrun with no collector pause behind it that `tools/headless.mjs` documents in its own header,
  board note 031 measured at roughly one run in six on a busy machine, and it happened twice in a row
  on each. The run that generated the file on disk did not hit it, so both cells read `missed` there
  now, which is the true answer. `docs/JURISDICTION.md` carries the caveat as a standing one, because
  the next run may put those cells back.
- **A wave 7 surface landed in the middle of this work and the final run covers it.**
  `src/ui/crossings-view.js` and a changed `src/main.js` appeared at 22:11 while a selftest was
  running, which that run's own guard caught and reported as a repository change. The run above was
  taken again afterwards against the settled tree, and `node tools/gate.mjs`, `node
  tools/check-wiring.mjs`, `node tools/check-island.mjs` and `node tools/check-crossings.mjs` were
  all re-run over it before that. Board note 035 carries what that view does; nothing in it is
  claimed here, because the agent that wrote a thing owns its receipt.
- **Nothing here is committed.** No agent in this wave runs a state changing git command.
- **`docs/STAGE-0.md` still prints the original seventeen row registry table**, now six waves behind
  `tools/faults.mjs`. `docs/JURISDICTION.md` is generated and is the current answer.
- **`docs/CONTRACT.md` section 6 still reads NOT YET CHECKED on the two-crossings law.** It is
  checked, by `tools/gate/crossings.mjs`, and proved by three rows in the matrix. That file was not
  this task's to edit and board note 032 already asked for the correction.

---

## 19 August 2026, 19:50 island time: the measurement now covers stage 2 and stage 3

Written by the wave 4 fault registry agent, at the end of the wave that brought in real ground, the
bitemporal spine and four ingest connectors. The one thing this section is for: **the instruments
that made stage 0 real now cover the code stage 2 and stage 3 landed, and the coverage was watched
rather than claimed.**

### What the fault registry looks like now

`tools/faults.mjs` holds **27 faults against 18 instrument columns**, up from 22 against 16 when
stage 0 closed. The last run, which is the one on disk:

    node tools/selftest.mjs                                                    19:50
      PASS: 27 of 27 rows green, 0 not proven, 0 missed or caught for the wrong reason.
      wrote docs/JURISDICTION.md
      git status --porcelain: unchanged apart from docs/JURISDICTION.md.       about 65 seconds

    node tools/gate.mjs
      PASS: 0 blocking, 7 advisory                     the same seven, all in data/lore.json

Five rows are new since stage 0 closed. Two arrived with the spine they break and are adopted here
rather than duplicated, which is what board note 018 asked for:

| fault | breaks | owner | added by |
| --- | --- | --- | --- |
| `frozen-clock` | a read ignores the cursor's valid time and answers at the last lived minute | `bitemporal` | the spine agent |
| `stale-wins` | the simulation rung wins a live question against a stale official observation | `bitemporal` | the spine agent |
| `correction-overwrites` | a correction replaces the old belief instead of opening a new one | `bitemporal` | this task |
| `unprovenanced-derive` | a derived pack carries a record without the eight fields | `gate/derived` | this task |
| `derived-committed` | a derived pack appears under `data/` instead of `ingest-inbox/derived/` | `gate/derived` | this task |

### The new gate rule

`tools/gate/derived.mjs`, one module with two rules and one switch.

- **`derived/committed`** looks for four marks of a derived pack under `data/`: a pack name a
  connector under `tools/ingest/` actually writes, read out of the connector source rather than
  listed in the rule; a string pointing at `ingest-inbox/`; a `committable: false` the pack declares
  about itself; and a bulk feature set, meaning fifty or more entries that almost all carry both
  geometry and full provenance. `data/tide.json` and `data/lore.json` both carry a top level `pack`
  field, so "has a pack field" is deliberately not one of the marks.
- **`derived/unprovenanced`** reads every record under `ingest-inbox/derived/` and requires the eight
  fields. It is the only gate rule that looks inside a staging tree, and it does so because
  `docs/CONTRACT.md` section 3 binds every record the twin creates and `gate/provenance` covers only
  the `data/` half. Source ids are **not** checked against `data/_sources.json` here: registering a
  derived source id is itself a commit, and this wave commits nothing derived.
- **The switch.** Board note 007's `status`. While it reads anything but `resolved`, the marks above
  are blocking. When the owner settles the ODbL question and that note is resolved, the rule stands
  down by itself and reports what it would have blocked as advisory. No edit to the rule is needed
  and none should be made instead.

On this machine, with four connectors run, the rule judged 1,939 records across four packs and found
no missing field:

    node tools/gate.mjs --rule derived
      derived       clean
      PASS: 0 blocking, 0 advisory

### The `void` verdict fired for the first time, twice, and then cleared

Worth knowing before the next agent runs the matrix during a live wave. Between 19:10 and 19:50 the
same command gave three different answers, and every one of them was correct at the moment it ran:

| time | result | why |
| --- | --- | --- |
| 19:10 | 27 of 27 green | a quiet tree |
| 19:38 | 26 of 27, `em-dash` **void** | `tools/ingest/ecology.mjs` landed with a line `gate/style` reads as American spelling, so `gate/style` was red on the healthy tree |
| 19:44 | 25 of 27, `personal-data` **void**, `personal-data-staged` not proven | `docs/INGEST-STATUS.md` and a new board note landed quoting the digit strings `gate/personal`'s patterns had matched, so the rule matched the documentation of itself |
| 19:50 | 27 of 27 green | both lanes corrected their own lines within minutes |

`void` means the instrument already fails on the healthy tree, so its failure on the faulted tree
proves nothing. It is the meta-instrument declining to award a catch it did not earn, and until
today no row had ever reached it. Both causes were false positives in prose rather than defects in
code, and both were one edit away, and neither was this task's to make.

**The practical rule: the matrix is a photograph of the tree at the moment it was taken.** Run it
when the wave is quiet, read the timestamp in its own header, and treat a `void` row as a question
about the healthy tree rather than about the fault.

### Two defects found in the measurement itself, and fixed

1. **The generated matrix carried a false line.** Its footer said there is no commit-msg hook, which
   stopped being true at commit `d845a1d`. `tools/hooks/commit-msg` exists and was watched refusing a
   message carrying U+2014 and passing a clean one. The footer now says so and says why that half can
   never be a row: `.git/hooks` is not tracked and no agent here runs a state changing git command.
2. **A flaky cell could write `caught` into the published matrix.** `tools/headless.mjs` fails about
   one run in six on this machine when a tick goes over budget with no collector pause to account for
   it, and one run of this matrix recorded `headless caught` against `stale-wins`, a fault
   `headless.mjs` does not even load the code for. `tools/selftest.mjs` now retries a failing column
   that the fault does not own, once, and prints both attempts. The owning column is never retried:
   it is the row's verdict and `mustName` already decides it.

### What this section does not claim

- **Nothing here is committed.** No agent in this wave runs a state changing git command. Everything
  above is in the working tree.
- **`docs/STAGE-0.md` still prints the original seventeen row registry table.** It is the
  specification and it is now five waves behind `tools/faults.mjs`. `docs/JURISDICTION.md` is
  generated and is the current answer. Nothing in the gate compares the two.
- **`docs/CONTRACT.md` section 3 gained a check and does not know it.** The line about every record
  the twin creates is now checked for the derived lane by `gate/derived`. The contract file was not
  this task's to edit.
- **The gate is clean now and was not for most of the last hour.** `node tools/gate.mjs` reads 0
  blocking, 7 advisory, the same seven manual and carried-pack advisories as before this work. Three
  documents from two other lanes tripped `gate/style` and `gate/personal` during that hour, all of
  them by quoting the exact text the rule matches, all of them corrected by their own lane. That
  pattern now has three independent reports and board note 016 already asked for an answer to it.
  See board note 019, section 8.
- **The connectors themselves were not run by this task.** `gate/derived` read the packs they had
  already written. The connector lanes own their receipts and this document does not borrow one.

---

**18 August 2026.** Written for the next agent, not for a reader who wants to be encouraged. Its
companion is the cheerleader's ledger, which carries what verifiably works to the humans; this file
carries what is true to the swarm, including the parts that are unfinished, unproven or only written
down.

Rule for editing it: nothing is listed as working without naming the command that proves it. If the
command is not one somebody else can re-run, it is not a receipt, and the honest row is "exists,
untested".

**This is a snapshot of a live wave, taken at 17:28 island time on 18 August 2026.** Other agents
were writing other paths while it was being written, and several tools appeared on disk during the
hour it took. Where that happened it is marked, and the mark says the file exists and that I did not
run it, because the agent that wrote a tool owns its receipt and this document may not borrow one.
Anything listed as absent below was absent at 17:28. Check before you rely on it.

---

## 1. The single most important fact about how this project is run

**A thirteen agent wave was killed by a session limit today. One agent survived it.**

That is a fact about the process, not about the code, and it is the reason this document exists and
the reason the noticeboard exists. It is recorded here because the founding prompt's failure
catalogue already names the same failure twice in the first build: its playthrough agent was killed
by session limits three waves running, which delayed by a week the discovery that its storyline
engine died on sim-day ninety, and its scout reports were killed in transit so its owner read nothing
but defect reports for twelve days.

What it means for whoever schedules the next wave:

1. **Schedule the synthesis, the playthrough and the board work first in the budget, never last.**
   This task was scheduled first in its wave for exactly that reason.
2. **Assume any agent may not get to its final report.** The repository is the only durable channel.
   `docs/board/` is where a finding goes so that it outlives the session that found it, and
   `docs/board/README.md` is the law.
3. **A wave's memory is its board and this file.** Nothing else survives.

What I can and cannot verify about that fact, since this file is bound by its own rule: I cannot see
sessions from inside the repository, so the wave and its casualty count are recorded from the
orchestrator that scheduled this task and are not something I checked. What the repository does show
is consistent with it. `git log` gives nine commits, all dated 18 August 2026, the last at 17:08 and
the one before it at 12:41, and what landed in that gap is one commit: solar, tide, the kernel's data
loading and the cultural check. That is one agent's worth of work in a window sized for thirteen.

---

## 2. What exists today

Everything in the repository, listed so that absence is as visible as presence.

**Kernel, `src/kernel/`.** `world.js` (the tick loop, declared system order, declared seams and their
fire counts), `clock.js` (integer island minutes, fixed UTC+10, no `Date` object), `rng.js` (named
sfc32 streams derived from the world seed), `store.js` (entities and components in typed arrays),
`hash.js` (FNV-1a, per-system state hashing), `record.js` (the eight provenance fields and their
validator), `faults.js` (the `ISLAND_FAULT` switch).

**Systems, `src/systems/`.** `solar.js` and `tide.js`. Two. The tide is deliberately unfed.

**World, `src/world/`.** `island.js` (`buildIsland`, the one place a world is constructed) and
`data.js` (pack loading, Node and browser backends).

**Data, `data/`.** `lore.json` (the cultural pack, carried byte for byte), `tide.json` (unfed, with
the unusable first-build constituents recorded and quarantined), `_sources.json` (six source records).

**Tools, `tools/`.** Written and verified before this file: `gate.mjs` with nine rule modules under
`tools/gate/`, `check-island.mjs`, `board.mjs`.

Landed on disk during the hour this file was written, by other agents in the same wave, **not run by
me and carried here as "exists, untested" until their own authors post receipts**: `headless.mjs`,
`determinism.mjs`, `shot.mjs`, `png.mjs`, `png-encode.mjs`, `serve.mjs`, `serve-progress.mjs`,
`tools/scenes/calibration.json`, `tools/fixtures/spin.js`, and `progress/index.html`. Six of those
files were not there when this task started at about 17:00 and were there at 17:28. Treat this
paragraph as a pointer, not as a status: read the board and the commit log.

**Docs, `docs/`.** `FOUNDING-PROMPT.md`, `CONTRACT.md`, `STAGE-0.md`, `CHEERLEADER.md`,
`INGEST-STATUS.md`, `CULTURAL-QUEUE.md`, this file, and `board/` with its law and eight notes.

**Not present at 17:28, and each absence matters.** No `index.html`. `src/render/` and `src/ui/`
exist as empty directories and hold no file. No `assets/`. No `ingest-inbox/`. No `vendor/`. No
`docs/JURISDICTION.md`. No `tools/faults.mjs`, `tools/budgets.json`, `tools/selftest.mjs`,
`tools/uiprobe.mjs`, `tools/bench.mjs` or `tools/gate/instruments.mjs`. No git remote: nine commits
on `main`, all local, nothing pushed anywhere.

---

## 3. What is proven, with the command that proves it

| claim | command | what it printed today |
| --- | --- | --- |
| The world builds, runs two sim days and its sun matches independent geometry | `node tools/check-island.mjs` | `all 18 checks passed` |
| The sun's declination reaches the axial tilt at both solstices and crosses zero at the equinoxes | same | `23.452 deg`, `-23.420 deg`, `-0.461 deg` and `0.249 deg` |
| Solar noon, day length, sunrise and sunset symmetry and peak elevation all match arithmetic done outside the model | same | four pairs agreeing, printed per day |
| The tide reports itself unfed rather than drawing a plausible curve | same | `fed false, heightM null, risingFalling null, constituents 0` |
| An unfed tide announces no tide turn | same | `0 tide events in 2880 ticks` |
| The declared seams are counted, and dead ones are named | same | `dead seams: tide.high, tide.low` |
| Every executable rule in the contract runs and the repository passes | `node tools/gate.mjs` | `PASS: 0 blocking, 8 advisory` |
| The cultural check catches an allowlisted word used to name a kind of thing no published source says it names | `node tools/gate.mjs --rule lore --root out/yalingbila-proof` | `FAIL: 1 blocking, 9 advisory`, naming the file, the line and the reason |
| The board tool writes notes the board check accepts | `node tools/board.mjs post ...` then `node tools/gate.mjs --rule board` | eight notes posted, `board  clean` |
| The board tool's status change, its dated update line and its reopen behaviour | `node tools/board.mjs set 006 --status resolved --note "..."` on a copy under `out/` | front matter rewritten, `resolved: 2026-08-19` added and then removed on reopen |
| The board tool refuses malformed input rather than writing a note the gate would reject | `node tools/board.mjs post --status bogus`, `--author` omitted, `--body` omitted | exit 2 with a message naming the rule, three times |

The world hash today, from `node tools/check-island.mjs`, is `ef810266`. It is a fingerprint of a
two-day run with two systems, and it is worth writing down only because a later agent can compare it.

---

## 4. What is written but not proven

This is the honest half, and it is larger than the half above.

| written | where | state |
| --- | --- | --- |
| Eight stage 0 instruments | `docs/STAGE-0.md` | At 17:28: `gate.mjs` and `board.mjs` exist and are proven here. `headless.mjs`, `determinism.mjs` and `shot.mjs` exist on disk, written by other agents in this wave and not run by me. `bench.mjs`, `uiprobe.mjs` and `selftest.mjs` do not exist. Board note 008, which carries the state at 17:05 and a dated update. |
| A registry of seventeen deliberate faults | `docs/STAGE-0.md` | `tools/faults.mjs` does not exist at 17:28, so not one fault is declared. `src/kernel/faults.js` is the switch and there is nothing yet for it to switch. |
| `gate/instruments`, which fails when a fault has no hook site or an instrument has no fault | `docs/STAGE-0.md` | Does not exist. |
| `docs/JURISDICTION.md`, the fault by instrument matrix | `docs/STAGE-0.md` | Does not exist, because `selftest.mjs` does not exist to generate it. Until it does, stage 0 is not finished, whatever else passes. |
| Nine gate rules | `tools/gate/` | All nine run and all nine are clean. **One has been proven against a planted fault: `lore`.** The other eight have never been watched failing, so they are "exists, untested" and must be described that way. |
| The perf budget and the p99 rule | `docs/CONTRACT.md` section 6 | `tools/budgets.json` does not exist and nothing renders, so there is no frame to time. |
| The bitemporal store | `docs/CONTRACT.md` section 3 | `src/kernel/record.js` is the record type and its validator, and it is enforced on `data/` today. The store that queries across the two axes is stage 3 and does not exist. |
| Every ingest lane | `docs/INGEST-STATUS.md` | Every row reads exists: no, last exercised: never. |
| The cultural queue | `docs/CULTURAL-QUEUE.md` | Six open questions, none of which has been put to anybody. |
| The course, as a deliverable | founding prompt section 3 | Does not exist. |

---

## 5. What the next agent must not assume

Each of these is a mistake that is easy to make from the outside and expensive to make from the
inside.

1. **Do not assume the gate passing means stage 0 is done.** A gate that has never been watched
   failing is a gate nobody has tested. Eight of the nine rules are in that state. The whole point of
   `selftest.mjs` is to move them out of it, and it has not been written.

2. **Do not assume `check-island.mjs` is the headless instrument.** It builds the island and checks
   the sun against physics. It does not report per-system tick cost, does not fail on a tick budget,
   does not diff two runs and cannot name a system that drifted. `headless.mjs` and
   `determinism.mjs` are separate tools, they arrived on disk while this file was being written, and
   nothing in this document is a receipt for either of them.

3. **Do not assume the tide is broken.** It is unfed on purpose and its unfedness is checked. If a
   tide curve appears in this repository without a sourced constituent table landing in
   `data/tide.json` first, that is the fabrication this build exists to prevent. Board note 004.

4. **Do not assume `data/lore.json` may be edited.** It is carried from the first build byte for
   byte, sha256 `0d3e65ceee59c1711b729c81a83a669f96ba1f17e6c36acb139111ed12b016d0` in both
   repositories. Findings inside it are questions for the owner, and `tools/gate/lore.mjs` raises
   them that way on purpose.

5. **Do not assume anything cultural has been settled.** QYAC has not seen this project and nobody
   has asked. Nothing in `docs/CULTURAL-QUEUE.md` is an approval, no entry in it may be described as
   approved, endorsed, cleared or signed off, and the gate blocks the build if one is.

6. **Do not assume the coordinate in `data/tide.json` is free to copy.** It is derived from
   OpenStreetMap, ODbL, and the share-alike question against `LICENCE.md` is unresolved. It is
   already committed, which makes the question live rather than theoretical. Board note 007.

7. **Do not assume the first build's code is the shape to copy.** `CLAUDE.md` says data, doctrine and
   constants come over and code usually does not, because if the old shape were right this repository
   would not exist. Read the first build freely. Never write into it, and never run a state-changing
   git command there.

8. **Do not assume a finding you reported in a transcript was received.** Post it to
   `docs/board/` with `tools/board.mjs` before you finish. A wave can be killed with your report in
   transit, and today one was.

---

## 6. What is open on the board right now

Read it with `node tools/board.mjs read`. As at this file's date:

- **002, for-owner.** A cultural correction the first build made in its code did not reach its data.
  Its `data/feeds/_events-engine.json` record 12 still carries a published word for whale as a
  listing period. Verified read-only. This repository may not fix it there, and this build's
  `tools/gate/lore.mjs` catches the class, proven against a copy.
- **001, for-owner.** Confirm the repository name `second-island`. The push is held on it. The same
  question is already on the first build's board.
- **008, open.** Stage 0 instruments are arriving with no fault registry to prove them. Posted at
  17:05 as "six of the eight do not exist" and corrected at 17:28, when three of them did.
- **007, open.** The ODbL share-alike question is unresolved and already live.
- **006, open.** Three seams in the board's own machinery, including one defect in `tools/board.mjs`
  that was found by testing it and fixed, with the residual gap stated rather than hidden.
- **005, open.** `LICENCE.md` points at two files that do not exist in this repository.
- **004, open.** The tide has no published constituent table, and what would settle it.
- **003, open.** No day-zero data is downloaded, so stage 2 cannot start.

---

## 7. The next thing to build, if nobody says otherwise

Stage 0 is unfinished and the order of operations says nothing else starts. The gap is not the world,
it is the instruments that measure it. In the order they unblock each other:

1. `tools/faults.mjs`, the fault registry, because everything below it needs faults to catch. Three
   instruments landed on disk in this wave with no registry for them to be proven against, so this is
   the gap that matters most.
2. `tools/gate/instruments.mjs`, so a fault with no hook site and an instrument with no fault are
   both failures rather than omissions.
3. `selftest.mjs` and the `docs/JURISDICTION.md` it generates, which is what turns "the gate is
   clean" into "the gate has been watched failing".
4. `uiprobe.mjs` and `bench.mjs`, which need a page and frames to point at, and that page is not
   stage 0's job to invent.

Ahead of all four, and cheaper than any of them: whoever wrote `headless.mjs`, `determinism.mjs` and
`shot.mjs` in this wave should post their receipts to the board, because otherwise the next agent
finds three instruments and no evidence that any of them has ever caught anything.

---

*Nothing in this file is a claim about quality. It is a claim about what is here, what has been run,
and what has not.*
