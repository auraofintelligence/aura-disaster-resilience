# The contract

Every agent in this repository builds to this file. `docs/FOUNDING-PROMPT.md` says what we are
building and in what order; this file says what the code must look like while we do it. Where they
disagree, the founding prompt wins and this file is wrong and must be fixed.

Ancestry: the first build at `minjerribah-living-twin` ran thirteen waves against a document of the
same name. This is not that document. It is written for this build, and where a rule here exists
because that build paid for it, the receipt is named in the line.

## 0. The one rule that generates the others

**A rule that is not in the gate does not exist.** The first build wrote its cultural rules down and
then violated them, because prose does not execute. Every rule below is either already a check in
`tools/gate/`, or carries `NOT YET CHECKED` and a reason. There is no third state, and a rule may
not be added to this file without one of those two.

## 1. The split

    src/kernel/    the tick loop, the store, the clock, the seeded streams, the record type
    src/systems/   island behaviour, one file per system, pure over the store
    src/world/     data loading and the bitemporal store
    src/render/    everything that needs a GPU
    src/ui/        everything that needs a DOM
    tools/         the instruments, the gate, the servers
    data/          packs, every record provenanced
    docs/          this, and the board

**Simulation never imports the renderer or the UI.** Not through a helper, not through a shared
constants file that happens to import one. This is what lets the whole island run in Node with no
browser, which is what makes determinism testable at all. Checked: `gate/imports`.

**The renderer never writes simulation state.** It reads a frame's worth of state and draws it.
Checked: `gate/imports` in one direction, and by review in the other.

## 2. Determinism, which is a property we test rather than hope for

- The world advances in **integer ticks. One tick is one island minute.** A sim-day is 1440 ticks.
  Timetables are written in minutes because that is how they are published.
- **No wall clock in simulation.** `Date.now`, `new Date()`, `performance.now` and `Math.random` are
  banned under `src/kernel`, `src/systems` and `src/world`. Checked: `gate/no-wallclock`.
- **Randomness comes in named streams.** `world.rng('koala')` derives a stream from the world seed
  and the name. A system draws only from its own stream, so adding a system does not shift another
  system's numbers, and a determinism failure names one system instead of the whole world. This is
  the correction: the first build could tell you two runs differed and not which system moved.
- **Iteration order is explicit.** Systems declare an integer order and are sorted by it, then by
  name. No system may depend on registration order, on object key order, or on the insertion order
  of a Map or Set for anything that changes state. Checked in part, by running the determinism
  instrument with a shuffled registration order.
- Floating point is allowed. Non-reproducible floating point is not: no accumulation over an
  unordered set, no branch on a value that depends on host maths precision.

## 3. Records, provenance and the two times

Every record in `data/**`, and every record the twin creates at runtime, carries:

    source          an id in data/_sources.json, never free text
    locator         page number, section or URL fragment: enough to check the claim in one step
    validFrom       when this became true of the island
    validTo         when it stopped being true, or null for still true
    recordedAt      when the twin learned it
    recordedUntil   when the twin superseded it, or null for current belief
    confidence      high | medium | low | contested | unknown
    register        known | modelled | proposed | contributed

**The two times are not optional and are not added later.** Live mode, history mode and scenario
mode are three cursor positions over one store, and that only works if the store never held a
single-time record. The first build bolted time onto a single-time model and paid for it in every
panel that touched time. Checked: `gate/provenance`.

- **Low confidence never reaches a player as a claim.** The honest display is a contested-or-unknown
  marker with the date. NOT YET CHECKED: no UI exists. The check lands with the first panel.
- **The three registers are visually distinct** and `proposed` never blends into the island's default
  state, and never inflates a real island figure. Publish the split. NOT YET CHECKED: no UI exists.
- **Where real data exists and is licensed, invention is a bug.** Procedural fill is allowed only
  where nothing real exists, carries `register: modelled`, and says so on screen. Checked:
  `gate/provenance` for the register field. Whether real data existed is human-judged.

## 4. The cultural boundary, blocking

Minjerribah is Quandamooka Country. QYAC has not seen this project.

- No Aboriginal language word appears anywhere unless it is on the allowlist carried from the first
  build's `data/lore.json`. No word is inflected, combined, translated, pluralised or coined. If a
  needed word is not on the list, use English. Checked: `gate/lore`, token allowlist.
- The banned-token list is carried forward whole. It holds words an earlier agent invented, and one
  published word that agent used for a thing it does not name. Checked: `gate/lore`.
- No ceremony, ritual, dance, song, initiation, mourning or welcome is depicted, named, animated,
  scheduled, simulated or written as dialogue. Checked: `gate/lore`. A hit is a stop-and-ask, not an
  automatic violation, and the usual right answer is to delete the line.
- No sacred, restricted, secret, gendered or otherwise culturally restricted site is placed, given a
  coordinate, named in a map layer or generated. This includes middens and burial places, and the
  scope covers `assets/**` as well as `data/**`. Checked: `gate/lore`. The first build found the
  assets gap in its own rule and did not close it; it is closed here.
- Organisations may be named and their publicly advertised events listed as advertised. Their views,
  decisions and knowledge may not be invented or inferred. NOT YET CHECKED: human-judged.
- `docs/CULTURAL-QUEUE.md` is a queue of open questions for the Traditional Owners. Nothing in it is
  an approval and it is never described as one. Checked: `gate/lore`, forbidden phrasings.

## 5. What may not be invented

- **No invented business, place, road, person, organisation, event or word.** Where the real thing
  exists in a licensed source, use it. Checked: `gate/lore` for language. NOT YET CHECKED for places
  and businesses, which needs the real gazetteer from stage 2. That check lands with that data.
- **An agent never coins a name for the owner's designs.** The first build invented a name for one of
  his and quoted it back to him as his own. If a thing he designed needs a label, ask, or use his
  words exactly.
- **Every generated person is disclosed as generated, on every card, permanently.** About two
  thousand real people live here and a name pool will eventually collide with one of them by chance.
  NOT YET CHECKED: no people exist yet.
- **Personal data never lands in the repository.** Contact details are screened at ingest with a
  published-versus-personal distinction, and the staging area is proven sealed by asking git rather
  than assumed sealed. Checked: `gate/personal` and `gate/sealed`.

## 6. Honesty about ourselves

- **Nothing is marked done that was not verified in the running artefact by whoever marked it.**
- **"Works" without a receipt is forbidden.** "Exists, untested" is an acceptable and useful answer.
  This binds the instruments hardest of all: `docs/STAGE-0.md` carries a status table, and an
  instrument that has not caught a deliberately injected fault is listed there as unproven.
- **A finding that lives only in a transcript is treated as never made.** Read `docs/board/` before
  starting and post to it before finishing. Checked: `gate/board`.
- **Passenger and vehicle crossings are never one figure.** You can almost always get off the island.
  You cannot always get your car off, and that is the useful question. NOT YET CHECKED: the check
  lands with transport data in stage 2.
- **p99 frame time is the shipping metric.** A 25 ms hitch fails the build no matter the average.
  Checked: `bench`, budgets in `tools/budgets.json`.
- **Australian English. Prices in A$. No em dashes anywhere, including code comments and commit
  messages. No overstatement: the smaller true claim beats the bigger vague one.** Checked:
  `gate/style` for em dashes and a spelling list. Overstatement is human-judged.

## 7. Doctrine is rewritten, never copied

Carrying a document from the first build means rewriting it for this build, in this build's voice,
citing that build as ancestry and never wearing its history as ours. A fresh repository whose
doctrine claims thirteen waves of experience is lying about itself. Data, constants and gate rules
are copied exactly. Prose is not.

## 8. Amending this file

Anyone may propose an amendment by posting to `docs/board/` with status `for-owner`. An amendment
lands with the check that enforces it in the same commit, or with `NOT YET CHECKED` and the reason.
