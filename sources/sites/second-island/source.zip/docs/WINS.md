# Wins

The cheerleader's ledger. Newest first, dated, every entry carrying its receipt in one line. Its
mirror is `docs/STATE-OF-PLAY.md`, which says what is broken so the next agent is not fooled. This
one says what is won so the humans are not worn down. A project that keeps only one of them is lying
in one direction or the other.

The discipline is `docs/CHEERLEADER.md`: receipts or silence. Nothing is here that was not watched.

---

## 18 August 2026, day one, stage 0

### What works now that did not work before

**A determinism failure names the system that caused it.** `ISLAND_FAULT=nondeterminism node
tools/determinism.mjs --ticks 2000 --fixtures` exits 1 with "the two runs diverged at tick 1 in
fixture.jitter", and then goes further than naming it: it reports that the stream state and draw
count were identical in both runs, so the number that changed did not come from that system's own
stream, so it came from outside the seed. The first build could tell you two runs differed. It could
not tell you what moved.

**A sim year runs headless in 0.144 seconds.** `node tools/headless.mjs --ticks 52560` reports
365,109 ticks a second with no browser and no renderer in the way. Fast-forwarding a year to see
whether something falls over is now a thing you do while reading the output, not a thing you plan.

**Every instrument has been watched failing.** `node tools/selftest.mjs` runs 22 faults against 16
instrument columns and reports 22 of 22 green, 0 not proven, 0 caught for the wrong reason. Eight of
the nine gate rules had never been watched failing before this ran. `docs/JURISDICTION.md` is
generated from it and must not be hand edited.

**A screenshot provably cannot see the interface, and that is now a matrix row.** Under
`?fault=ui-text-change` the shot assertions pass 6 of 6 while `tools/uiprobe.mjs` fails naming the
element and both strings: `[data-panel="clock"]` reads "Clock, island time" where the baseline
declares "Island clock". Checked by hand in the browser, not only by the selftest. The first build
spent three waves judging its interface through a screenshot tool that structurally could not
contain one, and every verdict from that period was worthless.

**WebGPU is the live render path on this machine.** `ISLAND.info()` returns `renderPath: "webgpu"`,
device from `navigator.gpu`, canvas format bgra8unorm, Intel adapter. The WebGL2 and 2D fallbacks
were built and each posted a frame that passes all six sample points, so the ladder is real rather
than declared. The first build's ceiling was WebGL.

**The honest-absence rule survived contact with a real screen.** No published Dunwich harmonic
constituent table could be found, so `data/tide.json` ships zero constituents, `tide.js` sets
`heightM` to null, and the panel reads "contested or unknown, as at 18 August 2026" with no number
anywhere near it. `tide.high` and `tide.low` fire zero times and show up as dead seams in the world
report. That is four separate parts of the system agreeing to say "not known" instead of one of them
quietly inventing a curve.

**The cultural gate catches a misuse that is still live next door.** `tools/gate/lore.mjs` blocks
`"listing_period": "Yalingbila / winter-spring transition"`, a published word for whale used as the
name of a season. The first build removed that exact misuse from its code, recorded the correction in
its own pack, and the ingest lane brought it back in from another repository, where it sits today.

**A commit message with an em dash is refused.** The hook was watched rejecting the very commit that
introduced it, before the message was rewritten.

### Who did something that mattered

**The order of operations in the founding prompt is doing the work.** Stage 0 before anything it
measures is not a style preference; it is the reason 22 rows could be watched at all. Every
instrument in this repository was built against a subject that already existed, and the subject was
two systems whose numbers are physics rather than invention, chosen so nothing had to be made up to
give the instruments something to hash.

**The carry agent refused to ship the first build's tide constants.** It found them, found that the
comment above them claims a source that does not contain them, found that the first build had
already caught this itself on 10 August and that the false comment still stands, and shipped zero
constituents in a quarantined block that no code reads. Refusing to ship a plausible number is the
hardest thing to get an agent to do, and it did it without being asked twice.

**The board agent audited the claim it was handed.** Told that a thirteen agent wave had been killed
by a session limit, it wrote into `docs/STATE-OF-PLAY.md` that it could not see sessions from inside
the repository, that the count came from the orchestrator, and then checked what the repository does
show: nine commits, the gap between 12:41 and 17:08, one agent's worth of work in a window sized for
thirteen. That is the correct handling of a fact you were given rather than found.

**The gate reports rules it has not run.** Six of its lore findings say MANUAL and two say NOT YET
RUN with the reason, rather than passing silently. A manual rule nobody is ever shown is a rule
nobody runs, and printing it every time is the cheapest possible fix.

### What compounded

**Named random streams paid for themselves twice in one day.** They were built so that adding a
system could not shift another system's numbers. The second payment was unplanned: because each
system's stream state is hashed with its own state, a drift is attributable, which is what let the
determinism instrument name a system, which is what let the fault registry assert on that name, which
is what made `mustName` a real check instead of a formality.

**The board outlived the session limit that killed twelve of thirteen agents.** Everything those
agents knew is gone. Everything that reached `docs/board/` is not. That is the whole argument for the
law, delivered on the first day it existed.

**One blind spot is recorded rather than hidden.** `personal-data-staged` is caught by no instrument,
and `gate/personal` was watched not catching it. It sits in the matrix as BLIND SPOT PROVEN. A known
gap in the instruments is worth more than a clean sheet that nobody tested for gaps.

### What would be missed if it vanished

`docs/JURISDICTION.md`. Without it, every argument about whether a verdict is trustworthy goes back
to being an argument. With it, the answer is a table cell, and the cell was produced by watching the
instrument rather than by reasoning about it.
