# Licence questions: the ODbL against this repository's LICENCE.md

**I am not a lawyer and this is not legal advice.** What follows is a reading of published licence
text, retrieved and quoted on 19 August 2026, against the files in this repository. Every claim
below names the document it came from and quotes the sentence, so that a reader who disagrees can
disagree with a source rather than with me. The Open Data Commons text carries its own disclaimer,
quoted here because it applies to this document too: "Open Data Commons is not a law firm and does
not provide legal services of any kind." Where an answer depends on a fact only the owner knows, it
is written as a question to him in section 8 rather than assumed.

This file answers board note 007 and the blocked row in `docs/INGEST-STATUS.md`. It does not resolve
them. Resolving them is a decision, and the decision is the owner's.

---

## 1. The question

The founding prompt, section 5, says of the OpenStreetMap extract: "Resolve the ODbL share-alike
question against the repo licence BEFORE committing derived packs." That instruction is why the
single most valuable ingest lane on the list, the real building outlines for an island where the
first build invented 1,922 boxes instead, is fetched, staged and unable to move into `data/`.

Stated plainly: OpenStreetMap data is share-alike. `LICENCE.md` reserves commercial rights. Can both
live in one repository, and if so, how.

## 2. What is true in this repository today, checked rather than assumed

| fact | how it was checked, 19 August 2026 |
| --- | --- |
| No OpenStreetMap derived pack is committed here | `git status --short` at 18:50 shows `ingest-inbox/` untracked and sealed by `.gitignore`. The connector `tools/ingest/osm.mjs` landed during this task, from another agent in this wave, and writes only into `ingest-inbox/`. Code committed, pack not: which is what the founding prompt asks for. |
| A real extract now exists, staged and uncommitted | The same agent's new `osm-overpass` entry in `data/_sources.json` records one Overpass query on 19 August 2026, "HTTP 200, 1,743,826 bytes, 1,539 elements", returning "601 buildings and 924 road ways inside the island polygon". **Their receipt, not mine: I did not run the connector.** |
| One OpenStreetMap derived value is committed | `data/tide.json`, the `port` record: `"lat": -27.4992, "lon": 153.4025`, `"source": "first-build-places-pack"`, whose locator names `coordinate_source 'osm'`. |
| That value is in the running world | `data/tide.json` `site_note` says `port` "carries the island reference coordinate, and the solar system uses it too". |
| The registered source says the question is open | `data/_sources.json`, `osm-nominatim`, licence field: "Open Database Licence (ODbL). The founding prompt, section 5, requires the ODbL share-alike question to be resolved against this repository's licence before a derived pack is committed. It is not resolved." |
| The repository has never been published | `git remote -v` prints nothing. `https://github.com/auraofintelligence/second-island` returns HTTP 404. Board note 001 holds the push pending the owner's approval of the name. |
| No screenshot has been published either | `.gitignore` line 1 is `shots/`. |

**That last pair matters more than anything else in this document.** Almost every obligation in the
ODbL is triggered by the word "Publicly". Nothing here has been Publicly Used or Publicly Conveyed.
So there is no breach to remedy, no clock running, and the decision can be made cheaply and once,
before the push, rather than expensively afterwards.

## 3. The documents this reading is built on

Every one was fetched and read in full on 19 August 2026. Where a document is a guideline rather
than the licence, its own status line is quoted, because an endorsed guideline and a proposal are
not the same kind of evidence.

| document | where | status, in its own words |
| --- | --- | --- |
| Open Database License (ODbL) v1.0, the legal text | https://opendatacommons.org/licenses/odbl/1-0/ | The instrument itself. |
| OpenStreetMap copyright page | https://www.openstreetmap.org/copyright | "OpenStreetMap is open data, licensed under the Open Data Commons Open Database License (ODbL) by the OpenStreetMap Foundation (OSMF)." |
| OSMF Attribution Guideline | https://osmfoundation.org/wiki/Licence/Attribution_Guidelines | "Adopted by the OpenStreetMap Foundation board on 2021-06-25." |
| OSMF Substantial Guideline | https://osmfoundation.org/wiki/Licence/Community_Guidelines/Substantial_-_Guideline | "Status: Endorsed by the OSMF board 2014-06-06" |
| OSMF Produced Work Guideline | https://osmfoundation.org/wiki/Licence/Community_Guidelines/Produced_Work_-_Guideline | "Status: Endorsed by the OSMF board 2014-06-06" |
| OSMF Geocoding Guideline | https://osmfoundation.org/wiki/Licence/Community_Guidelines/Geocoding_-_Guideline | "Status: Endorsed by the OSMF board 2017-08-24" |
| OSMF Collective Database Guideline | https://osmfoundation.org/wiki/Licence/Community_Guidelines/Collective_Database_Guideline_Guideline | "Status: Endorsed by the OSMF board 2016-06-17" |
| OSMF Trivial Transformations Guideline | https://osmfoundation.org/wiki/Licence/Community_Guidelines/Trivial_Transformations_-_Guideline | "This is at the proposal stage in our process - it may change after discussion by the OpenStreetMap community". **Not endorsed. Weighted accordingly below.** |
| Nominatim Usage Policy | https://operations.osmfoundation.org/policies/nominatim/ | An acceptable use policy for one server, not a licence. |
| Buildings, Queensland series | https://www.data.qld.gov.au/dataset/buildings-queensland-series | "Creative Commons Attribution 4.0", data last updated 27 April 2026. |
| Queensland Government copyright statement | https://www.qld.gov.au/legal/copyright | "Unless otherwise noted, all copyright material available on or through this website is licensed under a Creative Commons Attribution 4.0 International licence (CC BY 4.0)." |
| Microsoft Australia building footprints | https://github.com/microsoft/AustraliaBuildingFootprints | "This data is licensed by Microsoft under the Open Data Commons Open Database License (ODbL)." |
| `LICENCE.md` | this repository | The Strange But True Public Source Licence. |

On the OSMF guidelines generally, the OSMF's own index page says what weight they carry: "On legal
advice, what a Licensor says carries weight with users of our data and, potentially, to a judge. A
court would make a final decision on the issue, however we hope these guidelines are helpful to
avoid disputes arising in the first place." They are the Licensor's stated position, not a ruling.

### A note on quotation and the style gate

The ODbL spells its own name and its central defined term with the American spelling. This
repository's `tools/gate/style.mjs` blocks that spelling in prose when a determiner sits directly in
front of it, which is exactly the shape a verbatim quotation of the ODbL takes. So where a quoted
sentence would have tripped the gate, the quote is broken around the phrase and resumed, and no word
inside a quotation mark has been altered anywhere in this file. It is a seam worth closing properly,
and it is board note 016 rather than a fix here, because `tools/gate/style.mjs` is not this task's to
edit. Board note 013 carries the decision this file asks the owner for.

## 4. What the ODbL actually says

### 4.1 It licenses the database, not the facts in it, and not your code

Preamble: "Databases can contain a wide variety of types of content (images, audiovisual material,
and sounds all in the same database, for example), and so the ODbL only governs the rights over the
Database, and not the contents of the Database individually."

Section 2.3 a says it "does not apply to computer programs used in the making or operation of the
Database".

Section 2.2 b: "Database Rights only extend to the Extraction and Re-utilisation of the whole or a
Substantial part of the Contents."

**Consequence for this repository:** connector code, the kernel, the renderer, the gate and every
line under `src/` and `tools/` stay under `LICENCE.md` whatever happens to a data pack. There is no
mechanism in the ODbL by which carrying OSM data makes this a share-alike codebase. This is the
single most common misreading of the licence and it is worth stating first.

### 4.2 The four terms the question turns on

Section 1.0 defines **Derivative Database** as "a database based upon the Database, and includes any
translation, adaptation, arrangement, modification, or any other alteration of the Database or of a
Substantial part of the Contents. This includes, but is not limited to, Extracting or Re-utilising
the whole or a Substantial part of the Contents in a new Database."

**Collective Database**: "Means this Database in unmodified form as part of a collection of
independent databases in themselves that together are assembled into a collective whole. A work that
constitutes a Collective Database will not be considered a Derivative Database."

**Produced Work**: "a work (such as an image, audiovisual material, text, or sounds) resulting from
using the whole or a Substantial part of the Contents (via a search or other query) from this
Database, a Derivative Database, or this Database as part of a Collective Database."

**Substantial**: "Means substantial in terms of quantity or quality or a combination of both. The
repeated and systematic Extraction or Re-utilisation of insubstantial parts of the Contents may
amount to the Extraction or Re-utilisation of a Substantial part of the Contents."

And **Publicly**: "means to Persons other than You or under Your control by either more than 50%
ownership or by the power to direct their activities (such as contracting with an independent
consultant)."

### 4.3 What share-alike attaches to

Section 4.4 a says any Derivative Database you Publicly Use "must be only under the terms of" the
ODbL, a later version of it "similar in spirit", or "A compatible license."

Section 4.4 b: "For the avoidance of doubt, Extraction or Re-utilisation of the whole or a
Substantial part of the Contents into a new database is a Derivative Database and must comply with
Section 4.4."

Section 4.4 c: "Derivative Databases and Produced Works. A Derivative Database is Publicly Used and
so must comply with Section 4.4. if a Produced Work created from the Derivative Database is Publicly
Used."

### 4.4 What share-alike does not attach to

Section 4.5 b: "Using this Database, a Derivative Database, or this Database as part of a Collective
Database to create a Produced Work does not create a Derivative Database for purposes of Section
4.4".

Section 4.5 a: "You are not required to license Collective Databases under" the ODbL "if You
incorporate this Database or a Derivative Database in the collection, but" it "still applies to this
Database or a Derivative Database as a part of the Collective Database".

Section 4.5 c: "Use of a Derivative Database internally within an organisation is not to the public
and therefore does not fall under the requirements of Section 4.4."

Section 6.2 says the licence "does not affect any rights of lawful users to Extract and Re-utilise
insubstantial parts of the Contents, evaluated quantitatively or qualitatively, for any purposes
whatsoever, including creating a Derivative Database".

**Those four clauses together are the whole architecture of the answer.** Share-alike attaches to a
substantial derived *database*. It does not attach to the rendered output, it does not attach to
non-OSM layers sitting beside it, it does not attach to private work, and it does not attach to an
insubstantial extract at all.

### 4.5 Produced Works: what they do require

Section 4.3: "Creating and Using a Produced Work does not require the notice in Section 4.2.
However, if you Publicly Use a Produced Work, You must include a notice associated with the Produced
Work reasonably calculated to make any Person that uses, views, accesses, interacts with, or is
otherwise exposed to the Produced Work aware that Content was obtained from the Database, Derivative
Database, or the Database as part of a Collective Database, and that it is available under this
License."

It then gives its own example, which is the safest text there is because the licence wrote it:
"Contains information from DATABASE NAME, which is made available here under the Open Database
License (ODbL)."

### 4.6 The obligation people forget

Section 4.6: "If You Publicly Use a Derivative Database or a Produced Work from a Derivative
Database, You must also offer to recipients of the Derivative Database or Produced Work a copy in a
machine readable form of: a. The entire Derivative Database; or b. A file containing all of the
alterations made to the Database or the method of making the alterations to the Database (such as an
algorithm), including any additional Contents, that make up all the differences between the Database
and the Derivative Database." It adds that this must be "free of charge if distributed over the
internet."

The Produced Work Guideline says the same thing in fewer words: "However, if you publish a produced
work, the underlying database has to be published as well (or alternations to the original database
as is the case of derived databases), according to section 4.6 of ODbL." ("alternations" is the
guideline's own typo, quoted as written.)

**This is the clause that decides between the options in section 7.** Publishing the twin publicly,
rendering real footprints, obliges an offer of the derived database whether or not that database is
in the repository. Keeping the pack out of git does not remove the obligation. It only makes it
harder to satisfy.

### 4.7 How share-alike interacts with a licence that reserves commercial rights

Two clauses collide here, and they collide in a specific and narrow way.

Section 3.1: "the Licensor grants to You a worldwide, royalty-free, non-exclusive, terminable (but
only under Section 9) license to Use the Database for the duration of any applicable copyright and
Database Rights. These rights explicitly include commercial use, and do not exclude any field of
endeavour."

Section 4.7 a says the licence "does not allow You to impose (except subject to Section 4.7 b.) any
terms or any technological measures on the Database, a Derivative Database, or the whole or a
Substantial part of the Contents that alter or restrict the terms of" it, "or any rights granted
under it, or have the effect or intent of restricting the ability of any person to exercise those
rights."

Against that, `LICENCE.md` section 2: "You may not use this repo, its code, ideas, text, designs,
workflows, data structures, assets, names or close derivatives for commercial, corporate,
institutional, government, startup, agency, client or employer purposes without written permission
from Luke Nathan Hayes", and among the specifics, "use it for commercial AI training, datasets,
embeddings, knowledge bases, agents, model products or evaluation systems".

**The collision is real but it is local.** If an OSM derived pack sat in this repository with nothing
said, a reader would apply `LICENCE.md` section 2 to it, and `LICENCE.md` section 2 restricts uses
that the ODbL grants. Section 9.1 gives that teeth: "Any breach by You of the terms and conditions
of" the ODbL "automatically terminates" it "with immediate effect and without notice to You."

`LICENCE.md` already has the beginning of the fix in section 5: "This licence only covers original
material created by Luke Nathan Hayes / Strange But True / Aura of Intelligence", and "Third-party
libraries, fonts, APIs, platforms, services or embedded material keep their own licences." OSM data
is not original material created by him, so on a careful reading it was never inside `LICENCE.md`'s
scope. But section 5 names libraries, fonts, APIs, platforms and services. It does not name data,
and it does not name a path, so a reader of the repository cannot tell which files are which. That
is what needs fixing, and it is a paragraph, not a rewrite.

## 5. The five questions this repository actually faces

### a. May a derived pack of OSM building footprints be committed under this LICENCE.md?

**Yes, under four conditions, and none of them is expensive.**

First, understand what the pack is. A pack of every building outline on the island is a Derivative
Database and it is Substantial. The Substantial Guideline sets the boundary explicitly: not
substantial is "Less than 100 Features", or "The features relating to an area of up to 1,000
inhabitants", and it summarises itself as "village map OK, town map not OK." The founding prompt
describes an island "of two thousand real people". The real extract fetched in this wave, per the
`osm-overpass` entry in `data/_sources.json`, holds "601 buildings and 924 road ways inside the
island polygon": six times the feature safe harbour on buildings alone, fifteen times it on the two
together, on an island twice the inhabitant threshold, gathered by one systematic query. There is no
argument available here that this is an insubstantial extract, and pretending otherwise would be
exactly the kind of convenient reasoning this repository exists to refuse.

So the pack must be under the ODbL. The four conditions:

1. **It lives in its own named directory** and that directory is licensed under the ODbL, not under
   `LICENCE.md`. Suggested path `data/osm/`.
2. **`LICENCE.md` says so explicitly**, naming the path. This is what discharges section 4.7 a. A
   proposed paragraph is written out in section 9 below.
3. **The directory carries the notices** required by section 4.2 b, which permits "a copy of this
   License ... or its Uniform Resource Identifier (URI) with the Database or Derivative Database,
   including both in the Database or Derivative Database and in any relevant documentation".
4. **Non-OSM data does not get mixed into OSM records.** The Collective Database Guideline keeps the
   rest of `data/` outside share-alike: "An OSM dataset and a non-OSM dataset combined in a single
   database will be considered independent (and thus form a Collective Database rather than a
   Derivative Database) so long as the data used for a particular data type is either all OSM or all
   non-OSM within the same regional cut." Read with ODbL 4.5 a, that keeps tide, solar, GTFS, census
   and everything else this build ever ingests out of the ODbL's reach.

That fourth condition is an architectural constraint on stage 2 and stage 3, not just a filing rule,
and it deserves to be in `docs/CONTRACT.md` when someone amends it: **if a property is attached to
OSM features, that property comes entirely from one source across the island, never half from OSM
and half from somewhere else.** The guideline allows a non-OSM database to add "a property of a
primary feature" by reference so long as it "uses either all OSM data or no OSM data for that
property of that primary feature within the same regional cut". Attaching an ABS-derived occupancy
figure to an OSM building outline is fine on that reading. Filling gaps in OSM building outlines
with Queensland outlines, inside the same island, is the case the guideline warns about.

**What it costs the owner:** he cannot reserve commercial rights over the contents of `data/osm/`.
ODbL 3.1 grants commercial use to everyone and cannot be narrowed. He never held those rights: the
data is not his. But it does mean one directory in his repository that anyone may use commercially,
including for the AI training that `LICENCE.md` section 2 forbids elsewhere. That is the real price,
it is small, and he should be told it in plain words rather than discover it.

### b. Does the single Dunwich coordinate already committed create an obligation?

**On the published guidance, no share-alike obligation, and no attribution obligation attached to
the record. Keep it, and credit OpenStreetMap anyway.**

The coordinate came from a Nominatim query, which the Geocoding Guideline addresses directly:
"Individual Geocoding Results are insubstantial database extracts: Individual Geocoding Results that
are based on a Direct Hit contain an insubstantial amount of raw OSM data". Its conditions are met
here: no modified OSM database was involved, and one coordinate is not "a new database that contains
the whole or a substantial part of the original OSM database". On those facts the guideline says
"the share-alike obligations of the ODbL are not triggered (per Section 4.4.b of the ODbL)."

On attribution it is equally direct: "A geocoded database need not maintain attribution attached to
the database, provided it is not a Derivative Database." The Attribution Guideline repeats it: "A
group of geocoding results need not maintain attribution attached to the results, as long as it does
not form a Derivative Database". The attribution duty in that guideline falls on "Geocoders that use
OpenStreetMap data" and "Applications that incorporate such a geocoder". This twin does neither: the
query was run once, by a person, in the first build, on 6 August 2026, and the answer was written
down. Nothing here calls a geocoder.

The independent route to the same answer is the Substantial Guideline's floor of "Less than 100
Features", and ODbL 6.2, which preserves the right to extract "insubstantial parts of the Contents
... for any purposes whatsoever".

**Two cautions, and both are live in this build.**

The first is the Substantial Guideline's own qualifier, that the safe harbour holds "provided that
the extraction is one-off and not repeated over time for the same or a similar project", and "we
regard repeated small extractions as one big extraction!" One coordinate is one coordinate. Twenty
coordinates gathered one at a time across a wave is a place-name gazetteer assembled by drip, and it
is the same extraction. Board note 007's closing line already says this and it is right: do not
quietly widen the one coordinate into a second and a third.

The second is that the Nominatim endpoint has an acceptable use policy separate from the licence,
and it forbids exactly the shortcut a future agent will be tempted by: "Systematic queries This
includes reverse queries in a grid, searching for complete lists of postcodes, towns etc. and
downloading all POIs in an area. If you need complete sets of data, get it from the OSM planet or an
extract." **The footprints lane must be built on a planet extract, not on Nominatim.** That is a
connector design constraint and it belongs in the ingest row when someone writes it.

**Recommended change, for whoever owns those files:** the note in `data/tide.json`'s `port` record
currently reads that "the share-alike question named in the founding prompt is still open", and
`data/_sources.json` says "It is not resolved." Once the owner decides, those two strings become
wrong. They should be updated to say the coordinate is carried as an insubstantial geocoding result
under the Geocoding Guideline, with this file as the locator. I have not made that edit: it is
outside this task's paths.

### c. Does the running twin, rendering those footprints, count as a Produced Work?

**Yes, and the OSMF has an endorsed test that says so in one sentence.**

Produced Work Guideline: "If the published result of your project is intended for the extraction of
the original data, then it is a database and not a Produced Work. Otherwise it is a Produced Work."
A simulated island that draws buildings, moves residents and shows a departure board is not intended
for the extraction of building outlines. It is a Produced Work. The Attribution Guideline confirms
that this is a recognised category by giving it a heading of its own: "Computer games and
simulations".

Three consequences, and the third is the one that matters:

1. **The twin itself does not have to be ODbL.** ODbL 4.5 b: creating a Produced Work "does not
   create a Derivative Database for purposes of Section 4.4". The twin, its code and its design stay
   under `LICENCE.md`.
2. **The twin must carry a notice.** ODbL 4.3, quoted in section 4.5 above. Text in section 9.
3. **But the pack behind it does not escape.** ODbL 4.4 c: "A Derivative Database is Publicly Used
   and so must comply with Section 4.4. if a Produced Work created from the Derivative Database is
   Publicly Used." Publishing the twin publishes the pack, in the sense that matters. Section 4.6
   then requires the offer of a machine readable copy. **This is why board note 007's option 2, keep
   the derived pack out of the repository, does not avoid the question.** It avoids committing a
   file. It does not avoid the obligation, and it costs the build reproducibility and the offline
   first goal at the same time.

On screenshots specifically, the Attribution Guideline sets a floor: "static images of fewer than
100 features do not require attribution. In addition, static images of areas less than 10,000 m2 do
not require attribution." A calibration shot of a sky gradient is under both floors. A published
render of a township is over both. `shots/` is gitignored today, so nothing has been conveyed, but
the moment a shot goes into a report or a course page it needs the line.

### d. What attribution text, and where?

Written out ready to paste, in section 9.

### e. Is there an option that avoids the question entirely?

**Partly. There is a real Queensland alternative under CC BY 4.0, and it is materially worse for
this build's actual purpose. It should be added as a second lane, not used as a replacement.**

The Queensland Government publishes "Buildings - Queensland series" under "Creative Commons
Attribution 4.0", custodian Natural Resources and Mines, Manufacturing and Regional and Rural
Development, data last updated 27 April 2026. It has three spatial resources, and their own
descriptions are the reason this is not a straight swap:

- **Building areas - Queensland**: "This topographic dataset displays a collection of building
  outlines greater than 625 m2 across the State of Queensland."
- **Building points - Queensland**: "This topographic dataset displays a collection of building
  centroids of areas less than 625 m2 across the State of Queensland."
- **Generated building outlines - Queensland**: "Building outlines has primarily been created on
  behalf of Queensland Reconstruction Authority (QRA) for the purpose of performing rapid damage
  assessments for natural disaster events. Emphasis has been placed on identifying presence or
  absence of building structures rather than high accuracy of outline geometry. Generated buildings
  outlines are generated by project area and is not State-wide."

And the department's own answer to a member of the public who asked for exactly this, on the
Queensland open data portal: "There is no complete dataset of building footprints available."

**What would be lost by swapping OSM out for it:**

- **Most houses become dots.** A 625 m2 footprint is a large commercial shed. Ordinary dwellings in
  Dunwich, Amity Point and Point Lookout are well under it, so in the topographic series they are
  centroids, not outlines. A twin whose buildings are points cannot render a street.
- **The generated outlines are not promised for this island** and their publisher says geometry
  accuracy was not the goal. Whether any QRA project area covers Minjerribah is unknown and I did
  not check it: that is a download and a coverage test, which is a connector task, and this task
  writes no connector. **It is an open question, not a fact in either direction.**
- **Only footprints are replaced.** OSM is also the roads, the paths, the jetties, the shops, the
  opening hours and the names. The founding prompt's stage 4 slice needs "shops open on published
  hours" and a person walked "from their house to the jetty". None of that is in a topographic
  building layer. Dropping OSM to dodge the licence question would trade one clean answer for four
  new empty lanes.
- **The measured count goes with it.** This wave now has a real number for OSM, 601 buildings inside
  the island polygon, from a query somebody ran and recorded. There is no equivalent number for the
  Queensland series, because nobody has downloaded it, and the honest state of that lane is
  therefore unknown rather than promising.

**Two other candidates, checked and rejected:**

- **Microsoft's Australia building footprints**, 11,334,866 polygons, would not avoid the question at
  all: "This data is licensed by Microsoft under the Open Data Commons Open Database License
  (ODbL)." Same licence, same analysis, plus its own recall caveats.
- **Geoscape National Buildings** is commercial. Its product page publishes no licence and no price,
  only "Talk to us", and the Queensland department pointed the same enquirer at it with "This
  footprint data set not owned by the Queensland Government."

**The honest conclusion on (e):** the question can be dodged, at the price of the thing the founding
prompt says this repository exists to get right. The Queensland series is worth ingesting anyway,
because CC BY 4.0 composes with everything and a second independent source is how the first build's
places pack defined high confidence in the first place, "two independent sources agree within about
50 m". It is a cross-check, not a substitute. Note the Collective Database constraint from section
5a if it is ever used to fill gaps in the OSM layer rather than sit beside it.

## 6. What I could not settle, and why

- **Whether the ODbL is enforceable in Australia as a Database Right.** The ODbL's own definition
  ties the right to "the Chapter III ("sui generis") rights in the Database Directive", which is an
  EU instrument, "as well as any similar rights available in the relevant jurisdiction under Section
  10.4". Australia has no equivalent sui generis database right. The ODbL is also "an agreement in
  contract" (section 2.1 c), which is the limb that would matter here. **I am not qualified to say
  how an Australian court would read that, I did not find an Australian authority on it, and I am
  not going to guess.** It cuts both ways and it is a reason to comply rather than to speculate.
- **Whether a set of building outlines carries copyright separate from the database.** ODbL 2.4 says
  the licence "does not cover any rights (other than Database Rights or in contract) in individual
  Contents". Not answered here.
- **Coverage of Minjerribah in the Queensland generated outlines.** Not downloaded, not tested.
- **The 1,059 figure.** Inherited from the founding prompt, unverified in this repository.

## 7. The options, and what each costs

| option | what it means | cost | verdict |
| --- | --- | --- | --- |
| **A. ODbL directory inside this repository** | `data/osm/` licensed ODbL, named in `LICENCE.md`, notices in place, attribution in the page | One directory the owner cannot reserve commercial rights over. Rights he never held. | **Recommended.** |
| **B. A separate repository for OSM derived packs** | `second-island-data`, wholly ODbL, consumed as a sibling checkout | Same licence outcome as A, plus a second repository to keep in step, plus a broken offline first story for anyone who clones one and not the other | Works. More machinery for no extra safety. |
| **C. Fetch at ingest, commit nothing** | board note 007's option 2 | Does not avoid the obligation: ODbL 4.4 c and 4.6 still bite once the twin is public. Costs reproducibility, costs the offline first design, and leaves the swarm unable to run the island from a clone | **Rejected on the licence text**, not on taste. |
| **D. Queensland CC BY 4.0 instead of OSM** | topographic buildings series | Houses become centroids, generated outlines are not state-wide and are not accuracy-first, and the roads, POIs, names and hours lanes go empty | **Rejected as a substitute. Adopt as a second lane.** |
| **E. Get a lawyer** | a written opinion | Money and time, for certainty rather than a defensible reading | The owner's call. Nothing above needs it to proceed, and nothing above is a substitute for it if he wants certainty. |

## 8. What only the owner can answer

Each of these changes the recommendation if the answer is not what I have assumed. I have assumed
the first answer in each pair.

1. **Do you intend to sell or license the derived data packs themselves,** as distinct from the twin,
   the code, the design, the courses and the brand? I have assumed no: that the product is the
   system, not the footprint file. If yes, OSM footprints cannot be part of that product and option
   D and its losses come back into play.
2. **Are you willing to have one directory in this repository that anyone may use commercially,**
   including for the AI training and dataset uses `LICENCE.md` section 2 forbids everywhere else? I
   have assumed yes, because the alternative is losing the data. It is worth saying out loud that
   this is the only thing option A actually costs you.
3. **Is this repository going public?** Board note 001 holds the push. Nothing in this document
   binds anything until it does, and while it stays private ODbL 4.5 c applies: "Use of a Derivative
   Database internally within an organisation is not to the public".
4. **Do you want a lawyer's opinion, or a documented defensible reading?** This file is the second
   one. It is not the first one and it does not pretend to be.

## 9. Ready to use text

### 9.1 A paragraph for `LICENCE.md`

To be added as a third item under "Two things this licence does not cover", which then needs its
heading changed to "Three things this licence does not cover". Written to sit in the existing voice.

> **OpenStreetMap derived data.** Anything under `data/osm/` is derived from OpenStreetMap and is
> licensed under the Open Database License (ODbL) version 1.0, not under this licence. That is the
> whole of the difference: the ODbL allows commercial use and this licence does not, so the two are
> kept in separate directories rather than argued about. Nothing in this licence restricts what you
> may do with the contents of `data/osm/`, and nothing in the ODbL gives you any right to the rest of
> this repository. The code that fetches, filters and loads that data is original work and stays
> under this licence, as the ODbL section 2.3 a expressly allows.

### 9.2 A notice for `data/osm/README.md`

This is the ODbL's own example notice from section 4.3 a, with the placeholder filled in. Pair it
with a link to the licence text, which satisfies section 4.2 b, and with a pointer to the source
extract and the extraction method, which satisfies section 4.6 b.

> Contains information from [OpenStreetMap](https://www.openstreetmap.org/), which is made available
> here under the [Open Database License (ODbL)](https://opendatacommons.org/licenses/odbl/1-0/).
>
> Every file in this directory is derived from an OpenStreetMap extract and is licensed under the
> ODbL version 1.0. The rest of this repository is not: see `LICENCE.md`.
>
> Source: one Overpass query bounded by OpenStreetMap relation 5911994, run DATE, response sha256
> HASH. Registered as `osm-overpass` in `data/_sources.json`.
> How it was derived: `node tools/ingest/osm.mjs --derive`.
> The unaltered response and the derivation script together are the offer required by ODbL section
> 4.6 b.

Those three lines are not decoration. The connector already records the query, the byte count and
the sha256 of the response, so discharging 4.6 b costs nothing beyond copying facts that exist.

The Attribution Guideline's "Databases" section is what that satisfies: "You must include attribution
to OpenStreetMap and either the text of the ODbL or a link to it as part of the database, derivative
database, or database as part of a collective database", in "a location (such as a relevant
directory) where users would be likely to look for it, such as a readme file, or within the data or
metadata".

### 9.3 A line for the running page

The Attribution Guideline requires attribution "to OpenStreetMap" and that it "make it clear that
the data is available under the Open Database License. This may be done by making the text
'OpenStreetMap' a link to openstreetmap.org/copyright". It permits qualifying the credit: "if you
have rendered OSM data to your own design, you may wish to use 'Map data from OpenStreetMap.'" It
also says "The historical forms of attribution '© OpenStreetMap contributors' or '© OpenStreetMap'
are acceptable."

Persistent, in a corner of the view, or in the credits or About panel per the "Computer games and
simulations" section:

> Building outlines and roads from [OpenStreetMap](https://www.openstreetmap.org/copyright)

Fuller, for an About panel or a splash screen:

> Building outlines, roads and points of interest are from OpenStreetMap, available under the Open
> Database License (ODbL). openstreetmap.org/copyright

Placement rules from the same guideline, worth writing into the UI contract rather than remembering:
attribution "must be presented to anyone who uses, views, accesses, interacts with, or is otherwise
exposed to the map or produced work", "should not require individuals to interact with the map or
produced work to see the attribution", and where it is collapsed, "the user must still be able to
find the licence information if they look for it".

### 9.4 The source record in `data/_sources.json`

The bulk lane already has its own id, `osm-overpass`, distinct from `osm-nominatim` because it is a
different acquisition under a different policy, and it was written by the connector agent in this
wave rather than by me. Its licence field currently reads that the question "is unresolved and
blocking". **When the owner decides, that string is the one to change**, to something like:

> Open Database Licence (ODbL) version 1.0, OpenStreetMap contributors,
> https://www.openstreetmap.org/copyright. Derived packs from this source live under `data/osm/` and
> are licensed ODbL, not under `LICENCE.md`. Settled by the owner on DATE, on the reading in
> `docs/LICENCE-QUESTIONS.md`.

The same edit is owed to `osm-nominatim`, whose licence field says "It is not resolved", and to the
note on the `port` record in `data/tide.json`. Three strings, one decision.

## 10. The recommendation, in one paragraph

Take option A. Put OSM derived packs in `data/osm/`, licensed ODbL, named as an exception in
`LICENCE.md`, with the ODbL's own notice in a README beside the data and an OpenStreetMap credit in
the running page. Concretely, on the state of the tree tonight, that is one paragraph in
`LICENCE.md`, one README, one credit line in the page, and a change of output directory in
`tools/ingest/osm.mjs --derive` from `ingest-inbox/derived/` to `data/osm/`. That last one is the
line its own author wrote a warning above: "this tool must not be changed to write into data/
without that decision landing first". This file is the decision paper for exactly that. It costs the owner nothing he holds: the ODbL grants commercial use over that
directory and he never owned that data. It protects everything he does hold, because the ODbL does
not reach code, does not reach the twin as a Produced Work, and does not reach non-OSM layers kept
independent per the Collective Database Guideline. Do it before the push, while nothing has been
Publicly Used and there is no clock running. Ingest the Queensland CC BY 4.0 buildings series as a
second, independent lane for cross-checking, not as a substitute. And keep the single Dunwich
coordinate exactly where it is: on the OSMF's endorsed geocoding guidance it is an insubstantial
extract that triggers nothing, and the honest thing to do about it is credit OpenStreetMap anyway.
