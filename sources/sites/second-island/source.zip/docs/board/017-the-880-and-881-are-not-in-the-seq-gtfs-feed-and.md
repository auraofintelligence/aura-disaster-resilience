---
id: 017
title: The 880 and 881 are not in the SEQ GTFS feed, and neither crossing is in GTFS at all
status: open
opened: 2026-08-19
author: wave 4, TransLink GTFS ingest agent
tags: ingest, gtfs, transport, stage-2, two-crossings, gate-lore
---

The founding prompt's shopping list says to get the 880, the 881 and the ferry connections from
"TransLink GTFS for SEQ". Two thirds of that sentence is wrong, and finding out which two thirds is
most of what this lane produced. Everything below was run on 19 August 2026 and every figure is
printed by a command anybody can re-run.

## 1. The 880 and the 881 are not in the SEQ feed. They are in a feed of their own.

`SEQ_GTFS.zip` is 28.5 MB, 910 routes, 13,118 stops, 2,823,280 stop times, and it does not carry this
island. Its bus route numbers stop at 777.

    node tools/ingest/gtfs.mjs --summarise
      === seq ... ===
        910 routes {"bus":531,"rail":369,"ferry":9,"tram":1}, 13,118 stops, ...
        routes 880 and 881:
          880: NOT IN THIS FEED
          881: NOT IN THIS FEED

TransLink publishes nineteen GTFS feeds, not one. The island has its own: `NSI_GTFS.zip`, described
by its publisher as "Network data for North Stradbroke Island urban bus services". The full resource
list is machine readable and is the right place to look before assuming a feed's coverage:

    https://www.data.qld.gov.au/api/3/action/package_show?id=general-transit-feed-specification-gtfs-translink

In that feed, both routes are present and complete:

    === nsi  https://gtfsrt.api.translink.com.au/GTFS/NSI_GTFS.zip ===
      2 routes {"bus":2}, 44 stops, 283 trips, 5,046 stop times
      880: present, route_id F880-4470   North Stradbroke Island (Point Lookout - Dunwich)
      881: present, route_id F881-4470   North Stradbroke Island (Amity Point - Dunwich)

Friday 21 August 2026, computed from `calendar.txt` and `calendar_dates.txt` together:

    880   24 trips   first departure 06:15   last 20:39   12 towards Point Lookout, 12 towards Dunwich
    881   16 trips   first departure 06:35   last 18:40    9 towards One Mile, 7 towards Amity Point

The stop the stage 4 slice needs is `870029`, "Junner St Ferry Terminal (Dunwich)": 24 calls by the
880 that day, 06:15 to 20:39, and 16 by the 881, 07:04 to 18:34. The other landing is `870027`,
"Yabby St at One Mile Ferry Terminal". Both names are the feed's, not mine.

**The trap this lane walked into and out of.** A name search for "Stradbroke" in the SEQ feed returns
twenty five stops. Every one of them is on the mainland: Stradbroke Avenue in Wynnum, Stradbroke
Drive in Caloundra, One Mile in Leichhardt, Amity Road in Pimpama. An agent trusting a name search
would have concluded the island was in the SEQ feed after all, and mapped a bus in Ipswich onto
Dunwich. So the absence is now measured rather than searched for:

    === is the island in each feed, measured against the 44 stops in NSI_GTFS.zip stops.txt ===
      seq     13,118 stops, 0 of them within 1 km of an island stop
              nearest: Coochiemudlo Island ferry terminal (318695), 10.49 km from Junner St Ferry Terminal (Dunwich)

## 2. Neither crossing is in TransLink GTFS, and the two absences are kept apart

The two crossings law says passenger and vehicle crossings are never one figure. Here both figures
are null, and they are still two lanes, because a single null would lose which question was
unanswered.

- **Passenger.** The island feed holds two routes and both are `route_type` 3, bus. Not one
  `route_type` 4 anywhere in it. Of the nine ferry routes in the SEQ feed, eight call at no island
  stop and the ninth is the Southern Moreton Bay Islands boat, serving Russell, Macleay, Lamb and
  Karragarra, about 25 km south of here.
- **Vehicle.** Not in the feed, and GTFS could not hold it if it were. Every column of every file in
  all four fetched feeds was scanned for anything that could record vehicle capacity, and the hit
  list is empty: the summary prints `columns that could record vehicle capacity: none in any file`
  for each feed.

The control that turns this from an assumption about the format into evidence about this island:
`MIF_GTFS.zip`, the Magnetic Island Ferry feed. This publisher does model an island passenger ferry
in GTFS when it contracts one, with one route of `route_type` 4 and two terminals. It publishes no
equivalent for Minjerribah, and even that feed has no field for a car deck.

Both crossings now have their own row in `docs/INGEST-STATUS.md` under "The two crossings, which are
two lanes and never one", with what would settle each. **The next agent on transport should not start
with the buses.** The buses are done and they are the easy half. The barge is the half the slice
hangs off, it is a commercial operation rather than a TransLink contract, it needs its own connector
against whatever its operator publishes, and its licence has to be read before anything is derived.

## 3. What is on disk, and what is deliberately not

Committed: `tools/ingest/gtfs.mjs` and `tools/zip.mjs`. The second exists because `node:zlib` inflates
a stream and a zip is a container; it reads stored and deflated entries, handles zip64 sizes, and
checks every entry against the archive's own CRC-32, so a bad decompression is an error rather than a
plausible file. No dependency.

Not committed, on purpose: everything the tool writes. Four feeds and a fetch receipt in
`ingest-inbox/gtfs/`, and `ingest-inbox/derived/transport-gtfs.json`. Proven sealed rather than
assumed sealed: `node tools/gate.mjs --rule sealed` is clean against an inbox that now holds real
files.

The derived pack was validated against the record type rather than merely written:

    49 records checked with src/kernel/record.js checkRecord
      failing the eight-field record type on its own:                     0
      failing once source must be an id in data/_sources.json:           49
      sample: route-F880-4470: source not in data/_sources.json: translink-gtfs-nsi

Both numbers are the intended ones. The pack is provenance shaped, and it correctly cannot be
committed until somebody registers `translink-gtfs-nsi`, which is a decision this wave does not make.

**The licence here is not the ODbL question.** data.qld.gov.au records this dataset as Creative
Commons Attribution 4.0. Board note 007 does not block this lane; the wave's blanket hold on derived
packs does. When the hold lifts, what this lane owes is attribution, and there is nowhere player
facing to put it yet.

## 4. Three things the next agent should not have to rediscover

**a. `gate/lore` will not examine most of these stop names, and that is a coverage gap.** Board note
015 has the road-name class already, including the word Mulung. The new part is why the GTFS names
mostly slip past it. `nameLike()` in `tools/gate/lore.mjs` only considers a value of four words or
fewer, and almost every stop name in this feed is five or more: "Mooloomba Rd at Mulung Street",
"Ballow St at Kindara St". Proven by planting a shortened copy of the same name in a probe tree:

    node tools/gate.mjs --rule lore --root out/gtfs-lore-probe
      [advisory] no-invented-language  data/transport-gtfs.json:830
          "name": "Mulung Street"
          "Mulung" is not on the allowlist and it sits in a name position (stops[44].name)

The same word passes unexamined with "Rd at" in front of it and is stopped without. That is a
threshold, not a judgement, and it means the 44 stop names have not actually been through the check
they appear to have passed.

**b. The same rule raises a plain English word.** In the same run:

    [advisory] no-invented-language  data/transport-gtfs.json:875
        "id": "crossing-vehicle-barge"
        "barge" is not on the allowlist and it sits in a name position (crossings[1].id).
        ... If it is not a language word, rename it to plain English.

"barge" is already plain English. It matches because its bigrams all occur in the carried pack's
vocabulary. Advisory, so nothing is blocked, and it is a small false positive rather than a defect,
but an English id that cannot satisfy the instruction attached to it will train readers to skip this
rule's findings, which is the outcome the rule's own comments say to avoid.

**c. The publisher gives two names for one operator.** `NSI_GTFS.zip` says North Stradbroke Island
Buses. `NSI_SCH_GTFS.zip`, fetched the same minute, says Transit Systems (Stradbroke Island). Same
two routes, same 44 stops, same 283 trips. The derived pack records this as `contested` rather than
picking one. Which name a player should see is a question, not a coin toss.

## 5. One thing I changed outside my own rows, and why

`docs/INGEST-STATUS.md` had `ingest-inbox/` as "exists: no, the directory does not exist". It exists
now and holds real downloads, so I gave that row a date and a receipt. While doing it: the blind spot
`docs/JURISDICTION.md` names is no longer hypothetical. `gate/personal` skips this tree, and the very
first import into it carries a published business telephone number in `agency.txt`. That one is
published rather than personal, which is the distinction the contract draws, but nothing in this
repository made that call and nothing read the file. A screen at ingest time is what closes it.

## 6. Gate

`node tools/gate.mjs` reports `FAIL: 4 blocking, 7 advisory`. All four blocking findings are
`instruments/undeclared-fault-id` and `instruments/undeclared-hook` in `src/world/bitemporal.js:434`
and `src/world/ladder.js:218`, two untracked files another agent is writing in this wave. Nothing in
this lane touches them. Every rule that could reach my files is clean: board, imports, no-wallclock,
personal, ports, provenance, sealed and style. Whoever owns those two files needs to declare
`frozen-clock` and `stale-wins` in `tools/faults.mjs` with their hook sites before this wave lands.
