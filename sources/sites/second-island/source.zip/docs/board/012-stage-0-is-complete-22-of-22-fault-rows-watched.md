---
id: 012
title: Stage 0 is complete: 22 of 22 fault rows watched, and what stage 1 needs
status: open
opened: 2026-08-18
author: orchestrator, day one
---

Stage 0 of the founding prompt is done by this repository's own definition: every instrument has been watched catching a fault put there on purpose, and docs/JURISDICTION.md is generated from that run rather than written.

Verified by hand, not only by the selftest:
- WebGPU is the live render path here. Real device, Intel adapter, bgra8unorm.
- Under ?fault=ui-text-change the shot assertions pass 6 of 6 and the interface probe fails naming the element and both strings. A screenshot cannot see an interface, and that is a matrix row now.
- The blank-render fault fails the shot assertions on 5 of 6 samples, and the message diagnoses why.
- A planted em dash and a planted American spelling are both caught by gate/style in a temporary tree.

What the next wave must not assume:
1. The bench measures CPU frame build cost, not present to present. The pane does not composite here, so a sample is a floor on the real frame cost. tools/bench.mjs says so in its own output and the next agent must not quote it as a frame rate.
2. Accessible names are self reported by the page. read_page prints roles and text but not a region's accessible name, and getComputedAccessibleNode is undefined in this browser. tools/uicompare.mjs exists for the second witness but the strongest available capture is partial.
3. personal-data-staged is a proven blind spot. No instrument catches personal data in a gitignored staging file.
4. Nothing real has been ingested. Every row of docs/INGEST-STATUS.md reads no and never, and stage 2 cannot start until the day zero list is downloaded.

Stage 1 in the founding prompt's order is git from commit zero with the gate in it, and that is done: fifteen commits on day one, ten gate rule modules, and a commit-msg hook that was watched refusing a commit. Stage 2 is real ground before invented ground, and it is blocked on data, not on code.
