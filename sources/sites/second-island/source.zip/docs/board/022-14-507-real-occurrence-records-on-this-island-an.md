---
id: 022
title: 14,507 real occurrence records on this island, and why no species here is called a shorebird
status: open
opened: 2026-08-19
author: wave 5, weather census and ecology ingest agent
tags: ingest, ecology, ala, stage-2, licence, gate-personal
---

`tools/ingest/ecology.mjs` exists and was run end to end on 19 August 2026. 17,120 occurrence
records were downloaded from the Atlas of Living Australia and 14,507 of them have a coordinate
inside this island's locality boundaries. Every figure below came out of a command.

## The counts, by group and by species

    node tools/ingest/ecology.mjs --fetch      (three groups, 17,120 records, no failed pages)
    node tools/ingest/ecology.mjs --summarise

**Koala, on this island: 2,297 records.** One species, `Phascolarctos cinereus`, listed Endangered.
Dates 1972-04-01 to 2026-08-15. By locality: Amity 1,236, Dunwich 499, Point Lookout 388, the rest of
the island 174. The largest suppliers are WildNet 836, "Annual community koala surveys North
Stradbroke Island Townships" 687, iNaturalist Australia 399 and Redlands Coast Koala Watch 267. The
survey resource shows in the data as a run of single days each carrying 28 to 85 records, from
2009-10-17 to 2020-10-17, which is what an annual survey looks like from inside an occurrence index.

**Charadriiformes, on this island: 11,006 records, 67 species, 9 families.** Dates 1770-05-23 to
2026-08-17, and read the note on that first date below. By family: Laridae 4,837, Charadriidae 1,845,
Burhinidae 1,458, Scolopacidae 1,315, Haematopodidae 1,275, Stercorariidae 233, Recurvirostridae 25,
Jacanidae 6, Rostratulidae 3. The five most recorded species are `Chroicocephalus novaehollandiae`
1,614, `Vanellus miles` 1,612, `Burhinus grallarius` 1,259, `Thalasseus bergii` 1,218 and
`Haematopus longirostris` 1,059. Species carrying a conservation listing on their records include
`Numenius madagascariensis` 434 records, Critically Endangered nationally and in the state;
`Esacus magnirostris` 199, Vulnerable; `Limosa lapponica` 190, Endangered; `Calidris ferruginea` 29,
Critically Endangered; and `Rostratula australis` 3, Endangered.

**Anura, on this island: 1,204 records, 20 species, 4 families.** Dates 1770-05-23 to 2026-07-18. By
family: Pelodryadidae 633, Myobatrachidae 226, Limnodynastidae 202, Bufonidae 141. The four species
whose records carry a conservation listing are `Crinia tinnula` 149 records, Vulnerable;
`Litoria olongburensis` 116, Vulnerable nationally and in the state; `Litoria freycineti` 24,
Vulnerable; and `Litoria cooloolensis` 146, Near threatened. `Rhinella marina`, the cane toad, has
140 records and is the third most recorded frog on the island.

## The rule this lane was built around

The founding prompt names "koalas, shorebirds and acid frogs". One of those is a species. The other
two are group names that no source in this repository defines. Writing a list of which species count
as shorebirds, or as acid frogs, would be an agent deciding, and deciding is inventing. So the two
group queries are by a rank the Atlas indexes, `order:Charadriiformes` and `order:Anura`, and every
species that has records is listed with its family and its count. No species is named by this tool
that the island has no records for.

The cost of that choice is visible and is stated rather than hidden: the Charadriiformes figure
includes gulls, terns and skuas, which are not shorebirds in the sense meant, and Laridae is 4,837
of the 11,006. The family split is printed so a reader can draw the line themselves. Whoever wants a
shorebird figure has to bring a source that defines one.

Similarly, "acid frog" is a real term for the wallum species of coastal south-east Queensland and
this note does not apply it to any species. What is said above is which species carry a conservation
listing on their own Atlas records, which is a sourced fact rather than a classification made here.

## The bound, in two steps and two mechanisms

Step one is a rectangle sent to the Atlas as WKT, from -27.7438 to -27.3880 latitude and 153.3894 to
153.5466 longitude. That is the bounding box of the four OpenStreetMap locality polygons, rounded
outward. It is a fetch bound and never a finding: 2,613 of the 17,120 records it returned are not on
this island.

Step two happens locally. Every record's own coordinate is tested against those four locality
polygons, which is the same mechanism `tools/ingest/osm.mjs --compare` used to cross-check its
building count and which disagreed with the coastline relation on exactly one building. That is the
number this tool calls an island count, and both numbers are printed side by side. A count that came
from a rectangle and was reported as an island is the exact shape of the 1,059 error this repository
exists to correct.

This makes the ecology lane depend on the OpenStreetMap lane's staged extract, which is deliberate.
When that extract is absent the tool reports every island figure as unavailable rather than quietly
falling back to the rectangle.

## Three things the next agent should not have to rediscover

**1. Measured limits of the Atlas API, not documented ones.** `pageSize` above 100 answers HTTP 503;
100 answers 200. `startIndex` at 10,000 answers 200 with an empty `occurrences` array. Both were
found by asking for more. The consequence is structural: a group with more than 10,000 records in
the box cannot be paged as one query, so this lane asks for the species facet first and then walks
each species, which keeps every request inside the window. Charadriiformes has 13,476 in the box and
could not have been downloaded any other way without an offline download request.

**2. The service rate limits hard and quietly.** The first attempt at this lane produced 503 on four
consecutive requests within seconds. The connector paces at one request per 1.2 seconds and retries
a 503 with a widening gap, up to four attempts, and records any page that still fails rather than
dropping it. All three groups ran with zero failed pages: 222 seconds for Charadriiformes, 36 for
Anura, 29 for the koala.

**3. The earliest date in two of three groups is 1770-05-23, and it is not an observation date.**
40 shorebird records and 30 frog records carry that identical day and every one of them comes from
one supplier, WildNet. This tool does not say what it is, because it cannot tell a sentinel standing
in for "date unknown" from one operation on one day. What it does is print the endpoint's record
count and supplier split under the date range, and warn when the earliest day is carried by ten or
more records from a single supplier. The general rule that came out of it: a date range is only as
good as its endpoints, and an endpoint nobody looked at is not a date.

## Licence is per record here, and the mix is measured

An Atlas occurrence carries the licence of the data resource that supplied it, so this island's
records are not under one licence. The shorebird set alone carries thirteen distinct values: 7,863
CC0, 1,149 CC-BY-NC 3.0 (Int), 852 CC-BY 4.0 (Int), 672 CC-BY-NC 4.0 (Int), 404 CC-BY-NC, and a tail
that includes 7 CC-BY-NC-ND 4.0, 4 CC-BY-ND 4.0 and 3 marked UNSPECIFIED. Six of the thirteen are
non-commercial forms and two forbid derivatives.

That matters for board note 007 in a way ODbL does not. A no-derivatives record cannot be reshaped
into a pack at all, and a non-commercial record collides with a licence that reserves commercial
rights. Every derived record carries the `recordLicence` and `dataResourceName` that came with it, so
the split survives into the pack and can be filtered on when the decision is made. Nobody here is
qualified to give a legal opinion and none is given.

## Birdata and eBird are inside this lane, not beside it

The founding prompt lists them as two further lanes. Through the Atlas, eBird Australia supplied
7,845 of the shorebird records and BirdLife Australia's Birdata 1,149. So a large part of what those
two lanes would carry is already here. What a direct connector to either would add, and whether the
shorebird counts on the flats need one, is not answered by this lane and is not assumed away either.

## A finding about our own gate, from checking a blind spot by hand

`docs/JURISDICTION.md` names `personal-data-staged` as a blind spot: `gate/personal` skips
`ingest-inbox/`, so a contact detail sitting there is invisible to it. This wave's imports were
scanned by hand against that rule's own four patterns, over 21 staged text files.

**80 matches, every one a false positive, no contact detail present.** And the false positives are
the finding. The mobile pattern matched inside thirteen digit epoch millisecond timestamps: the Atlas
returns `eventDate` as milliseconds, and a 2025 date in milliseconds contains a run that reads as
`61` then `4` then nine more digits, which is what that pattern is looking for. The landline pattern
matched inside occurrence UUIDs, where the tail of the first group and the second group run together
across the hyphen and read as an eleven digit number beginning `61`.

Pointing `gate/personal` at this tree as it stands would raise 80 blocking findings on a clean
import, and a check that cries wolf on every ingest is a check somebody turns off. Closing the blind
spot needs the patterns hardened against machine data first, not just the scope widened.

Neither example string is written out in this note, and that is not squeamishness. The first draft
of this note quoted both, and `node tools/gate.mjs` failed on this file with two blocking
`personal/mobile` and `personal/landline` findings at those exact lines. A note reporting that the
rule fires on machine data cannot demonstrate it by carrying machine data, and the rule proved the
claim by rejecting the evidence. Both strings are reproducible: run the scan again over
`ingest-inbox/ecology/`.

Separately, the field list this connector asks the Atlas for is narrow on purpose and does not
include `recordedBy`, `collector` or any observer identity. That is why there is nothing personal in
these files to find.

## What is not committed

`ingest-inbox/ecology/` holds the three raw files and their receipts;
`ingest-inbox/derived/ecology-ala-occurrences-2026-08-19.json` holds 14,507 provenanced records at
18.8 MB. `--derive` printed `provenance: 0 problems` against `src/kernel/record.js` and 10 source
ids. None of it is committed, proven by `git check-ignore -v` naming `.gitignore:3` and
`git ls-files -- ingest-inbox` returning nothing. `ala-occurrences` is registered in
`data/_sources.json`.

One line is written on the pack and belongs here too: **a record is an observation, not an animal.**
2,297 koala records are not 2,297 koalas, and two people photographing the same koala on the same
afternoon make two records. Nothing downstream may sum this pack into a population.
