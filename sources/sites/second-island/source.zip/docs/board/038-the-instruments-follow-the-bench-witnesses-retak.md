---
id: 038
title: The instruments follow the bench: witnesses retaken from lab.html and the front page, 33 of 33 green
status: open
opened: 2026-08-20
author: wave 9, instrument repointing agent
tags: instruments, faults, jurisdiction, uiprobe, uicompare, front-page, lab, stage-0
---

Board note 037 landed the page split and named three things it could not touch. All three are
closed, the whole browser witness set was retaken from the pages as they are now, and the suite
was run over the result. Everything below came out of a command or a running browser on
20 August 2026. docs/STATE-OF-PLAY.md carries the full receipts in its dated section.

## What was repointed

- tools/panels/calibration.json says its panels live on lab.html now, in `page`, `_what` and
  `_why`. The panel declarations did not change: the bench moved unrenamed, and a fresh lab
  capture passes against them, which a fresh capture could not do between wave 7 and the split.
- tools/panels/front.json is NEW: a hand-written baseline for the front page's eight panels,
  from src/ui/crossings-view.js and index.html. It closes the renamed-panel blind spot on the
  page a visitor actually sees. Rows whose citation is honestly dynamic, the record of whichever
  sailing or bus call answers at that minute, omit prov and pin register; every static citation
  is pinned. Watched passing at two different island minutes.
- tools/uicompare.mjs capture instructions now open http://localhost:4281/lab.html for the bench
  and name the front page as a second capture target.
- tools/selftest.mjs writes the lab URL into the docs/JURISDICTION.md footer, and the regenerated
  file carries it.
- tools/gate/crossings.mjs SCAN_FILES is now index.html plus lab.html.
- tools/faults.mjs: the capture provenance comment records the 20 August retake from lab.html,
  and the hitch row's why carries the fresh numbers. hookSites needed no change, because the
  hooks live in files that moved pages without moving, and gate/instruments agrees.

## The witnesses, retaken rather than carried

Every recorded capture the selftest points at was retaken from lab.html: seven shots, four
interface probes and both bench series, plus fresh calibration and front probes and a fresh
read_page tree for uicompare. Each was verified with its own instrument before the selftest ran:
the blank-render shot fails naming the background colour, the stale pair is byte for byte one
frame, the ui-text-change shot passes while its probe fails on matches-baseline, and the hitch
series fails at frame 58 with ten frames over budget exactly sixty apart, which is what the
registry requires the output to name.

## The suite

    node tools/gate.mjs                        PASS: 0 blocking, 15 advisory, all pre-existing
    node tools/check-island.mjs                all 18 checks passed
    node tools/check-crossings.mjs             all 40 checks passed
    node tools/determinism.mjs --ticks 2000    PASS, 21 checkpoints, 4 hashes identical
    node tools/selftest.mjs                    PASS: 33 of 33 rows green, 0 not proven, 0 missed
                                               or caught for the wrong reason
    node tools/uicompare.mjs --assert calibration
                                               PASS, five panel names agreeing

The acknowledgement-present rule is green on index.html. The selftest's own guard confirmed the
run changed nothing but docs/JURISDICTION.md. Nothing was committed and nothing was pushed.

## What this note does not claim

The gate caught this note's own author once: a first draft of the STATE-OF-PLAY section wrote a
movement figure without a landing point and crossings/unattributed blocked it, which is the rule
working on the person who had just edited it. The browser rows still rest on captures that are
not in git, so a fresh clone honestly reports them not proven until somebody opens the lab page
and posts captures again. The three non-owning caught cells in the fresh matrix are the same
structural ones as the 19 August run.
