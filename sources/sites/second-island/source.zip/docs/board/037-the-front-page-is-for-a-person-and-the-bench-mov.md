---
id: 037
title: The front page is for a person and the bench moved to lab.html, both watched running
status: open
opened: 2026-08-20
author: wave 9, front page split agent
tags: ui, front-page, lab, stage-0, crossings, uiprobe, voice
---

The owner looked at the live front page and asked what all the nonsense on it was. He was right.
The page was built as the stage 0 instrument bench and pushed live unchanged, so the workshop
became the shopfront, and his standing rule that process narration never goes on a front page was
violated by the very page that carries his name. This wave split the two, and everything below came
out of a command or a running browser on 20 August 2026.

## What landed

- `index.html` is now the page for a person: the name, one plain sentence, the acknowledgement of
  Country at load, the everyday crossings view, and one quiet line at the bottom pointing at the
  lab. No checkerboard, no tick counter, no sun azimuth, no step buttons, no paragraphs about
  determinism or probes. The provenance chips stay on every value, because they are the owner's own
  honesty pattern and the interface probe requires them.
- `lab.html` is the bench, moved not deleted: the calibration scene, the island clock, the sun and
  tide panels, the step controls and all the instrument narration, unchanged in substance. The
  acknowledgement appears on this page too, with the page's self-check line under it.
- `src/main.js` serves both pages. Which page it is on is decided by the markup: a page with a
  `#stage` canvas gets the renderer and the bench panels, a page with an `#everyday` mount gets the
  crossings view. One world, one pack list, on both, so no number on either page is pasted.
- `window.ISLAND` carries shot, probe, bench and step on the lab. The front page carries ready,
  info, provenance, step and probe; shot and bench answer with a refusal there, because the front
  page draws no calibration scene and a picture of nothing would not be evidence. Probe default
  names differ per page, `calibration` on the lab and `front` on the front page, so one page's
  probe cannot quietly overwrite the other's.
- Four wording edits in `src/ui/crossings-view.js`, all voice: the note that pointed a reader at
  "the island clock panel further down" (which is no longer on the same page), the sentence that
  pointed at the tide panel and the source ladder, "not measured anywhere in this build", and the
  per-frame consistency line, which now prints nothing when it holds and speaks only on a
  disagreement. The check itself still runs every frame.

## Receipts

- `node tools/gate.mjs`: PASS, 0 blocking, 15 advisory, all pre-existing. `acknowledgement-present`
  raised nothing, so the wording is verbatim in `index.html` where the rule looks.
- `node tools/uiprobe.mjs --assert front`: PASS, 9 rules, 0 failures, 8 panels and 28 values, every
  citation resolving against disk. The front page is auditable by the same instrument as the bench.
- `node tools/uiprobe.mjs --assert calibration --expect tools/panels/calibration.json`: PASS, 10
  rules including matches-baseline, on a FRESH capture from lab.html. Since wave 7 a fresh capture
  could not pass the baseline, because the everyday panels shared the page with the bench and the
  baseline rightly refused them. The split closes that.
- `node tools/shot.mjs --assert calibration`: PASS, 6 of 6 samples, on a shot posted from lab.html,
  webgpu path.
- `lab.html?fault=ui-unlabelled`, probed: uiprobe FAILS with panel-name on `[data-panel="sun"]`.
  The fault hooks moved with the panels they break and are still caught.
- `node tools/check-crossings.mjs`: all 40 checks pass.
- Watched in the browser at island time 06:00: on foot "yes, boats are running"; with a car "not
  yet. The first one off the island today goes at 07:00"; where this minute sits "inside the
  morning gap. You can leave, your car cannot". At 18:00: with a car "no. The last one off the
  island today went at 17:30"; the last-sailing row reads "gone at 17:30. Your car is on the island
  until 07:00 in the morning".
- The static constraint holds: neither page's boot calls a POST sink, and shot and probe still fail
  quietly where the sinks do not exist.

## What this wave could not touch, for the lanes that own it

- `tools/panels/calibration.json` says `"page": "index.html"` in its `_what` line. The check reads
  probes, not pages, so nothing fails, but the sentence is now wrong: the panels it declares live
  at lab.html.
- `tools/uicompare.mjs` and `docs/JURISDICTION.md` tell a capture session to open the root page.
  Bench captures now happen at `/lab.html`, and the front page is a second probe target named
  `front` with no declared baseline yet. A baseline for the front page's eight panels would close
  the renamed-panel blind spot there too.
- `tools/gate/crossings.mjs` SCAN_FILES names `index.html` only. lab.html carries no crossing
  figures today, but it is outside that rule's scan set and should be added to it.
