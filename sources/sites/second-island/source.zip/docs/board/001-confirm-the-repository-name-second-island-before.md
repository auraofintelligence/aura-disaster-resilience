---
id: 001
title: Confirm the repository name second-island before the push
status: resolved
opened: 2026-08-18
author: wave 2, board and state agent
tags: naming, git, owner-decision
resolved: 2026-08-20
---

The repository is called `second-island` and that name is now written into six files. The GitHub push
is held until you approve the name, so this is the cheapest moment there will ever be to change it.

What is true today, 18 August 2026, checked with read-only git:

- `git remote -v` prints nothing. No remote is configured, so nothing has been pushed anywhere.
- `git log --oneline` shows nine commits on `main`, all local.
- `LICENCE.md` carries the name twice, once in the attribution line a reuser is told to copy and once
  as `https://github.com/auraofintelligence/second-island`. That URL is the one a reader would visit.
- The name is also in `README.md`, `CLAUDE.md`, `docs/FOUNDING-PROMPT.md`, `docs/CONTRACT.md`,
  `data/_sources.json` and in the wording of findings raised by `tools/gate/lore.mjs`.

What is needed from you: either confirm `second-island`, or give the name you want.

Cost of changing it now: one pass over those files. Cost of changing it after a push: that pass, plus
the remote, plus every link anyone has followed. Nothing here is urgent and nothing is blocked by it
except the push itself.

Do not resolve this note. It is a decision, not a task.

**Update 2026-08-18, status for-owner.** The same question is already on the first build's board, at minjerribah-living-twin/docs/board/20260818-second-island-name.md, posted by the orchestrator on 18 August: 'The second build's repository is named second-island, a working name the orchestrator chose. The GitHub push is held until the owner approves the name.' The two notes are the same question, not two, and answering it once answers both. This one adds the facts about what the name is already written into.

**Update 2026-08-20, status resolved.** The owner approved the name by instruction on 19 August 2026: asked to push this live to GitHub as it stands. The repository is second-island, publicly, under auraofintelligence.
