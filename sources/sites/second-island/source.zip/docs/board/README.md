---
id: 000
title: The law of this board
status: resolved
opened: 2026-08-18
author: board builder
tags: law, meta
---

# The board

**Read this directory before you start. Post to it before you finish. A finding that lives only in a
transcript is treated as never made.**

That last sentence is the whole law. Everything below is how to obey it.

## Why a directory of Markdown files

Within a wave, agents talk through the orchestrator. That channel is real but it is not durable: a
full report can die with a session limit while it is in transit, and the finding dies with it. The
repository does not die. So a finding goes in a file, in the repository, where the next agent finds
it whether or not the agent who found it got to finish its sentence.

This is not a nice-to-have. It is the correction for a specific set of costs the first build paid,
recorded in the founding prompt's failure catalogue under the row that reads "Findings died in
transcripts":

- **A precisely diagnosed bug shipped anyway, and its owner hit it himself.** The diagnosis was
  correct, it was made, and it existed nowhere a person or a later agent would look.
- **Three counted fabrications were never chased.** They were counted. Counting them was the end of
  it.
- **The scouts' work was never read.** The scout role exists so that a build judged only by critics
  does not converge on inoffensive. Its reports were killed by session limits before delivery, and
  the owner read defect reports for twelve days while the commit log filled with wins nobody showed
  him.

None of those three is a failure of intelligence. All three are a failure of storage.

## The shape of a note

One note per file, `docs/board/NNN-slug.md`, front matter and then a body:

    ---
    id: 004
    title: The tide has no published constituent table
    status: open
    opened: 2026-08-18
    author: board builder
    ---

    What was found, where, and what the next agent should do about it.

Five required fields: `id`, `title`, `status`, `opened`, `author`. Two optional ones: `tags`, and
`resolved` on a resolved note. One field per line, because the front matter is read by a tool as
well as by a person.

`status` is one of:

| status | what it means |
| --- | --- |
| `open` | a live finding. Anyone may take it. |
| `taken` | somebody is on it right now. Say who in the body. |
| `resolved` | done, with the receipt in the body: the command, the file, the output. |
| `for-owner` | a decision only Luke can make. Never resolve one of these yourself. |

Ids are zero padded and are **not reused**. The next id is one past the highest number this board has
ever issued, and "ever issued" is asked of two witnesses: the note files here now, and every note
file git has ever seen added under `docs/board/`. A reply that lands on a different finding than the
one it answers is worse than no reply, so a deleted note's number is not handed to something else.

One gap is left open and is stated rather than hidden: a note created and deleted before it was ever
committed is invisible to both witnesses, and its number can be reissued. That gap is wide today,
because nothing on this board has been committed yet. The way to close it is not to delete notes.
Resolve them.

## Use the tool, not your editor

    node tools/board.mjs read
    node tools/board.mjs read --status open
    node tools/board.mjs post --title "..." --status open --author "..." --body "..."
    node tools/board.mjs set 004 --status resolved --note "what changed and where"
    node tools/board.mjs set 004 --status open --title "a heading the finding has outgrown"

`set --title` changes the title in the front matter and deliberately leaves the file name alone. The
file name is the note's permanent handle, and other notes, documents and reports already point at it.
A note whose title has moved on from its file name is normal; a note whose path changed under a
reference is a broken link.

The tool allocates the id, writes the front matter in the shape the gate validates, and appends a
dated line to the body when a status changes. Hand-writing a note is not forbidden and it is a good
way to produce a file that `node tools/gate.mjs --rule board` rejects.

`tools/gate/board.mjs` is the check, and it is the definition of the shape. Where this document and
that file disagree, that file is right and this one is a bug.

## What belongs here, and what does not

Post a note when you find something the next agent would want and cannot see from the code: a defect
you are not fixing, a constant you could not source, a question for the owner, an assumption you had
to make, a rule that is written down but not executed anywhere.

Do not post your wave summary here. The board is for findings that outlive a wave, not for a log of
what you did. `docs/STATE-OF-PLAY.md` carries the standing picture, `docs/INGEST-STATUS.md` carries
the pipeline, and the cheerleader's ledger carries what verifiably works.

## Two rules with teeth

1. **Never resolve a `for-owner` note.** It is waiting on a person, and a status is not a substitute
   for an answer.
2. **A note resolved without a receipt is not resolved.** "Works" without a receipt is forbidden by
   `docs/CONTRACT.md` section 6, and "exists, untested" is an honest answer that this board is happy
   to carry. Name the command and paste what it printed.

## About this file

This is the board's law, not a finding. It carries front matter because `tools/gate/board.mjs`
validates every `.md` file in this directory as a note, and a law that failed its own check would be
the first thing somebody switched off. Its id is `000`, outside the range the tool ever issues, and
its status is `resolved` because there is nothing here for anyone to action. `tools/board.mjs`
leaves it out when it lists the board.
