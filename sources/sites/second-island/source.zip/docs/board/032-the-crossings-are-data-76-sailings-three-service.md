---
id: 032
title: The crossings are data: three services, two operators, and the five hours a person has that a car does not
status: open
opened: 2026-08-19
author: wave 6, crossings agent
tags: crossings, transport, stage-2, two-crossings-law, gate-crossings, owner-ground-truth
---

The owner's ground truth from board notes 029 and 030 is now a pack, a system and a gate rule.
Everything below came out of a command run on 19 August 2026.

## What landed

    data/crossings.json          20 sealink-vehicle-barge, 28 sealink-passenger-ferry and 28
                                 gold-cats-flyer-passenger-ferry sailings, every one provenanced,
                                 plus 2 operators, 3 landing points, 6 pack notes and 6 open
                                 questions
    data/_sources.json           4 new entries: sealink-timetables,
                                 gold-cats-flyer-departure-sign, owner-statement-2026-08-19,
                                 first-build-transport-pack
    src/systems/crossings.js     system "crossings", order 30, three events
    tools/gate/crossings.mjs     three rules, watched catching six planted faults
    tools/check-crossings.mjs    40 checks, all passing
    out/crossings-pack.mjs       the generator, kept runnable the way out/capacity.mjs is

Receipts:

    node tools/check-crossings.mjs      all 40 checks passed
    node tools/gate.mjs                 PASS: 0 blocking, 10 advisory
    node tools/check-island.mjs         all 18 checks passed, unchanged
    node tools/determinism.mjs          PASS: 2880 ticks, 21 checkpoints, 4 hashes identical
    node tools/bitemporal.mjs --check   PASS: 35 checks

## The figures reproduced, and the one that needed a day named

The orchestrator's arithmetic was recomputed from the pack rather than trusted, and it holds:

  off-island vehicle window 07:00 to 17:30, 630 minutes, on every day of the week
  off-island passenger window 05:15 to 20:45, 930 minutes, on every day of the week
  the gap is 300 minutes, 105 in the morning and 195 in the evening

One figure needed a day attached to it. Junner Street ferry terminal carrying 48 vessel movements
and One Mile jetty carrying 28 are both true on a Friday, which is what this world's epoch is. They
are not the every-day figures, because two SeaLink passenger sailings run Friday, Saturday and
Sunday only and four Gold Cats Flyer sailings do not run on a Saturday, a Sunday or a public
holiday. Measured: Junner Street 48 on a Friday and 46 on a Wednesday; One Mile 28 on a Friday and
24 on a Saturday. Friday is the only day both original figures hold at once, which is fortunate
rather than planned, and quoting either without the day is the shape of mistake board note 027 was
written about.

Two more things fell out of the day rules that nobody had noticed. The 05:15 first departure off the
island is SeaLink's every day, and on a Saturday it is SeaLink's alone, because the Flyer's 5.15am
is a red time. The 20:45 last departure off the island is the Gold Cats Flyer's every day, and from
Monday to Thursday it is the Flyer's alone, because SeaLink's 8:45pm is Friday to Sunday. So the
fifteen and a half hour passenger day is held open at one end by one operator and at the other end
by the other, and losing either operator shortens the day at one end. That is a consolidation fact
that came out of arithmetic rather than out of an opinion, and it belongs to whoever argues note
029's question in either direction.

## The law is in the type now, not in a paragraph

`carries` is an enum with exactly two values and there is no third meaning both. A vehicle sailing
also carries people and that is fine; what the schema refuses is a field where a vehicle number and
a passenger number could be added. `tools/gate/crossings.mjs` has three rules and each says what it
cannot see:

    crossings/summed        a vehicle figure added to a passenger figure, or one name holding both
                            classes and something countable
    crossings/carries-enum  a carries value that is not one of the two, or a sailing with none
    crossings/unattributed  a crossing figure written without saying which of the three services it
                            belongs to

The third rule is the fussy one and it is deliberately two tests rather than one. A sailing count
belongs to one service, so the line has to name one, and "passenger" on its own does not count
because both passenger services run fourteen departures each way. A movement count is a landing
point figure by nature, so naming Junner Street or One Mile is enough for that one. The service
vocabulary is read out of the pack rather than listed in the rule, so a fourth service is covered
the day it lands.

Watched failing, not assumed. A copy of the tree was taken, faults planted, and the rule run against
both copies: the healthy copy printed `crossings clean`, and the faulted copy printed six blocking
findings naming the file, the line and the offending text for every one. The five shapes planted,
quoted exactly, and the first three carry the rule's own specimen marker because a rule that refuses
a shape cannot be written about without writing the shape down:

    vehicleCount + passengerCount                    gate/crossings: specimen
    vehicleAndPassengerCount                         gate/crossings: specimen
    carries: "both"                                  gate/crossings: specimen
    a sailing record with no carries field at all
    a sentence in a document giving a sailing figure and a movement figure with neither a service
    nor a landing point named

That marker is new and it is the answer to board note 016, which found gate/style blocking a
verbatim quotation of the licence this repository is most obliged to quote accurately, and worked
around it. It is per line, never per file, has to be written on the line it excuses, and every use
is reported as an advisory naming the line and its text. An exemption nobody can see is how a check
stops checking.

The rule also caught two things in my own writing before anybody else read them: a comment in
tools/check-crossings.mjs that gave a movement figure without naming the terminal, and a line in a
board-note draft that did the same.

## Where my brief and this board disagreed, and what I did

The task I was given was written between note 029 and note 030 landing. It said to quarantine the
vessel capacities as unusable, read by no code, the way data/tide.json quarantines the first build's
tide constituents. Note 030, posted after it, records the owner sourcing those same figures to
SeaLink's ferry information and the Redland City disaster plan, and says they come out of
quarantine.

I followed the board, because the board is the current state and the brief was not. The capacities
are recorded as sourced records at medium confidence, and the confidence says exactly why: neither
cited page has been opened by this repository, so the evidence here is the owner's citation of them.
The half of the brief I kept is the important half: no code reads a capacity, this system computes
no capacity figure, and the two numbers sit in two named fields, carsMax and deckPassengersMax, with
no total anywhere. Note 030's own capacity arithmetic is not carried into the pack. If that reading
is wrong, the fix is one field in data/crossings.json under capacity, and nothing else moves.

One thing was quarantined properly: the first build's third vessel on the vehicle service, held
under capacity.unverified_carry, marked unusable, read by nothing. The owner named two vessels and
the first build's pack names three. That bears directly on the open question about extra services,
which is why it is held where it can be asked about rather than dropped or used.

## What could not be encoded without guessing, which is the honest half of this note

  A crossing time per sailing. SeaLink publishes 45 to 50 minutes for the vehicle crossing, which
  is a range, so tripMinutes is null on every sailing and the range sits on the service record.
  Picking one end of it would have been inventing a number that is not published. Neither passenger
  timetable publishes a crossing time at all.

  The red marking on the Gold Cats Flyer sign. Four sailings carry confidence medium and a note
  saying the medium is about the red reading and only that: the departure times are as well
  evidenced as every other row. A photograph of the sign raises all four to high in one look.

  Which mainland berth. Both timetables head the mainland column Cleveland, and that is all any
  record says. The berth field on the Cleveland landing point is null. Note 030 names Toondah
  Harbour as the interchange the sailings connect to and leaves the Flyer's berth open, so it stays
  open here.

  Public holidays. Four Gold Cats Flyer sailings state that they stop on one and no source says what
  a public holiday does to the other seventy two. There is no Queensland public holiday calendar in
  this repository, so the system reports the input unfed and flags any day whose answer would change
  if it were one. It does not guess a calendar, and the state says the flag is a floor on the
  uncertainty rather than a bound on it, because a sailing whose source is silent is recorded
  unknown rather than running.

  School holidays and seasonal variation. Nothing. No source says anything, so the day rules carry
  weekdays and nothing seasonal.

  How many extra vehicle services run. SeaLink calls its vehicle timetable a base timetable and says
  additional services are visible only on its booking page. So a vehicle sailing count from this
  pack is a floor and never a total, and the pack says so in its own record rather than in a comment.

  Why two of fourteen mainland departures differ. Recorded as an open question with both
  possibilities named and neither preferred, per the instruction. The owner has answered the larger
  question in note 030, that both operators are pinned to the Cleveland train, and the residual is
  the two afternoon rows: SeaLink 5:00pm against Flyer 4:45pm, and SeaLink 6:15pm against Flyer
  6:00pm. All fourteen island-to-mainland departures match.

  Whether a vehicle crossing is booked or turn-up-and-queue. Open. No queue is modelled anywhere: a
  timetable is not a queue.

## Three things the next agent should not have to rediscover

FIRST. A system registered on a bare `new World()` gets a different world hash, and it is not the
system's fault. Board note 031 hands the tide system the world's field resolver at registration
time, so a bare World gives tide `answerFrom: "no resolver was supplied"` and a different state
hash. My first determinism check did exactly that and reported a failure that was the test's error
rather than the world's. Register on a world that buildIslandWith built, always.

SECOND. Repeating a service name inside seventy six machine keys cost twenty advisory findings in
gate/lore's stop-and-ask tier, because "barge" is shaped like a word the allowlist guards. The
sailing ids now name operator, class, direction and minute, and the serviceId is the field to join
on. gate/lore's advisories against this pack went from 22 to 1. This is a data point for board note 015 rather than a
complaint: the rule is right to raise a word in a name position, and the cost of a false positive is
that it is paid once per occurrence.

THIRD. There are now two vocabularies for the same distinction. `data/transport-gtfs.json` records
its two crossing lanes with `kind: "passenger"` and `kind: "vehicle"`, and this pack uses `carries`.
gate/crossings only enforces the enum on `carries`, so the other spelling is unguarded. Widening the
rule to `kind` would fire on every unrelated pack that uses that ordinary word, so it was left
alone rather than made broad. Somebody should pick one spelling. Those GTFS records also carry
`sailingsFriday: null` with the reason "not in this publisher's data", which is still true of that
source and is now answerable from another one: 76 sailings run on a Friday, 20 sealink-vehicle-barge,
28 sealink-passenger-ferry and 28 gold-cats-flyer-passenger-ferry. That is a source ladder question,
not a contradiction, and neither record should be edited to match the other.

## Owed, and not done here because the task did not name the path

  1. `src/world/island.js` and STAGE_0_PACKS. The crossings system is not registered in the island
     the instruments build, so headless, determinism and the page do not see it. It is a line in
     registerSystems and a pack name in the list. Not done because another agent was editing that
     file during this task, and the check tool builds its own world so that nothing was blocked on
     it. Until it lands, `node tools/check-crossings.mjs` is the only instrument that runs this
     system.
  2. `tools/faults.mjs`. gate/crossings has no fault row, so it has no column in
     docs/JURISDICTION.md and the selftest does not prove it. It was proved by hand this once, and a
     hand proof is a rumour by the second week. Three faults are ready to be lifted from this note.
  3. `docs/INGEST-STATUS.md`. The two crossing lanes still read `exists: no` and `last exercised:
     never`. Both are now wrong: the pack exists and is committed. The lane is not a connector and
     never will be, because no operator publishes a feed, so the honest row says supplied by the
     owner from the operators' published timetables on 19 August 2026, proven by
     `node tools/check-crossings.mjs`.
  4. `docs/CONTRACT.md` section 6. The two-crossings law reads NOT YET CHECKED with the reason that
     the check lands with transport data in stage 2. It has landed: the rule is
     `tools/gate/crossings.mjs`.

## One measurement, since nothing else in this repository holds it yet

The system costs 0.0108 ms a tick averaged over a sim day, against a declared budget of 0.5 ms, with
one spike of 0.817 ms at tick 59. In the same run the tide system spiked twice in the same way, and
headless is the instrument that separates a collector pause from real work. Crossings is not wired
into headless yet, so that spike is reported unexplained rather than explained away.
