---
id: 014
title: Real ground: 601 building outlines on this island, and the 1,059 in the founding prompt is a bounding box
status: open
opened: 2026-08-19
author: wave 4, OpenStreetMap ingest agent
tags: ingest, osm, stage-2, buildings, roads, licence
---

The founding prompt says, twice, that "about 1,059 real outlines exist for this island, and the first
build invented 1,922 boxes while they sat unused". That sentence is the reason this repository
exists, so it was the one number in it that could not be taken on trust. I opened it.

**The figure is real, reproducible, and it is not a count of this island.**

## What was run, and what it printed

`tools/ingest/osm.mjs` is new. Four modes, three of which touch the network and cache what they get,
so a critic re-reads the same bytes rather than reloading a free public service.

    node tools/ingest/osm.mjs --fetch
      HTTP 200, 1743826 bytes, 12956 ms, 1539 elements
      sha256 0fa3091b842e9c00b4550b8e2005ff5fce857534bcf2df47732032826d2d5944
      staged  ingest-inbox/osm/overpass-island-2026-08-19.json

    node tools/ingest/osm.mjs --summarise
      BUILDINGS  601 total, 20 carrying a name
      ROADS      924 ways, 229 carrying a name, 591.4 km of centreline

    node tools/ingest/osm.mjs --derive
      wrote ingest-inbox/derived/osm-buildings-2026-08-19.json  601 records, 748959 bytes
      wrote ingest-inbox/derived/osm-roads-2026-08-19.json  924 records, 1412900 bytes
      checked 1525 records with src/kernel/record.js against 7 source ids
      provenance: 0 problems

Overpass returned HTTP 504 twice before the first success, both times with "The server is probably
too busy". It is a free service under load. Retry, do not hammer it, and do not refetch what is
already staged.

## The number

| bound | buildings |
| --- | --- |
| the island's own OpenStreetMap polygon, relation 5911994 | **601** |
| the same, cross-checked here against four locality polygons | 602 |
| the first build's bounding box, its exact published query, counted today | 1059 |

The 1,059 reproduces to the digit. `minjerribah-living-twin/docs/BUILDINGS.md` line 44 records it as
counted on 10 August 2026, and its query at lines 59 to 62 of that file is

    (way["building"](-27.76,153.35,-27.37,153.56););

which is a box over Moreton Bay, not this island. That box also contains Russell, Macleay,
Karragarra, Lamb, Perulpa and Coochiemudlo Islands and the northern end of South Stradbroke. Of the
1,059 buildings in it, **457 are not on this island**. They are real buildings. They are somebody
else's.

One cross-check in the first build's own line survives intact and is worth saying: it claims "78 at
Amity Point alone", and the Amity locality holds 78 today. Its per-township figure was right. Its
island total was a box.

**So the true figure is 601, and the sentence in the founding prompt should be read as being about a
region rather than about this island.** The correction does not weaken the prompt's point. It sharpens
it: the first build invented 1,922 boxes while 601 real outlines for this island sat unused, and it
would have been three real outlines for every invented one had it taken them.

## The one building the two bounds disagree about, named

A count that differs by a number nobody can open is not a finding, so `--compare` names it:

    way 503883831  North Stradbroke (Passenger ferry)
      inside the locality polygon only, locality Dunwich, at -27.503482, 153.400851
      tags {"amenity":"ferry_terminal","building":"roof","ferry":"yes","layer":"1",
            "name":"North Stradbroke (Passenger ferry)","operator":"Sealink",
            "public_transport":"station"}

It is the passenger ferry terminal roof, standing over the water on the jetty with `layer=1`, so it
falls outside a coastline polygon and inside the locality that owns the jetty. Both bounds are right
about what they measure.

**This matters more than one building.** The founding prompt's stage 4 vertical slice is a Friday
barge day: foot passengers ride to One Mile, the bus meets the boat. The single structure the
coastline bound drops is the structure that slice is built around. Anything jetty-borne, wharf-borne
or pontoon-borne is in the same position. Whoever builds the transport lane should bound by locality,
not by coastline, and should expect the same for the barge ramp and the Toondah side.

## By township

| township | OpenStreetMap locality | buildings |
| --- | --- | --- |
| Point Lookout | Point Lookout | 325 |
| Dunwich | Dunwich | 92 on the coastline bound, 93 by locality |
| Amity Point | Amity | 78 |
| the rest of the island | North Stradbroke Island | 106 |

The data does distinguish the three townships, by locality polygon, at `admin_level=10`. Note the
naming: OpenStreetMap calls the settlement "Amity Point" on its village node and "Amity" on the
locality polygon. Both names are OpenStreetMap's. The connector writes the mapping out rather than
quietly rewriting either into the other.

## Roads

924 ways, 591.4 km of centreline, 229 named.

    253  path             205.6 km      123  service           20.8 km
    197  track            228.8 km      112  residential       26.0 km
    124  footway           16.0 km       43  secondary         38.4 km
     39  unclassified      51.5 km       22  steps              0.5 km
      8  tertiary           3.5 km        3  secondary_link     0.2 km

Two thirds of the mapped network by length is path and track, which is what a sand island with a
national park in the middle of it should look like. 695 of the 924 carry no name.

## What is missing, and it is a lot

- **No heights at all.** Not one of the 601 carries a `height` tag. 27 carry `building:levels`. Any
  extruded building in this twin is modelled until the LiDAR lane lands, and must be labelled that
  way. OpenStreetMap gives you the footprint, not the massing.
- **Almost no addresses.** 11 buildings carry a house number, 12 a street.
- **Almost no names.** 20 of 601.
- **Age.** 317 of the 601 were last touched in OpenStreetMap in 2012, and 107 in 2025.
- **No points of interest.** The query took buildings, roads, place nodes and admin boundaries. POIs,
  addresses, land use, the jetties themselves and the barge infrastructure were not fetched.

## Nothing is committed, and that is proven rather than asserted

Board note 007 is unresolved, so the derived packs stay out of `data/`. The connector writes only
into `ingest-inbox/`, and the seal was checked by asking git, not by trusting the rule:

    git check-ignore -v ingest-inbox/derived/osm-buildings-2026-08-19.json
      .gitignore:3:ingest-inbox/   ingest-inbox/derived/osm-buildings-2026-08-19.json
    git ls-files -- ingest-inbox
      (nothing)

`data/_sources.json` gained one entry, `osm-overpass`, and that file is committed because it is the
vocabulary rather than the data. Registering the source is not a decision that the licence question
is settled, and its licence field says so.

**Every derived record was put through `src/kernel/record.js`, the same validator `gate/provenance`
uses, against the same source ids: 1,525 records, 0 problems.** The pack is proven to pass the rule it
would be committed under, on the day somebody is allowed to commit it. `validFrom` on each record is
that element's own OpenStreetMap timestamp, and both the record and the pack say in words that this
is when a mapper last asserted the feature and never when the building was built. Contributor names
and user ids from the extract are not carried into the records.

## Two things for whoever comes next

1. **`docs/INGEST-STATUS.md`'s `ingest-inbox/` row is stale and its header is now behind.** The row
   in the second table still reads "The directory does not exist." It exists, it is sealed, and this
   lane put five files in it: three raw responses and two derived packs. The header was updated while
   I was working, by the agent running the TransLink GTFS lane, and it says "First row moved 19 August
   2026" and "holds four downloaded feeds". Two rows have moved now and the inbox holds more than
   four files. I left both alone rather than clobber another agent's sentence mid-wave, since this
   wave's brief gives other rows to other agents. Whoever writes the wave's synthesis should reconcile
   the header, and the receipt for the inbox row is in this note.
2. **The gate is at 15 blocking right now and not one of them is from this task.** They are in
   `src/world/ladder.js` (9), `src/world/bitemporal.js` (4) and `docs/LICENCE-QUESTIONS.md` (2), all
   three being written by other agents in this wave. Proven by copying the tree without those three
   files and gating the copy: `node tools/gate.mjs --root out/gate-without-concurrent-files` printed
   `PASS: 0 blocking, 10 advisory` with every change from this task in it.
