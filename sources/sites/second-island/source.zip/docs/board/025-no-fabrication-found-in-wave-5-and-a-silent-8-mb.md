---
id: 025
title: No fabrication found in wave 5, and a silent 8 MB hole in gate/personal
status: open
opened: 2026-08-19
author: wave 5, critic
tags: critic, ingest, gate-personal, bitemporal, licence, traceability
---

I was asked to falsify one claim: **nothing this wave produced is invented, and every number in it
traces to a source that can be opened.** I could not falsify it. I traced every figure in
`docs/INGEST-STATUS.md`, `docs/STATE-OF-PLAY.md`, board notes 013 to 024 and all six packs under
`ingest-inbox/derived/`, by re-running the connectors and by writing my own scripts against the raw
bytes. **Not one fabrication.** The four findings below are real and none of them is an invented
number.

## What I ran, and what it printed

    node tools/gate.mjs                          PASS: 0 blocking, 7 advisory
    node tools/selftest.mjs                      PASS: 27 of 27 rows green, 0 not proven
    node tools/bitemporal.mjs --check            PASS: 35 checks over 10 fixture records
    node tools/check-island.mjs                  all 18 checks passed
    node tools/determinism.mjs --ticks 5000      PASS: 5000 ticks, 21 checkpoints, 4 hashes identical
    node tools/bench.mjs --assert                PASS: p99 0.25 ms within 16.7 ms, worst 1.055 ms
    node tools/shot.mjs --assert calibration     PASS: 6 of 6 samples within tolerance
    node tools/uiprobe.mjs --assert calibration --expect tools/panels/calibration.json
                                                 PASS: 10 rules, 0 failures, 5 panels, 8 values

## The traceability check, lane by lane

Every `sha256sum` and byte size quoted in `docs/INGEST-STATUS.md` for the staged raws matches the
file on disk. Every `--summarise` figure reproduced. Where I could, I counted it again myself
rather than trusting the connector:

- **OpenStreetMap.** My own count over `overpass-island-2026-08-19.json`: 1539 elements, 601 with a
  building tag, 20 named, 0 with a `height` tag, 27 with `building:levels`, 11 with
  `addr:housenumber`, 317 last edited in 2012, 924 highway ways, 229 named, 9 place nodes.
  Every one matches the row. `--compare` reproduces 601, 1059 and 602 and names way 503883831 as
  the one building between the two bounds.
- **TransLink GTFS.** I opened `NSI_GTFS.zip` with `tools/zip.mjs` and counted Friday 2026-08-21
  myself: service id `NSI 26_27-42958`, `friday trips total: 40`, `stop_time rows on that day: 692`,
  `calls per trip min 14 max 20`, 40 trips at 870029 and 40 at 870027, `shape points in feed: 1865
  distinct shapes: 5`. Board note 023's receipt block reproduces to the digit. SEQ prints
  `880: NOT IN THIS FEED` and `881: NOT IN THIS FEED`, `13,118 stops`, `0 of them within 1 km`,
  nearest Coochiemudlo at 10.49 km.
- **Weather.** 365 days, 0 with no value, hottest 29.3 on 2025-10-27, wettest 137.8 mm on 2026-02-13,
  gust 78.5 km/h on 2026-02-02, grid 9.62 km away. `21 identical to the digit` between era5 and
  era5_land, which is the row's `344 of 365 days differing`, arrived at the other way round.
- **Census.** 277.1095 sq km, 8 SA1s, Dunwich 737, Amity 453, Point Lookout 785, the island SA2 2156.
- **Ecology.** 2314 / 2297, 13476 / 11006, 1330 / 1204. 2297 + 11006 + 1204 = 14507, which is the
  count field in the derived pack. 9 shorebird families, 13 distinct licence values, Laridae 4837,
  CC0 7863, eBird 7845, Birdata 1149, 20 frog species. All of it printed.
- **The 49 GTFS records.** I walked the pack myself with `src/kernel/record.js`:
  `records carrying all eight provenance fields: 49`, `passing checkRecord with no sourceIds set: 49
  of 49`, `refused when sourceIds is the registered set: 49 of 49`, one reason,
  `source not in data/_sources.json: translink-gtfs-nsi`. True in every part. See finding 3 for
  where the receipt for it points.
- **Board note 015's fourteen road names.** I rebuilt the probe tree and ran it:
  `PASS: 0 blocking, 39 advisory`, and 15 distinct `STOP AND ASK` words, of which `Janday` is the
  pre-existing finding inside the carried lore pack and the other fourteen are the road names.

## Nothing derived is committed

    git ls-files -- data           data/_sources.json, data/lore.json, data/tide.json. Three files.
    git ls-files -- ingest-inbox   nothing
    git check-ignore -v -- ingest-inbox/.gate-probe    .gitignore:3
    node tools/gate.mjs --rule sealed                  sealed clean
    node tools/gate.mjs --rule derived                 derived clean

## The bitemporal store held every attack I could think of

I wrote four attacks the shipped suite does not run, hunting for a confident number where the honest
answer is "not known". All of them held:

- **A record superseded twice.** Timeline holds three beliefs with two `recordedUntil` stamps. The
  belief on the 13th reads 12, on the 15th reads 15, on the 17th reads 19. Six sampled belief minutes
  gave zero holes and zero double beliefs. A minute before the first belief returns nothing.
- **Exactly on a boundary, both axes.** `validAt` on `validFrom` is inside, on `validTo` is outside:
  a clean half open interval, and the same on the belief axis. A correction recorded in the same
  minute as the belief it corrects leaves exactly one readable belief and keeps the other in the
  timeline.
- **A scenario cursor past every record.** With every valid interval closed, it answers
  `not known as at 2031-01-01T00:00+10:00`, with the reason in words. Live mode refuses the cursor
  outright before the ladder is asked.
- **A field with no observation.** Not known, dated. Only a simulation in live mode: not known.
  An instrument reading with no staleness window: not known. A stale observation still beats a fresh
  simulation.

## Both new gate/derived faults fail for the reason the registry names

Planted into a throwaway tree with `tools/faults.mjs`'s own `apply()`, control tree clean:

    node tools/gate.mjs --rule derived --root out/critic/control          PASS: 0 blocking
    node tools/gate.mjs --rule derived --root out/critic/derived-faults   FAIL: 10 blocking

All four marks of `derived/committed` fired by name, and `derived/unprovenanced` named the five
missing fields one at a time. Not a crash and not a missing file.

## docs/LICENCE-QUESTIONS.md: every quote I checked is verbatim

I fetched the ODbL and four OSMF guidelines and compared. ODbL 2.2 b, 2.3 a, 3.1, 4.2 b, 4.4 a b c,
4.5 a b c, 4.6, 4.7 a, 6.2, 9.1 and the five section 1.0 definitions all match, including the stray
full stop the licence itself carries in "must comply with Section 4.4. if a Produced Work". The
Substantial Guideline's "Less than 100 Features" and "village map OK, town map not OK" match. The
Collective Database Guideline's regional cut sentence matches. Microsoft's 11,334,866 matches. And
the Produced Work Guideline really does say "alternations", which the document flags as the
guideline's own typo and quotes as written. Both `LICENCE.md` quotes are exact. `git remote -v`
prints nothing, as it says.

---

# The four findings

## 1. serious. gate/personal silently skips any file over 8 MB

`tools/gate/personal.mjs` line 92: `if (statSync(abs).size > 8 * 1024 * 1024) return null;`. The
rule then produces no finding, no advisory and no note that it declined to read the file, and the
gate prints `personal clean`. Two throwaway trees, the same synthetic address in the same field of
the same file, differing only in padding:

    node tools/gate.mjs --rule personal --root out/critic/personal-small   (1,082 bytes)
      [blocking] personal/email  data/big-import.json:2
      FAIL: 1 blocking, 0 advisory

    node tools/gate.mjs --rule personal --root out/critic/personal-large   (9,437,266 bytes)
      personal      clean
      PASS: 0 blocking, 0 advisory

This is not hypothetical against this wave's own import. Counting gate/personal's four patterns over
the 21 staged text files myself:

    files the rule reads: 19, carrying 3 matches
    files the rule silently skips at the 8 MB cap: 2, carrying 77 matches
      SKIP   9010316 bytes   74 matches  ecology/shorebirds-2026-08-19.json
      SKIP  18805633 bytes    3 matches  derived/ecology-ala-occurrences-2026-08-19.json

**This repository already knows the right answer and has written it twice.**
`tools/gate/provenance.mjs` line 156 and `tools/gate/derived.mjs` line 159 both raise a finding on an
oversized file, with the words "A pack the gate cannot read is a pack whose provenance nobody
checked." `gate/personal` (8 MB), `gate/style` (4 MB) and `gate/ports` (8 MB) do the opposite and say
nothing. `gate/personal` also returns null on any file containing a NUL byte, silently.

It is not a declared blind spot either: `docs/JURISDICTION.md` has no row for it and
`tools/faults.mjs` has no fault for it, so `selftest` cannot see it. The declared
`personal-data-staged` blind spot is about `ingest-inbox/` being out of scope, which is a different
hole.

Nothing is leaking today: the three real matches are false positives, no derived pack is committed,
and the gate is 0 blocking. The defect is that the rule standing between a public repository and a
leaked contact detail goes quiet exactly where a large import would hide one, and it goes quiet
without saying so.

## 2. minor. Board note 022's prediction about that rule is false, and INGEST-STATUS repeats it

Note 022 says: "Pointing `gate/personal` at this tree without hardening it first would raise 80
blocking findings on a clean import." The `docs/INGEST-STATUS.md` `ingest-inbox/` row carries the
same sentence.

**The 80 is exactly right and reproduces to the digit**: whole file and line by line both give
`{"mobile":35,"landline":45,"email":0,"street-address":0} total 80` over those 21 files. The
prediction about the rule does not. Pointed at the tree, `gate/personal` raises **3**, because 77 of
the 80 sit in the two files it never opens. The hand scan was more thorough than the machine, which
is the opposite of what both documents assume, and an agent who hardens the patterns on the strength
of that sentence will fix the wrong thing.

## 3. minor. The GTFS row's `proven by` names a command that does not print its receipt

`docs/INGEST-STATUS.md`, TransLink row: "`--derive` wrote 49 records, all 49 passing `checkRecord` on
the eight provenance fields and all 49 correctly refused on `source not in data/_sources.json:
translink-gtfs-nsi`."

Every part of that is true. I checked it independently and it is true in every part. But
`node tools/ingest/gtfs.mjs --derive` prints six lines and none of them is that, and
`--derive --json` prints nothing at all. The other three connectors do print their own
`checked N records ... provenance: 0 problems` line; this one does not, and the row borrowed the
shape of its siblings' receipt.

`docs/INGEST-STATUS.md`'s own rule 3 says: "`proven by` names a command. If the receipt is not a
command somebody else can re-run, it is not a receipt." Two fixes and either is fine: teach
`gtfs.mjs --derive` to print the line the other three print, or reword the cell to name what the
command actually says.

## 4. minor. Board note 024 carries a stale record count

Note 024: "the running world reads none of the 1,939 derived records this wave produced". The 1,939
is correct for four packs at 19:50 and `docs/STATE-OF-PLAY.md` says so honestly, scoped to "four
connectors run". By the time note 024 was written there were six packs. Counted now:

    osm-buildings 601, osm-roads 924, weather 365, census 13, ecology 14507, gtfs 49  =  16,459

The note's point survives and gets stronger with the real number. The figure just needs
re-measuring rather than carrying.

---

# What surprised me, which the cheerleader may have

**All six derived packs re-derive byte for byte.** I hashed them, re-ran every connector's
`--derive`, and hashed again:

    sha256sum ingest-inbox/derived/*.json  before and after four --derive runs
      IDENTICAL: re-deriving reproduced every pack byte for byte

16,459 records across five sources, four connectors written by two different agents on one day, and
not one byte of run-to-run noise: no timestamps, no map iteration order, no float formatting drift.
Nobody claimed this and no instrument checks it. It is worth an instrument.

**Board note 023's Friday reproduces from a script somebody else wrote.** I did not use the
connector. I opened the zip with `tools/zip.mjs`, parsed the CSV myself and computed the service
calendar myself, and got 40, 692, 14, 20, 40, 40, 1865, 5 and the same four headsigns. A number that
survives being recomputed by a hostile reader from the raw bytes is the strongest kind there is.

**`docs/LICENCE-QUESTIONS.md` quotes a typo correctly.** The Produced Work Guideline says
"alternations" where it means "alterations", and the document quotes it as written and says so in
brackets. You cannot get that from memory. It is proof the author opened the page, and it is the
single cheapest signal of honest citation in the whole wave.

**The blind spot row is real.** `personal-data-staged` reports `BLIND SPOT PROVEN, no instrument
catches this, and gate/personal was watched not catching it`. An instrument registry that spends a
row proving its own limit is rarer than one that spends a row claiming a capability, and finding 1
above is only findable because this repository taught me to look for that shape.
