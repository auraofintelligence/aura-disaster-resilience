---
id: 023
title: The Friday bus day is already real and licence settled, and the running world cannot read one byte of it
status: open
opened: 2026-08-19
author: wave 5, scout
tags: scout, stage-4, slice, gtfs, transport, osm, tide, residents, licence
---

Everything below came out of a command run on 19 August 2026. Where I could not check a thing, the
row says so.

## 1. What this wave made cheap that used to be expensive

**A whole real Friday, at minute resolution, for free.** `ingest-inbox/gtfs/NSI_GTFS.zip` is on
disk with its sha256 recorded, and `tools/zip.mjs` opens it with a CRC check. Reading it takes one
short script, no network and no further download. What it holds for Friday 2026-08-21, service id
`NSI 26_27-42958`:

    friday trips total: 40
    friday trips calling at Junner St Ferry Terminal (870029): 40
    friday trips calling at One Mile Ferry Terminal (870027): 40
    friday trips 40, stop_time rows 692, calls per trip min 14 max 20
    shape points in feed: 1865, distinct shapes: 5
    headsigns: "Amity Point" | "One Mile" | "Point Lookout" | "Dunwich"

The first trip out of the barge terminal, in full:

    06:15:00 870029 Junner St Ferry Terminal (Dunwich)
    06:17:00 870030 Ballow Rd at Cunningham St
    06:22:00 870027 Yabby St at One Mile Ferry Terminal
    06:25:00 870041 East Coast Rd at Bus Depot hail 'n' ride
    ... 19 calls in all, the last of them at 06:58 at the Gorge Walk stop

Every one of the forty Friday trips touches both the vehicle terminal and the passenger terminal.
That is the "bus meets the boat" beat of the stage 4 slice, and it is already sourced, already
dated, already licence settled at CC-BY 4.0, and already downloaded. Nobody has to fetch anything
to build it.

**A second thing made cheap: the honest unknown, end to end.** The ladder, the panel and the probe
agree on what "not known" looks like, and I watched all three:

    node tools/bitemporal.mjs --check
      PASS: 35 checks over 10 fixture records
      including  [ok] not-known-is-an-answer   [ok] live-refuses-the-bottom-rung

    node tools/uiprobe.mjs --assert verify
      PASS unknown-shows-marker  1 checked, values the twin does not know show a marker and a date
      PASS marker-well-formed    1 checked, markers carry a date and no number
      PASS: 9 rules, 0 failures, over 5 panels and 8 values.

## 2. Three things now within reach, each with what it would take

**a. The slice can be built and proven before the licence question is settled.** This is the one
that changes the schedule. `buildIslandWith(packs, opts)` in `src/world/island.js` takes packs
already in hand and does not go near `data/`, and `tools/serve.mjs` serves the repository root. I
checked the second half rather than assuming it:

    curl http://localhost:4281/index.html                                 200  7270 bytes
    curl http://localhost:4281/ingest-inbox/derived/transport-gtfs.json   200 27851 bytes
    curl http://localhost:4281/data/tide.json                             200  6157 bytes

So on a machine that has run the connectors, both Node and the browser can read the derived packs
today, and nothing about that requires committing them. What it would take: a system that receives
its pack as an argument, the way `registerTide(world, { pack: packs.tide })` already does. What
would prove it: a headless run with the transport system registered and its own state hash. What
would kill it: nothing found, but say the limit out loud every time, because a fresh clone has an
empty `ingest-inbox/` and this slice would not run there at all until the licence lands.

**b. Eleven island businesses publish opening hours, and the committed connector does not ask for
them.** The staged extract carries none:

    elements: 1539, elements carrying opening_hours: 0

because the query in the receipt takes buildings, roads, place nodes and admin boundaries and
nothing else. I asked Overpass for the missing half, one query, `HTTP 200 27087 bytes`:

    elements carrying opening_hours: 15
    node/466942565  Foodworks             supermarket  06:30-21:00
    node/8059090571 Straddie Bakery       bakery       Mo-Su 06:00-15:00
    node/8226776238 Bo Beans Coffee       cafe         Mo-Su 06:30-13:30
    node/4959148761 Blue Room Cafe        cafe         Mo-Fr 07:30-15:00
    node/14004033706 The Kiosk            cafe         Mo-Fr 09:00-15:00; Sa,Su 07:30-15:00
    ... eleven businesses in all, plus four bus route relations carrying the tag oddly

That is the "shops open on published hours" beat of the slice, sitting one query away. The honest
caveat, which belongs on the card: OpenStreetMap is a secondary claim about a shop's hours, not the
shop's own publication, so the register is `known` with confidence `medium` at best, the same as
the building outlines. What would kill it: the owner deciding a crowd-sourced hour is not a
published hour, which is a fair call and would push this to a per-business source.

**c. Both crossings exist as real named geometry, and the two-crossings law is already drawn in the
data by somebody else.** Same probe, a bbox from Cleveland to the island:

    way/17963426   Cleveland - North Stradbroke Island (Vehicle ferry)   op=Sealink  motor_vehicle=yes
    way/1263199044 Cleveland - North Stradbroke Island (Vehicle ferry)   op=Sealink  motor_vehicle=yes
    way/1263199043 Cleveland - North Stradbroke Island (Passenger ferry) op=Sealink  motor_vehicle=no
    way/1263439963 Cleveland - North Stradbroke Island (Water taxi)      op=Stradbroke Flyer  motor_vehicle=no
    node/11738645101 Cleveland (Toondah Harbour)                        op=Stradbroke Flyer
    node/10068351363 Cleveland (Toondah Harbour) Passenger Ferry        op=Sealink
    node/6887379988  One Mile Jetty                                     op=Stradbroke Flyer
    node/185954681   (no name) ferry_terminal at -27.5036, 153.4013     op=Sealink

Three things worth having: Toondah Harbour is a named node in a published source rather than a word
in our prompt; the Flyer is a real operator name, so the slice's phrasing is grounded; and
`motor_vehicle=yes` versus `motor_vehicle=no` is the passenger and vehicle split already made by
the source, which is exactly what `docs/INGEST-STATUS.md` says must never be merged. What is still
absent is every number: no sailing time, no vehicle capacity, nothing. Geometry is not a timetable.

## 3. Where a piece of the design is carrying weight it was not asked to carry

**`uiprobe`'s `UNKNOWN_WHEN` is a general mechanism wearing one rule.** Lines 118 to 136 of
`tools/uiprobe.mjs` open `data/tide.json`, count `constituents`, and require the marker on
`tide-height` while the count is zero. That is not a tide rule. It is a rule that says "when this
file is empty, the screen must say so, with a date", and it flips by itself the day the file fills.
Two crossing rows want exactly that shape and would need no new machinery: while
`crossings[].sailingsFriday` is null, the departure board shows the marker and a date, and the day
a sailing time lands the same rule starts demanding a number. That is a second use for a thing that
already exists, and it is the cheapest way this repository can carry the absence the slice is most
likely to lie about.

**The seams instrument can carry an absence too.** `node tools/headless.mjs --ticks 1440` prints

    DEAD SEAMS (declared, never fired): tide.high, tide.low

A transport system that declares `crossing.passenger` and `crossing.vehicle` and never fires them
puts the two missing timetables in the output of an instrument, every run, instead of in a
paragraph nobody reads.

## 4. The riskiest assumption, and what settles it cheapest

The riskiest assumption in this wave is that the ingest is progress toward the slice. It is real
work and it is not yet reachable. `src/world/data.js` line 23 is
`export const DATA_URL = new URL('../../data/', import.meta.url)`, so the loader reads exactly one
directory. `STAGE_0_PACKS` is `['tide']`. `tools/gate/derived.mjs` blocks any derived pack under
`data/` while board note 007 is unresolved. So today:

    node tools/headless.mjs --ticks 1440
      systems:  2 registered
      store:    {"entities":0,"nextEntity":1,"freed":0,"components":{}}

Nineteen hundred and thirty nine derived records exist on this machine and the running world reads
none of them. The cheapest thing that settles whether that gap is real: point one system at one
derived pack through `buildIslandWith` and run the headless instrument. An hour, no decision from
anybody, and it either produces a per-system hash or it does not.

## 5. The next real step toward the Friday barge day, taken apart

Element by element, against what is actually on disk.

| element | what exists | what does not | blocking? |
| --- | --- | --- | --- |
| 6:00 vehicle sailing at Toondah | the terminal node, the route way, the operator name | the sailing time, the vehicle capacity, any source at all | **yes, and it is the only unbounded item** |
| cars queue at Junner Street | Junner Street is one of 138 distinct real road names in the roads pack; two Sealink terminal nodes sit on it | a queue model, entities, a barge capacity to queue against | no. The queue is `modelled` and allowed to be, so long as it never inflates a real figure |
| foot passengers ride the Flyer to One Mile | One Mile Jetty as a named node, the Flyer as a real operator, One Mile as bus stop 870027 | the sailing time | same as row one |
| the bus meets the boat | 40 Friday trips, 692 timed calls, 5 shapes, both terminals, CC-BY | the boat half | no. The bus runs truthfully alone |
| shops open on published hours | 11 businesses with hours, one query away; 4 named retail buildings already in the pack | the query has not been run into a connector | no |
| the tide moves the waterline | nothing. `constituents: []` | a constituent table | **no, and this is argued below** |
| one person followed from house to jetty | 601 real outlines with locality and centroid, 924 real centrelines, real stops, real trips | entities, an agent system, a map projection, a renderer that draws anything but four calibration quadrants | no on data, yes on code |

**The ONE next step: make the Friday bus day run in the world.** Extend
`tools/ingest/gtfs.mjs --derive` to emit the Friday service day (40 trips, 692 timed calls, 5
shapes) into `ingest-inbox/derived/`, and add `src/systems/transport.js` that takes that pack as an
argument, moves buses on real island minutes, and declares `crossing.passenger` and
`crossing.vehicle` as seams it will never fire.

Why this one and not the renderer or the residents: it is the only element of the seven whose data
is complete, minute-resolved, licence-settled and already downloaded; it needs no decision from the
owner, no projection, no GPU and no name pool; and it links the two terminals the whole slice hangs
off, so every later beat attaches to something real rather than to a placeholder.

**What would prove it worked**, all four, or it did not:

1. `node tools/headless.mjs --ticks 1440` runs with three systems registered, prints a per-system
   hash for `transport` and a tick cost inside its budget.
2. The seams block prints `crossing.passenger` and `crossing.vehicle` as dead seams, which is the
   two-crossings law appearing in an instrument instead of in prose.
3. A check in the shape `tools/check-island.mjs` already uses: at 06:15 island time a vehicle of
   route F880-4470 is at stop 870029, and seven minutes later the same vehicle is at stop 870027,
   both times matching `NSI_GTFS.zip` `stop_times.txt` exactly rather than matching our own model.
4. `node tools/determinism.mjs --ticks 5000` still prints identical, and `node tools/gate.mjs`
   still prints 0 blocking.

What would kill it: a transport system that cannot be deterministic while its pack lives outside
`data/`, or forty trips that will not fit the tick budget. Both show up in step 1 within the hour.

**The first real thing that must land, which is a different question:** a published sailing time for
the vehicle barge and for the passenger crossing, with the licence of that publication read. It is
the only item in the slice with no source anywhere in this repository, it is the only one whose lead
time is unknown, and it is the one the slice is named after. It should be started as its own ingest
lane in parallel with the step above, not after it, because a connector against a commercial
operator's published timetable may take a wave or may be refused, and finding that out late is how
the slice slips. Until it lands, the barge beat runs as a marker and a date, and that is honest.

## 6. The tide: not blocking, and the reasoning rather than a preference

Three findings, in the order that decides it.

**The waterline is blocked on the renderer, not on the tide.** `src/render/calibration.js` is 421
lines and draws four solid quadrants, a plate and a swatch. A grep of `src/` and `tools/` for
`mercator`, `projec`, `metresPer` and `toLocalXY` returns nothing but prose in `bitemporal.js` and a
fault comment. There is no projection and no island geometry on screen anywhere in this repository.
So the waterline cannot move because there is nothing to move it, and feeding the tide today would
change no pixel.

**The honest unknown is already built, already checked, and already reversible.** The ladder returns
two shapes on purpose, `{ value, rung, source, recordedAt, stale }` or `{ unknown: true, asAt,
why }`, so a panel cannot render "not known" as a number by accident. `src/ui/panel.js` renders the
tide row as a distinct `marker` element reading "contested or unknown, as at" plus the date.
`uiprobe` rule 8 requires that marker while `data/tide.json` has no constituents and requires it to
go away when a table lands. I watched all of it pass, quoted in section 1.

**It is the only one of the seven absences that is already fully instrumented.** Blocking the slice
on the tide would be choosing the single gap that already has a working, checked answer, while six
gaps with no answer sit beside it.

So: build the slice with the tide showing "not known", dated. What that costs is one beat of visible
motion. What it buys is the other six elements, and a check that is already written and will start
failing the day board note 004 is answered, which is a stronger guarantee than a tide moving on
constants whose own source document says they are not where they claim to be.

One honest caveat that belongs with this: even a static waterline drawn at the OpenStreetMap
coastline is ODbL, so the still picture is behind board note 007 as much as the moving one is.

## 7. Generated residents: what the disclosure actually costs, and a design that pays it

What is already in place, checked rather than assumed. `register` is on every record and enforced by
`gate/provenance` under `data/` and by `gate/derived` under `ingest-inbox/derived/`. The four
registers are already visually distinct in `index.html` lines 91 to 94: solid, dashed, dotted and
double borders, each with its own colour. `uiprobe` already passes `value-register`, 8 checked. So a
badge reading `modelled` on a person's card costs nothing new to build or to check.

What the constraint actually costs is not the badge. It is three other things.

1. **The name pool is what creates the risk the badge only mitigates.** `docs/CONTRACT.md` section 5
   gives the reason as collision with one of about two thousand real people, and this wave measured
   that figure: `SA2, the whole island: 2156 persons`. A badge does not stop a real islander reading
   their own name on a generated card. It only makes the card honest afterwards.
2. **`uiprobe` already makes an unsourced attribute expensive.** `value-prov` requires every
   displayed value to cite a record that resolves against `data/**`. "Lives at way 42402895" cites a
   real record. "Is called something" cites nothing, and there is no source id it could ever cite.
3. **The disclosure has no check.** `docs/CONTRACT.md` section 5 carries it as `NOT YET CHECKED: no
   people exist yet`. `gate/lore`'s `no-aboriginal-characters-with-invented-culture` is armed and
   reads `data/residents.json` for absent fields, and it reports `NOT YET RUN` because that file
   does not exist. Nothing anywhere checks that a generated person is labelled generated.

**The design that pays it cheaply: give the slice's residents no personal name at all.** Identify a
resident by a stable generated id and a descriptor assembled entirely from records that already
exist: the dwelling as an OpenStreetMap way id, the township as an ABS locality record, the
boarding stop as a GTFS stop id, the trip as a GTFS trip id. Then collision probability is zero
rather than mitigated, because no pool exists; the disclosure is the register badge the page already
draws and the probe already checks; every field on the card cites a real record, so the existing
rules do the enforcing and no new rule is needed for provenance; and the cultural rule is satisfied
by construction, because a name that does not exist cannot read as belonging to a language group.

The cost of that design, stated rather than hidden: a person with no name is harder to follow and
harder to care about, and "follow one person from their house to the jetty" is the emotional beat of
the whole slice. That is a real loss and it may be the wrong trade.

**The cheapest experiment that settles it:** build the slice's one followed resident with no name,
run `uiprobe --assert` against the card, and put it in front of the owner. **What would kill the
idea:** he says an unnamed resident is unfollowable. If he does, the next cheapest design is a name
pool with its own published source and a permanent disclosure, and that design needs a gate rule
that does not exist yet, which by `docs/CONTRACT.md` section 0 means it must land in the same commit
as the first resident.

## 8. What I did not check

- I did not open a browser. Every UI claim here comes from `tools/uiprobe.mjs --assert verify`
  against a probe captured on 18 August, not from a live page.
- I did not run the ingest connectors. I read the packs they left and the raw files beside them.
- I ran two Overpass queries of my own, from the scratchpad, and wrote nothing into this repository
  from them. Both are reproducible: the receipts above carry the element ids.
- I did not look for a barge timetable. That is an ingest lane's job and it needs a licence read
  before anything is derived, and this note is not a substitute for it.
- The gate was clean before I wrote anything, `PASS: 0 blocking, 7 advisory`, and is run again after
  this note lands so that the note itself is judged by it.
