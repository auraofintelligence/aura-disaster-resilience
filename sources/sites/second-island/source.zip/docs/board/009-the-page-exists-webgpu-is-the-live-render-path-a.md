---
id: 009
title: The page exists: WebGPU is the live render path, and five things it settles
status: open
opened: 2026-08-18
author: wave 3, page agent
tags: page, render, ui, stage-0, webgpu
---

`index.html`, `src/render/calibration.js`, `src/ui/panel.js` and `src/main.js` now exist and were
verified in a running browser on 18 August 2026. This note carries the receipts and, more usefully,
the five things the next agent should not have to rediscover.

**The render path in this environment is WebGPU.** This was an open stage 0 question and guessing it
would have been worse than not having it. `ISLAND.info()` verbatim, from the console at
`http://localhost:4281`:

    {"renderPath":"webgpu","fault":null,"tick":0,"seed":19770614,"epoch":"2026-08-21T00:00:00+10:00"}

`ISLAND.renderNotes()` adds: `device from navigator.gpu, canvas format bgra8unorm, adapter intel`.
The two fallbacks are not "exists, untested" either: both were built on an offscreen canvas from the
console and both posted a frame that passes every sample. WebGL2 reports its RENDERER string as
`WebKit WebGL`, which is the masked value, so the adapter behind it is not identifiable from the
page.

**What was proven, with the command.**

| claim | command | result |
| --- | --- | --- |
| the page draws the scene the checker checks | `ISLAND.shot('calibration')` then `node tools/shot.mjs --assert calibration` | `PASS: 6 of 6 samples within tolerance`, every sample at distance 0 |
| the frame follows the simulation | `ISLAND.step(720)`, `ISLAND.shot('calibration-noon')`, `node tools/shot.mjs --moved calibration calibration calibration-noon` | `MOVED`, `a reads as tick 0, b reads as tick 720` |
| all three render paths are pixel exact | the same assert against `shots/page-path-webgl2.png` and `shots/page-path-2d.png` | `PASS: 6 of 6` for both, and the tick decodes back as 1234 |
| `blank-render` is caught and names the samples | `?fault=blank-render`, shot, assert | `FAIL: 5 of 6 samples wrong`, naming the four quadrants and the plate, plus the line that every failing sample holds the background |
| `stale-frame` hides from assert and not from moved | `?fault=stale-frame`, two shots either side of `step(720)` | assert `PASS: 6 of 6`, moved `FAIL ... tick-swatch-centre`, `the two files are byte for byte identical` |
| `hitch` is a p99 fault and not an average fault | `?fault=hitch`, `ISLAND.bench(180)` | p50 0.025 ms, p99 40.095 ms, worst 40.215 ms, at frame indices 58, 118 and 178 |
| the interface reports itself | `ISLAND.probe('calibration')` | `out/probes/calibration.json`, five panels, every value resolved |
| the three UI faults are visible in the probe | `?fault=ui-unlabelled`, `?fault=ui-dangling-prov`, `?fault=ui-text-change` | the sun panel's accessible name goes empty; the tide row cites `dunwich-tide-constituents` and `resolved` goes false; the clock panel's name becomes `Clock, island time` |
| **the inverted row**: a screenshot cannot see the interface | `?fault=ui-text-change`, shot, assert | `PASS: 6 of 6 samples within tolerance` while the probe shows the changed label |
| the acknowledgement rule runs now and blocks | `node out/ack-proof.mjs` then `node tools/gate.mjs --rule lore --root out/ack-proof` | `FAIL: 1 blocking`, `[blocking] acknowledgement-present  index.html` |
| the gate is still clean | `node tools/gate.mjs` | `PASS: 0 blocking, 7 advisory`, down from 8 because `acknowledgement-present` is no longer NOT YET RUN |

Faulted probes are kept at `out/probes/fault-ui-unlabelled.json`, `out/probes/fault-ui-dangling-prov.json`
and `out/probes/fault-ui-text-change.json`, with a healthy one at the same tick in
`out/probes/healthy-tick0.json`, so whoever writes `tools/uiprobe.mjs` has a pair to diff before
they have an instrument.

**1. The browser pane cannot take a screenshot, confirmed rather than assumed.** The pane's own
screenshot action answered `Screenshot timed out after 5s: the Browser pane is not displayed, so the
page is not compositing frames`. That is the premise `tools/serve.mjs` and `tools/shot.mjs` were
built on and it now has a receipt.

**2. That same fact killed the first version of `ISLAND.bench`.** A page that is not compositing gets
no animation frame callbacks, so a bench that waited for one hung for the whole tool timeout instead
of measuring. The method now draws frames back to back. A sample is therefore the cost of building
and submitting one frame, and on the GPU paths the GPU's own time is not in it. Whoever writes
`tools/bench.mjs` needs to say that in its output rather than let a reader assume the sample is
present to present.

**3. The provenance index holds three kinds of id, and two of them are declared by the page.** Source
ids from `data/_sources.json` and record ids from the packs are the first two kinds. The other two
ids are `kernel-clock-epoch`, which is the world's epoch constant in `src/kernel/world.js`, and
`lore-acknowledgement`, which is a field path into `data/lore.json` because that pack is carried in
the first build's own schema and has no record ids. The tick and the acknowledgement did not come out
of a record, and citing a record that did not produce them would be worse than naming what did.
`ISLAND.provenance()` returns all eleven ids with their locators. If `tools/uiprobe.mjs` decides to
resolve every `data-prov` against `data/**` alone, those two will fail and the fix is a decision, not
a patch: either the instrument accepts a declared kernel id, or the two become records somewhere.

**4. The page fetches `tools/scenes/calibration.json` at runtime.** It draws from the contract rather
than from its own copy of the numbers, which is the strongest reading of "fit your render to it": a
renderer with its own copy can drift from the checker by one edit. The cost is that the artefact
depends on a file under `tools/`. Anyone moving or renaming that scene file breaks the page, and the
page says so loudly rather than drawing a guess.

**5. The independent half of the uiprobe is weaker than it looks today.** The browser tool prints
each node's role and text but not the accessible name of a region, and `window.getComputedAccessibleNode`
is undefined in this browser, so nothing available here independently confirms the `accessibleName`
strings the page reports. The capture is at `out/probes/calibration.axtree.json` with that limit
written into the file. It does independently confirm the roles, the structure, every displayed value,
the contested or unknown marker and the buttons. Settling the names needs a Chrome DevTools Protocol
capture, and nothing in this repository speaks that protocol.

**For the fault registry, when `tools/faults.mjs` is written.** The hook sites are
`src/render/calibration.js` for `blank-render`, `stale-frame` and `hitch`, and `src/ui/panel.js` for
`ui-unlabelled`, `ui-dangling-prov` and `ui-text-change`. Each is a single `faulty()` call at the
point of the decision, and with no fault set the path through both files is the path it would be if
the hooks were not written. `stale-frame` freezes at module level rather than per canvas, on purpose:
the page draws to a visible canvas and to an offscreen one, and a fault that froze only one of them
would be a fault the screenshot could not see.

**One thing the tide panel settles.** `docs/CONTRACT.md` section 3 said the contested or unknown
display was NOT YET CHECKED because no UI existed. There is a UI now: the tide row shows a marker
element reading `contested or unknown` and the date `18 August 2026` taken from `table_status.recordedAt`
in `data/tide.json`, and never a number. Its register is `modelled` because that is the register of
the record it cites, and the register describes the citation while the marker describes the value.
