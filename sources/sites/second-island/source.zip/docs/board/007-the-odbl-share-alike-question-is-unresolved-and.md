---
id: 007
title: The ODbL share-alike question is unresolved and already live
status: open
opened: 2026-08-18
author: wave 2, board and state agent
tags: licence, osm, ingest, stage-2
---

The founding prompt, section 5, says to resolve the ODbL share-alike question against this
repository's licence BEFORE committing any OpenStreetMap derived pack. It is not resolved, and it is
not theoretical: a coordinate derived from OpenStreetMap is already committed here.

**What is already carried.** `data/_sources.json` registers `osm-nominatim` with the licence field
reading, in part: "Open Database Licence (ODbL). ... It is not resolved. Nothing in this repository is
a derived extract yet: one township coordinate is carried, and that carry is the only reason this
entry exists." That coordinate is in `data/tide.json`, the `port` record: lat -27.4992, lon 153.4025,
sourced through `first-build-places-pack` to an OpenStreetMap query of 6 August 2026. The solar system
reads the same record as the island reference site, so the number is in the running world today.

**The tension, stated plainly and without a legal opinion, because nobody here is qualified to give
one.** ODbL is a share-alike licence for databases: a derived database is generally required to be
offered under ODbL. `LICENCE.md` here is the Strange But True Public Source Licence, which reserves
all commercial rights and is not an open licence. Those two do not obviously compose. A single
coordinate may or may not be a substantial extract, which is the question ODbL turns on, and "may or
may not" is not a basis on which to commit 1,059 building footprints.

**What is blocked by it.** The OpenStreetMap lane in `docs/INGEST-STATUS.md`, which is the lane the
founding prompt names as the reason not to invent building footprints. It is the single most valuable
lane on the list and it cannot be committed until this is answered.

**What would settle it.** One of:

1. A decision by the owner, recorded in `LICENCE.md`, about how ODbL derived material is carried:
   most likely a separate directory holding OSM derived packs under ODbL with attribution, kept
   outside the reserved-rights part of the repository, so the two licences never have to compose.
2. A build path that keeps the derived database out of the repository entirely: OSM data fetched at
   ingest time into `ingest-inbox/`, which is sealed and uncommittable, with only produced geometry
   committed. This still needs an answer about whether that geometry is a derived database.
3. Advice from someone qualified, if the owner wants certainty rather than a defensible choice.

Until one of those lands, do not commit an OSM derived pack, and do not quietly widen the one
coordinate already carried into a second and a third.
