---
id: 028
title: The founding prompt is demoted. docs/ALREADY-DECIDED.md replaces it as the first read
status: resolved
opened: 2026-08-19
author: orchestrator, on the owner's correction of 19 August
---

The owner was asked directly how much of docs/FOUNDING-PROMPT.md was his. His answer: mostly a previous Claude's, treat it as a draft. So it is a draft, and an agent opening this repository should read docs/ALREADY-DECIDED.md first.

His actual brief, in his words: an actual digital twin, a simulation engine, a real place made operational for ancestor simulations, real life and future planning via scenarios, real and accurate data not guesses, and a build path that is participatory and inclusive.

On what it must be, which the founding prompt did not say and which changes the first slice: it is a system that works for every day use but is prepared for all the existential threats, building trust and usefulness every day, and earning its keep when things go wrong. He had already written this himself in the Straddie Disaster Kiosk pitch, section 1.2: resilience requires daily active use, and the named failure mode is satellite phones in lockboxes found uncharged and unfamiliar when a crisis strikes.

On technology: he is technology agnostic and prefers free and open source, on the reasoning that AI is rewriting the software stack anyway. So the durable layer is the contracts and the data, not the engine. The existing rule that simulation never imports the renderer is what makes that survivable, and it should not be relaxed.

Three structural corrections from reading his live work:

1. This twin is not the top level. It is section 5.1 of the Sovereign Kiosk Network, and its name in his work is Virtual Minjerribah, running on nodes he calls Gumpi/Goompi-Node. Do not coin names.

2. Micronova is a parameter supplier, not a module. It gives depth, dose and lead time. His words on building.html: the evidence pages shape the specification, around timing and around how hard the shelter holds, rather than being the ticket in.

3. Nothing across the five projects wants a control system. Mirror, not master, in sandworm; digital twin, not digital master, in p4a. Both are his phrasings.

Two dated facts that reorder priorities. The Dunwich terminal consultation window was 28 May to 21 June 2026 and has closed. The business case completes late 2026 and project planning completes 2027, against 41 million dollars: 10 Commonwealth, 30 Queensland, 1 local. The business case, not the survey, is the live window.

The single highest value data unblock is not a dataset. It is the vehicle barge and the passenger boat as two separate numbers, sailings and vehicle capacity, held by the operators and absent from every open source checked.
