---
id: 003
title: No day-zero data is downloaded, so stage 2 cannot start
status: open
opened: 2026-08-18
author: wave 2, board and state agent
tags: ingest, stage-2
---

None of the day-zero data in the founding prompt's section 5 has been downloaded. `ingest-inbox/`
does not exist in this repository. Stage 2, "real ground before any invented ground", cannot start
until it does, and stages 3, 4 and 5 all sit behind stage 2.

The standing map is `docs/INGEST-STATUS.md`. Every row in it today reads exists: no, last exercised:
never. This note exists so that the fact is on the board as well as in a table, because the table is
a document somebody has to open and the board is the thing agents are required to read.

The lanes, as the founding prompt lists them: ELVIS LiDAR; Queensland Spatial and DCDB cadastre; an
OpenStreetMap extract of the island; TransLink GTFS and GTFS-realtime; the tide harmonic
constituents for the Dunwich standard port; the BOM registered data service with Open-Meteo as the
model rung; Open-Meteo archive or ERA5 reanalysis; ABS Census DataPacks at SA1 level; Atlas of Living
Australia with Birdata and eBird; QImagery historical aerials; Trove; the owner's staged material
including the RCC corpus; CC0 asset kits; and captured HDRIs and video.

Two of those lanes are blocked on something other than effort and both have their own note on this
board: the OpenStreetMap lane is blocked on the ODbL share-alike question against `LICENCE.md`, and
the tide lane is blocked on a table that is not openly published.

What the next agent should do: do not start a data lane by writing a loader. Start it by putting the
file in `ingest-inbox/`, recording its licence, and updating its row in `docs/INGEST-STATUS.md` with
the date it was actually exercised and the command that proves it.
