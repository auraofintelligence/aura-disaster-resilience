---
id: 015
title: Fourteen real gazetted road names trip the invented-language rule, and neither branch of its instruction is available
status: for-owner
opened: 2026-08-19
author: wave 4, OpenStreetMap ingest agent
tags: cultural, gate-lore, osm, roads, owner-decision
---

`gate/lore`'s `no-invented-language` rule cannot tell a word an agent invented from a road name the
Queensland government gazetted, and this island has fourteen of the second kind. The rule is right to
raise them. There is no answer to it that is obviously correct, and the answer is not an agent's to
pick, so it is written down here before anybody picks one by accident at three in the morning.

## How this was found, and the receipt

The OpenStreetMap lane stages its derived packs in `ingest-inbox/`, which every gate rule skips. So
the packs have never met the check they will meet the day the licence question is settled and they
move to `data/`. Rather than guess what would happen, I built a throwaway tree and ran it:

    node -e "..."                                   # copy .gitignore, data/lore.json,
                                                    # data/_sources.json and the two derived packs
                                                    # into out/osm-gate-probe/data/
    node tools/gate.mjs --rule lore --root out/osm-gate-probe
      PASS: 0 blocking, 39 advisory

Of those 39, six are pre-existing findings inside the carried `data/lore.json` itself, three are
rules that report NOT YET RUN because the files they guard do not exist, and **thirty come from the
roads pack**. None come from the buildings pack.

## The fourteen words

Each sits in a `name` field, each is the published name of a real road or track on this island, and
none is on `lore.language.allowlist`:

    Bambara Street        Bigoon Road           Billa Street          Booran Street
    Boreen Street         Geera Street          Gindarra Street       Mallon Street
    Merinda Crescent      Mulung Street         Yarrong Road          Kabul Track
    North Gorge Walk      Bippo Penbean walking trail

The rule's own words on each: "STOP AND ASK: X is not on the allowlist and it sits in a name
position. A word in a name position is being used to name a thing. If it is an Aboriginal language
word it must be in `lore.language.allowlist` with a published source before it ships. If it is not a
language word, rename it to plain English."

## Why neither branch of that instruction is available here

**Renaming is prohibited.** `CLAUDE.md` and `docs/CONTRACT.md` section 5 both say no invented place or
road. Renaming Bigoon Road to something English would be inventing a road name for a real road, which
is the exact defect this repository was started to stop, arrived at by obeying a cultural rule. It
would also make the twin unusable: a resident cannot walk to an address on a street the map has
renamed.

**Adding them to the allowlist is worse.** The allowlist is a list of Quandamooka words with published
sources. Putting a street name on it asserts that the word is a Quandamooka language word. Nobody
here knows that. Some plainly are not: "Gorge" in North Gorge Walk is an English noun, and "Kabul" in
Kabul Track is a word with an entirely different and well known referent. Sorting the fourteen into
language and not-language is precisely the judgement `docs/CONTRACT.md` section 4 reserves for the
Traditional Owners, and an agent doing it quietly to clear a gate finding would be the same failure
that put board note 002 on this board.

**And the third option, suppressing the rule for road names, is the one that would actually cost
something.** The rule exists because an agent in the first build coined language-shaped words. A road
name field is exactly where a coined word would hide. Exempting the field would blind the rule at the
one place it most needs to see.

## What is true today, so nobody thinks this is on fire

Zero blocking. `no-invented-language` is advisory by design, and its wording is "STOP AND ASK", not
"you broke the build". The gate does not block on this now and would not block on it if the packs
moved to `data/` tomorrow. This note is about the answer, not about an outage.

## What would settle it

For the owner, and eventually a question for QYAC rather than for us:

1. Distinguish, in `lore.json`'s own schema, a word this build *uses to name a thing* from a
   published proper noun this build *reproduces from an official source*. The gazetted road register
   and OpenStreetMap are both citable, and a rule that reads the source id could pass a name that
   carries one and still stop a name that carries none. That keeps the rule's teeth exactly where
   they were: an invented word has no source to cite, so it still fails.
2. Leave it advisory and read the fourteen once, by hand, with the owner. Fourteen is a number a
   person can read in five minutes. That may simply be the answer.

Option 1 is a contract amendment and `docs/CONTRACT.md` section 8 says an amendment lands with the
check that enforces it. I have not written either, because the shape is not mine to choose.

## For the next agent

Do not clear these findings. Do not add a word to the allowlist to make a gate run quieter. If you
need the probe tree back:

    node -e "const fs=require('fs');const p='out/osm-gate-probe';fs.rmSync(p,{recursive:true,force:true});fs.mkdirSync(p+'/data',{recursive:true});fs.copyFileSync('.gitignore',p+'/.gitignore');for(const f of ['lore.json','_sources.json'])fs.copyFileSync('data/'+f,p+'/data/'+f);fs.copyFileSync('ingest-inbox/derived/osm-buildings-2026-08-19.json',p+'/data/osm-buildings.json');fs.copyFileSync('ingest-inbox/derived/osm-roads-2026-08-19.json',p+'/data/osm-roads.json');"
    node tools/gate.mjs --rule lore --root out/osm-gate-probe

It needs `node tools/ingest/osm.mjs --fetch` and `--derive` to have been run first, because
`ingest-inbox/` is sealed and nothing in it survives a fresh clone.
