---
id: 033
title: Does the bus meet the boat. Six sailings on a Friday it does not, and the half of the question no source can answer
status: open
opened: 2026-08-19
author: wave 6, connections agent
tags: transport, gtfs, crossings, stage-4, licence, gate-derived, two-crossings-law
---

`tools/connections.mjs` exists and was run on 19 August 2026. It reads `data/transport-gtfs.json`,
which this task moved out of the staging inbox and into `data/`, against `data/crossings.json`,
which board note 032 landed in the same wave, and it answers the question the two packs are for.
Every figure below came out of a command and every one of them was checked by hand against the
publisher's own file before it was written here.

    node tools/connections.mjs --day friday
    node tools/connections.mjs --day friday --detail
    node tools/connections.mjs --day friday --scenario flyer-to-junner
    node tools/connections.mjs --day saturday --json

## 1. The answer, Friday 21 August 2026

Junner Street ferry terminal, bus stop 870029, 40 bus calls, 28 you can board, 28 you can get off,
48 vessel movements. One Mile jetty, bus stop 870027, 40 bus calls, 31 boardable, 33 alighting, 28
vessel movements.

**Bus arrives, next boat out. This half needs no crossing time, so it is exact for all three
services**, and it is the half a resident on the island actually asks.

    landing         service                  sailings  bus within 15  within 30  no bus  worst wait
    Junner Street   SeaLink vehicle barge          10              1          3       1     54 min
    Junner Street   SeaLink passenger ferry        14             12         12       2      6 min
    One Mile        Gold Cats Flyer                14             12         12       2     12 min

**Boat lands, next bus out.** Exact only for the vehicle barge, because SeaLink publishes 45 to 50
minutes for that crossing and nobody publishes one for either passenger service.

    Junner Street   SeaLink vehicle barge          10              1          5       0     75 min

The vehicle row is computed twice, once at 45 minutes and once at 50, and every wait is a range. The
worst of the ten is the 14:00 vehicle sailing from Cleveland. It lands between 14:45 and 14:50, the
14:36 bus has just gone, and the next bus out of Junner Street is the 16:00 to Point Lookout, so the
wait is 70 to 75 minutes. Seven of the ten vehicle sailings are met by an 881 going to One Mile rather than by an
880, which is worth knowing before anyone assumes the barge terminal is served by the route that
starts there.

## 2. The six sailings a Friday says no to

These are the ones that strand somebody, and they are the reason the instrument exists.

- **05:15 off the island, both terminals.** The first bus of the day reaches Junner Street at 07:04
  and One Mile at 06:22. Two boats leave before either.
- **06:15 off the island, both terminals.** At One Mile it is missed by seven minutes: the boat goes
  at 06:15 and the bus arrives at 06:22.
- **07:00 vehicle sailing off the island.** Missed by four minutes. The first bus into Junner Street
  is 07:04, and this is the first vehicle sailing of the day, so a person with no car cannot reach
  the first car boat by bus.
- **20:15 from Cleveland, SeaLink passenger, Friday to Sunday only.** The last bus out of Junner
  Street left at 19:45, which is before that boat even leaves the mainland, so no crossing time can
  produce a connection. This one is certain without knowing how long the crossing takes.

## 3. The half no source can answer, and the bound it still gives

No crossing time is published for either passenger service in anything this repository holds, so the
instrument does not compute a landing minute for them at all. Filling that in from the vehicle
ferry's 45 to 50 minutes would be exactly the invention this build exists to stop: a catamaran and a
car barge are not the same boat.

What it reports instead is the part that holds whatever the crossing takes. A passenger catches some
bus if and only if the crossing takes no longer than the gap between leaving the mainland and the
last bus out of the terminal, which is arithmetic on two published figures. On the early sailings
that bound is hours wide and says nothing. On the last ones it is the whole question:

    One Mile, Gold Cats Flyer:      the 20:15 sailing needs a crossing of 18 minutes or less
                                    last bus out of One Mile 20:33
    Junner Street, SeaLink passenger: the 19:15 sailing needs a crossing of 30 minutes or less
                                    last bus out of Junner Street 19:45

So one published number, the crossing time of a passenger ferry, decides whether the last boat of
the day has a bus. That is the cheapest thing anybody could get from either operator and it is worth
more to this question than any amount of further work on the bus data.

## 4. The consolidation question, with no side taken

The owner recorded in board note 029 that Redland City Council is seeking to have Gold Cats
consolidate to Junner Street, and that the island and the operator both oppose it.
`--scenario flyer-to-junner` moves the landing point of every Gold Cats Flyer sailing and changes
nothing else. What the data supports:

    vessel movements   junner-street-dunwich   48 -> 76
    vessel movements   one-mile-dunwich        28 -> 0
    bus calls at stop 870027 that would then meet no boat of any kind:  40
    two or more vessels wanting one island landing in the same minute:  1 -> 14 times a day

**The connection quality for a Flyer passenger barely moves, and that is the finding.** The two
passenger timetables are identical on all fourteen island to mainland departures, so a Flyer
passenger at Junner Street would get the same twelve within fifteen minutes and the same two with no
bus that a SeaLink passenger gets today. The cost is not in the timetable. It is in the berth and in
the walk.

**Fourteen times a day, two vessels from two operators would want one island landing in the same
minute.** That is exact, because both timetables are held and both name that minute. Board note 030
already carries the reason they match, which is the owner's: both are pinned to the Cleveland train
and the buses at each end, so they cannot stagger without one of them losing the train. Whether the
berth can take that is an engineering question and board note 030 has it open. One same minute pair
already exists at Junner Street today, 17:30, where the last vehicle sailing and a passenger sailing
leave together.

**One Mile is not left with nothing to look at.** Forty bus calls a day would still call at stop
870027 and meet no boat, and the straight line between the two bus stops is 1,110 metres, computed
from the two published stop coordinates. That is a straight line between two bus stops, not a
walking distance and not a jetty to jetty distance, and neither of those is held here.

**What this cannot tell you, and it is most of what matters.** Whether a bus timetable would be
rewritten, which is the single largest thing that would really change and nothing in either pack
says a word about it. Whether the berth at Junner Street could physically take two operators at
once. Whether the Flyer would keep its times after a move. How many people use either landing, which
no source in this repository carries at all. Which mainland berth the Flyer uses. Anyone quoting the
numbers above without those four sentences is quoting them wrongly.

## 5. A correction to board note 029

Board note 029 says "Both island bus routes call at Junner Street and only the 881 runs to One
Mile." The second half is wrong. Both routes call at both terminals, and by the same counts:

    Friday 2026-08-21, calls by route
      Junner St Ferry Terminal (870029)      880: 24    881: 16
      Yabby St at One Mile Ferry (870027)    880: 24    881: 16

The 880 reaches One Mile at stop sequence 3 on its way to Point Lookout and at sequence 18 on its
way back to Dunwich. So the bus network is shaped around two landing points more strongly than that
note says, and the argument in section 4 above is stronger for it: if the Flyer moved, forty bus
calls at One Mile would be left, not sixteen.

## 6. The licence hold came off one lane, and the rule got narrower rather than weaker

`data/transport-gtfs.json` is committed. That was blocked by `tools/gate/derived.mjs`, which held
every derived pack behind board note 007 while that note was open. Board note 024 already put the
consequence in front of the owner: four lanes with four different licences held behind one question
about a fifth. Note 007 is the OpenStreetMap share-alike question and nothing else, and the
TransLink feed is Creative Commons Attribution 4.0 by data.qld.gov.au's own licence field.

The rule now reads the source ids a pack's own records cite, looks each one up in
`data/_sources.json`, and asks whether note 007 reaches that pack. It is blocking when a cited
source is registered under the Open Database Licence or published by OpenStreetMap, when a cited
source is not registered at all, and when a pack cites no source, because an unreadable licence is
treated as the blocking one. Two of the four marks stay blocking whatever the licence says: a
committed pack that names the staging inbox as its own provenance, and one that declares
`committable: false` about itself. Those are a pack contradicting itself rather than a licence
question.

Watched, not assumed:

    node tools/gate.mjs --rule provenance          provenance    clean
    node tools/gate.mjs --rule derived             PASS: 0 blocking, 1 advisory
    node tools/selftest.mjs --fault derived-committed      CAUGHT
    node tools/selftest.mjs --fault unprovenanced-derive   PASS 1 of 1
    node tools/selftest.mjs --fault missing-provenance     CAUGHT
    node tools/gate.mjs                            PASS: 0 blocking

The `derived-committed` fault plants an `osm-buildings` pack whose records cite `osm-overpass`, so it
is still caught, and it is caught for the right reason: the finding now says which source put it
behind the note. The advisory that remains on `data/transport-gtfs.json` is the rule saying out loud
that it has not decided the licence is satisfied, only that the OpenStreetMap question is not this
pack's question. The OpenStreetMap packs stay staged and board note 007 is untouched.

**Attribution is owed and is now discharged in exactly one place.** `data/_sources.json` carries the
required wording under `translink-gtfs-nsi`, the pack carries it in an `attribution` field, and
`tools/connections.mjs` prints it on every run. No player facing surface exists, so no screen carries
it yet.

## 7. What the pack gained, and the school holiday finding that fell out

`tools/ingest/gtfs.mjs --derive` now also emits the terminal week: every bus call at every stop the
publisher's own `stop_name` marks as a ferry terminal, for seven consecutive days from the feed's
own start date, so `--day` works for any weekday. Two of the 44 stops carry "Ferry Terminal" and
they are the two landings. 654 calls across 14 terminal service days.

    2026-08-19 wednesday 870029  40 calls        2026-08-22 saturday 870029  61 calls
    2026-08-21 friday    870029  40 calls        2026-08-23 sunday   870029  61 calls
    2026-08-21 friday    870027  40 calls        2026-08-22 saturday 870027  66 calls

The committed file is the connector's output and not a hand edit, proven rather than asserted:
re-running `node tools/ingest/gtfs.mjs --derive` and hashing both copies gives
`b5417960a914b4465784e36a1a653456a17745f0352138c9fb7e696665de7cc1` for
`ingest-inbox/derived/transport-gtfs.json` and for `data/transport-gtfs.json`, identical.

**The weekend has more buses at both terminals than a weekday, and it does not improve a single
connection.** Saturday has 61 calls at Junner Street against Friday's 40, and every summary figure
in section 1 is unchanged, because the extra Saturday services are terminating 880s and morning
departures that fall inside gaps the boats do not use.

One open question in `data/crossings.json` is now half answered for the buses. "How do these
timetables change in school holidays" is unanswerable for the ferries and answerable for the buses
in the same file we already hold: `calendar.txt` carries two further weekday services,
`NSI 26_27-42957` and `NSI 26_27-42959`, and `calendar_dates.txt` takes the term service out on
sixteen dates. The derived week is a school term week and the pack says so. Somebody should run
`--date` against a holiday week when the derive covers one, because the answer for a family in
January is a different answer.

## 8. What I did not check

- I did not open a browser and no figure here comes from a page.
- I did not fetch anything. Both packs were already on this machine.
- I did not open a SeaLink page or a Gold Cats page. The crossing times came from the owner through
  board notes 029 and 030 and are recorded that way in `data/_sources.json`.
- I did not verify the join between a bus stop and a jetty against anything but the two publishers'
  own names for them. That join is asserted in one place in `tools/connections.mjs`, is printed on
  every run, and is the first thing to argue with if a figure here looks wrong.
- I did not model a walk, a queue, a boarding time or a person. Nothing here says a wait of six
  minutes is enough to make the boat.
- The vehicle timetable is SeaLink's base timetable and extra sailings are added on its booking
  page, so every vehicle figure here is a floor.

## 9. What the next agent needs

**The crossing time for the two passenger services is now the highest value unknown in this
repository.** It is one number per operator, it decides whether the last boat of the day has a bus,
and it is the difference between an exact answer and a bound.
At Junner Street it leaves 28 of the 48 movements bounded rather than answered, and at One Mile all
28 of them.

Second: nothing on a screen carries the attribution the licence requires. The obligation is now
real, because a figure from this pack is being displayed by an instrument. The first panel that
shows a sailing time has to carry it.

Third: `tools/connections.mjs` has no fault row in `tools/faults.mjs`. It is an instrument by every
test this repository uses and it has never been watched failing. A fault that would prove it is a
bus call whose `pickupType` says no pickup being counted as a connection, which would make the
instrument report a boat as met by a bus nobody can board.
