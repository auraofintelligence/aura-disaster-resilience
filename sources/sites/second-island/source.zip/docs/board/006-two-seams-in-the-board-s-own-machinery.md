---
id: 006
title: Two seams in the board's own machinery
status: resolved
opened: 2026-08-18
author: wave 2, board and state agent
tags: board, gate, docs
resolved: 2026-08-18
---

Two things about the board's own machinery, found while building it. Neither is blocking and both
would be confusing to discover later.

**1. `docs/STAGE-0.md` shows a post command that the check would reject.**

Section 7 of that document gives:

    node tools/board.mjs post --title "..." --status open --body "..."

`tools/gate/board.mjs` requires five fields on every note, and `author` is one of them, so a note
posted without an author is a blocking finding the moment the gate runs. `tools/board.mjs` therefore
requires `--author`, or the environment variable `ISLAND_BOARD_AUTHOR`, and refuses with a message
naming the check rather than writing a note that fails it.

The specification and the check disagree, the check is right, and this task was told not to edit
`docs/STAGE-0.md`. Somebody with that file in scope should add `--author` to the example.

**2. The `board/empty` advisory can no longer fire.**

`tools/gate/board.mjs` treats every `.md` file in `docs/board/` as a note, and raises an advisory
finding `board/empty` when there are none. `docs/board/README.md` now exists, so the directory is
never empty again and that advisory is unreachable.

The README carries valid front matter, id `000`, status `resolved`, so the check passes rather than
failing on it, and `tools/board.mjs` leaves it out of the listing because it is the board's law and
not a finding anybody has to action. Before this change the gate printed `board: 1 finding(s), 0
blocking` with the empty-board advisory; it now prints `board  clean`.

The advisory was worth something: it was the line that said out loud that no agent had posted yet.
The honest replacement is a check that the board carries at least one note that is not the README,
and the person who adds it owns `tools/gate/board.mjs`, which this task was not asked to change.

**Update 2026-08-18, status open.** A third seam, found by testing this tool rather than by reading it. The first version of `nextId` in
`tools/board.mjs` counted only the note files present, so deleting note 009 and posting again
produced a second note 009. Fixed: the next id is now one past the highest of two witnesses, the
files on disk and every note file `git log --diff-filter=A -- docs/board` has ever seen added.
Receipt for the git witness, run against the first build, whose board is committed: 7 note files
returned. Run against this repository: nothing, because no note here is committed yet. So the gap is
narrowed and not closed, and the honest statement is in `docs/board/README.md`: a note created and
deleted before it was ever committed can still have its number reissued. Do not delete notes.
Fourth, for whoever compares the two builds: the first build's board notes use bare `key: value`
lines with no three-hyphen delimiters, so `node tools/board.mjs read --root ../minjerribah-living-twin`
reports all seven of them as unreadable. That is a difference in format between the builds, not a
fault in either, and it means the two boards cannot be read by one tool without a change nobody has
asked for.

**Update 2026-08-18, status resolved.** The docs/STAGE-0.md post example now carries --author, so it matches what tools/gate/board.mjs validates. The id reuse gap is real and stays documented in docs/board/README.md: it is a property of notes deleted before they were ever committed, and git log is the second witness.
