---
id: 027
title: OSM has 601 buildings. The island has at least 1703, and the owner said so before the data did
status: open
opened: 2026-08-19
author: orchestrator, on the owner's correction
---

Corrects board note 014 and the OpenStreetMap row of docs/INGEST-STATUS.md, both of which say the island has 601 building outlines. It does not. OpenStreetMap has 601 outlines for it, which is a different claim and the one that should have been written.

The owner said there are far more buildings than that. The census, already staged on this machine since 19 August, agrees with him and nobody had checked it against the roads and buildings lane.

2021 Census, table G36, SA2 301021550 North Stradbroke Island: total private dwellings 1703, occupied 842, so 861 unoccupied on census night, which is what a holiday island looks like in a table.

Per township, from the SAL geography, against the OSM counts in note 014:

  Dunwich        378 dwellings, OSM 92,  24 per cent
  Amity Point    353 dwellings, OSM 78,  22 per cent
  Point Lookout  858 dwellings, OSM 325, 38 per cent
  rest of island 111 dwellings, OSM 106, 95 per cent
  total         1703 dwellings, OSM 601, 35 per cent

Private dwellings only. The census does not count a shed, a shop, a hall, a depot, an amenity block, the school, the hospital, a surf club or anything left from the mining, so the real building count is above 1703 by an unknown margin.

The failure this repository exists to stop was the first build inventing 1922 building outlines while 1059 real ones sat unused. This is the same failure pointed the other way: taking a dataset's coverage and reporting it as the ground. It survived a wave, a critic who traced every number in it, and an orchestrator's summary, because all three checked that 601 was really what OSM said and none of them asked whether OSM was complete.

The general lesson, and it should become a rule: a count from one source is a count from one source. Where a second source counts the same things by another method, the two get compared before either is reported. The census and OSM were both on this machine for a day and nobody put them side by side.

Reproduce with: node out/dwell4.mjs, or read table G36 in ingest-inbox/census/2021_GCP_SAL_for_QLD_short-header.zip.

Open, not resolved: what actually fills the gap is undecided. Queensland's own buildings dataset excludes anything under 625 square metres and its publisher states there is no complete footprint dataset. This is a question for the owner and probably for people who live there, not for another connector.
