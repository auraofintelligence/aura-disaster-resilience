---
id: 020
title: A year of real past weather, and the first outside check the solar system has had
status: open
opened: 2026-08-19
author: wave 5, weather census and ecology ingest agent
tags: ingest, weather, era5, stage-2, stage-3, licence, solar
---

`tools/ingest/weather.mjs` now exists and was run end to end on 19 August 2026. A year of real past
weather is staged, and the lane produced one thing nobody asked for that is worth more than the
weather: the first external check the solar system has ever had.

Everything below is a command that was run and what it printed. Nothing here is a figure that was
not fetched.

## What was fetched

    node tools/ingest/weather.mjs --fetch

Three GETs to `archive-api.open-meteo.com/v1/archive`, HTTP 200 each.

    HTTP 200, 43008 bytes, 2854 ms, 365 days
    sha256 7bcd3da54ee43d9b4c018379d44705922e2f8a79890081d853d2ab1f2c8051ca
    grid    requested -27.4992, 153.4025 -> answered -27.5, 153.5, elevation 8 m

The window is pinned at 2025-08-01 to 2026-07-31 rather than relative, so two runs a month apart
can be compared. The archive lags: on 19 August 2026 the last day carrying values was 13 August, so
a window that ran to "today" would end in six days of nulls that a later reader would read as a
finding.

## What it says about this island

    node tools/ingest/weather.mjs --summarise

    WINDOW     2025-08-01 to 2026-07-31, 365 days, 0 with no value
    hottest day      29.3 degC on 2025-10-27
    coldest night    11.3 degC on 2025-08-03
    year total       1138.9 mm over 365 days
    wettest day      137.8 mm on 2026-02-13
    strongest gust   78.5 km/h on 2026-02-02

The check day, 2026-07-31, in full: maximum 18.7 degC, minimum 15.6 degC, mean 17 degC, rain 2.2 mm
over 9 hours, maximum wind 34.1 km/h gusting 50, dominant direction 156 degrees, radiation
13.02 MJ/m2. The hourly file for the same day carries 24 hours and its midday reading is 18.2 degC,
66 per cent humidity, no rain, 27.8 km/h from 157 degrees, 1026.9 hPa, 74 per cent cloud.

## Three things the next agent should not have to rediscover

**1. The grid cell is not the township, and it is 9.62 km away.** ERA5 is published on a 0.25 degree
grid. The request carried the Dunwich coordinate from `data/tide.json` and the API answered from the
cell centred at -27.5, 153.5, which is most of the way across the island. A cell at this latitude is
about 25 km across. Every derived record therefore carries `register: modelled` and
`confidence: medium`, and a panel that shows one of these numbers against a township name is making
a claim this pack does not support.

**2. A reanalysis is not an observation, and the observation rung is not fetched.** ERA5 is a model
run over assimilated observations. The nearest observation is the Bureau of Meteorology registered
data service, which this repository has not registered for, and the undocumented
`api.weather.bom.gov.au` is prohibited by its own terms. Under the founding prompt's source ladder
the bottom rung never wins in live mode, and this lane feeds a rung near the bottom.

**3. The second model is not a second opinion about the place, and it is not nothing either.**
`era5_land` was fetched beside `era5` on the theory that a finer grid might resolve this island
separately. It reports the same cell centre, -27.5, 153.5, and returns different values: of 365 days
compared on daily maximum temperature, 21 are identical and the largest gap is 2.1 degC on
2026-01-26, era5 26.7 against era5_land 28.8. So the coordinate the API echoes back is not a full
description of what was sampled, and the spread between the two is the closest thing this lane has
to an error bar. It is still not a check against an observation, because neither is one.

## The thing that was not asked for

`sunrise` and `sunset` were asked for in the daily request on purpose, and `--summarise` holds them
against `src/systems/solar.js`, which implements the NOAA equations for the same site with the same
fixed UTC+10 offset. Over 365 days:

    sunrise difference  min -0.5, median 0.93, max 2.37 minutes
    sunset  difference  min -0.54, median 0.74, max 2.52 minutes

Positive means this repository puts the event later. That is the first time the sun in this world has
been checked against anything outside it. `node tools/check-island.mjs` checks the solar model
against arithmetic done from the same document, which is a different and weaker claim.

**The defect I put in and took out, recorded because the next person will hit it.** The first run of
that comparison reported sunrise differences up to 78 minutes with a seasonal swing, which reads
exactly like a real finding about the solar system. It was not. `sunEvents(site, dayOfYear, inYear)`
takes days in the year, 365 or 366, as its third argument, and I passed the calendar year 2026. The
signature is documented in the file. The lesson is the general one: an instrument that disagrees
with a source is more often wrong about how it called the source than about the world, and 78
minutes was small enough to be believable, which is what made it dangerous.

## Licence, and an obligation this repository cannot yet meet

CC BY 4.0, stated at https://open-meteo.com/en/licence and read there on 19 August 2026. That page
adds a display obligation beyond the bare licence: a link next to any location the data are shown,
with `Weather data by Open-Meteo.com` given as the example, and it requires that changes be
indicated. Everything derived here is aggregated or compared, so changes were made and saying so is
part of the attribution. The underlying reanalysis is Copernicus Climate Change Service material
under the Licence to Use Copernicus Products.

Nothing player facing exists to carry any of that, so the obligation is owed and unmet. The
attribution string travels inside every pack the tool writes so it cannot be separated from the
numbers, and the first panel that shows a weather figure has to carry it.

## What is not committed, and why

`ingest-inbox/weather/` holds the three raw files and their receipts;
`ingest-inbox/derived/weather-era5-daily-2026-08-19.json` holds 365 provenanced records.
`node tools/ingest/weather.mjs --derive` printed `provenance: 0 problems` against
`src/kernel/record.js` and 10 source ids. None of it is committed. `git check-ignore -v` names
`.gitignore:3` for the file and `git ls-files -- ingest-inbox` returns nothing. CC BY is not what
blocks it; the wave's blanket hold is, and that lifts with board note 007.

`open-meteo-archive` is registered in `data/_sources.json`, which is committed because it is the
vocabulary, and registering a source is not a decision that the licence question is settled.
