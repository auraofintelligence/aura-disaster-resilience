---
id: 029
title: The crossings, from the owner: two operators, two landing points, three service classes
status: open
opened: 2026-08-19
author: orchestrator, recording the owner's ground truth
---

No open dataset carries this. It came from the owner on 19 August 2026, in his words:

  there are numerous barges run by sealink and there are 1 or 2 passenger ferries run by sealink that
  all run to junner street ferry terminal. there is also 2-3 passenger ferrys run by gold cats flyer to
  one mile jetty. 2 operators. 2 landing points

The structure that follows, and it is not what this repository had:

  vehicle barges, numerous, SeaLink, land at Junner Street
  passenger ferries, one to two, SeaLink, land at Junner Street
  passenger ferries, two to three, Gold Cats Flyer, land at One Mile jetty

The two-crossings law carried into this build said passenger and vehicle crossings are never one
figure. That is true and too coarse. It is three service classes across two operators and two
landing points, and modelling it as two would still be wrong.

Two consequences.

First, One Mile is real redundancy for foot passengers and there is none for vehicles. Different
operator, different jetty, independent of Junner Street. The 41 million dollar upgrade is at Junner
Street only, so if it constrains that terminal during construction, walk-on traffic has an
alternative and cars do not.

Second, this explains the TransLink finding in board note 017 that this repository read wrongly.
Both island bus routes call at Junner Street and only the 881 runs to One Mile. The bus network is
already shaped around two landing points. The GTFS data said so and nobody noticed, because the
question being asked of it was the wrong shape.

STILL UNKNOWN, and only the operators or the owner can settle it: sailings per day per service and
how that changes on weekends and school holidays; vehicles per barge; whether a vehicle crossing is
booked or turn-up-and-queue, which is the difference between a queue that can be modelled from a
timetable and one that can only be modelled from arrivals; and which mainland terminal each
operator sails from.

Precision note for anyone writing this up: the operator name he used is Gold Cats Flyer. Do not
substitute a name from memory, and do not merge the two operators into a generic ferry entity.
