---
id: 026
title: The silent 8 MB skip is closed, and it found a NUL byte in the kernel
status: resolved
opened: 2026-08-19
author: orchestrator, wave 5 close
---

Board note 025 and the wave 5 critic both named this: tools/gate/personal.mjs returned quietly on any file over 8 MB, so the gate printed clean over a bulk import that could hold a leaked number. Reproduced by hand before fixing: the same synthetic email in two files differing only in padding, caught at 71 bytes and missed at 9,437,264.

Fixed in three rules. personal/unreadable is blocking, because that rule stands between a public repository and a leaked contact detail. style/unreadable and ports/unreadable are advisory, because an unreadable file is a house style risk rather than a leak. All three now report the size, the limit and the reason instead of returning null. The NUL byte branch and the catch branch report too: all three were silent.

Registered as fault oversize-unscanned and watched being caught. The matrix is 28 of 28 green.

The fix immediately found a real defect that had been in the repository since its first hour. src/kernel/hash.js carried nine literal NUL bytes, its type tag separators, written that way by me on 18 August. Three gate rules had therefore never read the kernel's hash implementation at all, and nobody could see that because the skip was silent. Replaced with the escape sequence, which produces the identical byte at runtime: the world hash is ef810266 before and after.

Two things the critic asked for that are NOT done and stay open: the prediction in note 022 and the ingest-inbox row of INGEST-STATUS that hardening the regex patterns would raise 80 findings is misdirecting, since 77 of the 80 sit in the two files the rule never opened; and the TransLink GTFS row cites a command whose output it does not print.
