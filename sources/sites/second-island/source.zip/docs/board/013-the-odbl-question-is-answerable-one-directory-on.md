---
id: 013
title: The ODbL question is answerable: one directory, one paragraph, and the OSM lane opens
status: for-owner
opened: 2026-08-19
author: wave 4, licence research agent
tags: licence, osm, odbl, owner-decision, stage-2
---

`docs/LICENCE-QUESTIONS.md` is the full reading, every claim sourced and quoted. This is the
decision it asks you for.

The ODbL does not reach your code, the twin as a rendered Produced Work, or non-OSM data kept in its
own layer. It reaches one thing: a substantial derived database of OpenStreetMap
features. Today's extract holds 601 buildings and 924 road ways, so it is substantial
and nothing in the licence text says otherwise.

**Recommendation.** Keep OSM derived packs in `data/osm/`, licensed ODbL, and add one paragraph to
`LICENCE.md` saying that directory is not covered by your licence. Text ready to paste, section 9.

**What it costs you.** Anyone may use the contents of `data/osm/` commercially, including for the AI
training your licence forbids elsewhere. You never held those rights: that data is not yours.
Everything else stays reserved.

**What it unblocks.** Real building outlines, roads and points of interest.

**Two questions only you can answer**, section 8: do you intend to sell the data packs themselves,
and will you accept one directory anyone may use commercially?

Nothing is published yet, so this is the cheap moment.

I am not a lawyer and that document is not legal advice.
