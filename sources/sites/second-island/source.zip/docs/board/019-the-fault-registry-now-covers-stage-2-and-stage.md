---
id: 019
title: The fault registry now covers stage 2 and stage 3: 27 faults, 18 columns, and a new rule for the derived lane
status: open
opened: 2026-08-19
author: wave 4, fault registry and jurisdiction agent
tags: instruments, faults, jurisdiction, gate-derived, licence, stage-2, stage-3
---

The instruments now cover what stage 2 and stage 3 landed. `tools/faults.mjs` holds 27 faults against
18 instrument columns, up from 22 against 16 when stage 0 closed, and `tools/gate/derived.mjs` is a
new rule with two halves and a switch that is not in the rule. Everything below was run on
19 August 2026 between 18:55 and 19:52.

## The receipts

    node tools/selftest.mjs                                                     19:50
      PASS: 27 of 27 rows green, 0 not proven, 0 missed or caught for the wrong reason.
      wrote docs/JURISDICTION.md
      git status --porcelain: unchanged apart from docs/JURISDICTION.md.        about 65 seconds

    node tools/gate.mjs
      PASS: 0 blocking, 7 advisory                      the same seven, all in data/lore.json

    node tools/selftest.mjs --fault correction-overwrites --skip-browser     CAUGHT
    node tools/selftest.mjs --fault unprovenanced-derive  --skip-browser     CAUGHT
    node tools/selftest.mjs --fault derived-committed     --skip-browser     CAUGHT

    node tools/gate.mjs --rule derived
      derived       clean                                  1,939 records across four packs judged

    ISLAND_FAULT=correction-overwrites node tools/bitemporal.mjs --check
      FAIL: 4 of 35 checks failed, first a-correction-closes-the-old-belief-and-opens-a-new-one

The matrix on disk is the 19:50 run. It was not that answer for most of the previous hour, and
section 8 says what happened, because it is the most useful thing in this note for whoever runs the
matrix next.

## 1. Three rows added, two adopted

Board note 018 asked the next agent to adopt `frozen-clock` and `stale-wins` rather than write
duplicates. Adopted, untouched, both green. Three more:

- **`correction-overwrites`**, runtime, hooked in `src/world/bitemporal.js`, owned by `bitemporal`.
  The write half of the spine had no fault. `frozen-clock` breaks a read and `stale-wins` breaks the
  ladder, and nothing had been watched breaking the claim that a correction is a new belief rather
  than an edit, which is the whole reason the second time axis exists.
- **`unprovenanced-derive`**, tree, owned by `gate/derived`. A derived pack in the inbox with a
  record that carries an id, a source and a confidence and nothing else.
- **`derived-committed`**, tree, owned by `gate/derived`. A derived pack sitting under `data/`.

## 2. The check `nothing-is-overwritten` does not catch an overwriting store

Worth knowing before somebody trusts it. Under `correction-overwrites` four of the 35 bitemporal
checks fail and `nothing-is-overwritten` is not one of them. It holds a record reference captured
before the correction and still reads the old value, so what it proves is that the stored object is
not mutated, which is a narrower claim than its name. `the-timeline-holds-every-belief-in-order` is
the check that sees this fault, and it names the missing row:

    wanted:  [open, closed, closed for works]
    got:     [open, closed for works]

Both checks are worth keeping. The name of the first one is not worth trusting on its own.

## 3. `tools/gate/derived.mjs`, and the switch that turns it off

Two rules. `derived/committed` looks for four marks of a derived pack under `data/`: a pack name a
connector under `tools/ingest/` actually writes, read out of the connector source rather than listed
in the rule so a new connector is covered the day it lands; a string pointing at `ingest-inbox/`; a
`committable: false` the pack declares about itself; and a bulk feature set, fifty or more entries
that almost all carry both geometry and full provenance. `data/tide.json` and `data/lore.json` both
carry a top level `pack` field, so "has a pack field" is deliberately not a mark: a rule that fires
on everything gets ignored.

`derived/unprovenanced` reads every record under `ingest-inbox/derived/` and requires the eight
fields. It is the only gate rule that looks inside a staging tree. `docs/CONTRACT.md` section 3 binds
every record in `data/**` AND every record the twin creates at runtime; `gate/provenance` covers the
first half and skips the staging trees, and until now the second half was checked only by each
connector checking itself, which is a claim rather than a measurement. Source ids are NOT checked
against `data/_sources.json` here, because registering a derived source id is itself a commit and
this wave commits nothing derived.

**The switch is board note 007's `status` field.** While it reads anything other than `resolved`, the
marks are blocking. The day the owner settles the ODbL question and 007 is resolved, the rule stands
down by itself and reports what it would have blocked as advisory. Nobody should edit the rule to
land a derived pack. `docs/LICENCE-QUESTIONS.md` is the reading behind the decision and carries no
machine readable verdict, so it is named in the finding but is not the switch.

## 4. The rule found a real half provenanced object on its first day, and I decided it was not one

While this was being written the weather lane wrote `ingest-inbox/derived/weather-era5-daily-2026-08-19.json`.
Its 365 day records carry all eight fields. Its `site` block does not: it carries `id`, `name`, `lat`,
`lon`, `crs`, `source` and `locator`, and no times and no register. My first version of the rule
called that a broken record. I decided it is not one and tightened the rule instead: an object
qualifies as a record when it has an id and at least one field only a record carries, meaning a time
bound or a register. Citing a source without claiming a moment is a descriptor, and the `site` block
is an honest descriptor saying where the twin got Dunwich's coordinate from.

**What the next agent needs to know about that decision.** `gate/provenance` would NOT agree. Its
rule for `data/` is that any object carrying one of the eight is a record, so on the day that pack is
committed the `site` block is blocking unless it gains the eight fields or the coordinate moves onto
a record of its own. That is a question for the weather lane and for whoever commits the first
derived pack, and it is written here rather than discovered then.

## 5. Two defects in the measurement itself

**The generated matrix carried a false line.** Its footer said there is no commit-msg hook. That
stopped being true at commit `d845a1d`. `tools/hooks/commit-msg` exists and was watched refusing a
message carrying U+2014 and passing a clean one. The footer now says so, and says why that half can
never be a row here: `.git/hooks` is not tracked and no agent in this repository runs a state
changing git command.

**A flaky cell could write `caught` into the published matrix.** `tools/headless.mjs` fails about one
run in six on this machine when a tick goes over budget with no collector pause to account for it.
One run of this matrix recorded `headless caught` against `stale-wins`, a fault whose only branches
are in `src/world/ladder.js`, which `headless.mjs` does not load. `tools/selftest.mjs` now retries a
failing column that the fault does not own, once, and prints both attempts, which is the convention
`healthySuite` already used. The owning column is never retried: it is the row's verdict and
`mustName` already decides it. The underlying flake is not fixed and is not mine: it is a budget in
`tools/budgets.json` against a machine that sometimes takes the thread away.

## 6. The crash guard was watched working, not assumed

The one thing this whole exercise can fool itself with is an instrument that crashed being counted as
an instrument that saw something. I proved the guard rather than asserting it. In a throwaway copy
under `out/`, the `correction-overwrites` branch was changed to call a function that does not exist,
so the instrument throws under the fault and passes without it:

    node out/crashproof/tools/selftest.mjs --fault correction-overwrites --skip-browser
      correction-overwrites   bitemporal   WRONG REASON   bitemporal failed with a crash signature
        (is not defined), which is a failure it survived rather than a fault it caught
      CLAIM DISAGREES: correction-overwrites  the registry declares proven: true and this run says
        wrong reason
      FAIL: 0 of 1 rows green

The copy was deleted afterwards. The guard works, and so does the claim check that reports a registry
saying `proven: true` about a row this run did not see caught.

## 7. What is still not measured

- **`docs/STAGE-0.md` prints the original seventeen row registry table** and is now five waves behind
  `tools/faults.mjs`. Nothing in the gate compares them. `docs/JURISDICTION.md` is generated and is
  the current answer.
- **`docs/CONTRACT.md` section 3 gained a check and does not say so.** The derived half is now
  checked by `gate/derived`. That file was not this task's to edit.
- **`personal-data-staged` is still a blind spot** and this rule does not close it. `gate/derived`
  reads the inbox for provenance, not for contact details. Closing it still needs a scan at ingest
  time.
- **`derived/unprovenanced` reads a gitignored tree.** On a fresh clone it reads nothing and reports
  nothing. Silence from that half is silence, not a pass. Run the connectors, then
  `node tools/gate.mjs --rule derived`.

## 8. The `void` verdict fired for the first time today, twice, and what that means

Between 19:10 and 19:50 the same command gave three different answers, and every one was correct at
the moment it ran. This is the most reusable thing in this note.

| time | result | why |
| --- | --- | --- |
| 19:10 | 27 of 27 green | a quiet tree |
| 19:38 | 26 of 27, `em-dash` **void** | `tools/ingest/ecology.mjs` landed naming the Atlas of Living Australia's own `license` facet with a determiner in front of it, which `gate/style` calls American spelling, so `gate/style` was red on the healthy tree |
| 19:44 | 25 of 27, `personal-data` **void**, `personal-data-staged` not proven | `docs/INGEST-STATUS.md` and a new board note landed quoting the digit strings that `gate/personal`'s own patterns had matched during a hand scan, so the rule matched the report of itself |
| 19:50 | 27 of 27 green | both lanes corrected their own lines within minutes |

`void` means the instrument already fails on the healthy tree, so its failure on the faulted tree
proves nothing. It is the meta-instrument declining to award a catch it did not earn, and no row had
reached it before today. Both causes were false positives in prose rather than defects in code, both
were one edit away, and neither was this task's to make.

I did not take the void on trust either. A throwaway copy under `out/` with that one ecology line
corrected, deleted afterwards:

    node tools/gate.mjs --root out/styleproof          PASS: 0 blocking, 10 advisory
    node out/styleproof/tools/selftest.mjs --fault em-dash --skip-browser
      em-dash   gate/style   CAUGHT
      PASS: 1 of 1 rows green, 0 not proven, 0 missed or caught for the wrong reason.

**Two things follow.**

**The matrix is a photograph of the tree at the moment it was taken.** Run it when the wave is
quiet, read the date in its own header, and treat a `void` row as a question about the healthy tree
rather than about the fault. Board note 018 declined to run it for exactly this reason and was right.

**The style and personal rules have a seam, and it now has three independent reports.** Board note
016 hit it quoting the ODbL and worked around it. The ecology lane hit it naming a published field.
The ingest lane hit it reporting which strings a pattern had matched. Writing this note tripped it
twice more, here and in `docs/STATE-OF-PLAY.md`, because quoting the offending string is itself the
offence, and I worked around it too. That is five workarounds and no answer. A rule you cannot
describe without breaking needs a way to quote: a fenced block the scanners skip, an inline marker,
something. It is not mine to design, it is not urgent, and it will keep costing an edit per document
until somebody does it.
