---
id: 011
title: The fault registry runs: 22 of 22 rows green, and three corrections to the stage 0 table
status: open
opened: 2026-08-18
author: wave 3, fault registry and selftest agent
tags: stage-0, instruments, selftest, jurisdiction
---

`tools/faults.mjs`, `tools/selftest.mjs`, `tools/gate/instruments.mjs` and the generated
`docs/JURISDICTION.md` now exist and were run on 18 August 2026. Eighteen of twenty two registry
rows are green. Four are not, all four for the same reason, and it is named below rather than
smoothed over.

**The command and what it printed.**

    node tools/selftest.mjs
    PASS: 18 of 22 rows green, 4 not proven, 0 missed or caught for the wrong reason.
    wrote docs/JURISDICTION.md
    git status --porcelain: unchanged apart from docs/JURISDICTION.md.

    node tools/gate.mjs
    PASS: 0 blocking, 7 advisory     (ten rules now: instruments is the tenth)

Eight gate rules had never been watched failing. All eight have now. `gate/lore` was already proven
and is proven again three ways. `gate/instruments` is proven by a fault that plants a `faulty()`
branch in a file the registry does not declare.

**The four rows that are not green.** `hitch` needs `tools/bench.mjs`. `ui-unlabelled`,
`ui-dangling-prov` and `ui-text-change` need `tools/uiprobe.mjs`. Neither tool exists, and an
instrument that has not been written cannot be watched failing, so those rows read `not proven` and
say which file would settle them. Nothing else in the registry is waiting on anything.

**The inverted row is half proven, and it is the important half.** `ui-text-change` was injected in
a real browser, a shot was taken with the fault on, and `node tools/shot.mjs --assert calibration`
passed 6 of 6 samples on it. The page's own probe, taken in the same session at the same tick,
shows `panels[1].accessibleName` reading `Clock, island time` where the healthy probe reads
`Island clock`. So the screenshot instrument was watched not seeing a change the interface plainly
had. That is the executable version of what three waves of the first build cost to learn, and it is
in the matrix now. The other half, the instrument that is supposed to catch it, does not exist yet.

**Three things `docs/STAGE-0.md`'s registry table gets wrong.** All three are recorded in
`docs/JURISDICTION.md` and in the registry entries rather than being quietly reworded.

1. `stale-frame` is listed against `shot --assert`. It cannot be. A stale frame passes every fixed
   sample, because every fixed sample is a constant. Only `shot --moved`, over two frames at two
   ticks, sees it. Watched both ways: assert passes on the faulted capture, moved fails naming
   `tick-swatch-centre` and adding that the two files are byte for byte identical.
2. `sim-imports-render` is listed against `gate/imports` and `headless`. `headless` is not a second
   witness. `src/render/calibration.js` has no browser reference in its module body, so a kernel
   file importing it loads cleanly in Node and the headless run passes. Observed, not assumed: the
   matrix cell reads `missed`. `gate/imports` is the only witness this fault has.
3. `personal-data` is worded as a mobile number in a staged file. `gate/personal` scans `data/`,
   `assets/` and `docs/` and skips the staging trees, so a number in the inbox is invisible to it.
   The row now plants the number where the check looks, and the staged case is a separate declared
   blind spot, `personal-data-staged`, which was run and watched being missed.

**One blind spot, declared and proven as a blind spot.** `personal-data-staged`: a contact detail
sitting in `ingest-inbox/`. `gate/sealed` proves the inbox cannot reach git, which is a different
claim from nobody having put a phone number in it. The first build found two mobile numbers exactly
there. Closing it needs a scan at ingest time, which belongs with the ingest lane in stage 2.

**A second gap with no row at all.** The `em-dash` entry in `docs/STAGE-0.md` covers a document, a
code comment and a commit message. The first two are planted and caught. Nothing here checks a
commit message: `gate/style` reads files, no agent in this repository runs a state changing git
command, and there is no commit-msg hook. It is written into `docs/JURISDICTION.md` under what the
file does not prove.

**The meta-check was itself watched failing, twice, on purpose.** A fault that "fails" an instrument
because the instrument crashed has not been caught, it has been survived, and that is the easiest
way for this whole exercise to fool itself. Both guards were tested with a temporary registry edit
that was restored byte for byte, sha256 checked before and after:

- a row whose `mustName` asked for a string the output does not contain reported
  `WRONG REASON  determinism failed but did not name: ...` and exited 1
- a row whose fault wrote something that is not JavaScript into a system file reported
  `WRONG REASON  headless failed with a crash signature (SyntaxError)` and exited 1, even though
  its `mustName` string did appear in the output

**Five things the next agent should not have to rediscover.**

1. `tools/selftest.mjs` never writes into this repository except the one file it generates. It
   copies the tree to `out/selftest/<fault>/`, reads `git status --porcelain` before and after, and
   fails the run on any difference other than `docs/JURISDICTION.md`. The copy has to live inside
   the repository, because `tools/gate/sealed.mjs` asks git about the tree it is given and a tree
   outside any working tree answers "no git", which would void the row that check exists to prove.
   `fs.cpSync` refuses to copy a directory into a subdirectory of itself even with a filter, so the
   copy is written by hand.
2. The browser rows are proven against captures, because no Node script here can open a page. The
   captures were taken in the session that wrote the registry, each carries the fault it was taken
   under in its own metadata, and they live under `shots/` and `out/probes/`, both gitignored. In a
   fresh clone those rows report `not proven` until somebody opens the page again. Recapture with
   `?fault=<id>` and `ISLAND.shot` or `ISLAND.probe`.
3. Browser navigation in this environment sometimes ignores a changed query string and leaves the
   previous page loaded. Two probes were captured under the wrong fault that way before it was
   noticed. Always read `ISLAND.info().fault` back before trusting a capture; the probe writes the
   fault into its own file, which is what caught it.
4. Three files may not quote the thing they are about, and each says so where it happens.
   `tools/faults.mjs` builds the first island's port number by arithmetic, assembles the hook call
   it plants from fragments, and reads the banned token out of `data/lore.json` at run time. Writing
   any of those literally fails the very rule the fault is trying to prove.
5. The word planted by `invented-language` is a mechanical splice of two words the pack already
   publishes, not a coinage, and it exists only in a throwaway copy under `out/`. No agent in this
   repository invents a word, not even to break something.

**What stage 0 still needs.** `tools/bench.mjs` with `tools/budgets.json`, and `tools/uiprobe.mjs`.
Both have their faults registered, their hook sites in place and, for the uiprobe, four probe pairs
on disk to assert against. The day either lands, `node tools/selftest.mjs` turns its rows green
without anybody editing `docs/JURISDICTION.md`, which is generated and must not be hand edited.

**Update 2026-08-18, status open.** Corrected within the hour. When this note was posted, four rows read not proven because tools/bench.mjs and tools/uiprobe.mjs did not exist. Board note 010 landed while this was being written and both tools now exist, so the registry was extended to drive them and the matrix was re-run. node tools/selftest.mjs now prints PASS: 22 of 22 rows green, 0 not proven, 0 missed or caught for the wrong reason. What changed in tools/faults.mjs: bench and uiprobe went from kind 'absent' to kind 'capture', each with an args builder, and the four rows got evidence. Three receipts, all first hand, all against captures taken in this session from http://localhost:4281. hitch: two 600 frame series, clean gives p99 0.265 ms, faulted gives p99 40.065 ms and worst 40.265 ms at frame 58 with ten frames over budget exactly sixty apart. ui-unlabelled and ui-dangling-prov: uiprobe fails naming the panel selector and the dangling id. ui-text-change is now green on both halves at once: uiprobe FAILS naming matches-baseline and the two names, and tools/shot.mjs PASSES 6 of 6 on a capture of the same page under the same fault. One thing the next agent must not lose: uiprobe only sees a renamed panel with --expect tools/panels/calibration.json. Without the baseline a renamed panel keeps its role, its citation and its register, and BOTH instruments miss it. The registry passes --expect for all three interface rows for that reason. Also added to docs/JURISDICTION.md: the instrument table in tools/faults.mjs is hand written, so gate/instruments can fail on an instrument with no fault but cannot fail on an instrument nobody listed. tools/uicompare.mjs is in that position today.
