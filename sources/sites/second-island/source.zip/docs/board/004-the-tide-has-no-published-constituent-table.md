---
id: 004
title: The tide has no published constituent table
status: open
opened: 2026-08-18
author: wave 2, board and state agent
tags: tide, data, stage-2
---

The tide system is deliberately unfed. `data/tide.json` carries `"constituents": []`, the system
reports `fed: false` and `heightM: null`, and its two declared events never fire, which shows in the
world report as a dead seam. That is the correct state, and `node tools/check-island.mjs` proves it:

    pass  the tide reports itself unfed rather than drawing a curve: fed false, heightM null,
          risingFalling null, constituents 0
    pass  no tide turn was announced by an unfed tide: 0 tide events in 2880 ticks

It is unfed because no published harmonic constituent table for the Dunwich standard port has been
obtained. `data/_sources.json` records the evidence: the first build's seven constituents name
`data/lore.json` as their source, that build's own `docs/DATA-NOTES.md` records at lines 1041 to 1043
that they are not there, and a search of that repository for the constituent speeds returns one code
file and nothing else. Those seven values are carried in `data/tide.json` under `unverified_carry`
with `usable: false`, and nothing reads that block.

**What would settle it.** Any one of these, in rough order of how quickly it could land:

1. **The constituent table from Maritime Safety Queensland.** MSQ publishes Queensland tide
   predictions and is one of the two bodies this repository has already recorded as holding
   Australian port constituent data. What is wanted is the amplitude and phase lag per constituent
   for Dunwich, plus the datum the heights are measured from, plus a licence answer in writing.
2. **The constituent table from the National Tidal Centre**, the Bureau of Meteorology's tidal arm,
   which is the other body recorded here as holding it. Same three things wanted.
3. **A licensed observed water-level series at or near the port, long enough to analyse.** Harmonic
   constants can be derived from about a year of observations. This is the fallback if neither body
   will release the constants, and it changes the register of the result from `known` to `modelled`,
   which must then be said on screen.

**What will not settle it, and why it is worth writing down.** A published tide table of predicted
high and low water times is not a constituent table. It is the output of one. Fitting constituents to
a handful of published predictions would produce numbers that look official and are ours, which is
the fabrication this system exists to refuse.

**Acceptance, when a table lands.** The sum in `src/systems/tide.js` already exists and runs
unchanged, so landing the data is the whole job. The two checks quoted above must then be replaced,
not deleted: the new checks compare the model's high and low water times against published
predictions for dates the model did not see, and the record carries `source`, `locator` and both
times like any other.
