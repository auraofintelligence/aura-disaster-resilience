---
id: 010
title: The interface probe and the frame time instrument, and a tool that reported agreement when a value was missing
status: open
opened: 2026-08-18
author: wave 3, interface probe and frame time agent
tags: stage-0, instruments, uiprobe, bench, faults
---

`tools/uiprobe.mjs`, `tools/uicompare.mjs` and `tools/bench.mjs` now exist and have been watched
both passing and failing, on hand written fixtures and on the real page. The receipts are below, and
so are four things the next agent should not have to rediscover. One of them is a defect I put in
this repository myself and then found by running the tool against a page at a different tick.

## What was run, 18 August 2026

Fixtures are hand written under `out/fixtures/`, which is gitignored scratch. Real files are what
the running page posted to `out/probes/`.

**`tools/uiprobe.mjs`, the four contract rules plus five more, over nine hand written fixtures and
five real probes.** `probe-good` passes. Each of six known bad fixtures fails with exit 1 and names
the element: a panel with no accessible name, a citation that resolves to nothing, a tide height
shown as `1.42 m` while `data/tide.json` carries no constituents, a marker with a number beside it,
a page marking its own dangling citation resolved, and a panel with no role whose value has no
citation and an invented register. On the real probes: `calibration` and `healthy-tick0` pass ten
rules over five panels and eight values, `fault-ui-unlabelled` fails naming
`[data-panel="sun"]`, and `fault-ui-dangling-prov` fails naming `dunwich-tide-constituents` and
`[data-panel="tide"] [data-value="tide-height"]`.

**`tools/bench.mjs`.** A hand written 200 frame series with a 12 ms worst frame passes. A hand
written series whose p99 is 1.3 ms and whose worst frame is 40 ms fails, which is the shape the
first build shipped for a week. On the real page: 600 frames with no fault give p99 0.255 ms and
worst 2.43 ms and pass; 600 frames under `?fault=hitch` give p99 40.08 ms and worst 40.35 ms at
frame 418, and the ten frames over budget are 58, 118, 178 and so on every sixtieth frame, which is
what the registry says that fault does. No average is computed anywhere in the tool.

**`tools/uicompare.mjs`.** A hand written tree and a matching self report agree. Four hand written
lies against that same tree each fail: a panel the tree does not hold, a name that disagrees with
the heading, a value the tree does not hold, and a marker buried in prose rather than being a node
of its own. On the real page, two capture and probe pairs taken at the same moment agree.

`node tools/gate.mjs` still prints `PASS: 0 blocking, 7 advisory`.

## 1. This tool reported agreement when a value was missing, and I found it by changing the tick

The first version of the text matching rule in `tools/uicompare.mjs` accepted any substring in
either direction. I captured a fresh accessibility tree at tick 1305, which is night, where the
daylight row reads `no`. The capture had no node for that value at all. The tool printed:

    No contradiction: every panel, name and value the page reported is corroborated by the capture.

It was matching `no` against the letters inside `register: known`, one node away. An instrument that
answers agreement by accident is worse than no instrument, because somebody believes it. The rule
now carries length floors and a word boundary, and `out/fixtures/probe-tree-substring-lie.json`
pins it. Nothing was wrong with the page: the wave 3 capture was taken at tick 720, where the same
row reads `yes`, and at that tick the tool was right for the wrong reason.

## 2. The accessibility capture drops a text shorter than three characters

Checked twice on the same page rather than assumed. At tick 1305 the daylight row read `no`, the DOM
held it, checked at the console with `document.getElementById('value-daylight').outerHTML`, and the
capture had no node for it. Stepping the same page to tick 2160, where the row reads `yes`, brought
the node back at `ref_57`. Under `?fault=ui-text-change` at tick 0 the tick row reads `0` and it is
missing too.

So a reported text shorter than three characters can be neither corroborated nor contradicted from a
capture. `tools/uicompare.mjs` now reports that as UNSETTLED, says so in its verdict line, and fails
on it under `--strict`. It is not counted as agreement, because it is not agreement. The threshold
comes from one observed pair and is written in the tool as an observation rather than as a rule of
the tool that produced it.

## 3. `ISLAND.bench` posts to a fixed name, so a faulted run overwrites the healthy one

`src/main.js` line 328 posts to `/__probe/bench` with the name hard coded. When I started,
`out/probes/bench.json` and `out/probes/bench-hitch.json` were byte identical, both hitched, md5
`a440b0c1b1f8e4184d15eb7cd712de4b`. The healthy series had been overwritten by the faulted run and
the default file `tools/bench.mjs` reads was a faulted one. I re-ran both and the two files are now
what their names say, but the next agent to bench a fault will overwrite the healthy series again.

The fix belongs in `src/main.js`, which is not this task's lane: `ISLAND.bench(frames, name)`, the
way `ISLAND.probe(name)` and `ISLAND.shot(name)` already work.

## 4. What `tools/faults.mjs` should change, exactly

That file was written an hour after these three tools landed on disk and says they do not exist. Four
rows are now provable.

- `INSTRUMENTS.bench` and `INSTRUMENTS.uiprobe`: `kind: 'absent'` becomes `kind: 'capture'`. Both
  read a recorded artefact and neither drives a browser.
- `hitch`: healthy `out/probes/bench.json`, faulted `out/probes/bench-hitch.json`, both 600 frames
  posted today. `node tools/bench.mjs --assert --file <path>` exits 1 on the faulted one and names
  p99, the budget and the worst frame with its frame index.
- `ui-unlabelled`: the failure line now reads `accessibleName is empty` at
  `[data-panel="sun"]`, so `mustName: ['accessibleName', 'sun']` matches literally.
- `ui-dangling-prov`: names `dunwich-tide-constituents` and `tide-height`, as the row requires.

**`ui-text-change` needs an argument, and this is the row the whole exercise is for.** The four
contract rules cannot see a renamed panel: it keeps its role, its name, its citation and its
register, so it is honest in every respect except being different. Only a baseline declared outside
the page catches it, and it is off unless it is named:

    node tools/uiprobe.mjs --assert <probe> --expect tools/panels/calibration.json

Without `--expect` that probe passes nine rules and exits 0, and the run says so in its output
rather than letting a green line stand for a check nobody made. The baseline is committed at
`tools/panels/calibration.json`, written by hand from `src/ui/panel.js` and `index.html`. It could
not live under `out/`, which is gitignored, and it is to the interface what
`tools/scenes/calibration.json` is to the picture. When a panel is deliberately renamed, that file
is edited in the same commit.

There is a second half to that row. I ran `tools/uicompare.mjs` against a live capture of
`?fault=ui-text-change` and it **passes**, correctly: the heading and the accessible name change
together, so both witnesses see the same renamed panel, they agree with each other, and they are
both wrong. The registry's `mustMiss` names `shot`. On the evidence it should name `uicompare` as
well, and the row's instrument should be uiprobe **with the baseline argument**, or the matrix will
show a row that is green in a run nobody could reproduce.

## 5. What is still not settled

An accessible name is still not confirmed by anything outside the page. `read_page` prints a node's
role and its text and does not compute a name, and `window.getComputedAccessibleNode` is undefined
in this browser. `tools/uicompare.mjs` compares the reported name with the heading that
`aria-labelledby` points at, which is evidence and not proof, and its header says so. Settling it
needs a Chrome DevTools Protocol capture, `Accessibility.getFullAXTree`, and nothing here speaks
that protocol.

The page's self report carries panel names and value texts and not the row labels beside the values,
so the `ui-text-change` fault's second half, the changed row label `Elevation of the sun`, is
invisible to both instruments. It is visible in a capture. Closing it means `src/ui/panel.js`
reporting labels, and that is a page change, not an instrument change.
