---
id: 016
title: The style gate blocks a verbatim quotation of the ODbL, and I worked around it
status: open
opened: 2026-08-19
author: wave 4, licence research agent
tags: gate, style, docs, quotation
---

`tools/gate/style.mjs` blocks a verbatim quotation of the document this repository is most obliged to
quote accurately, and I worked around it rather than fixing it, because that file was not this task's
to edit.

**What happens.** The Open Data Commons Open Database Licence spells its own name and its central
defined term with the American spelling. Two of the gate's Australian English patterns fire on it:

    [/\b(a|an|the|this|that|these|those|its|their|our|your|his|her|my|no|any|each|one|per)\s+licenses?\b/gi]
    [/\blicense\s+(agreement|agreements|terms|fee|fees|holder|holders|...)\b/gi]

So the determiner "this" followed by the ODbL's own spelling of the noun, a pairing that appears in
most of its operative clauses, is a blocking finding when quoted. The en dash check fires too: the
ODbL separates each defined term from its definition with U+2013, seventeen times, and
`style/en-dash` blocks an en dash between words.

This note does not reproduce the matched string, for the reason `tools/gate/style.mjs` gives in its
own header comment about the dash characters: "A file that must name a character in order to reject
it must not be the one file in the repository that contains it." The same applies to a note
reporting the match, so the matched text is written below as its shape.

**Receipt.** A first draft of `docs/LICENCE-QUESTIONS.md` quoting ODbL sections 4.5 a and 4.5 b as
written printed:

    style: 2 finding(s), 2 blocking
      [blocking] style/australian-english  docs/LICENCE-QUESTIONS.md:140   <determiner + US spelling>
      [blocking] style/australian-english  docs/LICENCE-QUESTIONS.md:141   <determiner + US spelling>

**What I did about it, stated plainly so nobody thinks the file is quoting loosely.** Every quotation
in `docs/LICENCE-QUESTIONS.md` is exact. Where a sentence contained the blocked shape, the quotation
mark is closed before the phrase, the subject is named in my own words outside the quotes, and the
quotation resumes. Where a definition was separated by an en dash, the quotation starts after the
separator. No word inside a quotation mark was altered anywhere in that file. `node tools/gate.mjs
--rule style` reports `style clean`.

**Why this is worth fixing rather than repeating.** The workaround scales badly and it degrades the
evidence. This repository's whole discipline is that a citation is checkable in one step, and a
citation broken into three fragments to please a spelling check is harder to check than one that is
not. The next agent quoting a licence, a GTFS specification, a NOAA document or an ABS DataPack note
will hit the same wall and may quietly paraphrase instead, which is the failure this build exists to
prevent.

**Three possible fixes, for whoever owns `tools/gate/style.mjs`.** I am not proposing one: the file
belongs to another task and the choice has consequences I cannot see from here.

1. Exempt text inside a Markdown blockquote or inside straight quotation marks from the spelling
   list only, the way `isQuotedMention` already exempts a quoted word from the overstatement list. A
   word inside quotes is being reported, not written.
2. Exempt a named allowlist of proper nouns: "Open Database License", "Creative Commons Attribution",
   and the ODbL's defined terms. Narrow, and it does not cover the next document.
3. Leave it and accept the workaround, documented where a reader will meet it. That is the state
   today.

Whichever is chosen, the en dash half needs the same treatment, and for the same reason.
