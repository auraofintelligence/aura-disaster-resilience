---
id: 002
title: A cultural correction the first build made in code is still live in its data
status: for-owner
opened: 2026-08-18
author: wave 2, board and state agent
tags: cultural, first-build, gate-lore
---

A cultural correction the first build made in its code did not reach its data, and the misuse is
still live there today. This repository may not edit the first build, so this note is the whole of
what we can do about it. Everything below was checked with read-only commands on 18 August 2026.

**What is still in the first build**

`minjerribah-living-twin/data/feeds/_events-engine.json`, line 637, record index 12 of 63, id
`qcee-quandamooka-festival-2026`, carries the field:

    "listing_period": "Yalingbila / winter-spring transition"

**Why that is wrong, by the first build's own pack**

`minjerribah-living-twin/data/lore.json` line 260 publishes Yalingbila in its language allowlist as
referring to whale, sourced to `uq-yalingbila-bibula`, the University of Queensland page on the
Yalingbila Bibula project at Mooloomba, a QYAC, UQ and Queensland Government partnership published in
English as Whale on the Hill. The same entry's `usage` field reads: use it only as part of the
project name or as the name of the SeaLink vessel, and "Do not use the bare word as a label for a
season, a month, an animal in the sim or anything else."

The same entry carries a `correction_note` at line 267: "src/kernel/clock.js previously glossed
Yalingbila as a season meaning hot wet time. That was wrong. It has been removed."

It is removed from that file. `minjerribah-living-twin/src/kernel/clock.js` now carries only a
cultural note about the removal, at lines 108 to 117, and plain descriptive English season names.

So the correction landed in the code, was written down in the pack, and did not land in the data
feed. The field is called `listing_period` rather than `season`, which is exactly why a check keyed
on the word "season" walks straight past it.

**Commands, all read-only, run in the first build's directory**

    grep -rn "Yalingbila" -i . --include=*.js --include=*.json --include=*.md
    node -e "JSON.parse(fs.readFileSync('data/feeds/_events-engine.json')).records[12]"
    sed -n '105,125p' src/kernel/clock.js

**second-island catches this class of misuse, and here is the receipt**

`tools/gate/lore.mjs` in this repository does not stop at the allowlist. For an allowlisted word it
reads every published meaning the pack carries for that word and asks whether any of them says the
word names the kind of thing it is being used to name. It infers the kind from the key, where
`listing_period` is one of its `KIND_PATTERNS`, and from plain English companions in the value, where
`winter-spring` is one of its `KIND_COMPANIONS`. Nothing in the pack says Yalingbila names a season,
so it blocks.

Proof, run here today against a copy carrying that one record verbatim:

    cp data/lore.json out/yalingbila-proof/data/lore.json
    # record 12 copied verbatim into out/yalingbila-proof/data/feeds/_events-engine.json
    node tools/gate.mjs --rule lore --root out/yalingbila-proof

    lore: 10 finding(s), 1 blocking
      [blocking] no-invented-language  data/feeds/_events-engine.json:20
          "listing_period": "Yalingbila / winter-spring transition",
    FAIL: 1 blocking, 9 advisory

The healthy run of the same rule on this repository is `PASS: 0 blocking, 9 advisory`.

**What is for you to decide**

The fix is one string in one record in the other repository, and it is yours to make or to direct,
not ours. QYAC has not seen either project, so no part of this is settled by anyone here. If the
first build wants the same protection, `tools/gate/lore.mjs` from this repository is the check that
raises it, and the two builds share `data/lore.json` byte for byte: sha256
`0d3e65ceee59c1711b729c81a83a669f96ba1f17e6c36acb139111ed12b016d0` in both.
