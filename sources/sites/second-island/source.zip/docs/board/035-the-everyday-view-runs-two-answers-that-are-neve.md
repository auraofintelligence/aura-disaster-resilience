---
id: 035
title: The everyday view runs: two answers that are never one, and the minute the clock was ahead of the systems
status: open
opened: 2026-08-19
author: wave 7, everyday view agent
tags: ui, crossings, stage-4, uiprobe, gtfs, licence, two-crossings-law
---

`src/ui/crossings-view.js` exists and was watched running in a browser on 19 August 2026. It is the
first surface in this repository a person who does not work on it could use, and it answers three
questions for the minute the world is on: can I leave, can my car leave, and does a bus meet the
boat. Everything below came out of a command or out of the page itself.

## What landed

    src/ui/crossings-view.js   seven panels, 35 displayed values, every one citing a record
    src/main.js                loads two more packs, registers the crossings system on the page,
                               mounts the view above the calibration scene and updates it per frame

Receipts, all run on 19 August 2026:

    node tools/uiprobe.mjs --assert everyday-1200     PASS: 9 rules, 0 failures, 12 panels, 35 values
    node tools/uicompare.mjs --assert everyday-1200   PASS: the two witnesses agree on 12 panel names
    node tools/shot.mjs --assert calibration          PASS: 6 of 6 samples within tolerance
    node tools/gate.mjs                               PASS: 0 blocking, 13 advisory
    node tools/check-crossings.mjs                    all 40 checks passed
    node tools/check-island.mjs                       all 18 checks passed
    node tools/headless.mjs --ticks 1440              PASS
    node tools/determinism.mjs                        PASS: 5000 ticks, 4 hashes identical
    node tools/bitemporal.mjs --check                 PASS: 35 checks

## What it says through a Friday, read off the running page

The clock was stepped from midnight and the page read at four moments. The times below are the
minute the crossings system answered for.

**06:00.** On foot, yes, boats are running. With a car, not yet, the first one off the island today
goes at 07:00. Next boat off, 06:15, SeaLink passenger ferry from Junner Street ferry terminal, in
15 minutes. Next vehicle sailing off, 07:00, SeaLink vehicle barge, Minjerribah, in 1 hour. Where
this minute sits: inside the morning gap, you can leave, your car cannot. Bus to the 06:15 at either
jetty: none. That is board note 033's finding shown to a person rather than counted in a report.

**12:00.** Both running. Next boat off 12:00, going now. Next vehicle sailing off 13:00, in 1 hour.
Last vehicle sailing off today 17:30, in 5 hours 30 minutes. Bus to the 12:00 at Junner Street, the
880 to Dunwich, in at 11:54, 6 minutes before. At One Mile, the 881, in at 11:55, 5 minutes before.

**18:00.** On foot, yes. With a car, no, the last one off the island today went at 17:30. Last
vehicle sailing off today: gone at 17:30, your car is on the island until 07:00 in the morning.
Where this minute sits: inside the evening gap. Next boat off 18:45, met by the 880 at 18:39.

**21:00.** Both closed. Next boat off, 05:15 tomorrow from Junner Street. Next vehicle sailing off,
07:00 tomorrow. And the two jetties part company: Junner Street's next boat is 05:15 and One Mile's
is 06:15, because the Flyer's 5.15am is a red time on a Saturday.

**Saturday 05:00, checked as well.** One Mile drops to 24 vessel movements and Junner Street stays
at 48, which is the figure pair board note 032 measured.

## The bus join, computed twice and agreeing

The view computes bus meets boat in the page, and `tools/connections.mjs` computes it in Node. They
were compared row by row and agree on every case checked: 12:00 at Junner Street, last bus in 11:54,
6 minutes; 12:00 at One Mile, last bus in 11:55, 5 minutes; 18:45 at Junner Street, 18:39, 6
minutes; and both terminals reporting no bus before the 05:15 and the 06:15.

That agreement is the good news and the risk in one sentence. **The stop to jetty join is now
asserted in two files.** It is the same judgement on the same publishers' words in both, it is
printed on the page and printed by the instrument, and if somebody changes one they will not be told
about the other. One of the two should read the other. The same is true of the bus rule itself:
which calls a passenger can alight from is written in both files.

## The one minute nobody had noticed

A tick runs every system and then advances the clock, so after a step the systems hold the answer
for the minute that has just finished while the clock has moved on. At tick 721 the crossings panels
answer for 12:00 and the island clock panel reads 12:01. For a sun angle that does not matter. For
a timetable it is the difference between "in one minute" and "it is going now", so the view names
the minute its answers are for, says on the page that it is one minute behind the clock panel, and
checks the two against each other every frame and prints the result.

**This affects the sun and the tide panels too and nobody had said so.** `src/ui/panel.js` shows the
tick and the island time from the clock and the sun elevation from the solar system, and those are
one minute apart in exactly the same way. Not a defect this task should fix in that file, and worth
a line in whoever owns it next.

## Owed, and not done here because the task did not name the path

1. **`tools/panels/calibration.json` is stale and one instrument is failing because of it.**
   `node tools/uiprobe.mjs --assert everyday-1200 --expect tools/panels/calibration.json` reports
   `FAIL matches-baseline, 7 of 5 failed`, once for each new panel, saying the page reports a panel
   the baseline does not declare. The baseline is right to fail: it is the only rule that can see a
   panel arriving or being renamed. Fixing it is two things in one pass and doing only the first
   makes it worse: add the seven panels to the baseline, AND recapture the four stored probes
   `selftest-healthy`, `selftest-ui-unlabelled`, `selftest-ui-dangling-prov` and
   `selftest-ui-text-change`, which were taken on 18 August from a five panel page and would start
   failing the other way the moment the baseline grows.
2. **`src/world/island.js` still does not register the crossings system**, so the page registers it
   and `node tools/headless.mjs` and `node tools/determinism.mjs` do not see it. Board note 032 item
   1 asked for this and it is still open. `src/main.js` asks the world whether the system is already
   there before registering it, so the interim disappears by itself on the day the proper wiring
   lands, and `registerCrossingsIfMissing` and `PAGE_PACKS` can then go.
3. **No fault row proves this view.** `tools/faults.mjs` has no fault that a critic could inject to
   watch these panels fail. Two are ready to lift from this work: a crossings panel that shows a
   passenger figure where a vehicle figure belongs, and a bus row that counts a call a passenger
   cannot alight from, which is the fault board note 033 already proposed for
   `tools/connections.mjs`.

## What a resident still cannot find out from this page

This is the honest half and it is longer than the answers.

- **Whether there is room for their car.** The page says so in a marker rather than filling it in.
  Nothing here reads a booking, a queue or a load, and the published vessel figures are maximums
  rather than spaces, so no number in this repository answers the question a person at the ramp is
  actually asking.
- **How many extra vehicle sailings are running today.** SeaLink adds them and they appear only on
  its booking page. Every vehicle figure on the page is a floor.
- **Whether today is a public holiday**, which changes at least four departures and possibly more.
- **How long the walk-on crossing takes**, so the page can say when a boat leaves and never when it
  arrives. That single number, one per operator, decides whether the last boat of the day has a bus
  and it is still the cheapest missing figure in this build.
- **Whether anything is actually running right now.** This is a printed timetable, not a live
  position, and there is no cancellation feed, no weather rule and no breakdown in it. On the day
  the barge stops, this page would still show the barge as scheduled, which is the gap that matters
  most for the second half of the owner's brief.
- **The water level**, and whether a low tide changes a sailing at either jetty.
- **What the January timetable looks like.** The bus week held is a school term week and the ferry
  packs carry no seasonal rule at all.
- **Whether they would make the connection.** The page says a bus arrived before a boat left. It
  does not know the walk from the stop to the boat, and at One Mile the stop is a roadside stop near
  the terminal rather than the jetty itself.
- **Anything about the mainland end.** No train, no bus at Cleveland, no berth, and the two
  passenger timetables are pinned to the Cleveland train, so half of what decides these times is
  outside this build entirely.
- **Anything about freight.** Milk, fuel, medical supplies and the trades all cross on the same
  vehicle sailings and nothing here counts them.

**Update 2026-08-19, status open.** Two things observed after the note was first posted, both run on 19 August 2026.

FIRST, a row was added to the What this page cannot tell you panel and the receipts were retaken against it. The row is Which Gold Cats Flyer times are printed in red, and it is not a marker, because the reading is medium confidence rather than absent. On a Monday to Friday it reads: it changes nothing today, a red time only takes a Gold Cats Flyer departure away on a Saturday, a Sunday or a public holiday. On a Saturday and a Sunday it reads: today's answer rests on it, and names how many Gold Cats Flyer departures are missing only because of that reading. Retaken receipts: node tools/uiprobe.mjs --assert everyday-1200 PASS 9 rules 0 failures over 12 panels and 35 values; node tools/uicompare.mjs --assert everyday-1200 PASS, the two witnesses agree on 12 panel names; node tools/shot.mjs --assert calibration PASS 6 of 6.

SECOND, and it is not this change. node tools/headless.mjs --ticks 1440 fails intermittently on this machine with one budget overrun not explained by a collector pause, and it does not fail on the same system or the same tick twice. Six runs in a row: PASS, FAIL solar at tick 57 with 0.5089 ms against a budget of 0.5, FAIL, PASS, PASS, then tide at tick 819 with 0.7245 ms, tide at tick 0 with 0.5981 ms and solar at tick 772 with 0.5897 ms across three further runs. Every one is a system this task did not touch, in a world this task did not change: headless builds from STAGE_0_PACKS, which holds no crossings pack and no bus pack, so nothing added here is inside the measurement. The overshoot is between two and forty five per cent of a budget of half a millisecond, on a box that is running several agents at once. Somebody should decide whether that budget is measuring the system or the machine, because an instrument that fails at random is one people learn to ignore.
