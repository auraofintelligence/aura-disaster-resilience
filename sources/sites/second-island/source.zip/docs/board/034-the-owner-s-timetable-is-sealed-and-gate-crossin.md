---
id: 034
title: The owner's timetable is sealed, and gate/crossings is proved rather than claimed
status: open
opened: 2026-08-19
author: wave 6, fault registry and jurisdiction agent
tags: instruments, faults, jurisdiction, crossings, gate-crossings, gate-ground-truth, owner-ground-truth, bitemporal
---

Wave 6 landed three things the instruments could not see: a pack of the owner's crossing
timetables, a gate rule about them that had been proved by hand once, and a record store wired into
the world whose proof was written into a gitignored file. All three can be seen now. Everything
below came out of a command run on 19 August 2026.

## What landed

    tools/gate/ground-truth.mjs   a second copy of the owner's departure times and a digest over
                                  the sailing structure, both blocking
    tools/check-wiring.mjs        13 checks that the record store is in the world and that the
                                  value a panel shows came through the ladder
    tools/faults.mjs              6 new rows and 3 new instrument columns, 33 faults over 21 columns
    src/world/island.js           one runtime hook, `store-unwired`, declared in the registry
    tools/selftest.mjs            three more caveats in the generated document, named below
    docs/JURISDICTION.md          regenerated from the run, not written

Receipts:

    node tools/selftest.mjs          PASS: 33 of 33 rows green, 0 not proven, 0 missed or caught
                                     for the wrong reason. 2m19s.
    node tools/gate.mjs              PASS: 0 blocking, 13 advisory
    node tools/check-wiring.mjs      PASS: 13 checks
    node tools/check-crossings.mjs   all 40 checks passed
    node tools/check-island.mjs      all 18 checks passed
    node tools/bitemporal.mjs --check   PASS: 35 checks
    node tools/determinism.mjs --ticks 5000            PASS
    node tools/determinism.mjs --ticks 5000 --shuffle  PASS
    node tools/headless.mjs --ticks 1440               PASS

Before this task, with the same flags: 28 faults over 18 columns.

## The finding, and it is the reason this note exists

`data/crossings.json` is the only data in this repository that no connector can fetch again. It came
from the owner out of the two operators' published timetables and a photographed sign. Nothing in
the world can be asked whether a value in it has moved, and until today nothing here could either.

That was measured rather than assumed. A copy of the tree was taken and one middle row of the
SeaLink vehicle Departs Cleveland column was moved from 10:30 to 10:35, which is the smallest
plausible transcription slip.

    cd out/drift-tree && node tools/check-crossings.mjs
      all 40 checks passed

Forty checks, and the drift is not in any of them. That is not a defect in that tool and it should
not be read as one. Its window checks read the first and last row of a column, its rotation checks
read vessel codes, and its movement checks are row counts, so a middle row of a column is invisible
to every one of them by design. The gate saw nothing either, before this task. The drift would have
shipped, and the person it would have been wrong about is the person who supplied it.

`tools/gate/ground-truth.mjs` now holds a second copy of the departure times, transcribed from the
owner's own words rather than read back out of the pack, and a digest over service, direction,
departure minute, published clock time, vessel code and day rule. On the same copy:

    node tools/gate.mjs --root out/drift-tree
      FAIL: 2 blocking
      ground-truth/timetable-drift  data/crossings.json:366
        sealink-vehicle-barge mainland-to-island departure 5 (sealink-vehicle-m2i-1030):
        the owner supplied 10:30 and this pack says 10:35
      ground-truth/seal  data/crossings.json
        the sailing structure no longer matches its seal

Two rules rather than one, because a digest can say that something moved and only a comparison can
say what.

**The transcription agreed with the pack on the first run, in all seventy six departures.** That is
worth recording. It was written from the owner's supply and from board notes 029 and 030, not from
the pack, so a disagreement would have meant one of the two copies was wrong. There was none.

**What the seal is not.** It is not a claim that the timetable is correct. That belongs to the
operators and to the owner. It is a claim that the timetable in the pack is the timetable that was
supplied, which is the only claim a program can make about ground truth.

**What it costs when the timetable really changes**, and it will. Three edits in two files: the
pack, the transcription, and the digest the rule prints in its own failure. Plus a line on this
board saying who read the new timetable and when. That cost is the point.

## The three rules of gate/crossings are proved now

Board note 032 said it plainly and it was right: "gate/crossings has no fault row, so it has no
column in docs/JURISDICTION.md and the selftest does not prove it. It was proved by hand this once,
and a hand proof is a rumour by the second week." Three rows, one per rule:

    crossings-summed        two constants added, and a name holding both classes and a countable
                            word, planted in src/systems/crossings.js
    crossing-unattributed   a departure count and a movement count in docs/INGEST-STATUS.md with
                            neither a service nor a landing point named
    crossing-carries-both   one sailing given a third value for what it carries, and another with
                            the field deleted

The unattributed plant uses the word "passenger" on purpose. It reads like attribution and is not:
both passenger services run fourteen departures each way, so a figure that says only "passenger"
leaves a reader unable to tell which one. A row that planted an obviously bare figure would not have
tested the case worth catching.

One thing fell out of writing those plants. `tools/faults.mjs` is scanned by `gate/crossings` like
every other file under `tools/`, so a registry that spelled out the shapes it plants would fail the
rule it is proving. Every shape is assembled from fragments at apply time, which is the convention
that file already used three times for the first island's port, for an undeclared hook call and for
a spliced word. Board note 032's per-line `specimen` marker would also have worked and was not used:
a marker is an exemption and assembly is not, and this file plants shapes for a living.

## The store is in the world, and now it can be watched not being

Board note 018: "Nothing is wired. src/world/island.js builds no store, no system reads one, no
number on screen goes through the ladder." Board note 031 closed that and proved the closing with
`out/records-wiring-check.mjs`, and `out/` is gitignored, so the proof went away with the agent that
wrote it.

`tools/check-wiring.mjs` is that proof kept. Thirteen checks over a world built the way every
instrument builds it: the store is on the world and the load report agrees with it, a quarantined
record is named rather than skipped, the three cursors are there, the store's present follows the
world clock and not a clock of its own, every field the twin declares resolves to one of the
ladder's two shapes, an absence carries the record that explains it, and the value a panel shows is
the ladder's answer at that cursor rather than a second opinion beside it.

The last of those is the one that matters most and it needed a correction while it was being
written. The first version compared `world.state.tide.answer` against the ladder's raw result shape
and failed on the healthy tree. The tide system does not hand the ladder's object straight through:
it flattens it into a payload a panel can read without knowing the ladder's two shapes. That is a
reasonable seam and it is also exactly where a second opinion could be introduced without anybody
noticing, so the check now holds the payload against a fresh resolve at the same cursor rather than
only checking that it looks like an answer.

`store-unwired` is a runtime hook in `src/world/island.js`: the store is built and then dropped, so
the world has no records, no cursor and no resolve, the tide system is registered with no resolver
and reports `answerFrom: 'no resolver was supplied'`, and the value the page shows stops being the
ladder's answer. Ten of the thirteen checks fail under it. One that does not is worth reading:
`the-simulation-rung-is-not-the-answer` passes, because with no answer at all nothing borrowed the
simulation rung, and a row that counted that as a pass would be counting an absence.

The half this cannot reach is the other half of its own description: a panel in a browser reading a
value around the ladder. That needs a capture nobody has taken, and it is written into the registry
row rather than left as a silent gap.

## Four things the next agent should not have to rediscover

FIRST. **Three tools under `tools/` are instruments with no column in the matrix, and a fourth
cannot have one.** `check-island.mjs`, `check-crossings.mjs` and `connections.mjs` all exit non-zero
on a failure and none has ever been watched failing. Board note 033 already names the fault that
would prove `connections.mjs`: a bus call whose `pickupType` says no pickup, counted as a
connection, which would report a boat as met by a bus nobody can board. `uicompare.mjs` is the
fourth and cannot get a row, because the fault that would prove it is a page that lies about itself
and no Node script can inject that. All four are now named in `docs/JURISDICTION.md` rather than
left to be discovered. Adding them is the next honest piece of this work and it was not done here
because each one needs a hook in a file another agent wrote this evening.

SECOND. **Two `caught` cells in the published matrix are the headless flake and not findings.**
`headless` reads `caught` on `stale-frame` and `port-collision`, two rows it does not own and
structurally cannot see: one hooks the renderer and the other writes `tools/serve.mjs`, and headless
loads neither. It is the budget overrun with no collector pause behind it that `tools/headless.mjs`
documents in its own header, board note 031 measured at roughly one run in six on a busy machine,
and it happened twice in a row on both of those rows. `tools/selftest.mjs` retries a failing
non-owning column once and prints both attempts, so it is never invisible, and the generated
document now carries the caveat. If a `headless` cell reads `caught` on a row it does not own, read
the run log before believing it.

THIRD. **The seal covers the timetable and deliberately not what a boat carries.** `crossing-carries-both`
changes `carries` on a sailing and `gate/ground-truth` does not fire, which looks like a hole and is
a boundary: what a boat carries is a different claim with a different rule, and `gate/crossings`
owns it. Two rules that both fired on the same edit would tell a reader nothing about which one is
working.

FOURTH. **`docs/CONTRACT.md` section 6 still reads NOT YET CHECKED on the two-crossings law.** It is
checked, by `tools/gate/crossings.mjs`, and now proved by three rows. Board note 032 asked for the
correction and it is still owed. `docs/STAGE-0.md` is six waves behind `tools/faults.mjs` in the
same way, and nothing in the gate compares either document to the registry.

## What I did not do

- I did not open a browser. The six browser rows in the matrix are green from captures already on
  disk under `shots/` and `out/probes/`, taken by earlier sessions, and a fresh clone reports them
  not proven until somebody opens the page again.
- I did not edit `data/crossings.json`, `src/systems/crossings.js`, `tools/gate/crossings.mjs`,
  `tools/connections.mjs` or `tools/check-crossings.mjs`. The faults plant into copies under `out/`.
- I did not run a state changing git command.
- I did not fetch anything, and nothing in this task needed a network.
- I did not register the crossings system in the island. Board note 031 and board note 032 both name
  that as an orchestrator's call between two agents, and it is still open. `check-wiring` will
  answer for a crossing field the day one carries a `field` and a `rung`, and today none does.

**Update 2026-08-19, status open.** Correction to the SECOND item above, made after the final selftest run at 22:18. That item said two caught cells in the published matrix are the headless flake. They were, in the run I wrote it from. They are not in the file on disk: the 22:18 run did not hit the flake and both stale-frame and port-collision now read missed in the headless column, which is the true answer. The caveat is still worth having and tools/selftest.mjs writes it into docs/JURISDICTION.md as a standing one, because the next run may put those cells back. Read the run log before believing a caught cell outside the owning column. Second thing, recorded rather than left: src/ui/crossings-view.js and a changed src/main.js landed from a wave 7 agent at 22:11, in the middle of a selftest run, and that run's own guard caught it and reported the repository had changed under it. The gate, check-wiring, check-island and check-crossings were re-run over the settled tree and the selftest taken again, so the matrix on disk covers that surface. Board note 035 carries what it does.
