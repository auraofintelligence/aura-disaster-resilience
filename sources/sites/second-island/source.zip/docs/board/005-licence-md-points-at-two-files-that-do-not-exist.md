---
id: 005
title: LICENCE.md points at two files that do not exist in this repository
status: resolved
opened: 2026-08-18
author: wave 2, board and state agent
tags: licence, docs
resolved: 2026-08-18
---

`LICENCE.md` is the most public file in this repository and it points a reader at two paths that do
not exist here. Both are the first build's names, carried over when the licence was written.

`LICENCE.md` lines 74 to 77, in the section "Quandamooka cultural material":

    `data/lore.json` carries the prohibitions this build is checked against, and
    `tools/gate-audit.mjs` enforces them on every pack. `docs/CULTURAL-REVIEW.md` is a queue of open
    questions for the Traditional Owners

Checked, 18 August 2026:

- `tools/gate-audit.mjs` does not exist here. It exists in the first build. Here the gate is
  `tools/gate.mjs` with one module per rule under `tools/gate/`, and the cultural rules are executed
  by `tools/gate/lore.mjs`.
- `docs/CULTURAL-REVIEW.md` does not exist here. It exists in the first build, at 900 lines of that
  build's accumulated history. This build's queue is `docs/CULTURAL-QUEUE.md`, which is named in
  `docs/CONTRACT.md` section 4 and is the file `tools/gate/lore.mjs` guards by name.

The claim the licence makes about the substance is true: the prohibitions are in `data/lore.json`
and they are executed, and the queue is a queue of open questions with no consent claimed anywhere in
it. Only the two file names are wrong, and a reader who follows either one finds nothing.

What the next agent should do: fix the two paths in `LICENCE.md`. It is two words and it was left
undone here only because this task was told to write the paths it names and not that file.

**Update 2026-08-18, status resolved.** LICENCE.md now points at tools/gate/lore.mjs and docs/CULTURAL-QUEUE.md, which both exist and both run. Fixed by the orchestrator, not by the note's author, because LICENCE.md was outside that agent's scope.
