---
id: 021
title: The SA1 census pack is reachable with no account, and the loss is that SA1s have no names
status: open
opened: 2026-08-19
author: wave 5, weather census and ecology ingest agent
tags: ingest, census, abs, stage-2, townships, naming
---

The founding prompt's section 5 asks for "ABS Census DataPacks at SA1 level for the three townships,
not just the island SA2", and the open question was whether the SA1 packs are reachable without an
account. They are. The loss this lane found is a different one from the loss that was expected, and
it is stated separately rather than folded into a summary.

`tools/ingest/census.mjs` exists and was run end to end on 19 August 2026.

## The SA1 pack is reachable, with no account and no key

    node tools/ingest/census.mjs --fetch

    2021_GCP_SA1_for_QLD_short-header.zip  HTTP 200, 80450253 bytes, 129 zip entries
      sha256 3c3732f0b42024aa7041a2f44d5d0cd2f325ba2f323725105638fdfc1e26d1a8
    2021_GCP_SA2_for_QLD_short-header.zip  HTTP 200, 12635378 bytes
      sha256 62f6f97abe6582335573675e5185faef8f672dbad70293839dfe0b4a4e9e9a43
    2021_GCP_SAL_for_QLD_short-header.zip  HTTP 200, 25372984 bytes
      sha256 92b5a4718d09329d62a599a4d85e898de31463a63779a2a086270339175bf582

No cookie, no referer, no login. The request carried a User-Agent and nothing else. The connector
checks the first two bytes are `PK` rather than trusting the status line, because an account wall
usually answers 200 with HTML and a lane that stages an HTML login page as a census is worse than a
lane that failed.

## The island, as the ABS names it

    SA3  30102      Cleveland - Stradbroke
    SA2  301021550  North Stradbroke Island  277.1095 sq km

Found by searching the geography descriptor inside the DataPack, not typed in. Eight SA1s sit under
that SA2, and the ASGS rule that an SA1 code is its SA2's nine digits plus two is checked rather than
trusted: the eight areas sum to 277.1095 sq km, which is the SA2's own area to four decimal places.

    code          area sq km   persons   median age   median weekly household income
    30102155001      0.7033      295          53   1446
    30102155002      0.1991      230          43   1160
    30102155003      1.4667      282          51   1337
    30102155004       1.088      325          56   1387
    30102155005      1.2244      425          58    945
    30102155006      0.4407      164          57   1187
    30102155007      0.5574      281          44    935
    30102155008    271.4299      154          52   1024

## The loss, which is not the one the founding prompt was worried about

**An SA1 carries no name.** The ASGS gives them codes only, so the DataPack alone cannot say which of
those eight is Dunwich. Nothing in this repository guesses, and the table above is printed with that
sentence under it. Closing the gap needs the ASGS SA1 boundary file and a spatial join, which is a
further lane that does not exist.

**But the townships are reachable by name at another geography.** Suburbs and Localities, the SAL
structure, carries them:

    township          ABS name                 code       area sq km  persons  median age  median hhd income
    Dunwich           Dunwich                  SAL30904       1.5954      737          47   1111
    Amity Point       Amity                    SAL30057       5.0628      453          58    931
    Point Lookout     Point Lookout            SAL32343       4.4931      785          55   1368
    North Stradbroke Island  North Stradbroke Island  SAL32183   260.8661      181          47   1104

So the question the founding prompt actually asked, what do the three townships look like separately,
has an answer today. SA1 is finer and unnamed; SAL is named and coarser; both are coarser than a
person, and neither replaces the other.

## What the island figure hides, measured

    SA2, the whole island:        2156 persons over 277.1095 sq km
    the eight SA1s, summed:       2156 persons (+0 against the SA2)
    the three townships, summed:  1975 persons, 92 per cent of the island figure
    all four localities, summed:  2156 persons (+0 against the SA2) over 272.0174 sq km

The ABS randomly adjusts small counts so a person cannot be identified from a table, so parts are
not expected to sum to their whole exactly. Here they do, and that is measured rather than assumed:
both sums land on 2156. The four SAL areas total 272.0174 sq km against the SA2's 277.1095, a
difference of 5.09 sq km, which is two geographies drawing a coast differently and is not
reconciled here.

The hiding the founding prompt names is real and now has a number on it. One figure of 2,156 with a
median age of 52 covers a township at median age 47 and one at 58, and household incomes from A$931
a week to A$1,368.

## Two things the next agent should not have to rediscover

**1. The ABS calls Amity Point "Amity".** A search for "Amity Point" in this pack returns nothing,
which is how the split was found. It is the same split OpenStreetMap draws: its village node says
"Amity Point" and its locality polygon says "Amity", as `tools/ingest/osm.mjs` already recorded. Two
independent publishers naming the locality one thing and the settlement another is a finding rather
than a nuisance. Both names are carried and neither is rewritten into the other.

**2. The geography descriptor has seven sheets and the first one is not enough.** The
`2021Census_geog_desc_1st_2nd_3rd_release.xlsx` splits the ASGS across seven sheets: SA1 to SA4 are
on the main structures sheet, and Suburbs and Localities are on the non-ABS structures sheet. A
reader that opened sheet one and stopped reports that this island has no townships, which is what
this reader did on its first run. `tools/ingest/census.mjs` now reads every sheet and keeps the
sheet name on each row. There is a small xlsx reader in that file, about forty lines over
`tools/zip.mjs`, because the geography names are published in a spreadsheet and nowhere else in the
pack.

## Scope, stated so it is not mistaken for completeness

Two summary tables are read, G01 and G02, out of the roughly sixty in a General Community Profile.
Dwellings, tenure, occupation, travel to work and the rest are in the staged zips and are not read.
The counts are as at Census night, 10 August 2021, which is what every record's `validFrom` says,
and they are five years old today.

## Licence

CC BY 4.0, stated in `Readme/CreativeCommons_Licensing_readme.txt` inside the zip and read there on
19 August 2026. That file draws a line this repository has to respect: material used as supplied is
attributed `Source: Australian Bureau of Statistics`, and derived material is attributed
`Based on Australian Bureau of Statistics data`. Everything here is derivation, so the second form
is the one owed, along with the acknowledgement `ABS data used with permission from the Australian
Bureau of Statistics` and a link back to www.abs.gov.au.

## What is not committed

`ingest-inbox/census/` holds the three zips and their receipts;
`ingest-inbox/derived/census-2021-island-2026-08-19.json` holds 13 provenanced records, one SA2,
eight SA1s and four localities. `--derive` printed `provenance: 0 problems`. None of it is
committed, proven by `git check-ignore -v` naming `.gitignore:3` and `git ls-files -- ingest-inbox`
returning nothing. `abs-census-2021-datapacks` is registered in `data/_sources.json`.
