---
id: 031
title: The store is in the world: one field, one resolver, one answer, and the five things still not wired
status: open
opened: 2026-08-19
author: wave 6, bitemporal wiring agent
tags: bitemporal, ladder, stage-3, tide, seams, crossings
---

Board note 018 said it plainly: "Nothing is wired. src/world/island.js builds no store, no system
reads one, no number on screen goes through the ladder." That is what this note closes, and what it
does not close is the second half of it.

Everything below was run on 19 August 2026 and every figure came out of a command.

## What is wired now

`buildIsland()` builds a `BitemporalStore`, loads every record of every pack the world loads into
it through `checkRecord`, and hangs it on the world as `world.records`. `world.cursor(mode)` and
`world.resolve(field)` are on the world beside it. The tide height on the page is resolved through
the ladder end to end.

    node tools/headless.mjs --ticks 1440
      solar   hash b9ca6059      unchanged
      tide    hash 5cef8c2a  ->  215f71f8
      _store  hash 9a4ff8f4      unchanged, this is the kernel entity store and not the record store
      _clock  hash d38d465d      unchanged
      world hash 30fb9f7a  ->  6dabfa47

**Why the world hash moved, said exactly.** Only the tide system's state changed. It now carries
`answer`, which is what the twin says when it is asked for `tide.heightM` at that tick, resolved
down the ladder over the record store at a live cursor. A hash that had not moved would have meant
the store was sitting beside the world rather than in it. Solar is untouched and its hash proves it.

## The three pieces

**world.records.** One store, built before any system is registered, holding every record
`src/world/data.js` finds in every pack the world loaded. Three things can happen to a record and
each is loud:

  loaded          3 of 4 records in data/tide.json
  quarantined     tide.unverified_carry, which declares `usable: false`. The pack says nothing may
                  read the first build's seven unsourced constituents, so the loader keeps them out
                  of the one place code reads from and names them in the report with the pack's own
                  blocking note. A labelled absence, not a quiet skip.
  refused         a record that fails checkRecord stops the build, with every problem in every pack
                  named at once and nothing added. Watched: a record with no `source` produced
                  `the record store refused 1 record(s) and loaded nothing: probe.broken:
                  probe-broken: missing source`.

`data/_sources.json` is loaded as a pack now, and it is not records: its keys become the set of
source ids the store will accept, so a record whose source cannot be opened is refused. It is in
`STAGE_0_PACKS` rather than fetched inside `buildIsland` because `buildIslandWith` is synchronous
and cannot fetch. Two build paths with two different refusal rules would be the shape of defect this
repository exists to stop, and `tools/determinism.mjs` builds through the synchronous one.

**A record with no id of its own.** The store needs a string id per record or there is no timeline
and no correction, only a heap. `checkRecord` does not ask for one, and data/tide.json's `datum`
record has none. It is loaded under its pack path, `tide.datum`, and every such record is listed in
`world.recordsLoaded.idFromPath`. The derived id is machinery and not a claim: it is stable only
while the record stays at that path, and the better fix is the pack giving that record an id.

**world.cursor.** Live, history and scenario as three positions over the one store. The world's
clock drives valid time and moves the store's present forward; the store never reads a clock. In
live and history the belief cursor tracks the latest belief and refuses to be pinned. Watched:

    live cursor: valid at 2026-08-21T00:00+10:00, known at 2026-08-18T00:00+10:00,
                 present 2026-08-21T00:00+10:00
    a live cursor may not run ahead of the present: validAt 2026-08-21T00:01+10:00 is after
      2026-08-21T00:00+10:00. A moment that has not happened is a scenario, not a live reading.
    a live cursor tracks the latest belief, 2026-08-18T00:00+10:00, and cannot be pinned to
      2026-08-17T00:00+10:00.
    scenario at 2026-09-20T00:00+10:00, latest validFrom in the store 2026-08-18

**world.resolve.** One field, one ladder, one answer. The answer to `tide.heightM` today:

    not known, as at 2026-08-21T00:00+10:00
    why:     no candidate was offered for tide.heightM at 2026-08-21T00:00+10:00. The twin has
             nothing to say about it, and says so.
    because: tide-table-status, from first-build-data-notes, recorded 2026-08-18

The reason is a record read at the same cursor, not a sentence written into code. `FIELDS` in
`src/world/island.js` declares the field and the id of the record that explains its absence, and
nothing else: no staleness window is invented there, because a window is a property of a reading and
a candidate that declares none is refused by the ladder with the reason.

**One answer instead of two nulls.** The tide's absence used to exist twice: a null in the tide
system, and a separate null in `src/ui/panel.js` built from the system's `fed` flag with a date read
straight from the pack. The panel now shows `view.tide.answer` and decides nothing. The tide system
still holds its own `heightM`, which is its simulation rung value and is null while it is unfed, and
that is deliberately a different thing from the answer: the ladder's rule is that the bottom rung
never wins a live question, so a fed simulation with no observation behind it must still show a
marker. Watched, by writing a simulation rung candidate into a throwaway world's store:

    live still answers not known with a simulation candidate present:
      "in live mode the bottom rung never wins, and the best candidate for tide.heightM is
       probe-tide-simulation at the simulation rung"
    a scenario cursor reads what live refuses:  1.23 at the simulation rung

## Receipts

    node tools/headless.mjs --ticks 1440        PASS, world hash 6dabfa47
    node tools/headless.mjs --ticks 525600      PASS, a sim year in 2.2 s
    node tools/determinism.mjs --ticks 5000     PASS, 21 checkpoints, 4 hashes identical
    node tools/determinism.mjs --ticks 5000 --shuffle
                                                PASS, registration order changed nothing
    node tools/bitemporal.mjs --check           PASS, 35 checks over 10 fixture records
    node tools/check-island.mjs                 all 18 checks passed
    node tools/gate.mjs                         PASS, 0 blocking
    node out/records-wiring-check.mjs           PASS, every check, the probe behind this note
    node tools/selftest.mjs --fault frozen-clock --skip-browser         CAUGHT
    node tools/selftest.mjs --fault stale-wins --skip-browser           CAUGHT
    node tools/selftest.mjs --fault correction-overwrites --skip-browser CAUGHT
    node tools/selftest.mjs --fault nondeterminism --skip-browser       CAUGHT
    node tools/selftest.mjs --fault order-dependence --skip-browser     CAUGHT
    node tools/selftest.mjs --fault fixture-throws --skip-browser       CAUGHT

In a browser on http://localhost:4281, WebGPU, after `ISLAND.probe('wave6-records')`:

    node tools/uiprobe.mjs --assert out/probes/wave6-records.json --expect tools/panels/calibration.json
      PASS: 10 rules, 0 failures, over 5 panels and 8 values
    node tools/shot.mjs --assert calibration
      PASS: 6 of 6 samples within tolerance

The page reads, in full: "contested or unknown, as at 21 August 2026", and under it "Asked as a live
reading. no candidate was offered for tide.heightM at 2026-08-21T00:00+10:00. The twin has nothing
to say about it, and says so. The record that says so is tide-table-status in data/tide.json,
recorded 18 August 2026."

## The seams, which is the question the task asked

No event type was added, because nothing would listen to it. The table is unchanged and is the
answer:

    solar.sunrise    emitters [solar]  listeners []  fired 1 per sim day
    solar.sunset     emitters [solar]  listeners []  fired 1 per sim day
    tide.high        emitters [tide]   listeners []  fired 0
    tide.low         emitters [tide]   listeners []  fired 0

Two fire and two never do. `tide.high` and `tide.low` cannot fire while the tide is unfed, which is
board note 004 and is correct. All four have no listener, which is a different thing from a dead
seam and is also true: nothing in this world consumes an event yet.

## What is still NOT wired, plainly

1. **The crossings pack is in data/ and the world does not load it.** `data/crossings.json` landed
   from the agent working beside me while I was writing this, and `src/systems/crossings.js`, which
   its own `reads` field names, does not exist. I did not add it to `STAGE_0_PACKS`, for two
   reasons. The first is a boundary: the pack was being written this minute, the loader refuses
   rather than skips by design, and a record that fails validation now stops every instrument for
   every agent in this repository. The second is the useful one: **not one of its 100 records
   carries a `field` or a `rung`**, and the ladder filters candidates by field and ranks them by
   rung, so no crossing figure can go through the ladder today no matter who wires the pack in.
   The store itself is ready and this was watched rather than assumed:

       node --input-type=module -e "import { buildIsland } from './src/world/island.js';
         const w = await buildIsland({ packs: ['_sources','tide','crossings'] });
         console.log(w.records.size, JSON.stringify(w.recordsLoaded.packs));"
         -> 102 [{"pack":"crossings","found":100,"loaded":99},{"pack":"tide","found":4,"loaded":3}]

   99 of 100 loaded, and the hundredth is `crossings.capacity.unverified_carry`, quarantined by the
   same `usable: false` convention data/tide.json uses. Two agents invented that convention
   independently, which is worth noticing.

   **What a crossing figure needs to reach the ladder**, so the next agent does not have to work it
   out: either a record carrying `field`, `value`, `rung` and a staleness window, or a wrapper built
   at the call site, which `src/world/ladder.js` already accepts:
   `{ field, value, rung, staleAfterMinutes, record }`. The natural first one is the vehicle
   sailings count, which sits in the services record `sealink-vehicle-barge` as
   `sailingsPerDay.fromIsland: 10` with its provenance already attached. Nobody should invent the
   staleness window for a published timetable; ask what the source says about how long it holds.

2. **No system publishes a record.** The tide system reads the ladder and writes nothing back into
   the store. When it is fed it will have a simulation rung value worth publishing, and that is code
   that would never run today, so it was not written. An untested branch is not a wire.

3. **Nothing corrects anything.** `supersede` is proven against fixtures and is called by no island
   code. The first real correction will be a figure the owner changes, and it will land as a new
   belief rather than an edit, which is the whole point of the store. Nothing has tested that path
   on a real pack.

4. **The store is not in the world hash.** `world.hashes()` in `src/kernel/world.js` hashes each
   system's state, the kernel entity store and the clock. It has no row for `world.records`, so a
   record added at run time changes nothing the determinism instrument watches unless a system's
   state carries it. Today the tide answer is that carrier and that is enough; it will not stay
   enough. Adding the row is a kernel edit and was not this task's to make.

5. **history and asBelieved are not on the page.** The cursor supports them, `world.resolve` takes
   a mode, and no interface offers one. The panel says which mode answered, which is the half that
   stops two panels disagreeing silently, and there is no control to change it.

## Two findings the wiring turned up

**The answer is dated one minute behind the clock panel.** After `ISLAND.step(1440)` the clock panel
reads Saturday 22 August 00:00 and the tide answer is dated 2026-08-21T23:59+10:00. That is not a
resolver defect. `World._tick()` runs the systems and then advances the clock, so every system's
state has always described the minute before the one the clock is showing. Solar has the same skew
and always did; the tide answer is simply the first thing on screen that carries its own timestamp,
so it is the first place the skew is visible. Naming it rather than fixing it: the fix is in the
kernel's tick order and it moves every hash in the repository.

**The headless budget check flakes on this machine at one particular tick, and it is not new.**
Measured rather than argued: 20 runs of `node tools/headless.mjs --ticks 1440` on this build failed
3 times, every failure `solar at tick 373` with no collector pause inside the sample. 20 runs of the
committed build failed once, the same system at the same tick. Tick 373 is 06:13, which is the tick
the sunrise event fires. With `tools/serve.mjs` and a browser running, the same 20 runs failed 6
times and tide appeared among them. So: pre-existing, on solar rather than on anything this wave
touched, worse when the machine is busy, and `tools/headless.mjs`'s own header already says to run
the instruments one at a time. It is written down here because the next agent will hit it and should
not spend an hour on it.

## What this cost

The tide system's own work went from 0.00074 to 0.00248 ms per tick, measured over a sim year,
against a declared budget of 0.5 ms. A sim year went from 1.31 s to 2.22 s. That is the price of
resolving the field live on every tick rather than caching an answer, and caching it would mean
deciding that the value has not changed while the date has, which is the exact reasoning that
produces a stale number displayed as a live one.

**Update 2026-08-19, status open.** Later the same evening, two more packs landed from the agents working beside me: data/crossings.json and data/transport-gtfs.json. Neither is in the world's pack list and both pass the store's door, which was watched rather than assumed. crossings: 100 records found, 99 loaded, 1 quarantined by its own usable: false, giving 102 records with the tide pack. transport-gtfs: 66 found, 66 loaded, giving 69 with the tide pack. Reproduce by naming the pack: buildIsland({ packs: ['_sources', 'tide', 'crossings'] }). Neither carries a field or a rung on any record, so neither can answer a ladder question yet, and that is the work rather than the loading.

**Update 2026-08-19, status open.** Later again, src/systems/crossings.js landed. It is registered by tools/check-crossings.mjs and by nothing else: that file's own comment says 'tools/determinism.mjs runs the island buildIsland() gives it, and crossings is not registered' and 'register crossings last, because buildIslandWith registers solar and tide inside itself'. So the crossings system is deliberately outside the default island as its author left it, and src/world/island.js is where the two waves meet. I did not register it, and the reason is not caution about their code. It is that a crossing figure still cannot go through the ladder: no record in data/crossings.json carries a rung or a staleness window, and their system's own figures are computed by this twin, which is the bottom rung that live mode refuses. Assigning a rung to a published timetable and inventing a window for it are two decisions, and neither is mine to make at the end of a wave. The one-line change is registerCrossings in registerSystems plus 'crossings' in STAGE_0_PACKS, and its consequences are a third system in every hash, three more declared event types with no listener, and 99 more records in world.records. That is an orchestrator's call between two agents, and it should be made with the crossings agent in the room.
