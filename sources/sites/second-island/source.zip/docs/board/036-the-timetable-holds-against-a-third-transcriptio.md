---
id: 036
title: The timetable holds against a third transcription, and the seal that protects it covers six fields of nine
status: open
opened: 2026-08-19
author: wave 8, critic
tags: critic, crossings, gate-ground-truth, gate-crossings, owner-ground-truth, ui, traceability
---

I was asked to falsify one claim: **every crossing number this wave produced traces to the owner's
supplied timetables without alteration, and nothing sums a vehicle figure with a passenger figure.**

I could not falsify it. Everything below came out of a command run on 19 August 2026, and where I
could not test a thing the line says so.

## 1. The timetable, checked cell by cell against a third copy

I typed the owner's supply out a third time, from his words in this task's brief and in board note
029, without reading `data/crossings.json` first, and compared them by script rather than by eye.
The script is `verify.mjs` in my scratchpad and it imports no project code.

    sailings in pack: 76, owner rows: 76, cells compared: 76
    TIMETABLE: no difference found

That compares, for every sailing in the pack, which is 20 SeaLink vehicle barge and 28 SeaLink
passenger ferry and 28 Gold Cats Flyer: the departure minute, the printed clock label
against that minute, the vessel on all 20 vehicle rows, and the day rule on all 76. It also refuses
any sailing in the pack that is not in the owner's supply, and any row of his supply the pack does
not hold. Nothing was normalised, nothing merged, no day rule widened, nothing invented.

The four Gold Cats Flyer red readings are the four sailings at confidence medium and no others, and
they are the four the sign marks: 4.45am and 8.15pm from Cleveland, 5.15am and 7.45pm from One Mile.
The 8.45pm from One Mile is not red and is recorded daily at high confidence, which is right.

**There are now three independent transcriptions of this timetable and no two of them disagree**:
the pack, the second copy in `tools/gate/ground-truth.mjs`, and mine.

## 2. The derived figures, recomputed rather than trusted

Own script, `derive.mjs`, reading only `sailings[]`:

    every weekday   vehicle 07:00-17:30 = 630 min (10.50 h)
                    passenger 05:15-20:45 = 930 min (15.50 h)
                    gap morning 105 + evening 195 = 300 min (5.00 h)

    Junner Street   Fri/Sat/Sun 48 (vehicle 20, SeaLink passenger 28), Mon-Thu 46
    One Mile        Mon-Fri 28, Sat/Sun 24

All of it reproduces. The orchestrator's 48 and 28 hold together on a Friday and on no other day,
and board note 032 already caught that and put the day on them. It is on the page too: the page
prints the weekday beside the figures.

The five hours is a subtraction of two durations, not a sum of two counts:
`src/systems/crossings.js:369-372` and `tools/check-crossings.mjs:130`.

## 3. Nothing adds a vehicle figure to a passenger figure

Checked in the pack, in the two systems, in `tools/connections.mjs`, in `out/capacity.mjs`, in the
docs and on the running page. No such sum exists.

The one on-screen figure spanning two service classes is `48, counting each boat in and each boat
out` at Junner Street. That counts vessel movements, one unit both times, and the pack, the checker
and the page all name the terminal it belongs to, which is what `crossings/unattributed` asks for. I
am not filing it. What I will record without filing it: the page shows 48 and does not show that 20
of the 48 are the only ones that take a car, and `movementsTodayByService` already holds that split.

`data/crossings.json` capacity: no code reads `carsMax` or `deckPassengersMax`. Grepped across
`src/` and `tools/`, zero hits outside the gate rule that guards them.

## 4. The connection analysis, attacked on the three points it could have cheated on

Recomputed from `data/transport-gtfs.json` and `data/crossings.json` with my own script, `conn2.mjs`:

    07:00 vehicle sailing off the island   buses reaching Junner St before it: 0. Claim holds.
    14:00 vehicle sailing from Cleveland   lands 14:45-14:50, next bus 16:00, wait 70 to 75 min
    20:15 SeaLink passenger from Cleveland last boardable bus out of Junner St 19:45. Stranded.
    Flyer 20:15                            needs a crossing of 18 min or less (last bus out 20:33)
    SeaLink passenger 19:15                needs a crossing of 30 min or less
    same island landing, same minute       one today, the 17:30 pair at Junner Street ferry
                                           terminal, and fourteen under the Flyer scenario

Every one matches board note 033.

**A bus that leaves before the boat lands is not counted.** `nextBusOut` takes only departures at or
after the landing minute, so every wait is non negative by construction, and `lastBusIn` takes only
arrivals at or before the sailing minute. I scanned for a nought minute connection, which the file's
own header says would be printed as nought and would not mean a person could make it: there are none
on a Friday at either terminal.

**Passenger crossing time was not quietly assumed.** No landing minute is computed for either
passenger service at all. What is reported is the part that holds for any crossing time, and the
bound it still gives.

**The vehicle range was not collapsed to a point.** Every vehicle row is computed twice, at 45 and at
50, and where the two ends catch different buses the row says `depends-on-crossing-time`. The summary
counts use the slow end, which is the conservative direction: four sailings at 14 to 19 minutes are
counted as outside fifteen, not inside it.

## 5. The two new gate rules read files. Watched, on ten planted faults

A copy of the tree in my scratchpad. The healthy copy prints `FAIL: 1 blocking, 13 advisory`, the one
blocking being `sealed/no-git`, because a copy is not a git working tree. That is the control, and
every count below is against it.

Caught, each naming the file, the line and what moved:

    A  one middle departure moved 12:00 to 12:05           ground-truth/timetable-drift + /seal
    B  a red day rule widened to daily                     ground-truth/timetable-drift + /seal
    C  one sailing deleted                                 ground-truth/timetable-drift + /seal
    D  a carries value that is neither of the two          crossings/carries-enum
    E  a vessel swapped in the rotation                    ground-truth/timetable-drift + /seal
    K  a doc line giving a sailing count and a movement
       count with neither a service nor a terminal named   crossings/unattributed, twice
    K  a doc line adding a vehicle count to a passenger count    crossings/summed
    K  a doc line naming one field for both classes        crossings/summed

Missed by the whole gate, and they are findings 1 and 2 below:

    F  a vehicle sailing's carries flipped to passengers      gate clean. check-crossings: 6 of 40 fail
    G  a Flyer sailing's islandPoint moved to Junner Street   gate clean. check-crossings: 3 of 40 fail
    H  the 17:30 last car off relabelled passengers           gate clean. check-crossings: 7 of 40 fail
    I  days.rule left daily, days.weekdays cut to Mon-Fri     gate clean. check-crossings: 5 of 40 fail
    J  a SeaLink sailing's operator set to gold-cats-flyer    gate clean. check-crossings: all 40 pass

## FINDING 1, serious. The seal covers six fields and the figures are computed from nine

`canonicalLine` in `tools/gate/ground-truth.mjs:126` seals `serviceId`, `direction`,
`departsMinuteOfDay`, `departsLocal`, `vesselCode` and `days.rule`. It does not seal `carries`,
`islandPoint`, `mainlandPoint`, `operator`, or `days.weekdays`.

The file says what it deliberately leaves out and it is right about that list: notes, locators,
confidences and every other word around the sailings. None of the five above is writing about the
timetable. `carries` is the field the two-crossings law lives in. `islandPoint` is what 48 and 28 are
counted from. `days.weekdays` is the array the simulation actually reads, while `days.rule` is the
label beside it, so faults B and I are the same edit and only B is sealed.

Consequence, measured: four edits to the owner's least recoverable data pass `node tools/gate.mjs`,
which is the one command every agent in this repository is told to run before finishing.

`tools/check-crossings.mjs` catches four of the five. That is the mitigation and it is thinner than
it looks: check-crossings is not called by the gate, has no fault row in `tools/faults.mjs`, has no
column in `docs/JURISDICTION.md`, and `tools/selftest.mjs` already records it as having been watched
NOT seeing a drift. The standing instruction does not name it.

Cheapest fix: add the five fields to `canonicalLine` and reseal. That is one line and one digest.

## FINDING 2, serious. A sailing's operator is guarded by nothing at all

Fault J set `operator` to `gold-cats-flyer` on `sealink-passenger-i2m-0515` while leaving
`serviceId` as `sealink-passenger-ferry`. `node tools/gate.mjs` is clean and
`node tools/check-crossings.mjs` prints `all 40 checks passed`.

That field is not inert. `src/systems/crossings.js:162, 305, 325` puts it into every
`crossing.departed` payload, and `tools/connections.mjs:530` reports it as the operator in the
same-minute conflict rows of the consolidation scenario. `tools/connections.mjs:471` reads the
operator off the service record for the same fact, so there are two sources for one truth and nothing
compares them.

Board note 029 closes with an instruction about this exact field: do not substitute a name from
memory and do not merge the two operators. Today the pack is right, checked: every sailing agrees
with its service on `operator`, `carries`, `mainlandPoint` and `islandPoint`, and every landing
point's `servedBy` matches the sailings that actually use it. Nothing enforces that it stays right.

## FINDING 3, serious. The page invites a check it does not supply the inputs for

`src/ui/crossings-view.js:413` prints, under the five hour gap: worked out from four times on this
page and nothing else, the first and last boat off the island today, and the first and last vehicle
sailing off the island today.

The page shows the NEXT boat off and the NEXT vehicle sailing off, not the first. Read out of the
running DOM at four ticks:

    tick    island time   "05:15" on the page   "07:00" on the page
    0       00:00         yes                   yes
    320     05:19         no                    yes
    720     11:59         no                    no
    1080    17:59         no                    yes, as "07:00 tomorrow"

So the sentence is true from 00:00 to 05:14 and false for the other 1,125 minutes of the day. The
three numbers above it are correct: 1 hour 45 minutes, 3 hours 15 minutes and 5 hours all reproduce
from the pack. This is the sentence that tells a reader they can check them, and at the minute a
person is most likely to be reading the page they cannot.

It is the one thing on this page a councillor could be caught out by, because it invites the check
and then does not supply the inputs. Two fixes are visible and neither is mine to choose: name the
two times in the note, or show first and last rather than next and last.

## FINDING 4, minor. A displayed figure cites one of the two records it was computed from

`gap-morning`, 1 hour 45 minutes, cites `sealink-vehicle-i2m-0700`. It is 07:00 minus the 05:15
SeaLink passenger sailing and it does not cite that record. `gap-total`, 5 hours, and `gap-now` cite
the service record `sealink-vehicle-barge`, and half of what built them is passenger records.

`node tools/uiprobe.mjs` passes 35 of 35 on `prov-resolves` because it asks whether a citation
resolves, not whether it names every record the value came out of. No citation here is false and none
is dangling. The gap is between pointing at a real record and pointing at the records this number was
computed from, and only the second is what the traceability bar asks for.

## FINDING 5, minor. A floor rounded upwards, in front of the owner

`out/capacity.mjs:27` prints the resident vehicle clearing time through `.toFixed(1)`. 1388 divided
by 560 is 2.4786, and `toFixed(1)` gives 2.5, so the line reads "at least 2.5 days". A floor of
2.4786 does not establish at least 2.5.

The figure is in board note 030, in front of the owner, with his own command named for reproducing
it, and `node out/capacity.mjs` prints it today. Everything else in that block checks out: 560 car
spaces is 5 x 60 plus 5 x 52, 3500 deck passenger spaces is 5 x 300 plus 5 x 400 and is never added
to it, 53 an hour is 560 over 10.5, and 1388 is 336 + 566 + 306 + 180 from G34 counting four-or-more
as four. Only the last line rounds the wrong way. About two and a half days carries the same weight
and claims nothing extra.

## FINDING 6, minor. The merged figure the law refuses exists in the system that refuses it

`src/systems/crossings.js` state carries `sailingsToday` and `departedToday`, single numbers spanning
all three service classes: 76 on a Friday. Nothing displays them, nothing asserts them, and
`tools/gate/crossings.mjs` says in its own header that it cannot see a merged field whose name uses
neither class word. `movementsTodayByService` is right beside them and holds the split. They are one
render call away from being the figure this whole pack exists to prevent.

## What I did not test, and why

- I did not open a SeaLink page, a Gold Cats page or the Redland disaster plan. The owner's supply is
  the source of record here and my third transcription came from his words, not from a website.
- I did not judge the picture. `node tools/shot.mjs --assert calibration` passes 6 of 6 and that is
  all a shot can say.
- I did not run `tools/uicompare.mjs`. I read the accessibility tree from outside the page with the
  browser pane and it agrees with the probe on all twelve panel names and every value text I checked,
  which is the same comparison by hand rather than by that tool.
- I did not test the crossings system inside `headless` or `determinism`, because
  `src/world/island.js` still does not register it. Board notes 032 and 035 both already ask for that
  and it is still open. `tools/check-crossings.mjs` is the only instrument that runs this system.
- I could not judge whether the owner recognises his island. No agent can.

## Confirmed, not newly found

`node tools/headless.mjs --ticks 1440` failed 2 of 6 consecutive runs on this machine, both times
`1 budget overrun(s) not explained by a collector pause`, on `solar` or `tide` and never the same
tick. Board note 035 posted this already and it is not mine to file twice. The corroboration is that
it reproduces at about a third of runs on a busy box, in systems this wave did not touch.

## Receipts, all run 19 August 2026

    node tools/gate.mjs                        PASS: 0 blocking, 13 advisory
    node tools/check-crossings.mjs             all 40 checks passed
    node tools/check-island.mjs                all 18 checks passed
    node tools/check-wiring.mjs                PASS: 13 checks
    node tools/bitemporal.mjs --check          PASS: 35 checks
    node tools/determinism.mjs --ticks 5000    PASS: 4 hashes identical in both runs
    node tools/shot.mjs --assert calibration   PASS: 6 of 6 samples within tolerance
    node tools/uiprobe.mjs --assert critic-w8-witness   PASS: 9 rules, 0 failures, 12 panels, 35 values
    node tools/connections.mjs --day friday    read in full and recomputed independently
    node out/capacity.mjs                      read in full and recomputed by hand

The first build was not written to. `git status --porcelain` in `minjerribah-living-twin` prints
nothing, its newest file write is 18 August 2026 13:00:37, and no file under it including `.git` has
a write time on or after 19 August 2026.

What I wrote: two probes into `out/probes/`, which is gitignored and is the instrument's own sink,
named `critic-w8-everyday` and `critic-w8-witness` so no other agent's probe was touched. Everything
else I made is in my scratchpad, outside the repository.

## What surprised me

I planted a middle-row transcription slip expecting to find the hole board note 034 found in
check-crossings, and `ground-truth/timetable-drift` named it exactly: the file, the line, the sailing
id, and the sentence saying the owner supplied 12:00 and this pack says 12:05. A second hand-typed
copy of a hand-supplied timetable is the kind of rule most projects would call not worth the
maintenance, and here it is the only thing standing between the owner's least recoverable data and a
silent edit.

The larger surprise is the one I went looking for and did not find. My transcription was typed from
his words with the pack unread, and it agreed on all 76 rows, on all 20 vessel assignments, on all
four red readings and on both asterisked Friday to Sunday sailings. Three copies of a hand-supplied
timetable, made by three different agents on the same day, zero disagreements. Findings 1 and 2 are
about what happens on the day that stops being true.

**Update 2026-08-19, status open.** Three of my own lines in this note were blocked by the rules it reports on, which is worth recording because it is the strongest evidence in it. crossings/unattributed fired twice, on a bare sailing count and on a bare movement count with no service or terminal named, and personal/street-address fired on a line where a street name sat beside a time and read as an address with a number. All three were my writing, not the build's. I rewrote them rather than marking them as specimens, and node tools/gate.mjs is back to PASS 0 blocking, 13 advisory, the same figures it printed before this note landed. A gate that catches the critic on the way out is a gate that is running.
