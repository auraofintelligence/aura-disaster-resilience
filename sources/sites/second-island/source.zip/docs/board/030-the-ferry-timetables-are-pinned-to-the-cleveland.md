---
id: 030
title: The ferry timetables are pinned to the Cleveland train, and the vehicle capacity arithmetic
status: open
opened: 2026-08-19
author: orchestrator, on the owner's ground truth
---

Two things from the owner on 19 August 2026 that board note 029 left open.

WHY THE TWO PASSENGER TIMETABLES ARE IDENTICAL. His words: the ferry timetables are identical because they have to connect with the Cleveland train and buses at Toondah Harbour, and buses at Dunwich. So it is not competitive matching and it is not an error in either source. Both operators are pinned to the same intermodal timetable.

That is a dependency this repository did not have, and it runs the other way from how a twin would naturally model it. The island's crossing timetable is downstream of Queensland Rail's Cleveland line. Change the train and every sailing time moves, both operators at once. Any scenario that reschedules the crossings without asking what the train is doing is modelling something that cannot happen.

It also sharpens the consolidation question in note 029 rather than dissolving it. If both operators are at Junner Street and both are meeting the same train, they cannot stagger without one of them losing the train connection. Two vessels, one berth, the same minute, fourteen times a day, because that is when the train arrives. Whether the berth can take that is an engineering question nobody in this repository can answer and someone should ask.

VESSEL CAPACITIES, now sourced. The owner supplied them with two sources, sealink.com.au ferry information and the Redland City disaster plan sea transport providers page.

  Sea Breeze    up to 60 cars, up to 300 deck passengers
  Minjerribah   up to 52 cars, up to 400 passengers

These are the same figures the first build carried as unverified research notes. They now have sources and come out of quarantine. Note that the Redland disaster plan is one of them: the council's own emergency planning names these vessels and their capacity.

THE ARITHMETIC, which follows from that and from census data already on this machine.

  base timetable off the island: 10 sailings, 5 Minjerribah and 5 Sea Breeze
  car spaces off the island per day: 560
  deck passenger spaces on those same sailings: 3500, a separate figure that is never added to it
  averaged across the 07:00 to 17:30 window: about 53 car spaces an hour

  2021 Census table G34, SA2 301021550, occupied private dwellings only:
  52 dwellings with no motor vehicle, 336 with one, 283 with two, 102 with three, 45 with four or
  more, 29 not stated. Counting four-or-more as exactly four gives a FLOOR of 1388 resident vehicles,
  and it counts occupied dwellings only, with 861 dwellings empty on census night.

  So clearing resident vehicles alone takes at least 2.5 days of every base sailing running full,
  before one visitor vehicle, tradesperson, delivery or holiday household is counted.

CAVEATS THAT MUST TRAVEL WITH THAT NUMBER, and it should not be quoted without them: it is the base
timetable and SeaLink adds services that are visible only on its booking page; the capacities are
stated as up to, and real loading is lower because vehicles differ in size; the census is 2021 and
counts occupied dwellings; and this is capacity arithmetic and not an evacuation model. It says
nothing about whether people would leave, in what order, or whether the boats would run at all.

Reproduce with node out/capacity.mjs.

STILL OPEN: which mainland berth the Flyer uses at Toondah, and whether the berth at Junner Street
could physically take both operators at the same minute.
