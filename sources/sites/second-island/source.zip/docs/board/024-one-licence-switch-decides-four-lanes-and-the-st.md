---
id: 024
title: One licence switch decides four lanes, and the stage 4 slice is behind the wrong one
status: for-owner
opened: 2026-08-19
author: wave 5, scout
tags: licence, gate-derived, stage-4, owner-decision, ingest
---

One switch now decides four lanes with four different licences, and it is the switch on the
OpenStreetMap question. This is not a defect report against the rule, which does exactly what the
wave told it to do. It is the consequence for stage 4, and the two halves of it are opposite
mistakes.

Board note 013 already asks you the ODbL question and I am not asking it again. This note is the
part that sits either side of it.

## What is true today, checked

`tools/gate/derived.mjs` line 75 is `const LICENCE_NOTE_ID = '007'`. While that note is anything but
`resolved`, four marks of a derived pack are blocking under `data/`: a pack name a connector writes,
a string pointing at `ingest-inbox/`, a self declared `committable: false`, and a bulk feature set.
`src/world/data.js` line 23 reads exactly one directory, `data/`. `STAGE_0_PACKS` is `['tide']`.

    node tools/headless.mjs --ticks 1440
      systems:  2 registered
      store:    {"entities":0,"nextEntity":1,"freed":0,"components":{}}

So the running world reads none of the 1,939 derived records this wave produced, and it cannot,
because the loader reads one directory and the gate blocks that directory.

## Half one: the switch is broader than the question

Three of the four staged lanes have a settled licence, and `data/_sources.json` already says so in
its own words. The Open-Meteo entry, written by the ingest agent, ends: "Neither licence blocks this
lane. The blanket hold on committing derived packs does: board note 007."

| lane | licence, as recorded in data/_sources.json | is note 007 its question? |
| --- | --- | --- |
| OpenStreetMap | Open Database Licence | yes. This is the question |
| TransLink GTFS, island feed | Creative Commons Attribution 4.0 | no |
| ABS Census DataPacks | Creative Commons Attribution 4.0 | no |
| Open-Meteo archive | Creative Commons Attribution 4.0 | no |
| Atlas of Living Australia | fourteen values, per record | no, and see half two |

The stage 4 slice runs on the TransLink lane. Forty real Friday trips and 692 timed calls sit in
`ingest-inbox/derived/`, under a licence that is read and settled, held by a switch on a different
licence entirely. Board note 023 is the full receipt.

**What only you can decide:** whether a lane whose licence is read and settled may land in `data/`
while the OpenStreetMap question stays open, and if so under what attribution surface, since all
three of those licences owe attribution and this repository has no player facing surface that
carries one yet.

## Half two: when the switch flips, it flips for everything

The day board note 007 reads `resolved`, `tools/gate/derived.mjs` stands down for every pack, by
design and with no edit. One of those packs should not be waved through by an OpenStreetMap
decision. The Atlas of Living Australia pack carries its licence per record, and I counted them:

    distinct recordLicence values: 14
      7876  CC0
      2967  CC-BY 4.0 (Int)
      1520  CC-BY-NC 4.0 (Int)
      1149  CC-BY-NC 3.0 (Int)
       404  CC-BY-NC
       324  CC-BY-NC 3.0 (Au)
       241  CC-BY
         8  CC-BY-NC-ND 4.0 (Int)
         6  CC-BY 3.0 (Au)
         4  CC-BY-ND 4.0 (Int)
         3  UNSPECIFIED
         2  CC-BY-SA 3.0 (Int)
         2  CC-BY-SA 4.0 (Int)
         1  CC-BY-NC-SA 4.0 (Int)

Of 14,507 records: 3,406 are non-commercial, 12 forbid derivatives, 5 are share-alike and 3 say
nothing at all. Your `LICENCE.md` reserves commercial rights, so the non-commercial records are the
one place where a record's own licence is stricter than yours rather than looser, and the twelve
no-derivatives records are a problem for a pack that exists because it derived them.

**What only you can decide:** whether the derived gate keeps one switch, or one switch per lane. A
per lane switch is a small edit and it is not mine to make.

## What this note does not claim

- It gives no legal opinion and I am not qualified to give one. Every licence string above was read
  out of `data/_sources.json` or counted out of a staged pack, and the counting is the whole of my
  contribution.
- It does not ask you to resolve note 007. That is note 013 and it is already in front of you.
- The rule is not wrong. It implements the wave's instruction that nothing derived is committed, and
  it does that correctly. What is uneven is that one licence question is standing in for four.
