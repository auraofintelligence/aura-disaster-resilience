# Ground truth

**19 August 2026.** The owner said it plainly: "you need ground truth not assumptions." This file is
what that means for the code, written on the day it was proved seven times.

## The tally, because it is the evidence

Every one of these was a figure or a structure this repository held with confidence. Every one was
corrected by the person who lives there. Not one went the other way.

| what we held | what is true | how we got it wrong |
| --- | --- | --- |
| The island has 601 building outlines | OpenStreetMap has 601. The census counts 1,703 private dwellings, and no dataset counts caravans, sheds or off-grid dwellings on claimed land | reported a dataset's coverage as the ground |
| No Aboriginal word may appear unless it is on the allowlist | The allowlist was written by a Claude instance. It flags fourteen gazetted street names and works against a published language revival | generalised a rule against fabrication into a rule against use |
| The crossing, singular, with passenger and vehicle kept apart | Three service classes, two operators, two landing points | the correction we inherited was true and too coarse |
| Two identical timetables means competitive matching, or an error in a source | Both operators are pinned to the Cleveland train and buses at Toondah and Dunwich | reached for a market explanation of an intermodal fact |
| Vessel capacities are unverifiable and must be quarantined | Published by SeaLink and named in the Redland City disaster plan | did not look where the person who lives there knew to look |
| The boats are the constraint, so the capacity arithmetic is the finding | The boats are usually not full. The island buses are the bottleneck, and that is what turns walk-on visitors into car-borne ones | had every piece and read the causal chain backwards |
| `docs/FOUNDING-PROMPT.md` is the brief | A previous Claude wrote it. He demoted it to a draft | never asked whose document it was |

The pattern is not random error. It runs one way: toward what a model would expect, away from what is
actually so about this place. The owner's own note to agents in `githublocal\A-NOTE-TO-THE-NEXT.md`
recorded the same direction after seven corrections in a single day, more than a year ago, and it
happened again today to an agent that had read that note.

## What follows for the code

**1. Ground truth from a person is a first-class source, not a lesser one.**

`data/_sources.json` treats a URL as the real thing and a person as an absence. Today the person
outperformed every API in the repository. A source record for supplied knowledge carries: who said
it, when, what they said verbatim, what it corrected, and what remains unknown. It is checked by
`gate/provenance` like any other source, and it is never labelled anecdotal.

The verbatim matters. Paraphrasing is where the drift enters. "There are numerous barges run by
sealink" is the record; "SeaLink operates multiple vehicle services" is a reconstruction, and a
reconstruction is what this whole file is about.

**2. A number nobody has checked must say so.**

Every figure that failed today had no human behind it. So the twin needs a flag that is not about
instruments at all: **has a person who would know ever confirmed this.** Three states, and the
middle one is the point:

    confirmed    a named person with standing has checked it, and when
    unchecked    it came from a dataset or a calculation and nobody has looked
    contested    a person and a dataset disagree, and both are recorded

`unchecked` is the default and it is displayed, the same way the tide displays that it does not know
its own height. A figure with nobody behind it does not get to look like one that has been checked.
This is cheap, it is honest, and it turns the assumption problem from something the owner has to
find into something the artefact admits.

**3. The absence of ground truth is a finding, not a gap to be filled quietly.**

Where nobody has checked and nobody can, that is information about the island: the record does not
see caravans, sheds or dwellings on claimed land; SeaLink's extra vehicle sailings exist only on its
booking page; no published table gives the tide at this port. Each of those is a fact about who can
see what, and a civic instrument that hides them is doing the opposite of its job.

**4. This is the participatory build path, at n = 1.**

The owner asked for a build path that is participatory and inclusive. It has been running all day
with one participant and no infrastructure under it, and it has been the most productive input this
project has had. The mechanism to carry it to more people already exists in his own work: the
noticeboard's `profile.md` public, `aura.md` private, `public_noticeboard.md` as the contract, with
a named human release gate. Build the intake to that shape and it scales from him to the island
without being redesigned.

## The rule

Before any figure goes in front of a person, ask what would happen if someone who lives there read
it. If the answer is that they would correct it, it is not ready, and the fix is to ask rather than
to reason harder.
