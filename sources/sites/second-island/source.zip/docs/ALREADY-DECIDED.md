# Already decided

**What this file is.** Everything below was decided by the owner, in his own published work, before
this repository existed. It is here so no agent re-decides it, and so that a session which cannot
hold his corpus does not have to.

He named the constraint himself on 19 August 2026: "my plans are too big for your context windows."
The engineering answer to that is not a bigger container. It is to hold the interfaces between the
projects rather than the projects, which is what this is.

**Read this before docs/FOUNDING-PROMPT.md.** That document was written by a Claude instance, not by
him, and he demoted it to a draft on 19 August 2026. This one is derived from his live sites, read
in full on 19 August 2026: micronova-and-excursions (28 pages), grain-by-grain-documentary,
straddie-clean-energy-superpower, sandworm-subterranean-systems, p4a.xyz, and the
straddie-noticeboard-network with its events engine.

**Every quote below is his.** Where a claim carries a page name, that is the page it came from, on
his site or in his repositories. If you are about to invent something, look here first.

---

## 1. The spine

Five capabilities. Each project is the same engine asked a different question.

**a. A record that cannot be stored bare.** All five independently invented per-datum status, and none of them invented a score. Micronova: five labels, `Known / Modelled / Disputed / Speculative / Unsupported`. Grain by Grain: seven, including `Story` and `Needs checking` (`docs/evidence-register.md`). Sandworm: `loose, promising, contested, sourced, private` (`builders/source-trail.html`). P4A: `confidence`, `review_status`, `visibility`, `consent_model`, `correction_path` as required front matter (`assets/p4a-builders.js`). Second-island already runs eight provenance fields plus a `register`. The engine stores a value only with source, date, register, confidence and consent scope attached.

**b. Scale addressing, with the rung count left open.** P4A `L0/L1/L2/L3+` and a written prohibition on hardcoding the count; Sandworm `L0 bench / L1 shared gateway / L2 bioregion`; Grain by Grain's board of eight, self through deep time; Micronova's cell → person → satellite. Every object resolves to a scale path, and questions are answered at the rung asked.

**c. Stock-and-flow accounting where the unallocated remainder stays visible.** Spoil to product (three projects), the 38 m³ food loop, C-Hours, water and medicine stores. One mechanism. The residue term is mandatory: "'Nothing spoiled' is a direction for research, not a claim that every stream already has a safe destination" (grain-by-grain `mission.html`).

**d. A counterfactual clock, with lead time as a parameter and zero as a legal value.** Every project's real question is a removal: tunnel never built, barge not sailing, grid down, pilot removed, no warning at all. "Preparation against the fast class cannot rest on alerts" (micronova `building.html`) makes zero-notice a required scenario class, not an edge case.

**e. An answer object that carries its own refusal.** Not a UI affordance, a return type. Sandworm ships "Reasons to slow or stop" in all ten builders; P4A publishes rejections with reasons; micronova's tests name their kill conditions ("A flat residual kills it"); second-island's `not-known-is-an-answer` already passes.

**The fault line, named.** Micronova is not a fifth question asked of the twin. It is a parameter supplier: the evidence pages "shape the specification, around timing and around how hard the shelter holds, rather than being the ticket in" (`building.html`). Treat it as inputs (depth, dose, lead time), not as a module. And nothing across the five wants a control system: "Mirror, not master" (sandworm `digital-twin.html`), "Digital twin, not digital master" (p4a `web3-sensorium.html`).

## 2. The first slice, argued

Keep the Friday. Invert it. The founding prompt's normal barge day models the island working, which is the one state his brief never asks about: cyclone season, fire season, supply chain disruption. Sandworm's gate is "still be useful even if the largest Sandworm never gets built" (`index.html`), and our own pipeline already states the law: "You can almost always get off the island; you cannot always get your car off, and the second question is the useful one" (`INGEST-STATUS.md`). The counterfactual is also the cheaper build, because the working day needs barge data we do not have and the failed day needs the absence we already hold honestly (`crossing-vehicle-barge` carries a null count with the reason attached). Board note 023 shows the surrounding day is free and licence-settled: 40 Friday trips, every one touching both terminals, downloaded, CC-BY. The objection is real, that without barge capacity there is no baseline to measure loss against, and the answer is that the loss is measured in things we do hold: 1,703 dwellings, 2,156 residents, 44 stops, and a real weather year with 137.8 mm on 13 February 2026. Run the slice on that wet Friday with the vehicle crossing at zero sailings.

**The one thing that proves it.** A resident-shaped question returned twice, same question, barge absent and barge restored, where the number changes, every number traces to a receipt, and the barge capacity comes back as an explicit unknown with its reason rather than a plausible figure. If the engine invents a car deck to make the answer complete, the slice failed.

## 3. Already specified. We were about to guess these.

- Volume, not floor area: 38 m³ food cell, ~100 m³ per person. "A volume carries no site assumption inside it" (micronova `building.html`).
- Groundwater is the enabling condition, not a hazard: heat sink, supply, shielding, "one site condition answering three problems" (`building.html`).
- Excavation and materials net against each other: "The spoil is the building" (`building.html`).
- Sorting is by response, not by cause. Eighteen threats, six preparations (`building.html`); "Sort by what fails and what has to endure" (grain-by-grain `runtime.html`).
- Tunnel default 1.5 m bore, range 0.6 to 5 m, advance to 1,250 m/week, forming factor **1.15** (above 1) (`reefs.html` / `reef-calculator.js`).
- Sand batteries are heat, not electricity, and discharge into a separate heat demand layer (`storage.html`, `sharing.html`).
- No underwater blades, no towers, perched lakes excluded as storage: "A perched lake can be a teacher without being the battery" (`builders/perched-lake-boundary.html`).
- Solar objective is local offset, not export revenue (`sharing.html`).
- Transport is on-call autonomous, 24/7/365, not a timetable, and "mainland shopper days" is a third parking demand class (`index.html`, `start.html`).
- Material passport, seven fields: source, test, reviewer, destination, reuse, risk, public benefit (`sandworm-lab.html`).
- Reversibility is a modelled state: removable pilots need the site rendered after removal (`civilisation-of-sand.html`).
- Councils are the default map drill-down; electorates, bioregions and Nation boundaries are overlays, not replacements (p4a `states/qld/architecture`).
- Agents read, a separate permissioned container writes (p4a `architecture.html`).
- Collective consent is a distinct axis: `consent_model: collective-authority-required` already exists as an enum.
- C-Hours are not hand-entered and not spendable: `legal_gate_status` exists so verified hours can be held and not issued (`c-hour-receipt-builder.html`).
- FDV and refuge locations are never a map layer: "A public ledger must never become a map for an abuser" (`housing-simulations.html`). Wildlife locations likewise (grain-by-grain `boundaries.html`).
- Vacancy is not supply: "Unoccupied dwellings trigger local inquiry, not seizure."
- Every rendered frame carries its own provenance across six values, real footage through story (`boundaries.html`).
- Compliance, not detection accuracy, sets the outcome; false-alarm rate is the sensitive variable (micronova `earthquake.html`).
- "A bold simulation does not create site rights" (grain-by-grain `mission.html`).
- Scope is the Straddie-Moreton island system, not Minjerribah alone (`docs/90-minute-treatment.md`).

## 4. Data, ranked by what it unblocks

**Public, not yet fetched.** (1) ELVIS LiDAR island coverage: no OSM building carries a height and only 27 carry levels, so every extrusion is modelled until this lands. (2) The 58 unread census tables already on disk: G36 alone corrected our building count. (3) ASGS SA1 boundaries, to close the SA1-to-township join. (4) DCDB cadastre. (5) Clean Energy Regulator postcode solar installs, his named rooftop register. (6) TMR Dunwich/Gumpi concept design and business case. (7) WetlandInfo perched-lake hydrology, which is the correct run-off model here. (8) QImagery, Trove 1896 to 1898.

**Exists, held, must be asked for.** The vehicle barge operator and the passenger boat operator, for sailing counts and vehicle capacity as two separate numbers: this is the single highest-value unblock and no format substitution will produce it. BOM registered data service (registration required; the undocumented endpoint is prohibited). Redland City Council for road segments, repair history, parking inventory and asset register. Wildlife Rescue Minjerribah for the records behind the 250+ figure. Tide constituents for Dunwich, still unobtained (board note 004).

**Does not exist anywhere; his participatory path is the answer, not a connector.** A complete building footprint set (Queensland excludes anything under 625 m² and its publisher states no complete dataset exists, board note 027). Per-household readiness against the six preparations. Island electrical supply, load profiles and heat demand inventory, absent from every project. Sand assay, contaminants and lifecycle tests. Geotechnics and hydrogeology of a sand island. Beneficial residential ownership: "not one plain public map" (p4a `housing-simulations.html`). Who on the island knows how to fix what.