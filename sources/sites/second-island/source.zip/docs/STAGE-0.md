# Stage 0: the instrument, before anything it will measure

The founding prompt's first stage. Nothing else in this repository starts until every instrument
below has caught a fault that was put there on purpose. This file is the specification of the
instruments and the faults. `docs/JURISDICTION.md` is its output and is generated, not written.

## Why an instrument needs a subject, and what we chose

An instrument cannot be validated against nothing. So stage 0 ships the smallest world that is still
a real one: two systems whose numbers are physics rather than invention.

- **solar**: sun elevation and azimuth from real solar geometry, carried from the first build, which
  the founding prompt names as a carry.
- **tide**: water level at the Dunwich standard port from the official harmonic constituents, also
  a named carry.

Neither invents anything, both are deterministic, both are needed later, and between them they give
the instruments something real to hash, draw and display. No timetable, no residents and no
buildings exist at stage 0, on purpose: the first real data arrives at stage 2 and arrives real.

## The instruments

Each is a Node script in `tools/`, runnable alone, machine-readable with `--json`.

### 1. `headless.mjs`

Runs the whole simulation in Node with no browser and no renderer.

    node tools/headless.mjs --ticks 1440
    node tools/headless.mjs --ticks 1440 --json

Reports: ticks run, wall time, ticks per second, per-system state hash, per-system tick cost, and
the world hash. Fails loudly if any system throws, if a system exceeds its tick budget, or if the
simulation reaches into the renderer or the DOM.

### 2. `determinism.mjs`

Runs the world twice from the same seed and diffs it.

    node tools/determinism.mjs --ticks 5000
    node tools/determinism.mjs --ticks 5000 --shuffle

Hashes every system's state at every checkpoint. On a difference it reports **the first divergent
tick and the name of the system that drifted**, and a sample of the diverging fields. Naming the
system is the requirement, not an extra: the first build could tell you two runs differed and not
what moved. `--shuffle` registers systems in a different order to prove the explicit ordering rule.

### 3. `bench.mjs`

Frame time distribution from the running page.

    node tools/bench.mjs --frames 600

Reports p50, p95, **p99** and the worst frame, plus the frame that produced the worst. Fails on the
p99 budget in `tools/budgets.json`. The average is not reported, because reporting it invites
someone to quote it.

### 4. `shot.mjs`

Real pixels from the page to disk. The browser pane in this environment does not reliably composite
frames, so the page renders offscreen, encodes a PNG and POSTs it to the server, which writes it to
`shots/`. A critic then opens the file.

    node tools/shot.mjs --name calibration
    node tools/shot.mjs --assert calibration

`--assert` runs the pixel assertions for a named scene: sample points with expected colours and
tolerances, declared in `tools/scenes/<name>.json`. A screenshot nobody can machine-check is a
screenshot a builder can talk their way past.

### 5. `uiprobe.mjs`

The interface, which a screenshot structurally cannot see. Two witnesses, on purpose:

- **Self-report**: the page exposes `ISLAND.probe()`, which walks the DOM and POSTs a structured
  report to `out/probes/<name>.json`. `tools/uiprobe.mjs` asserts on that file.
- **Independent**: the accessibility tree, read by an agent with a browser tool and compared to the
  self-report. A page that lies about itself fails this comparison.

The contract it enforces: every panel has a role and an accessible name; every number displayed on
screen carries `data-prov` naming a record; every `data-prov` resolves to a record that exists;
every record shown carries its register and, where confidence is low, its contested marker.

### 6. `gate.mjs`

Every rule in `docs/CONTRACT.md` that can execute. Runs all of `tools/gate/*.mjs`, reports rule id,
file, line and the offending text. Exit code is non-zero on any blocking rule.

    node tools/gate.mjs
    node tools/gate.mjs --rule lore

### 7. `board.mjs`

The noticeboard. One note per file in `docs/board/`, statuses open, taken, resolved, for-owner.

    node tools/board.mjs read
    node tools/board.mjs post --title "..." --status open --author "..." --body "..."

### 8. `selftest.mjs`

The meta-instrument, and the one that makes stage 0 real.

    node tools/selftest.mjs

For every fault in `tools/faults.mjs`, it runs **every** instrument twice: once on the healthy build
and once with the fault injected. It asserts the healthy run passes, the faulted run fails, and the
failure message names what the registry says it must name. The full fault by instrument matrix is
written to `docs/JURISDICTION.md`.

## Fault injection

Faults are named, registered, and switched on by the environment variable `ISLAND_FAULT`. Fault
hooks may appear only in files the registry declares, so injection code cannot drift into behaviour
unnoticed. `gate/instruments` fails if a fault has no declared hook site, if an instrument has no
fault that proves it, or if a fault is caught by no instrument and is not listed as a known blind
spot with a reason.

## The fault registry

| id | what it breaks | which instrument must catch it | what the failure must name |
| --- | --- | --- | --- |
| `nondeterminism` | the tide system draws from an unseeded source | determinism | the tide system, and the first divergent tick |
| `order-dependence` | a system reads registration order instead of its declared order | determinism `--shuffle` | the system |
| `sim-imports-render` | a kernel file imports the renderer | gate/imports, headless | the importing file and line |
| `wallclock` | a system calls `Date.now()` | gate/no-wallclock | the file and line |
| `blank-render` | the renderer clears and draws nothing | shot `--assert` | the failed sample point and its colours |
| `stale-frame` | the renderer stops following the sim tick | shot `--assert` | the sample that did not move |
| `hitch` | a 40 ms stall every sixtieth frame | bench | p99, the budget, and the worst frame |
| `ui-unlabelled` | a panel loses its accessible name | uiprobe | the element |
| `ui-dangling-prov` | a number cites a record id that does not exist | uiprobe | the id and the element |
| `ui-text-change` | a visible label changes text | uiprobe catches it, **shot must not** | the changed label |
| `banned-token` | a banned word is written into a data file | gate/lore | the token, file and line |
| `invented-language` | a plausible language word not on the allowlist | gate/lore | the word, file and line |
| `approval-claim` | the cultural queue described as approved | gate/lore | the phrase and line |
| `missing-provenance` | a record without `source` and the two times | gate/provenance | the record id and the missing fields |
| `em-dash` | an em dash in a doc, a comment and a commit message | gate/style | each occurrence |
| `personal-data` | a mobile number in a staged file | gate/personal | the file, line and the pattern that matched |
| `unsealed-staging` | the ingest inbox becomes committable | gate/sealed | the path, proven by asking git |

`ui-text-change` is the important row and it is the only one whose expectation is inverted. It exists
to establish, executably, that the screenshot instrument cannot see the interface. The first build
spent three waves judging its interface through screenshots that structurally could not contain it,
and every verdict from that period was worthless. After this row lands, no critic in this repository
can make that mistake without the matrix contradicting them.

## Status

Generated by `node tools/selftest.mjs` into `docs/JURISDICTION.md`. Until that file exists and every
row in the registry above is green or explicitly excused, this repository is at stage 0 and no other
stage may begin. "Exists, untested" is an acceptable row. "Works" without a receipt is not.
