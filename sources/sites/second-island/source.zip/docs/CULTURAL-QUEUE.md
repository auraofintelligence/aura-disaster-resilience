# Cultural queue

Minjerribah is Quandamooka Country. QYAC, the Quandamooka Yoolooburrabee Aboriginal Corporation,
holds and manages the Quandamooka People's native title rights and interests.

**QYAC has not seen this project. Nobody has asked.**

**Nothing in this file is an approval.** No entry here may be described as approved, endorsed,
cleared or signed off by QYAC or by the Traditional Owners, because none of those things has
happened. That is not a style rule. `tools/gate/lore.mjs` reads this file and every file that
mentions it, finds each of those words, and fails the build when one of them is used of QYAC or of
the Traditional Owners without a negation in the same sentence. The fault that proves the check is
registered as `approval-claim` in the stage 0 fault registry, and nothing here is one.

This is a queue of open questions, held open on purpose. An entry leaves it when a human has had an
actual conversation and writes down what was said. No agent may close an entry, and no agent may
infer an answer from silence, from a public document, or from what a reasonable body would probably
think.

## Where this file came from, and what it is not

Seeded on 18 August 2026 from the first build's `docs/CULTURAL-REVIEW.md`, which runs to 900 lines
and carries twelve days of that build's history: its ecology pack, its residents slice, its civic
panels, its connector layer, its opening-hours pass, its map lane, its legislation pack. None of that
history is this repository's, and wearing it would be a lie about how much has been thought through
here.

**What this repository has built is its instruments and a sun.** Two systems, solar and tide, and the
tide is deliberately unfed. No residents, no places pack, no buildings, no events, no page, no
renderer. So the queue below is short, and it is short because the build is young rather than because
the questions are settled.

Every entry here is a question that is live for a repository at exactly this stage. The first build's
other sections become live here only when this build makes the thing they are about, and the last
section of this file says when.

## How an entry is written

**Affects** names the file and, where it helps, the line. **True today** is what is actually in the
repository right now. **The ask** is the question in the form a person could put it. **Blocked
until** says what may not be built while the question is open, because a queue with nothing behind it
is a wish list.

---

## Q1. Does QYAC want this to exist at all

**Affects:** the whole repository.

**True today:** nobody has asked. `data/lore.json` carries `"status":
"not_reviewed_by_traditional_owners"` and a `qyac_public_positions` block that records QYAC's view on
this project existing as explicitly unknown. Recording the unknown honestly is the right thing to do
and it is not the same as asking. A browser digital twin of Quandamooka Country, built by
non-Quandamooka hands from public records, is exactly the kind of thing a Traditional Owner
corporation may hold a firm view about.

**The ask:** does QYAC want a thing like this to exist, and if so on what terms.

**Blocked until:** nothing is blocked by it today, which is precisely why it is easy to keep not
asking. It blocks publication. The repository has no remote and has never been pushed, and that is
the moment this question becomes unavoidable rather than deferrable.

---

## Q2. The acknowledgement: what it says, where it appears, and whose name is on it

**Affects:** `README.md`, the Acknowledgement of Country section at the end;
`data/lore.json` `acknowledgement.game_wording`; and the first page, when one exists.

**True today:** two wordings are in play and they are not the same text.

- `data/lore.json` carries `acknowledgement.game_wording.long`, `.short` and `.hud`, written by an
  agent in the first build. The pack's own note says the project does not copy QYAC's published
  acknowledgement into an asset and uses its own plain wording instead, deferring to QYAC's published
  wording as the reference.
- `README.md` carries a variant of the long wording: it drops the pack's sentence naming QYAC as
  holding the native title rights and interests, and adds a sentence that says QYAC has not seen this
  project.

Both were written by agents. Neither has been put to anybody.

There is a mechanical consequence worth knowing before the first page is built.
`tools/gate/lore.mjs` executes the pack's `acknowledgement-present` rule, which requires the long or
the short wording to appear **verbatim** in `index.html` or under `src/ui/`, at load, not behind a
menu. Today that rule reports `NOT YET RUN` because no page exists. The moment a page exists, the
pack's exact words are what the gate demands, so changing the wording means changing the pack, and
the pack is a carried artefact: see Q5.

**The ask:** what should the acknowledgement say, where should it appear, and should QYAC's name be
on it at all.

**Blocked until:** nothing is blocked. The wording that ships is a decision that has not been made,
and it will be made by default by whoever builds the first page unless it is made deliberately first.

---

## Q3. Place names: three published spellings and no ruling

**Affects:** `data/tide.json`, the `port` record, which names the island reference site as
"Dunwich, Minjerribah"; `data/lore.json` `language.allowlist`; and every place pack that arrives at
stage 2.

**True today:** this repository names exactly one place, and it names it in English. The carried pack
records that published sources disagree with each other about the Quandamooka names, including QYAC's
own documents against each other: Goompi, Gumpi and Koompe are all published for Dunwich, and the
same kind of variation is recorded for Amity Point, Point Lookout, Blue Lake, Brown Lake, Myora
Springs and Moreton Island. The North Stradbroke Island Museum states on its own language map that
colonisation and the suppression of language produced ad hoc variation and that the names it
publishes are not universal. The pack records the variation rather than picking winners, and this
build has picked no winners because it has named nothing.

**The ask:** which spelling should the twin use for each place, and should it show the variants at
all or settle on one.

**Blocked until:** the first place pack. That pack cannot be written without answering this, because
writing it is answering it. `tools/gate/lore.mjs` will block a language word used in a name position
that is not on the allowlist, but it cannot choose between three spellings that are all on it.

---

## Q4. Should there be a Quandamooka seasonal calendar in the clock

**Affects:** `src/kernel/clock.js`.

**True today:** there is no season concept in this build at all. The clock in this repository is
integer minutes, a civil date and a weekday, and nothing else. That is not a fix, it is an absence,
and the question has to be answered before anything fills it.

The reason it is in this queue at this stage is the first build's receipt. That build carried six
season names in its clock, presented as a Quandamooka calendar and written from memory. None could be
sourced. One was demonstrably wrong in the way it was used: *yalingbila* is published as meaning
whale, in the QYAC and University of Queensland project *Yalingbila Bibula* at Mooloomba, and it was
being used as the name of a hot wet season. All six were deleted, the code identifier that asserted
the calendar was Quandamooka was renamed, and the words went on a banned-token list. That list is
carried into this repository byte for byte and `tools/gate/lore.mjs` executes it.

The first build searched for a published Quandamooka seasonal calendar and found none: not in QYAC's
publications, not in Queensland Government material, not in the Bureau of Meteorology's Indigenous
Weather Knowledge calendars, not in the North Stradbroke Island Museum's language material. Jajoo
Warrngara: The Culture Classroom hosts a video titled *Quandamooka Seasonal Cycles*, presented by
Quandamooka Traditional Custodian Elisha Kissick, and its contents sit behind a subscription and were
not read.

**The ask:** should a Quandamooka seasonal calendar be in the twin at all, and if so whose, in whose
words, and with what attribution.

**Blocked until:** any season, weather band, ecological cycle or calendar feature. Until it is
answered, seasons in this build are plain descriptive English or they do not exist.

---

## Q5. The carried cultural pack itself

**Affects:** `data/lore.json`, the whole file.

**True today:** this build carries the first build's cultural pack byte for byte. Checked on
18 August 2026: sha256 `0d3e65ceee59c1711b729c81a83a669f96ba1f17e6c36acb139111ed12b016d0` in both
repositories. The founding prompt names it as a carry and `docs/CONTRACT.md` section 7 says data,
constants and gate rules are copied exactly while prose is rewritten, so carrying it is the rule
being followed rather than a shortcut.

What that means in practice is that a document assembled by agents from public sources, in a build
QYAC has not seen, is now the authority two builds check themselves against. It is a good document.
It is not one anybody outside these two repositories has ever looked at.

**The ask:** is this pack something QYAC would want to look at, correct, or want removed. And a
narrower one that is ours rather than theirs: who owns it now that two repositories depend on it, and
what happens when one build needs to change it.

**Blocked until:** nothing is blocked, and one thing is constrained. This build does not edit the
pack. `tools/gate/lore.mjs` raises findings inside it as questions for the owner rather than as build
failures, which is the right behaviour for a carried artefact and is also a standing reminder that
the pack has open questions in it.

---

## Q6. What the first ingest lane will ask, before it is opened

**Affects:** `docs/INGEST-STATUS.md`, and stage 2.

**True today:** no data has been downloaded and `ingest-inbox/` does not exist, so no cultural
question has been raised by real data yet. This entry exists so that the question is asked before the
first lane opens rather than after the first pack lands.

Three of the lanes on the day-zero list touch Country directly and will raise questions this file
cannot pre-answer: the cadastre and OpenStreetMap lanes will place and name things; the Trove lane
reaches into the historical record of the protection era and the missions; the QImagery lane produces
imagery of the whole island including places that are not ours to publish. The carried pack already
forbids placing, naming, coordinating or generating any restricted place, and
`tools/gate/lore.mjs` executes that rule with a scope this build widened to cover `assets/` as well
as `data/`, because the first build found that gap in its own rule and did not close it.

**The ask:** who at QYAC should see an ingest lane before it opens, and what should be sent to them.

**Blocked until:** the first lane that produces place geometry or historical material. A weather feed
or a tide table raises nothing here. A cadastre extract does.

---

## What is deliberately not in this file

The first build's `docs/CULTURAL-REVIEW.md` carries whole sections that are not questions for this
repository yet, because this repository has not built the thing each one is about. They are named
here so that nobody has to wonder whether they were missed, and so that the person who builds each
thing knows a question is waiting for them.

| the first build's section | about | becomes live here when |
| --- | --- | --- |
| B, the lore pack detail | family groups, the protection era, named places and people, native title agreements, art | a places pack, a history layer or any player-facing cultural text exists |
| C, the ecology pack | ecological knowledge and its attribution | an ecology pack exists |
| R, the residents slice | whether simulated residents may be Aboriginal, and what that would mean | residents exist |
| G, the civic board and calendar | what a civic panel shows about cultural records, and where it stops | a page and a panel exist |
| N, the connector layer | publicly advertised events with a Quandamooka subject, carried as advertised | a connector or feed exists |
| E, opening hours | which bodies are not a shopfront and must not be given an open sign | a businesses pack exists |
| M, the owner's map | proposals on the owner's own map that touch Country | the map lane is ingested |
| L, the legislation pack | two Acts about Aboriginal rights and heritage | the legislation stack is ingested |

Copying those sections here today would make this repository look like it has thought about eight
things it has not built. It has thought about six, and they are above.

---

*Ancestry: seeded from `minjerribah-living-twin/docs/CULTURAL-REVIEW.md` on 18 August 2026 and
rewritten for this build. The first island keeps running. Nothing in this file has been put to
anybody, and nothing in it is settled.*
