# Standing instructions for any agent in this repository

You are in **second-island**, the second build of the Minjerribah twin. Read
`docs/FOUNDING-PROMPT.md` in full before writing anything, and obey its order of operations: the
measurement instrument comes first, and nothing else starts until a deliberately broken build fails
loudly.

## Separation, absolute

- `../minjerribah-living-twin` is the FIRST build. You may READ it: its data packs, its doctrine
  documents and its lessons are this project's inheritance. You may never write into it, and an
  agent working there may never write here. If a task seems to require editing both, stop and say so.
- Do not copy code from the first build by reflex. Copy data, doctrine and constants (tide
  harmonics, solar geometry, the banned-token list). Code comes over only when the founding prompt's
  architecture says the old shape is still the right shape, which it usually is not: that is why
  this repository exists.
- Ports: this repo serves on **4281** (app) and **4282** (progress). 4271 and 4272 belong to the
  first island. Never bind them.
- The owner's other repositories under `githublocal` are sources, not workspaces.

## The rules that bind every line here

Australian English. Prices in A$. No em dashes anywhere, including code comments and commit
messages. No overstatement. No invented business, place, road, person or word. The cultural
boundary in the founding prompt is blocking, and the banned-token list is seeded from the first
build's `data/lore.json`. Every rule that can be a runnable check is one, in the gate, before the
thing it checks exists.

Git from commit zero: every wave lands as a commit with an honest message. Nothing is marked done
that was not verified in the running artefact by the person marking it.
