// The record type: provenance and the two times.
//
// A digital twin is a bitemporal database with a renderer attached. Every record therefore says
// when it was true of the island, and separately when the twin learned it. With both, live mode,
// history mode and scenario mode are three cursor positions over one store rather than three
// systems that have to be kept in step. The first build kept a single time and paid for it in
// every panel that touched time.
//
// This file is the type and its validator. The store that queries across the two axes arrives with
// stage 3, and it can only work if nothing was ever written without both times, which is why the
// validator is here at stage 0 and the gate runs it over data/** from the first commit.

import { daysFromCivil } from './clock.js';

export const REGISTERS = ['known', 'modelled', 'proposed', 'contributed'];
export const CONFIDENCES = ['high', 'medium', 'low', 'contested', 'unknown'];

export const REQUIRED_FIELDS = [
  'source', 'locator',
  'validFrom', 'validTo',
  'recordedAt', 'recordedUntil',
  'confidence', 'register'
];

const DATE_ONLY = /^(\d{4})-(\d{2})-(\d{2})$/;
const DATE_TIME = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?\+10:00$/;

const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

function daysInMonth(y, m) {
  if (m !== 2) return DAYS_IN_MONTH[m - 1];
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28;
}

/**
 * Island civil time to a comparable integer minute. Returns null when the string is not a valid
 * island time, so a caller can tell a bad value from an absent one.
 */
export function toMinute(value) {
  if (typeof value !== 'string') return null;
  let y, mo, d, h = 0, mi = 0;
  const dt = DATE_TIME.exec(value);
  if (dt) {
    [, y, mo, d, h, mi] = dt.map(Number);
  } else {
    const dd = DATE_ONLY.exec(value);
    if (!dd) return null;
    [, y, mo, d] = dd.map(Number);
  }
  if (mo < 1 || mo > 12) return null;
  if (d < 1 || d > daysInMonth(y, mo)) return null;
  if (h > 23 || mi > 59) return null;
  return daysFromCivil(y, mo, d) * 1440 + h * 60 + mi;
}

/**
 * Check one record. Returns a list of problems, empty when the record is sound.
 *
 * @param {object} rec
 * @param {object} opts
 * @param {Set<string>} [opts.sourceIds] ids from data/_sources.json. When given, `source` must be
 *   one of them, because a source that is free text cannot be opened and checked.
 */
export function checkRecord(rec, opts = {}) {
  const problems = [];
  const at = opts.where ? opts.where + ': ' : '';

  if (!rec || typeof rec !== 'object' || Array.isArray(rec)) {
    return [at + 'not an object'];
  }

  for (const f of REQUIRED_FIELDS) {
    if (!(f in rec)) problems.push(at + 'missing ' + f);
  }
  if (problems.length) return problems;

  if (typeof rec.source !== 'string' || rec.source.trim() === '') {
    problems.push(at + 'source must be a non empty id');
  } else if (opts.sourceIds && !opts.sourceIds.has(rec.source)) {
    problems.push(at + 'source not in data/_sources.json: ' + rec.source);
  }

  if (typeof rec.locator !== 'string' || rec.locator.trim() === '') {
    problems.push(at + 'locator must say where in the source to look');
  }

  if (!REGISTERS.includes(rec.register)) {
    problems.push(at + 'register must be one of ' + REGISTERS.join(', ') + ', got ' + rec.register);
  }
  if (!CONFIDENCES.includes(rec.confidence)) {
    problems.push(at + 'confidence must be one of ' + CONFIDENCES.join(', ') + ', got ' + rec.confidence);
  }

  const validFrom = toMinute(rec.validFrom);
  if (validFrom === null) problems.push(at + 'validFrom is not an island time: ' + rec.validFrom);
  const recordedAt = toMinute(rec.recordedAt);
  if (recordedAt === null) problems.push(at + 'recordedAt is not an island time: ' + rec.recordedAt);

  let validTo = null;
  if (rec.validTo !== null) {
    validTo = toMinute(rec.validTo);
    if (validTo === null) problems.push(at + 'validTo must be null or an island time: ' + rec.validTo);
    else if (validFrom !== null && validTo < validFrom) problems.push(at + 'validTo is before validFrom');
  }

  let recordedUntil = null;
  if (rec.recordedUntil !== null) {
    recordedUntil = toMinute(rec.recordedUntil);
    if (recordedUntil === null) problems.push(at + 'recordedUntil must be null or an island time: ' + rec.recordedUntil);
    else if (recordedAt !== null && recordedUntil < recordedAt) problems.push(at + 'recordedUntil is before recordedAt');
  }

  return problems;
}

/**
 * The bitemporal read. Two cursors: what was true of the island at `validAt`, according to what the
 * twin believed at `knownAt`. Live is (now, now). History is (then, now). Replaying a past belief,
 * which is how you audit a decision, is (then, then).
 */
export function asOf(records, validAt, knownAt) {
  const v = typeof validAt === 'number' ? validAt : toMinute(validAt);
  const k = typeof knownAt === 'number' ? knownAt : toMinute(knownAt);
  if (v === null || k === null) throw new Error('asOf needs two island times');
  return records.filter((r) => {
    const vf = toMinute(r.validFrom);
    const vt = r.validTo === null ? Infinity : toMinute(r.validTo);
    const ra = toMinute(r.recordedAt);
    const ru = r.recordedUntil === null ? Infinity : toMinute(r.recordedUntil);
    return vf !== null && ra !== null && vf <= v && v < vt && ra <= k && k < ru;
  });
}
