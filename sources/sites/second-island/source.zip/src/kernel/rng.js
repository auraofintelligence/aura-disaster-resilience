// Randomness in named streams.
//
// The correction this file exists for: the first build drew every system's randomness from one
// global sequence. Two consequences, both expensive. Adding a system shifted every later system's
// numbers, so an unrelated change looked like a regression. And when two runs differed, the
// difference could be reported but not attributed, because every system shared one state.
//
// Here, a stream is derived from the world seed and a name. A system draws only from its own
// stream. Adding a system cannot move another system's numbers, and a drifting stream names its
// own system.

// The generator is sfc32: small, fast, passes PractRand, and its whole state is four u32 words we
// can hash. It is written inline in Stream.u32 rather than behind a closure, so those four words
// stay visible to the determinism instrument.

/** Mix a string into four u32, so stream names produce well separated seeds. */
export function streamSeed(worldSeed, name) {
  let h1 = (0x9e3779b9 ^ worldSeed) >>> 0;
  let h2 = (0x85ebca6b ^ Math.imul(worldSeed, 0x27d4eb2d)) >>> 0;
  const s = String(name);
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x85ebca6b) >>> 0;
    h1 = ((h1 << 13) | (h1 >>> 19)) >>> 0;
    h2 = Math.imul(h2 ^ (c + i), 0xc2b2ae35) >>> 0;
    h2 = ((h2 << 7) | (h2 >>> 25)) >>> 0;
  }
  const a = h1 >>> 0;
  const b = (h2 ^ 0x2545f491) >>> 0;
  const c = (Math.imul(h1 ^ h2, 0x9e3779b1)) >>> 0;
  const d = (h1 + h2 + s.length) >>> 0;
  return [a, b, c, d];
}

export class Stream {
  constructor(worldSeed, name) {
    this.name = name;
    const [a, b, c, d] = streamSeed(worldSeed, name);
    this.a = a; this.b = b; this.c = c; this.d = d;
    this.draws = 0;
    // sfc32 wants a few discarded outputs before its state is well mixed.
    for (let i = 0; i < 12; i++) this.u32();
    this.draws = 0;
  }

  u32() {
    let { a, b, c, d } = this;
    let t = (a + b) >>> 0;
    this.a = (b ^ (b >>> 9)) >>> 0;
    this.b = (c + (c << 3)) >>> 0;
    this.c = (((c << 21) | (c >>> 11)) >>> 0);
    this.d = (d + 1) >>> 0;
    t = (t + this.d) >>> 0;
    this.c = (this.c + t) >>> 0;
    this.draws++;
    return t >>> 0;
  }

  /** Uniform in [0, 1). */
  float() {
    return this.u32() / 4294967296;
  }

  /** Uniform integer in [0, n). */
  int(n) {
    if (!Number.isInteger(n) || n <= 0) throw new Error('Stream.int needs a positive integer');
    // Rejection sampling, so the distribution does not skew and the draw count stays reproducible.
    const limit = 4294967296 - (4294967296 % n);
    let x = this.u32();
    while (x >= limit) x = this.u32();
    return x % n;
  }

  pick(arr) {
    if (!Array.isArray(arr) || arr.length === 0) throw new Error('Stream.pick needs a non empty array');
    return arr[this.int(arr.length)];
  }

  /** Normal by Box-Muller, both halves consumed so the draw count is stable. */
  normal(mean = 0, sd = 1) {
    const u = 1 - this.float();
    const v = this.float();
    return mean + sd * Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  /** The whole state, for hashing. Draw count included: a system that drew and discarded moved. */
  state() {
    return [this.a, this.b, this.c, this.d, this.draws];
  }
}

export class StreamSet {
  constructor(worldSeed) {
    this.worldSeed = worldSeed >>> 0;
    this.streams = new Map();
  }

  get(name) {
    let s = this.streams.get(name);
    if (!s) {
      s = new Stream(this.worldSeed, name);
      this.streams.set(name, s);
    }
    return s;
  }

  /** Names in sorted order, so a hash over the set does not depend on creation order. */
  names() {
    return [...this.streams.keys()].sort();
  }
}
