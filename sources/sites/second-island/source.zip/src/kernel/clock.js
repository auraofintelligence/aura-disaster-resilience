// Island time, in integers.
//
// One tick is one island minute. A sim-day is 1440 ticks. Timetables on this island are published
// in minutes, so the tick is the unit the published data already uses.
//
// Queensland does not observe daylight saving, so island civil time is a fixed UTC+10 and the
// conversion below is pure integer arithmetic with no timezone database and no Date object. That
// matters: `new Date()` is banned in simulation because it is a wall clock, and even the parsing
// side of Date drags in host locale behaviour we would then have to trust across two runs.

export const MINUTES_PER_TICK = 1;
export const TICKS_PER_HOUR = 60;
export const TICKS_PER_DAY = 1440;
export const ISLAND_UTC_OFFSET_MINUTES = 600; // AEST, no daylight saving in Queensland

/** Days from 1970-01-01 for a civil date. Howard Hinnant's algorithm, integer only. */
export function daysFromCivil(y, m, d) {
  y -= m <= 2 ? 1 : 0;
  const era = Math.floor(y / 400);
  const yoe = y - era * 400;
  const doy = Math.floor((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5) + d - 1;
  const doe = yoe * 365 + Math.floor(yoe / 4) - Math.floor(yoe / 100) + doy;
  return era * 146097 + doe - 719468;
}

/** The inverse. */
export function civilFromDays(z) {
  z += 719468;
  const era = Math.floor(z / 146097);
  const doe = z - era * 146097;
  const yoe = Math.floor((doe - Math.floor(doe / 1460) + Math.floor(doe / 36524) - Math.floor(doe / 146096)) / 365);
  const y = yoe + era * 400;
  const doy = doe - (365 * yoe + Math.floor(yoe / 4) - Math.floor(yoe / 100));
  const mp = Math.floor((5 * doy + 2) / 153);
  const d = doy - Math.floor((153 * mp + 2) / 5) + 1;
  const m = mp + (mp < 10 ? 3 : -9);
  return { year: y + (m <= 2 ? 1 : 0), month: m, day: d };
}

const pad = (n, w = 2) => String(n).padStart(w, '0');

export class Clock {
  /**
   * @param {string} epochISO island civil time of tick 0, for example '2026-08-21T00:00:00+10:00'.
   *   Parsed by hand, not by Date, and the offset must be the island's.
   */
  constructor(epochISO) {
    const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})\+10:00$/.exec(epochISO);
    if (!m) {
      throw new Error('Clock needs an island civil epoch like 2026-08-21T00:00:00+10:00, got ' + epochISO);
    }
    const [, Y, M, D, h, mi, s] = m.map(Number);
    if (s !== 0) throw new Error('Clock epoch must land on a whole minute');
    this.epochISO = epochISO;
    this.epochMinute = daysFromCivil(Y, M, D) * TICKS_PER_DAY + h * 60 + mi;
    this.tick = 0;
  }

  advance(n = 1) {
    this.tick += n;
    return this.tick;
  }

  /** Minutes since the Unix epoch, in island civil terms. */
  minuteAt(tick = this.tick) {
    return this.epochMinute + tick * MINUTES_PER_TICK;
  }

  civil(tick = this.tick) {
    const total = this.minuteAt(tick);
    const days = Math.floor(total / TICKS_PER_DAY);
    const minOfDay = total - days * TICKS_PER_DAY;
    const { year, month, day } = civilFromDays(days);
    // 1970-01-01 was a Thursday, so day 0 is weekday 4 with Sunday as 0.
    const weekday = (((days % 7) + 7) % 7 + 4) % 7;
    return {
      year, month, day, weekday,
      hour: Math.floor(minOfDay / 60),
      minute: minOfDay % 60,
      minuteOfDay: minOfDay,
      dayNumber: days
    };
  }

  iso(tick = this.tick) {
    const c = this.civil(tick);
    return `${pad(c.year, 4)}-${pad(c.month)}-${pad(c.day)}T${pad(c.hour)}:${pad(c.minute)}:00+10:00`;
  }

  /** Fractional day of year, which is what solar geometry wants. */
  dayOfYear(tick = this.tick) {
    const c = this.civil(tick);
    return c.dayNumber - daysFromCivil(c.year, 1, 1) + 1;
  }

  /** The tick at which a given island civil time falls, or a fractional value if it falls between. */
  tickOf(year, month, day, hour = 0, minute = 0) {
    return daysFromCivil(year, month, day) * TICKS_PER_DAY + hour * 60 + minute - this.epochMinute;
  }
}

export const WEEKDAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
