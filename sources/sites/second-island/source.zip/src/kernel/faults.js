// Deliberate faults, so the instruments can be proven.
//
// An instrument nobody has watched fail is a rumour. Stage 0 of the founding prompt says so: break
// a thing on purpose and watch the instrument catch it. This module is the switch.
//
// Rules that keep this from rotting into a back door:
//  - Faults are named in tools/faults.mjs and nowhere else.
//  - `faulty()` may only be called at hook sites the registry declares. gate/instruments checks it.
//  - A fault is off unless it is asked for, and asking is loud: an environment variable in Node,
//    a query string in the browser. Nothing reads a config file.
//  - The healthy path is the path with no branch: `faulty()` returning false must leave behaviour
//    exactly as it would be if this module did not exist.

function readFault() {
  const env = globalThis.process && globalThis.process.env && globalThis.process.env.ISLAND_FAULT;
  if (env) return String(env);
  const loc = globalThis.location;
  if (loc && typeof loc.search === 'string') {
    const q = new URLSearchParams(loc.search).get('fault');
    if (q) return String(q);
  }
  return '';
}

export const ACTIVE_FAULT = readFault();

/** True when the named fault is the one switched on. */
export function faulty(id) {
  return ACTIVE_FAULT === id;
}

/** For the instruments to report, so a faulted run can never be mistaken for a healthy one. */
export function faultBanner() {
  return ACTIVE_FAULT ? `FAULT INJECTED: ${ACTIVE_FAULT}` : '';
}
