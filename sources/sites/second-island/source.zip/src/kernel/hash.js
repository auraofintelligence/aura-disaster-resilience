// Stable hashing, so a determinism run can name what moved.
//
// FNV-1a over bytes. Not a cryptographic hash and does not need to be: it needs to be identical
// across two runs in the same process and cheap enough to take every checkpoint.

const OFFSET = 2166136261 >>> 0;
const PRIME = 16777619;

export function newHash() {
  return { h: OFFSET };
}

export function hashByte(state, b) {
  state.h = Math.imul(state.h ^ (b & 0xff), PRIME) >>> 0;
  return state;
}

export function hashString(state, s) {
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    hashByte(state, c & 0xff);
    hashByte(state, (c >>> 8) & 0xff);
  }
  return state;
}

const scratch = new DataView(new ArrayBuffer(8));

export function hashNumber(state, n) {
  // Every number goes in as a float64, so 3 and 3.0 hash the same and integer or float drift in a
  // system shows up rather than hiding behind a coercion.
  scratch.setFloat64(0, Number.isNaN(n) ? Number.NaN : n === 0 ? 0 : n, true);
  for (let i = 0; i < 8; i++) hashByte(state, scratch.getUint8(i));
  return state;
}

export function hashBuffer(state, buf) {
  const bytes = buf instanceof ArrayBuffer
    ? new Uint8Array(buf)
    : new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
  for (let i = 0; i < bytes.length; i++) hashByte(state, bytes[i]);
  return state;
}

/**
 * Walk any plain value deterministically. Object keys are sorted, so a system that rebuilds an
 * object in a different order does not read as drift, and a system whose values actually changed
 * does.
 */
export function hashValue(state, v) {
  if (v === null) return hashString(state, '\u0000null');
  if (v === undefined) return hashString(state, '\u0000undef');
  const t = typeof v;
  if (t === 'number') { hashString(state, '\u0000n'); return hashNumber(state, v); }
  if (t === 'boolean') { hashString(state, '\u0000b'); return hashByte(state, v ? 1 : 0); }
  if (t === 'string') { hashString(state, '\u0000s'); return hashString(state, v); }
  if (t === 'bigint') { hashString(state, '\u0000g'); return hashString(state, v.toString()); }
  if (ArrayBuffer.isView(v) || v instanceof ArrayBuffer) {
    hashString(state, '\u0000t');
    return hashBuffer(state, v);
  }
  if (Array.isArray(v)) {
    hashString(state, '\u0000a');
    hashNumber(state, v.length);
    for (const item of v) hashValue(state, item);
    return state;
  }
  if (t === 'object') {
    hashString(state, '\u0000o');
    const keys = Object.keys(v).sort();
    for (const k of keys) {
      hashString(state, k);
      hashValue(state, v[k]);
    }
    return state;
  }
  // Functions and symbols are not state. Reaching here is a bug in the caller, so say so rather
  // than hashing something meaningless.
  throw new Error('hashValue: not a state value: ' + t);
}

export function digest(state) {
  return (state.h >>> 0).toString(16).padStart(8, '0');
}

export function hashOf(v) {
  return digest(hashValue(newHash(), v));
}
