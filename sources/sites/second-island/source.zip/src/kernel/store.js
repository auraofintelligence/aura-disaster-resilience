// Entities and components, structure of arrays.
//
// Component data lives in typed arrays, one array per field, packed dense. That is the shape the
// founding prompt asks for at scale, and it is also the shape that hashes cheaply: a component's
// state is a few contiguous buffers, so a determinism checkpoint is a walk over bytes rather than
// a walk over objects.
//
// Determinism notes, because this is where a store usually leaks it:
//  - Entity ids come from a counter, with freed ids reused from a stack. Same operations in the
//    same order, same ids.
//  - Removal is swap with the last row. Deterministic given a deterministic order of removals, and
//    it keeps the arrays dense so iteration is a straight loop.
//  - Nothing iterates a Map or an object's keys to change state. Where order matters, it is sorted.

const KINDS = {
  f64: Float64Array,
  f32: Float32Array,
  i32: Int32Array,
  u32: Uint32Array,
  i16: Int16Array,
  u16: Uint16Array,
  u8: Uint8Array
};

class Component {
  constructor(name, fields, capacity) {
    this.name = name;
    this.fieldNames = Object.keys(fields).sort();
    this.kinds = {};
    this.data = {};
    this.capacity = capacity;
    this.count = 0;
    for (const f of this.fieldNames) {
      const kind = fields[f];
      if (!KINDS[kind]) throw new Error(`component ${name}.${f}: unknown field kind ${kind}`);
      this.kinds[f] = kind;
      this.data[f] = new KINDS[kind](capacity);
    }
    this.entities = new Uint32Array(capacity);
    this.row = new Map(); // entity id to row. Read only for lookup, never iterated for state.
  }

  grow() {
    const next = this.capacity * 2;
    for (const f of this.fieldNames) {
      const bigger = new KINDS[this.kinds[f]](next);
      bigger.set(this.data[f]);
      this.data[f] = bigger;
    }
    const ents = new Uint32Array(next);
    ents.set(this.entities);
    this.entities = ents;
    this.capacity = next;
  }
}

export class Store {
  constructor({ capacity = 1024 } = {}) {
    this.initialCapacity = capacity;
    this.components = new Map();
    this.nextEntity = 1; // zero is reserved so a falsy id is always a bug
    this.freed = [];
    this.alive = new Set();
  }

  defineComponent(name, fields) {
    if (this.components.has(name)) throw new Error('component already defined: ' + name);
    const c = new Component(name, fields, this.initialCapacity);
    this.components.set(name, c);
    return c;
  }

  component(name) {
    const c = this.components.get(name);
    if (!c) throw new Error('no such component: ' + name);
    return c;
  }

  create() {
    const id = this.freed.length ? this.freed.pop() : this.nextEntity++;
    this.alive.add(id);
    return id;
  }

  destroy(id) {
    if (!this.alive.has(id)) return false;
    for (const name of [...this.components.keys()].sort()) this.remove(id, name);
    this.alive.delete(id);
    this.freed.push(id);
    return true;
  }

  add(entity, name, values = {}) {
    if (!this.alive.has(entity)) throw new Error('add to a dead entity: ' + entity);
    const c = this.component(name);
    if (c.row.has(entity)) throw new Error(`entity ${entity} already has ${name}`);
    if (c.count === c.capacity) c.grow();
    const row = c.count++;
    c.entities[row] = entity;
    c.row.set(entity, row);
    for (const f of c.fieldNames) c.data[f][row] = values[f] === undefined ? 0 : values[f];
    return row;
  }

  remove(entity, name) {
    const c = this.component(name);
    const row = c.row.get(entity);
    if (row === undefined) return false;
    const last = --c.count;
    if (row !== last) {
      const moved = c.entities[last];
      c.entities[row] = moved;
      c.row.set(moved, row);
      for (const f of c.fieldNames) c.data[f][row] = c.data[f][last];
    }
    for (const f of c.fieldNames) c.data[f][last] = 0;
    c.entities[last] = 0;
    c.row.delete(entity);
    return true;
  }

  has(entity, name) {
    return this.component(name).row.has(entity);
  }

  rowOf(entity, name) {
    return this.component(name).row.get(entity);
  }

  /** The dense arrays for a straight loop: `for (let i = 0; i < view.count; i++)`. */
  view(name) {
    const c = this.component(name);
    return { count: c.count, entities: c.entities, ...c.data, _c: c };
  }

  stats() {
    const out = { entities: this.alive.size, nextEntity: this.nextEntity, freed: this.freed.length, components: {} };
    for (const name of [...this.components.keys()].sort()) out.components[name] = this.components.get(name).count;
    return out;
  }

  /** State for hashing: only the live rows, in row order, plus the entity ids that own them. */
  hashInput() {
    const out = { entities: this.alive.size, nextEntity: this.nextEntity, freed: [...this.freed], components: {} };
    for (const name of [...this.components.keys()].sort()) {
      const c = this.components.get(name);
      const part = { count: c.count, entities: Array.from(c.entities.subarray(0, c.count)) };
      for (const f of c.fieldNames) part[f] = Array.from(c.data[f].subarray(0, c.count));
      out.components[name] = part;
    }
    return out;
  }
}
