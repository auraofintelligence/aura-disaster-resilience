// The world: the tick loop, the systems, and the seams between them.
//
// Three things in this file exist because of specific first-build failures.
//
// 1. A system owns its state and may only read another's. So a determinism checkpoint hashes state
//    per system, and a drift names one system instead of the whole world.
// 2. Systems are ordered by a declared integer, never by registration order. The determinism
//    instrument can therefore register them shuffled and prove the ordering rule holds.
// 3. Events are declared before they are emitted, and the world counts how many times each type
//    actually fired. The first build shipped forty-six clean systems with dead seams between them:
//    nine of eleven sentiment channels had never fired once, and nobody could see that from inside.
//    Here, a type declared and never fired is a number in the headless report.
//
// Nothing in this file reads a wall clock. Timing for the perf instruments is injected as `now`,
// so the kernel stays free of `performance.now` and the ban in gate/no-wallclock stays absolute.

import { Clock } from './clock.js';
import { StreamSet } from './rng.js';
import { Store } from './store.js';
import { newHash, hashValue, hashString, digest } from './hash.js';

export const DEFAULT_EPOCH = '2026-08-21T00:00:00+10:00'; // a Friday, which is barge day

function readOnly(obj, owner, name) {
  return new Proxy(obj, {
    set() { throw new Error(`${owner} wrote to ${name}, which it does not own`); },
    deleteProperty() { throw new Error(`${owner} deleted from ${name}, which it does not own`); },
    get(target, key) {
      const v = target[key];
      return v && typeof v === 'object' && !ArrayBuffer.isView(v) ? readOnly(v, owner, name) : v;
    }
  });
}

export class World {
  constructor({ seed = 19770614, epoch = DEFAULT_EPOCH, strict = false, now = null, capacity = 1024 } = {}) {
    this.seed = seed >>> 0;
    this.clock = new Clock(epoch);
    this.streams = new StreamSet(this.seed);
    this.store = new Store({ capacity });
    this.strict = strict;
    this.now = now;
    this.systems = [];
    this.byName = new Map();
    this.state = {};
    this.booted = false;
    this.inbox = [];   // events emitted this tick, delivered at the start of the next
    this.pending = []; // events waiting for delivery
    this.emitted = new Map(); // event type to how many times it actually fired
    this.declared = new Map(); // event type to {emitters, listeners}
    this.cost = new Map(); // system name to accumulated milliseconds, only when `now` is injected
    this.overruns = [];
  }

  /**
   * @param {object} def
   * @param {string} def.name        unique, and the name of its random stream
   * @param {number} def.order       explicit tick order, lower first, ties broken by name
   * @param {object} [def.state]     the system's own state, the only thing it may write
   * @param {string[]} [def.emits]   event types it may emit. Emitting an undeclared type throws.
   * @param {string[]} [def.listens] event types it wants delivered
   * @param {number} [def.budgetMs]  per tick cost the instruments hold it to
   * @param {(self, ctx) => void} [def.boot]
   * @param {(self, ctx) => void} [def.tick]
   * @param {(self, event, ctx) => void} [def.onEvent]
   */
  system(def) {
    if (this.booted) throw new Error('systems are registered before boot, not after');
    if (!def || typeof def.name !== 'string' || !def.name) throw new Error('a system needs a name');
    if (this.byName.has(def.name)) throw new Error('duplicate system: ' + def.name);
    if (!Number.isInteger(def.order)) throw new Error(`system ${def.name} needs an integer order`);
    const sys = {
      name: def.name,
      order: def.order,
      state: def.state || {},
      emits: [...(def.emits || [])].sort(),
      listens: [...(def.listens || [])].sort(),
      budgetMs: def.budgetMs ?? null,
      boot: def.boot || null,
      tick: def.tick || null,
      onEvent: def.onEvent || null
    };
    this.systems.push(sys);
    this.byName.set(sys.name, sys);
    this.state[sys.name] = sys.state;
    for (const t of sys.emits) {
      if (!this.declared.has(t)) this.declared.set(t, { emitters: [], listeners: [] });
      this.declared.get(t).emitters.push(sys.name);
      if (!this.emitted.has(t)) this.emitted.set(t, 0);
    }
    for (const t of sys.listens) {
      if (!this.declared.has(t)) this.declared.set(t, { emitters: [], listeners: [] });
      this.declared.get(t).listeners.push(sys.name);
    }
    return this;
  }

  rng(name) {
    return this.streams.get(name);
  }

  _ctx(sys) {
    const world = this;
    return {
      get tick() { return world.clock.tick; },
      clock: world.clock,
      store: world.store,
      rng: world.streams.get(sys.name),
      read(name) {
        const other = world.byName.get(name);
        if (!other) throw new Error(`${sys.name} read unknown system ${name}`);
        if (name === sys.name) return other.state;
        return world.strict ? readOnly(other.state, sys.name, name) : other.state;
      },
      emit(type, payload = {}) {
        if (!sys.emits.includes(type)) {
          throw new Error(`${sys.name} emitted ${type}, which it does not declare`);
        }
        world.emitted.set(type, (world.emitted.get(type) || 0) + 1);
        world.inbox.push({ type, from: sys.name, tick: world.clock.tick, payload });
      }
    };
  }

  _sorted() {
    return [...this.systems].sort((a, b) => (a.order - b.order) || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0));
  }

  boot() {
    if (this.booted) throw new Error('already booted');
    this.order = this._sorted();
    for (const sys of this.order) {
      if (sys.boot) sys.boot(sys.state, this._ctx(sys));
    }
    this.booted = true;
    return this;
  }

  step(n = 1) {
    if (!this.booted) throw new Error('boot before step');
    for (let i = 0; i < n; i++) this._tick();
    return this;
  }

  _tick() {
    // Events emitted last tick are delivered first, in system order, so delivery never depends on
    // which system happened to emit first.
    this.pending = this.inbox;
    this.inbox = [];
    if (this.pending.length) {
      for (const sys of this.order) {
        if (!sys.onEvent || sys.listens.length === 0) continue;
        const ctx = this._ctx(sys);
        for (const ev of this.pending) {
          if (sys.listens.includes(ev.type)) sys.onEvent(sys.state, ev, ctx);
        }
      }
    }

    for (const sys of this.order) {
      if (!sys.tick) continue;
      const t0 = this.now ? this.now() : 0;
      sys.tick(sys.state, this._ctx(sys));
      if (this.now) {
        const dt = this.now() - t0;
        this.cost.set(sys.name, (this.cost.get(sys.name) || 0) + dt);
        if (sys.budgetMs !== null && dt > sys.budgetMs) {
          this.overruns.push({ system: sys.name, tick: this.clock.tick, ms: dt, budgetMs: sys.budgetMs });
        }
      }
    }

    this.clock.advance(1);
  }

  /** One hash per system: its own state and its own random stream. This is what names a drift. */
  hashes() {
    const out = {};
    for (const sys of this._sorted()) {
      const h = newHash();
      hashString(h, sys.name);
      hashValue(h, sys.state);
      hashValue(h, this.streams.streams.has(sys.name) ? this.streams.get(sys.name).state() : []);
      out[sys.name] = digest(h);
    }
    out._store = digest(hashValue(newHash(), this.store.hashInput()));
    out._clock = digest(hashValue(newHash(), this.clock.tick));
    return out;
  }

  hash() {
    return digest(hashValue(newHash(), this.hashes()));
  }

  /** Who emits what, who listens, and how often each type actually fired. Dead seams show here. */
  seams() {
    const rows = [];
    for (const type of [...this.declared.keys()].sort()) {
      const d = this.declared.get(type);
      rows.push({
        type,
        emitters: [...d.emitters].sort(),
        listeners: [...d.listeners].sort(),
        fired: this.emitted.get(type) || 0
      });
    }
    return rows;
  }

  report() {
    const seams = this.seams();
    return {
      tick: this.clock.tick,
      islandTime: this.clock.iso(),
      seed: this.seed,
      systems: this._sorted().map((s) => ({
        name: s.name,
        order: s.order,
        ms: this.cost.has(s.name) ? Number(this.cost.get(s.name).toFixed(3)) : null,
        budgetMs: s.budgetMs
      })),
      hashes: this.hashes(),
      hash: this.hash(),
      seams,
      deadSeams: seams.filter((s) => s.fired === 0).map((s) => s.type),
      unlistenedEvents: seams.filter((s) => s.listeners.length === 0).map((s) => s.type),
      unemittedEvents: seams.filter((s) => s.emitters.length === 0).map((s) => s.type),
      overruns: this.overruns,
      store: this.store.stats()
    };
  }
}
