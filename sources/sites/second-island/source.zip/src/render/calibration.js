// The calibration scene, drawn three ways, from the contract rather than from memory.
//
// tools/scenes/calibration.json is the agreement between whoever renders the picture and whoever
// checks it. Its `render` block says the frame is 512 by 512 device pixels, gives the background,
// four quadrants, a plate and a swatch as half open pixel ranges in draw order, and says that
// nothing in the scene is blended, filtered or scaled. So this file does not restate any of that.
// It fetches the scene file and draws what it says. A renderer that carried its own copy of the
// numbers could drift from the checker by one edit, and then the picture and the assertion would
// disagree about which of them was wrong.
//
// Three paths, tried in this order, because the answer to "does this environment have WebGPU"
// is a stage 0 fact and not something to assume either way:
//
//   webgpu   one render pass, one triangle list, one solid tint per vertex.
//   webgl2   scissor plus clear per rectangle. No shader, so no shader compile to go wrong.
//   2d       fillRect per rectangle.
//
// Whichever answers is reported by name through ISLAND.info(), and the reasons the earlier ones
// did not answer are kept, because "WebGPU is not available here, and this is what it said" is a
// useful result and "WebGPU" with nothing behind it is not.
//
// Exactness. Every colour in the scene is an ordinary 8 bit integer, so nothing here divides,
// blends or interpolates a colour except the one unavoidable conversion to a float for the two GPU
// paths, where c/255 written into an 8 bit unsigned normalised target comes back as c. Rectangles
// sit on whole pixel boundaries, so no edge is antialiased. The canvas backing store is set from
// the scene, never from devicePixelRatio: the scene says a page on a 2x display must still hand
// over 512 pixels.
//
// The three fault hooks this file declares, from docs/STAGE-0.md:
//
//   blank-render   clear to the background and draw nothing else.
//   stale-frame    stop following the simulation tick.
//   hitch          stall about 40 ms every sixtieth frame.
//
// With no fault set, `faulty()` is false at each of them and the path through this file is exactly
// the path it would be if the hooks were not written.

import { faulty } from '../kernel/faults.js';

/** The scene contract, resolved from this module so the page's own path never matters. */
export const SCENE_URL = new URL('../../tools/scenes/calibration.json', import.meta.url);

/** Tried in this order unless a caller names a preference. */
export const RENDER_PATHS = ['webgpu', 'webgl2', '2d'];

/** How many frames this module has drawn, across every canvas. The hitch fault counts these. */
let framesDrawn = 0;

/**
 * The tick the stale-frame fault freezes on. Module level rather than per renderer, so a stale
 * frame is stale on every canvas at once: the page draws to a visible canvas and to an offscreen
 * one, and a fault that froze only one of them would be a fault the screenshot could not see.
 */
let frozenTick = null;

export function framesSoFar() {
  return framesDrawn;
}

/**
 * The scene's tick encoding: red is the low byte of the tick, green the next byte, blue is held at
 * 128 so the swatch stays identifiable as the swatch whatever the tick is.
 * @param {number} tick
 * @returns {number[]} three integers from 0 to 255
 */
export function tickColour(tick) {
  const t = Math.max(0, Math.floor(tick));
  return [t % 256, Math.floor(t / 256) % 256, 128];
}

/** Encodings this renderer implements, by the name the scene file uses. */
const ENCODINGS = { 'tick-lo16-rgb': tickColour };

/** The colour of one step at one tick. A named encoding it does not know is an error, not a guess. */
export function stepColour(step, tick) {
  if (Array.isArray(step.colour)) {
    if (step.colour.length !== 3 || step.colour.some((c) => !Number.isInteger(c) || c < 0 || c > 255)) {
      throw new Error('step ' + step.id + ' has a colour that is not three integers from 0 to 255');
    }
    return step.colour;
  }
  if (typeof step.colour === 'string') {
    const fn = ENCODINGS[step.colour];
    if (!fn) {
      throw new Error('the scene asks for the encoding ' + step.colour
        + ', which src/render/calibration.js does not implement. Nothing was drawn, on purpose: a '
        + 'renderer that guessed at an encoding would produce a picture that passes some samples.');
    }
    return fn(tick);
  }
  throw new Error('step ' + step.id + ' has no colour this renderer can read');
}

/**
 * The scene's draw steps as plain rectangles at one tick, in draw order.
 * Ranges are half open, as the scene file says: x from 64 to 256 covers columns 64 to 255.
 */
export function rectsFor(scene, tick) {
  const steps = scene && scene.render && scene.render.steps;
  if (!Array.isArray(steps) || steps.length === 0) {
    throw new Error('the scene has no render.steps, so there is nothing to draw from');
  }
  return steps.map((s) => {
    const colour = stepColour(s, tick);
    if (s.shape === 'fill') {
      return { id: s.id, x0: 0, y0: 0, x1: scene.width, y1: scene.height, colour };
    }
    if (s.shape === 'rect') {
      if (!Array.isArray(s.x) || !Array.isArray(s.y) || s.x.length !== 2 || s.y.length !== 2) {
        throw new Error('step ' + s.id + ' needs x and y as two element ranges');
      }
      return { id: s.id, x0: s.x[0], y0: s.y[0], x1: s.x[1], y1: s.y[1], colour };
    }
    throw new Error('step ' + s.id + ' has shape ' + s.shape + ', which this renderer does not draw');
  });
}

/** Fetch and check the scene contract. A scene that is not usable stops the page, loudly. */
export async function loadScene(url = SCENE_URL) {
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error('the scene at ' + url + ' returned ' + res.status
      + '. The page draws from that file and will not draw a scene it has not read.');
  }
  const scene = await res.json();
  if (!Number.isInteger(scene.width) || !Number.isInteger(scene.height)) {
    throw new Error('the scene needs an integer width and height');
  }
  if (!Array.isArray(scene.background) || scene.background.length !== 3) {
    throw new Error('the scene needs a background of three integers');
  }
  rectsFor(scene, 0); // Throws here rather than at the first frame if a step is unreadable.
  return scene;
}

const rgb = (c) => 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';

/**
 * A stall, spelled as a busy wait on purpose. The hitch fault is a frame that took too long, not a
 * frame that waited for something, and a timer would hand the time back to the browser.
 */
function stall(ms) {
  const end = performance.now() + ms;
  let spins = 0;
  while (performance.now() < end) spins++;
  return spins;
}

// ---- the three backends ------------------------------------------------------------------------

const WGSL = `
struct VsOut {
  @builtin(position) position: vec4<f32>,
  @location(0) tint: vec4<f32>
};

@vertex
fn vs(@location(0) xy: vec2<f32>, @location(1) tint: vec4<f32>) -> VsOut {
  var result: VsOut;
  result.position = vec4<f32>(xy, 0.0, 1.0);
  result.tint = tint;
  return result;
}

@fragment
fn fs(frag: VsOut) -> @location(0) vec4<f32> {
  return frag.tint;
}
`;

/** One adapter and one device for the whole page, asked for once. */
let gpuPromise = null;

async function gpuDevice() {
  if (!gpuPromise) {
    gpuPromise = (async () => {
      if (!globalThis.navigator || !navigator.gpu) {
        throw new Error('navigator.gpu is not defined, so this browser exposes no WebGPU at all');
      }
      const adapter = await navigator.gpu.requestAdapter();
      if (!adapter) {
        throw new Error('navigator.gpu exists but requestAdapter() returned null, so no adapter is '
          + 'available to this page');
      }
      const device = await adapter.requestDevice();
      const format = navigator.gpu.getPreferredCanvasFormat();
      return { adapter, device, format };
    })();
  }
  return gpuPromise;
}

const MAX_RECTS = 64;
const FLOATS_PER_VERTEX = 6; // x, y, and four tint channels
const VERTICES_PER_RECT = 6;

async function webgpuBackend(canvas, scene) {
  const { device, format, adapter } = await gpuDevice();
  const context = canvas.getContext('webgpu');
  if (!context) throw new Error('this canvas returned no webgpu context');
  context.configure({ device, format, alphaMode: 'opaque' });

  const shader = device.createShaderModule({ code: WGSL });
  const pipeline = device.createRenderPipeline({
    layout: 'auto',
    vertex: {
      module: shader,
      entryPoint: 'vs',
      buffers: [{
        arrayStride: FLOATS_PER_VERTEX * 4,
        attributes: [
          { shaderLocation: 0, offset: 0, format: 'float32x2' },
          { shaderLocation: 1, offset: 8, format: 'float32x4' }
        ]
      }]
    },
    fragment: { module: shader, entryPoint: 'fs', targets: [{ format }] },
    primitive: { topology: 'triangle-list' }
  });

  const scratch = new Float32Array(MAX_RECTS * VERTICES_PER_RECT * FLOATS_PER_VERTEX);
  const buffer = device.createBuffer({
    size: scratch.byteLength,
    usage: GPUBufferUsage.VERTEX | GPUBufferUsage.COPY_DST
  });

  const info = (adapter.info && adapter.info.description) || (adapter.info && adapter.info.vendor) || '';

  return {
    path: 'webgpu',
    detail: 'device from navigator.gpu, canvas format ' + format + (info ? ', adapter ' + info : ''),
    paint(rects) {
      let n = 0;
      for (const r of rects) {
        const x0 = (r.x0 / scene.width) * 2 - 1;
        const x1 = (r.x1 / scene.width) * 2 - 1;
        const y0 = 1 - (r.y0 / scene.height) * 2;
        const y1 = 1 - (r.y1 / scene.height) * 2;
        const [cr, cg, cb] = r.colour;
        const corners = [[x0, y0], [x1, y0], [x0, y1], [x1, y0], [x1, y1], [x0, y1]];
        for (const [x, y] of corners) {
          const at = n * FLOATS_PER_VERTEX;
          scratch[at] = x;
          scratch[at + 1] = y;
          scratch[at + 2] = cr / 255;
          scratch[at + 3] = cg / 255;
          scratch[at + 4] = cb / 255;
          scratch[at + 5] = 1;
          n++;
        }
      }
      if (n) device.queue.writeBuffer(buffer, 0, scratch, 0, n * FLOATS_PER_VERTEX);
      const bg = scene.background;
      const encoder = device.createCommandEncoder();
      const pass = encoder.beginRenderPass({
        colorAttachments: [{
          view: context.getCurrentTexture().createView(),
          clearValue: { r: bg[0] / 255, g: bg[1] / 255, b: bg[2] / 255, a: 1 },
          loadOp: 'clear',
          storeOp: 'store'
        }]
      });
      if (n) {
        pass.setPipeline(pipeline);
        pass.setVertexBuffer(0, buffer);
        pass.draw(n);
      }
      pass.end();
      device.queue.submit([encoder.finish()]);
    },
    flush() {
      return device.queue.onSubmittedWorkDone();
    }
  };
}

async function webgl2Backend(canvas, scene) {
  const gl = canvas.getContext('webgl2', {
    alpha: false,
    antialias: false,
    depth: false,
    stencil: false,
    premultipliedAlpha: false,
    preserveDrawingBuffer: true
  });
  if (!gl) throw new Error('this canvas returned no webgl2 context');
  const renderer = gl.getParameter(gl.RENDERER);
  return {
    path: 'webgl2',
    detail: 'scissor and clear, no shader. RENDERER reports ' + renderer,
    paint(rects) {
      gl.disable(gl.SCISSOR_TEST);
      const bg = scene.background;
      gl.clearColor(bg[0] / 255, bg[1] / 255, bg[2] / 255, 1);
      gl.clear(gl.COLOR_BUFFER_BIT);
      if (rects.length === 0) return;
      gl.enable(gl.SCISSOR_TEST);
      for (const r of rects) {
        gl.scissor(r.x0, scene.height - r.y1, r.x1 - r.x0, r.y1 - r.y0);
        gl.clearColor(r.colour[0] / 255, r.colour[1] / 255, r.colour[2] / 255, 1);
        gl.clear(gl.COLOR_BUFFER_BIT);
      }
      gl.disable(gl.SCISSOR_TEST);
    },
    flush() {
      gl.finish();
      return Promise.resolve();
    }
  };
}

async function canvas2dBackend(canvas, scene) {
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('this canvas returned no 2d context');
  return {
    path: '2d',
    detail: 'fillRect per rectangle, opaque canvas',
    paint(rects) {
      ctx.fillStyle = rgb(scene.background);
      ctx.fillRect(0, 0, scene.width, scene.height);
      for (const r of rects) {
        ctx.fillStyle = rgb(r.colour);
        ctx.fillRect(r.x0, r.y0, r.x1 - r.x0, r.y1 - r.y0);
      }
    },
    flush() {
      return Promise.resolve();
    }
  };
}

const BACKENDS = { webgpu: webgpuBackend, webgl2: webgl2Backend, '2d': canvas2dBackend };

// ---- the renderer ------------------------------------------------------------------------------

/**
 * Build a renderer on a canvas, taking the first path that works.
 *
 * @param {object} opts
 * @param {HTMLCanvasElement|OffscreenCanvas} opts.canvas
 * @param {object} opts.scene       from loadScene()
 * @param {string} [opts.prefer]    a path to try first. It still falls back.
 * @returns {Promise<object>} { path, detail, notes, draw, flush, lastTick, frames }
 */
export async function createRenderer({ canvas, scene, prefer = null }) {
  if (!canvas) throw new Error('createRenderer needs a canvas');
  if (!scene) throw new Error('createRenderer needs a scene');

  canvas.width = scene.width;
  canvas.height = scene.height;

  const order = prefer
    ? [prefer, ...RENDER_PATHS.filter((p) => p !== prefer)]
    : [...RENDER_PATHS];

  const notes = [];
  let backend = null;
  for (const name of order) {
    const make = BACKENDS[name];
    if (!make) {
      notes.push({ path: name, ok: false, why: 'no backend by that name' });
      continue;
    }
    try {
      backend = await make(canvas, scene);
      notes.push({ path: name, ok: true, why: backend.detail });
      break;
    } catch (err) {
      notes.push({ path: name, ok: false, why: String((err && err.message) || err) });
    }
  }
  if (!backend) {
    throw new Error('no render path worked on this canvas:\n  '
      + notes.map((n) => n.path + ': ' + n.why).join('\n  '));
  }

  const renderer = {
    path: backend.path,
    detail: backend.detail,
    notes,
    scene,
    canvas,
    lastTick: null,
    frames: 0,

    /**
     * Draw one frame.
     * @param {{tick:number}} frame the simulation state this frame is of
     */
    draw(frame) {
      const asked = frame && Number.isFinite(frame.tick) ? frame.tick : 0;

      // stale-frame: the renderer stops following the simulation. Every fixed sample in the scene
      // still passes, because every fixed sample is a constant; only two frames at two ticks show it.
      let tick = asked;
      if (faulty('stale-frame')) {
        if (frozenTick === null) frozenTick = asked;
        tick = frozenTick;
      }

      framesDrawn++;
      renderer.frames++;

      // hitch: about 40 ms every sixtieth frame. The average survives it and p99 does not.
      if (faulty('hitch') && framesDrawn % 60 === 0) stall(40);

      // blank-render: clear to the background and draw nothing else.
      const rects = faulty('blank-render') ? [] : rectsFor(scene, tick);
      backend.paint(rects);
      renderer.lastTick = tick;
      return tick;
    },

    /** Wait for the work already submitted, before a pixel is read back. */
    flush() {
      return backend.flush();
    }
  };

  return renderer;
}
