// The everyday view: can I get off the island, and can my car.
//
// This is the thing a person on Minjerribah would open on a Tuesday to see whether they have missed
// the boat, and the same thing they would open on the day the barge stops. The owner wrote the
// design rule himself, in the Straddie Disaster Kiosk pitch, before anyone here asked him:
// "Resilience requires daily active use". The failure mode he named is a satellite phone in a
// lockbox, found flat and unfamiliar on the day it is needed. So this view has to be worth opening
// when nothing is wrong, or it will not be open when something is.
//
// THE ONE FINDING THIS VIEW EXISTS TO MAKE OBVIOUS
//
// For five hours of every day a person can leave this island and a vehicle cannot: 1 hour 45 minutes
// in the morning before the first vehicle sailing, and 3 hours 15 minutes in the evening after the
// last one. After the last vehicle sailing of the day your car is here until the morning, whatever
// the passenger timetable says. Those two answers are shown in two panels, in two registers of
// wording, and there is no number anywhere on this page that adds them together. docs/CONTRACT.md
// section 6 carries the law and tools/gate/crossings.mjs enforces it.
//
// WHERE THE NUMBERS COME FROM
//
//   sailing times      data/crossings.json, which is the owner's ground truth of 19 August 2026 and
//                      the two operators' own published timetables. Every row on this page cites the
//                      individual sailing, service or landing point record it came from.
//   bus times          data/transport-gtfs.json, from TransLink's island feed. That feed is licensed
//                      Creative Commons Attribution 4.0 and the attribution it requires is printed
//                      on this page, read out of the pack rather than typed here so it cannot drift.
//   the current minute the world's own clock. No wall clock is read anywhere in this build.
//
// WHAT IT REFUSES TO DO
//
// It fills nothing in. Where the twin does not know, the row shows a contested or unknown marker and
// the date the twin last looked, and the note beside it says why. The tide, whether today is a
// public holiday, how much room is left on the next vehicle sailing, how many extra vehicle sailings
// SeaLink is running today, how long the passenger crossing takes: all of those are absent, and all
// of them are absent on this page in a way a reader can see. A plausible number in any one of those
// rows would be more dangerous than the blank, because a person would plan around it.

import { hhmm, runsOnWeekday } from '../systems/crossings.js';
import { readableDate, readableIslandTime } from './panel.js';

const M2I = 'mainland-to-island';
const I2M = 'island-to-mainland';
const VEHICLES = 'vehicles';
const PASSENGERS = 'passengers';

const MARKER = 'contested or unknown';

const WEEKDAY_KEYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

/**
 * The join between the two packs, made in one place and printed on the page.
 *
 * TransLink names a bus stop and the two boat operators name a jetty, and no identifier is shared
 * between them, so saying that a stop and a jetty are the same place is a judgement. It is the same
 * judgement tools/connections.mjs makes, on the same two publishers' own words, and it is written
 * out here so a reader can disagree with it instead of having to go looking for it.
 */
const STOP_FOR_LANDING = [
  {
    landingPointId: 'junner-street-dunwich',
    stopId: '870029',
    why: 'TransLink calls stop 870029 "Junner St Ferry Terminal (Dunwich)" and the owner calls the '
      + 'landing "junner street ferry terminal". Same street, same town, both say ferry terminal.'
  },
  {
    landingPointId: 'one-mile-dunwich',
    stopId: '870027',
    why: 'TransLink calls stop 870027 "Yabby St at One Mile Ferry Terminal" and the departure sign '
      + 'heads its second column "1 MILE JETTY DUNWICH". The stop stands at the terminal rather '
      + 'than on the jetty.'
  }
];

// -----------------------------------------------------------------------------------------------
// Small helpers
// -----------------------------------------------------------------------------------------------

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined) continue;
    if (k === 'class') node.className = v;
    else if (k === 'text') node.textContent = v;
    else node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
}

/** A stretch of minutes as a person says it out loud. */
export function saidAsDuration(minutes) {
  if (typeof minutes !== 'number' || !Number.isFinite(minutes)) return 'no answer';
  const total = Math.max(0, Math.round(minutes));
  if (total === 0) return 'now';
  const days = Math.floor(total / 1440);
  const hours = Math.floor((total - days * 1440) / 60);
  const mins = total - days * 1440 - hours * 60;
  const parts = [];
  if (days) parts.push(days + (days === 1 ? ' day' : ' days'));
  if (hours) parts.push(hours + (hours === 1 ? ' hour' : ' hours'));
  if (mins) parts.push(mins + (mins === 1 ? ' minute' : ' minutes'));
  return parts.join(' ');
}

/** The wait before a departure, as a person says it. Zero is "going now", never "in no time". */
export function saidAsWait(minutes) {
  if (typeof minutes !== 'number' || !Number.isFinite(minutes)) return 'no answer';
  return Math.round(minutes) <= 0 ? 'going now' : 'in ' + saidAsDuration(minutes);
}

/** A published clock time such as 07:04 as minutes from midnight. Null when it is not one. */
export function clockToMinutes(text) {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(text || ''));
  if (!m) return null;
  return Number(m[1]) * 60 + Number(m[2]);
}

const shortName = (name) => String(name || '').split(',')[0].trim();

/** The three services in a fixed order, with the words this page uses for each of them. */
function serviceIndex(pack) {
  const out = new Map();
  for (const svc of (pack && pack.services) || []) {
    const operator = ((pack.operators || []).find((o) => o.id === svc.operator) || {}).name || svc.operator;
    out.set(svc.serviceId, {
      record: svc,
      operator,
      // The pack's own label, with its mainland-to-island direction trimmed off, because every row
      // on this page is about leaving the island and "Cleveland to Junner Street" reads backwards
      // there. Nothing is coined: the words are the pack's.
      plainName: shortName(svc.label),
      islandPoint: svc.islandPoint,
      carries: svc.carries
    });
  }
  return out;
}

function landingIndex(pack) {
  const out = new Map();
  for (const point of (pack && pack.landingPoints) || []) out.set(point.id, point);
  return out;
}

// -----------------------------------------------------------------------------------------------
// Reading the sailing the twin is about to answer with
// -----------------------------------------------------------------------------------------------

/**
 * The next departure off the island out of a set of services, from the crossings system's own
 * per-service answer. Nothing is recomputed here: the system already did the work at this tick and
 * a second implementation of it would be a second answer to one question.
 */
function nextOffIsland(state, serviceIds) {
  let best = null;
  for (const id of serviceIds) {
    const entry = state.nextByService && state.nextByService[id] ? state.nextByService[id][I2M] : null;
    if (!entry) continue;
    if (!best || entry.minutesUntil < best.minutesUntil) best = entry;
  }
  return best;
}

/** Every sailing that runs on this weekday, in the direction and class asked for, in time order. */
function runningToday(pack, weekday, carries) {
  return ((pack && pack.sailings) || [])
    .filter((s) => s.direction === I2M && s.carries === carries && runsOnWeekday(s, weekday))
    .sort((a, b) => a.departsMinuteOfDay - b.departsMinuteOfDay);
}

/** The bus day this pack holds for one stop on one weekday, or a stated absence. */
function busDay(transport, stopId, weekday) {
  const key = WEEKDAY_KEYS[((weekday % 7) + 7) % 7];
  const days = (transport && transport.terminalCalls) || [];
  const hit = days.find((d) => d.stopId === stopId && String(d.weekday).toLowerCase() === key);
  if (!hit) {
    return { known: false, why: 'this build holds no bus timetable for a ' + key + ' at stop ' + stopId };
  }
  return { known: true, record: hit };
}

/**
 * The last bus that puts a person at the terminal in time for a sailing.
 *
 * The publisher's own drop off type says whether a passenger can get off a bus at a stop, and a
 * trip's first stop is not somewhere anybody alights. Both are honoured, which is the same rule
 * tools/connections.mjs applies. No walk, no queue and no boarding time is modelled: this says a bus
 * arrived before the boat left and nothing more than that.
 */
function busBeforeSailing(transport, stopId, weekday, departsMinuteOfDay) {
  const day = busDay(transport, stopId, weekday);
  if (!day.known) return day;
  let best = null;
  for (const call of day.record.calls || []) {
    if (call.dropOffType === 1 || call.firstStopOfTrip) continue;
    const arrives = clockToMinutes(call.arrival || call.departure);
    if (arrives === null || arrives > departsMinuteOfDay) continue;
    if (!best || arrives > best.arrives) best = { arrives, call };
  }
  return { known: true, record: day.record, best };
}

// -----------------------------------------------------------------------------------------------
// The panels
// -----------------------------------------------------------------------------------------------

/**
 * A row's value is a list of parts, so a marker can be its own element rather than a phrase inside a
 * sentence. `prov` is worked out per frame, because the honest citation for "the next boat off the
 * island" is the record of that boat and not a general one.
 */
function markerParts(dateISO) {
  return [el('span', { class: 'marker', text: MARKER }), ', as at ' + readableDate(dateISO)];
}

function recordDate(pack, id) {
  const seen = [];
  const walk = (node) => {
    if (Array.isArray(node)) return node.forEach(walk);
    if (!node || typeof node !== 'object') return;
    if (node.id === id && typeof node.recordedAt === 'string') seen.push(node.recordedAt);
    for (const key of Object.keys(node)) walk(node[key]);
  };
  walk(pack);
  return seen.length ? seen[0] : null;
}

/**
 * The specification of every panel and every row.
 *
 * Each row reads the frame's view and returns `{ parts, prov, register }`. A row that cannot say
 * which record its answer came from does not belong on this page, so `prov` is never blank and is
 * never a name this build made up: it is the id of a record in data/crossings.json,
 * data/transport-gtfs.json or data/tide.json, or the world's own epoch constant, and
 * tools/uiprobe.mjs resolves every one of them against the files on disk.
 */
function panelSpecs() {
  const known = 'known';

  const nowRow = (id, label, tone, carries) => ({
    id,
    label,
    tone,
    read(v) {
      const state = v.crossings;
      const window = carries === VEHICLES ? state.offIslandVehicleWindow : state.offIslandPassengerWindow;
      const todays = runningToday(v.packs.crossings, state.weekday, carries);
      const first = todays.length ? todays[0] : null;
      const last = todays.length ? todays[todays.length - 1] : null;
      const next = nextOffIsland(state, v.serviceIdsFor(carries));
      if (!todays.length) {
        return { parts: ['nothing runs today'], prov: v.serviceIdsFor(carries)[0], register: known };
      }
      if (window.openNow) {
        return {
          parts: [carries === VEHICLES ? 'yes, vehicle sailings are running' : 'yes, boats are running'],
          prov: next ? next.sailingId : first.id,
          register: known
        };
      }
      if (state.minuteOfDay < window.firstMinute) {
        return {
          parts: ['not yet. The first one off the island today goes at ' + hhmm(window.firstMinute)],
          prov: first.id,
          register: known
        };
      }
      return {
        parts: ['no. The last one off the island today went at ' + hhmm(window.lastMinute)],
        prov: last.id,
        register: known
      };
    }
  });

  const nextRow = (id, label, tone, carries) => ({
    id,
    label,
    tone,
    read(v) {
      const next = nextOffIsland(v.crossings, v.serviceIdsFor(carries));
      if (!next) return { parts: ['nothing scheduled'], prov: v.serviceIdsFor(carries)[0], register: known };
      const svc = v.services.get(next.serviceId);
      const point = v.landings.get(svc ? svc.islandPoint : null);
      const when = next.daysAhead === 0 ? next.departsLocal : next.departsLocal + ' tomorrow';
      const vessel = next.vessel ? ', ' + next.vessel + ', from ' : ' from ';
      return {
        parts: [when + ', ' + (svc ? svc.plainName : next.serviceId) + vessel
          + (point ? shortName(point.name) : 'its jetty') + ', ' + saidAsWait(next.minutesUntil)],
        prov: next.sailingId,
        register: known
      };
    }
  });

  const lastTodayRow = (id, label, tone, carries) => ({
    id,
    label,
    tone,
    read(v) {
      const todays = runningToday(v.packs.crossings, v.crossings.weekday, carries);
      if (!todays.length) return { parts: ['nothing runs today'], prov: v.serviceIdsFor(carries)[0], register: known };
      const last = todays[todays.length - 1];
      const svc = v.services.get(last.serviceId);
      const point = v.landings.get(svc ? svc.islandPoint : null);
      const gone = v.crossings.minuteOfDay > last.departsMinuteOfDay;
      const left = last.departsMinuteOfDay - v.crossings.minuteOfDay;
      const tail = gone
        ? ', and it has gone'
        : ', ' + saidAsWait(left);
      return {
        parts: [last.departsLocal + ', ' + (svc ? svc.plainName : last.serviceId) + ' from '
          + (point ? shortName(point.name) : 'its jetty') + tail],
        prov: last.id,
        register: known
      };
    }
  });

  return [
    {
      id: 'crossing-now',
      name: 'Getting off the island right now',
      tone: 'both',
      note: (v) => 'Two answers, and they are never one answer. A boat that takes vehicles also '
        + 'takes people, so the walk-on question is almost always yes and the car question is the '
        + 'one worth asking. Everything on this page is the printed timetable for a '
        + v.crossings.weekdayName + '. It is not a live position report and no boat here is being '
        + 'tracked. The time above is the minute these answers were worked out for.',
      rows: [
        {
          id: 'crossing-now-time',
          label: 'Island time these answers are for',
          read: (v) => ({
            parts: [readableIslandTime(v.answeredAt || v.civil)],
            prov: 'kernel-clock-epoch',
            register: 'modelled'
          })
        },
        nowRow('crossing-now-foot', 'On foot, can you leave', 'foot', PASSENGERS),
        nowRow('crossing-now-vehicle', 'With a car, can you leave', 'vehicle', VEHICLES)
      ]
    },
    {
      id: 'crossing-foot',
      name: 'On foot: leaving the island',
      tone: 'foot',
      note: () => 'Two operators run walk-on boats and they land in two different places. SeaLink '
        + 'lands at Junner Street ferry terminal and the Gold Cats Flyer lands at One Mile jetty, so '
        + 'a person on foot has a second way off the island. A car does not.',
      rows: [
        nextRow('foot-next', 'Next boat off the island', 'foot', PASSENGERS),
        lastTodayRow('foot-last', 'Last boat off the island today', 'foot', PASSENGERS)
      ]
    },
    {
      id: 'crossing-vehicle',
      name: 'With a car: getting your vehicle off the island',
      tone: 'vehicle',
      note: () => 'One operator, one jetty, one printed timetable. SeaLink calls it a base timetable '
        + 'and says it adds services as required, which are visible only on its booking page, so the '
        + 'times below are the ones that always run and never the whole day. If the last one has '
        + 'gone, your car is here until the morning.',
      rows: [
        nextRow('vehicle-next', 'Next vehicle sailing off the island', 'vehicle', VEHICLES),
        {
          id: 'vehicle-last',
          label: 'Last vehicle sailing off the island today',
          tone: 'vehicle',
          read(v) {
            const state = v.crossings;
            const todays = runningToday(v.packs.crossings, state.weekday, VEHICLES);
            if (!todays.length) return { parts: ['nothing runs today'], prov: 'sealink-vehicle-barge', register: known };
            const last = todays[todays.length - 1];
            if (state.lastVehicleOffIslandHasGone) {
              const back = nextOffIsland(state, v.serviceIdsFor(VEHICLES));
              return {
                parts: ['gone at ' + last.departsLocal + '. Your car is on the island until '
                  + (back ? back.departsLocal + ' in the morning' : 'the next sailing')],
                prov: last.id,
                register: known
              };
            }
            return {
              parts: [last.departsLocal + ', ' + saidAsWait(state.minutesUntilLastVehicleOffIsland)],
              prov: last.id,
              register: known
            };
          }
        },
        {
          id: 'vehicle-room',
          label: 'Room for your car on it',
          tone: 'vehicle',
          marker: true,
          read: (v) => ({
            parts: markerParts(recordDate(v.packs.crossings, 'booked-or-turn-up')),
            prov: 'booked-or-turn-up',
            register: known
          })
        }
      ]
    },
    {
      id: 'crossing-gap',
      name: 'The hours a person has and a car does not',
      tone: 'both',
      note: (v) => 'Worked out from four times on this page and nothing else: the first and last boat '
        + 'off the island today, and the first and last vehicle sailing off the island today. Two '
        + 'lengths of day, one taken off the other. Nothing is added together here, because a boat '
        + 'that carries people and a boat that carries cars are two different questions and this is '
        + 'the difference between the answers. Today is a ' + v.crossings.weekdayName + '.',
      rows: [
        {
          id: 'gap-morning',
          label: 'In the morning, before the first vehicle sailing',
          read(v) {
            const todays = runningToday(v.packs.crossings, v.crossings.weekday, VEHICLES);
            return {
              parts: [saidAsDuration(v.crossings.windowGapMorningMinutes)],
              prov: todays.length ? todays[0].id : 'sealink-vehicle-barge',
              register: known
            };
          }
        },
        {
          id: 'gap-evening',
          label: 'In the evening, after the last vehicle sailing',
          read(v) {
            const todays = runningToday(v.packs.crossings, v.crossings.weekday, VEHICLES);
            return {
              parts: [saidAsDuration(v.crossings.windowGapEveningMinutes)],
              prov: todays.length ? todays[todays.length - 1].id : 'sealink-vehicle-barge',
              register: known
            };
          }
        },
        {
          id: 'gap-total',
          label: 'Over the whole day',
          read: (v) => ({
            parts: [saidAsDuration(v.crossings.windowGapMinutes)],
            prov: 'sealink-vehicle-barge',
            register: known
          })
        },
        {
          id: 'gap-now',
          label: 'Where this minute sits',
          read(v) {
            const state = v.crossings;
            const foot = state.offIslandPassengerWindow;
            const vehicle = state.offIslandVehicleWindow;
            let words;
            if (!foot.openNow && !vehicle.openNow) {
              words = state.minuteOfDay < foot.firstMinute
                ? 'before the day starts. Nothing is leaving on either timetable'
                : 'after the day ends. Nothing is leaving on either timetable';
            } else if (foot.openNow && !vehicle.openNow) {
              words = state.minuteOfDay < vehicle.firstMinute
                ? 'inside the morning gap. You can leave, your car cannot'
                : 'inside the evening gap. You can leave, your car cannot';
            } else {
              words = 'inside the part of the day when both are running';
            }
            return { parts: [words], prov: 'sealink-vehicle-barge', register: known };
          }
        }
      ]
    },
    {
      id: 'crossing-jetties',
      name: 'The two island jetties, and whether a bus meets the boat',
      tone: 'both',
      note: (v) => v.busNote,
      rows: STOP_FOR_LANDING.flatMap((join) => [
        {
          id: 'jetty-next-' + join.stopId,
          label: (v) => shortName((v.landings.get(join.landingPointId) || {}).name || join.landingPointId)
            + ', next boat off',
          read(v) {
            const ids = v.serviceIdsAt(join.landingPointId);
            const next = nextOffIsland(v.crossings, ids);
            if (!next) return { parts: ['nothing scheduled'], prov: join.landingPointId, register: known };
            const svc = v.services.get(next.serviceId);
            const when = next.daysAhead === 0 ? next.departsLocal : next.departsLocal + ' tomorrow';
            return {
              parts: [when + ', ' + (svc ? svc.plainName : next.serviceId) + ', '
                + saidAsWait(next.minutesUntil)],
              prov: join.landingPointId,
              register: known
            };
          }
        },
        {
          id: 'jetty-bus-' + join.stopId,
          label: 'Bus that gets you to it',
          read(v) {
            const ids = v.serviceIdsAt(join.landingPointId);
            const next = nextOffIsland(v.crossings, ids);
            if (!next) return { parts: ['no boat to meet'], prov: join.landingPointId, register: known };
            const weekday = (v.crossings.weekday + next.daysAhead) % 7;
            const answer = busBeforeSailing(v.packs.transport, join.stopId, weekday, next.departsMinuteOfDay);
            if (!answer.known) {
              return { parts: markerParts(v.busPackDate), prov: 'terminal-' + join.stopId, register: known };
            }
            if (!answer.best) {
              return {
                parts: ['no bus gets to this stop before that boat goes'],
                prov: answer.record.id,
                register: known
              };
            }
            const call = answer.best.call;
            const early = next.departsMinuteOfDay - answer.best.arrives;
            return {
              parts: [call.shortName + ' to ' + (call.headsign || 'its last stop') + ' gets in at '
                + hhmm(answer.best.arrives) + ', ' + saidAsDuration(early) + ' before the boat goes'],
              prov: answer.record.id,
              register: known
            };
          }
        },
        {
          id: 'jetty-movements-' + join.stopId,
          label: 'Vessel movements here today',
          read(v) {
            const count = v.crossings.movementsTodayByLandingPoint[join.landingPointId];
            const point = v.landings.get(join.landingPointId);
            if (typeof count !== 'number') {
              return { parts: markerParts(point ? point.recordedAt : null), prov: join.landingPointId, register: known };
            }
            return {
              parts: [String(count) + ', counting each boat in and each boat out'],
              prov: join.landingPointId,
              register: known
            };
          }
        }
      ])
    },
    {
      id: 'crossing-services',
      name: 'Each service on its own',
      tone: 'both',
      note: () => 'Three services, two operators, two island jetties. They are listed apart because '
        + 'they are apart in real life: losing one of them does not shorten the day by a third, it '
        + 'takes one end off it. The first boat off the island in the morning is SeaLink\'s and the '
        + 'last one at night is the Gold Cats Flyer\'s.',
      rows: null // built from the pack at construction, below
    },
    {
      id: 'crossing-unknowns',
      name: 'What this page cannot tell you',
      tone: 'unknown',
      note: () => 'Every line here is a blank on purpose. A number in any one of them would be a '
        + 'guess, and a person would plan around it. Each says the date the twin last looked. The '
        + 'water level has no tide table behind it. Nobody here holds a public holiday calendar, and '
        + 'four Gold Cats Flyer departures state that they stop on one. SeaLink adds vehicle '
        + 'sailings that appear only on its booking page. The school holiday timetable is a '
        + 'different timetable and no source here carries it. Neither passenger operator publishes '
        + 'how long the crossing takes.',
      rows: [
        {
          id: 'unknown-water-level',
          label: 'Water level at the jetties',
          marker: true,
          read(v) {
            const answer = v.tide && v.tide.answer;
            return {
              parts: markerParts(answer ? answer.asAt : null),
              prov: 'tide-table-status',
              register: 'modelled'
            };
          }
        },
        {
          id: 'unknown-public-holiday',
          label: 'Whether today is a public holiday',
          marker: true,
          read: (v) => ({
            parts: markerParts(recordDate(v.packs.crossings, 'public-holidays-are-not-fed')),
            prov: 'public-holidays-are-not-fed',
            register: 'known'
          })
        },
        {
          id: 'unknown-extra-vehicle-sailings',
          label: 'Extra vehicle sailings beyond the printed timetable',
          marker: true,
          read: (v) => ({
            parts: markerParts(recordDate(v.packs.crossings, 'vehicle-timetable-is-a-base')),
            prov: 'vehicle-timetable-is-a-base',
            register: 'known'
          })
        },
        {
          id: 'unknown-school-holidays',
          label: 'What changes in the school holidays',
          marker: true,
          read: (v) => ({
            parts: markerParts(recordDate(v.packs.crossings, 'school-holiday-timetable-variation')),
            prov: 'school-holiday-timetable-variation',
            register: 'known'
          })
        },
        {
          id: 'unknown-passenger-crossing-time',
          label: 'How long the walk-on crossing takes',
          marker: true,
          read: (v) => ({
            parts: markerParts(recordDate(v.packs.crossings, 'sealink-passenger-ferry')),
            prov: 'sealink-passenger-ferry',
            register: 'known'
          })
        },
        {
          // Not a blank, and not a certainty either. Four Gold Cats Flyer departures are marked as
          // not running on a Saturday, a Sunday or a public holiday, and which entries carried that
          // marking was read from a transcription rather than from the colours on the sign. On a
          // weekday that reading cannot change the answer, because the marking only ever takes a
          // service away on those three kinds of day. On a Saturday or a Sunday it is the whole
          // reason those departures are missing, so the page says which of the two today is.
          id: 'unknown-red-times',
          label: 'Which Gold Cats Flyer times are printed in red',
          read(v) {
            const soft = ((v.packs.crossings && v.packs.crossings.sailings) || [])
              .filter((s) => s.confidence !== 'high');
            const weekday = v.crossings.weekday;
            const restsOnIt = weekday === 0 || weekday === 6;
            const words = restsOnIt
              ? 'today\'s answer rests on it. ' + soft.length + ' Gold Cats Flyer departures are '
                + 'missing today only because they were read as red, and that reading came from a '
                + 'transcription rather than from the colours on the sign'
              : 'it changes nothing today. A red time only takes a Gold Cats Flyer departure away on '
                + 'a Saturday, a Sunday or a public holiday';
            return { parts: [words], prov: 'gold-cats-flyer-departure-sign', register: 'known' };
          }
        }
      ]
    }
  ];
}

/** One row per service, built from the pack so a fourth service appears the day it lands. */
function serviceRows(pack) {
  return ((pack && pack.services) || []).map((svc) => ({
    id: 'service-next-' + svc.serviceId,
    label: (v) => {
      const entry = v.services.get(svc.serviceId);
      const point = v.landings.get(svc.islandPoint);
      return (entry ? entry.plainName : svc.serviceId) + ', from ' + shortName(point ? point.name : svc.islandPoint);
    },
    tone: svc.carries === VEHICLES ? 'vehicle' : 'foot',
    read(v) {
      const entry = v.crossings.nextByService[svc.serviceId];
      const next = entry ? entry[I2M] : null;
      if (!next) return { parts: ['nothing scheduled'], prov: svc.serviceId, register: 'known' };
      const when = next.daysAhead === 0 ? next.departsLocal : next.departsLocal + ' tomorrow';
      return {
        parts: [when + ', ' + saidAsWait(next.minutesUntil)],
        prov: svc.serviceId,
        register: 'known'
      };
    }
  }));
}

// -----------------------------------------------------------------------------------------------
// Styling, injected once
// -----------------------------------------------------------------------------------------------

const STYLE_ID = 'crossings-view-style';

const STYLE = [
  '#everyday { margin: 0 0 1.75rem; }',
  '#everyday .xv-head { margin: 0 0 .75rem; }',
  '#everyday .xv-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(21rem, 1fr)); gap: 1rem; align-items: start; }',
  '#everyday .panel { border-left-width: 3px; border-left-style: solid; }',
  '#everyday .panel.tone-foot { border-left-color: #8ab4d8; }',
  '#everyday .panel.tone-vehicle { border-left-color: #d0be7a; }',
  '#everyday .panel.tone-both { border-left-color: #7fc08a; }',
  '#everyday .panel.tone-unknown { border-left-color: #d08a7a; }',
  '#everyday .row { align-items: baseline; }',
  '#everyday dd { text-align: right; max-width: 26rem; }',
  // A row about people and a row about vehicles never look the same, and the words in the label say
  // which it is as well, so the difference does not rest on a colour alone.
  '#everyday .row.tone-foot { border-left: 2px solid #8ab4d8; padding-left: .55rem; }',
  '#everyday .row.tone-vehicle { border-left: 2px solid #d0be7a; padding-left: .55rem; }',
  '#everyday .xv-attribution { font-size: .78rem; }'
].join('\n');

function ensureStyle(doc) {
  if (doc.getElementById(STYLE_ID)) return;
  const node = doc.createElement('style');
  node.id = STYLE_ID;
  node.textContent = STYLE;
  (doc.head || doc.documentElement).appendChild(node);
}

// -----------------------------------------------------------------------------------------------
// Building it
// -----------------------------------------------------------------------------------------------

/**
 * Build the everyday crossings view into a mount point.
 *
 * @param {Element} mount
 * @param {object} opts
 * @param {object} opts.packs `{ crossings, transport }`, both already loaded and provenanced.
 * @returns {{root: Element, update: (view: object) => void}}
 */
export function createCrossingsView(mount, opts = {}) {
  if (!mount) throw new Error('createCrossingsView needs a mount element');
  const packs = opts.packs || {};
  if (!packs.crossings) throw new Error('createCrossingsView needs the crossings pack');

  ensureStyle(mount.ownerDocument || document);
  mount.textContent = '';

  const services = serviceIndex(packs.crossings);
  const landings = landingIndex(packs.crossings);

  const specs = panelSpecs();
  for (const spec of specs) {
    if (spec.id === 'crossing-services') spec.rows = serviceRows(packs.crossings);
  }

  const heading = el('h2', { id: 'everyday-name', text: 'Can I get off the island' });
  mount.appendChild(el('div', { class: 'xv-head' }, [
    heading,
    el('p', {
      class: 'note',
      text: 'The printed timetables for both boat operators and both island jetties, read against the '
        + 'island clock. Sailing times come from SeaLink\'s published timetables and the Gold Cats '
        + 'Flyer departure sign, supplied on 19 August 2026. Bus times come from TransLink\'s island '
        + 'feed. Every line says where it came from and every blank says why it is blank.'
    })
  ]));

  const grid = el('div', { class: 'xv-grid' });
  const values = new Map();
  const labels = new Map();
  const notes = new Map();

  for (const spec of specs) {
    const headingId = 'panel-' + spec.id + '-name';
    const panelHeading = el('h3', { id: headingId, text: spec.name });
    const section = el('section', {
      class: 'panel tone-' + (spec.tone || 'both'),
      id: 'panel-' + spec.id,
      'data-panel': spec.id,
      role: 'region',
      'aria-labelledby': headingId
    }, [panelHeading]);

    const list = el('dl', { class: 'rows' });
    for (const row of spec.rows) {
      const term = el('dt', { text: typeof row.label === 'string' ? row.label : '' });
      const value = el('span', {
        class: 'value' + (row.marker ? ' has-marker' : ''),
        id: 'value-' + row.id,
        'data-value': row.id,
        'data-prov': '',
        'data-register': ''
      }, ['waiting for the first frame']);
      const badge = el('span', { class: 'badge', text: '' });
      list.appendChild(el('div', { class: 'row' + (row.tone ? ' tone-' + row.tone : '') }, [
        term,
        el('dd', {}, [value, badge])
      ]));
      values.set(row.id, { node: value, badge, row });
      if (typeof row.label === 'function') labels.set(row.id, { node: term, row });
    }
    section.appendChild(list);

    const note = el('p', { class: 'note' }, ['']);
    section.appendChild(note);
    notes.set(spec.id, { node: note, spec });

    grid.appendChild(section);
  }
  mount.appendChild(grid);

  // The licence obligation, discharged on a screen for the first time in this build. Board note 033
  // recorded that the wording was owed and carried nowhere a person could see it. It is read out of
  // the pack rather than typed here, so it cannot drift away from the pack that owes it.
  const attribution = el('p', { class: 'note xv-attribution' }, [
    packs.transport && packs.transport.attribution
      ? packs.transport.attribution
      : 'No bus data is loaded on this page, so no bus figure is shown and no attribution is owed.'
  ]);
  mount.appendChild(attribution);

  const joinLine = el('p', { class: 'note xv-attribution' }, [
    'Matching a bus stop to a jetty is a judgement, and this is it. '
      + STOP_FOR_LANDING.map((j) => j.why).join(' ')
      + ' The walk from the stop to the boat is not measured here, so a bus that gets in one '
      + 'minute before a sailing is reported as one minute before and not as a connection you '
      + 'would make.'
  ]);
  mount.appendChild(joinLine);

  const consistency = el('p', { class: 'note xv-attribution' }, ['']);
  mount.appendChild(consistency);

  const busPackDate = (packs.transport && packs.transport.serviceWeek && packs.transport.serviceWeek.recordedAt)
    || null;

  const busNote = (() => {
    const week = packs.transport && packs.transport.serviceWeek;
    if (!week) return 'No bus timetable is loaded, so no line here says whether a bus meets a boat.';
    return 'The bus week held here runs from ' + readableDate(week.dates[0]) + ' to '
      + readableDate(week.dates[week.dates.length - 1]) + ', and it is a school term week. A bus '
      + 'answer for any other week is this weekday\'s pattern and not that week\'s timetable. Boats '
      + 'in and boats out are counted together as movements, because that is what a jetty has to '
      + 'handle. The two jetty figures are shown apart and are not added: whether they are the same '
      + 'kind of number depends on the berths, and nobody here knows that.';
  })();

  return {
    root: mount,

    update(view) {
      const v = {
        ...view,
        packs,
        services,
        landings,
        busNote,
        busPackDate,
        serviceIdsFor(carries) {
          return [...services.entries()].filter(([, s]) => s.carries === carries).map(([id]) => id);
        },
        serviceIdsAt(landingPointId) {
          return [...services.entries()].filter(([, s]) => s.islandPoint === landingPointId).map(([id]) => id);
        }
      };

      for (const [, { node, badge, row }] of values) {
        const answer = row.read(v);
        node.textContent = '';
        for (const part of answer.parts) {
          node.appendChild(typeof part === 'string' ? document.createTextNode(part) : part);
        }
        node.setAttribute('data-prov', answer.prov || '');
        node.setAttribute('data-register', answer.register || '');
        badge.className = 'badge register-' + (answer.register || '');
        badge.textContent = answer.register || '';
        badge.setAttribute('title', 'register: ' + (answer.register || ''));
      }

      for (const [, { node, row }] of labels) node.textContent = row.label(v);
      for (const [, { node, spec }] of notes) {
        node.textContent = typeof spec.note === 'function' ? spec.note(v) : (spec.note || '');
      }

      // The view's own cross-check, run every frame and silent when it holds. The simulation
      // reports how long it is until the next departure off the island for each class, and this
      // page picks the same departure out of its per-service answers. If those two ever disagree
      // the page says so on itself instead of quietly showing the second one. The clean state
      // prints nothing: a person reading a noticeboard does not need it to narrate its own audit,
      // and the disagreement line is the one that matters.
      const state = view.crossings;
      const foot = nextOffIsland(state, v.serviceIdsFor(PASSENGERS));
      const road = nextOffIsland(state, v.serviceIdsFor(VEHICLES));
      const drift = [];
      if (view.answeredAt && view.answeredAt.minuteOfDay !== state.minuteOfDay) {
        drift.push('the minute named at the top of this page is ' + hhmm(view.answeredAt.minuteOfDay)
          + ' and the timetable answers were worked out for ' + hhmm(state.minuteOfDay));
      }
      if (foot && foot.minutesUntil !== state.minutesUntilNextPersonOffIsland) {
        drift.push('the next walk-on departure this page shows is ' + saidAsDuration(foot.minutesUntil)
          + ' away and the timetable answers say ' + saidAsDuration(state.minutesUntilNextPersonOffIsland));
      }
      if (road && road.minutesUntil !== state.minutesUntilNextVehicleOffIsland) {
        drift.push('the next vehicle departure this page shows is ' + saidAsDuration(road.minutesUntil)
          + ' away and the timetable answers say ' + saidAsDuration(state.minutesUntilNextVehicleOffIsland));
      }
      consistency.textContent = drift.length
        ? 'This page disagrees with the timetable data behind it, so trust neither until it is '
          + 'fixed: ' + drift.join('; ') + '.'
        : '';
    }
  };
}

export { STOP_FOR_LANDING, M2I, I2M };
