// The panels: the part of this build a screenshot cannot see.
//
// docs/STAGE-0.md is blunt about why this file is shaped the way it is. The first build spent three
// waves judging its interface through screenshots, which structurally cannot contain a DOM, and
// every verdict from that period was worthless. So the interface here is built to be read by a
// program: each panel is a region with a role and an accessible name, and each displayed value
// carries the id of the record or model input it came from and the register that value sits in.
//
// Two rules from docs/CONTRACT.md are load bearing in this file.
//
//   Section 3: low confidence never reaches a player as a claim. The honest display is a contested
//   or unknown marker with the date. The tide is the first real test of that rule in this
//   repository: data/tide.json carries no harmonic constituents, so the twin's answer for the tide
//   height is "not known", and this panel shows a marker and a date and never a height. A tide
//   number on this island today would be a fabrication, and it would be the easiest one in the
//   world to make look right.
//
//   That answer is read from `view.tide.answer`, which src/world/island.js resolved down the source
//   ladder over the bitemporal store, at a cursor whose mode and moment come back with it. This
//   file no longer decides the absence for itself. It used to, out of the tide system's null and a
//   date it read from the pack, which was a second answer to the same question sitting beside the
//   first with nothing on screen saying which was which.
//
//   Section 3 again: the three registers are visually distinct. Known, modelled, proposed and
//   contributed get a different badge colour and a different border, so a modelled figure never
//   reads as an observed one.
//
// The register of a value is the register of the record it cites, carried across rather than
// decided here. The tide row cites `tide-table-status`, whose register in the pack is `modelled`,
// and the row shows that register beside a value that is deliberately absent. The register
// describes the citation. The marker describes the value.
//
// The fault hooks this file declares, from docs/STAGE-0.md:
//
//   ui-unlabelled      one panel loses its accessible name.
//   ui-dangling-prov   one value cites a record id that does not exist.
//   ui-text-change     one visible label changes text, and nothing else changes.
//
// ui-text-change is the inverted row of the fault matrix. It exists to establish, executably, that
// the screenshot instrument cannot see this file. What it changes is text and only text: the panel
// heading and one row label. The calibration scene is drawn from tools/scenes/calibration.json onto
// a canvas of its own, so no sample point in that scene can be reached from here, and the
// screenshot must keep passing while the probe reports the change.

import { faulty } from '../kernel/faults.js';
import { WEEKDAY_NAMES } from '../kernel/clock.js';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'];

const DEGREE = String.fromCharCode(0x00b0);

/** A date such as 2026-08-18 as a person writes it. Returns the input when it is not a date. */
export function readableDate(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  if (!m) return String(iso || 'no date');
  return Number(m[3]) + ' ' + MONTHS[Number(m[2]) - 1] + ' ' + m[1];
}

/** Island civil time as a person reads it, from the clock's own fields. */
export function readableIslandTime(civil) {
  const hh = String(civil.hour).padStart(2, '0');
  const mm = String(civil.minute).padStart(2, '0');
  return WEEKDAY_NAMES[civil.weekday] + ' ' + civil.day + ' ' + MONTHS[civil.month - 1] + ' '
    + civil.year + ', ' + hh + ':' + mm;
}

function degrees(value, places = 2) {
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'no value';
  return value.toFixed(places) + DEGREE;
}

/** A latitude and longitude the way a chart writes them, with the hemisphere spelled out. */
function coordinate(lat, lon) {
  if (typeof lat !== 'number' || typeof lon !== 'number') return 'no coordinate';
  const ns = lat < 0 ? 'S' : 'N';
  const ew = lon < 0 ? 'W' : 'E';
  return Math.abs(lat).toFixed(4) + DEGREE + ' ' + ns + ', ' + Math.abs(lon).toFixed(4) + DEGREE + ' ' + ew;
}

/**
 * True only when the twin's answer for the tide height is a number. Today it never is.
 *
 * This asks the ANSWER, which came through the source ladder, and not the tide system's own
 * `heightM`. The two are different questions and the difference is the point: the tide system's
 * number is the simulation rung, and the ladder's rule is that the bottom rung never wins a live
 * question. A fed simulation with no observation behind it still shows a marker here, which is the
 * honest display and is what the first build got wrong when it stood synthetic weather beside a
 * real feed with nothing on screen saying which was which.
 */
function tideAnswerKnown(view) {
  const a = view && view.tide && view.tide.answer;
  return !!(a && a.known === true && typeof a.value === 'number');
}

/** The moment the twin's tide answer is dated to, as a person reads it. */
function tideAnswerDate(view) {
  const a = view && view.tide && view.tide.answer;
  return readableDate(a ? a.asAt : null);
}

function el(tag, attrs = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined) continue;
    if (k === 'class') node.className = v;
    else if (k === 'text') node.textContent = v;
    else node.setAttribute(k, v);
  }
  for (const c of [].concat(children)) {
    if (c === null || c === undefined) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
}

/**
 * The panels, and the rows in them.
 *
 * `prov` is the id of the record or model input the number came from, and it is checked against the
 * page's provenance index at probe time rather than being trusted here. `register` is that record's
 * register. A row that cannot say where its number came from does not belong on the screen.
 */
const PANELS = [
  {
    id: 'clock',
    name: 'Island clock',
    note: 'One tick is one island minute. Island civil time is a fixed UTC+10, because Queensland '
      + 'does not observe daylight saving.',
    rows: [
      {
        id: 'tick',
        label: 'Tick',
        prov: 'kernel-clock-epoch',
        register: 'modelled',
        read: (v) => String(v.tick)
      },
      {
        id: 'island-time',
        label: 'Island time',
        prov: 'kernel-clock-epoch',
        register: 'modelled',
        read: (v) => readableIslandTime(v.civil)
      }
    ]
  },
  {
    id: 'sun',
    name: 'Sun over the reference site',
    note: 'Elevation and azimuth from the NOAA general solar position calculations, evaluated for '
      + 'the island reference site. Azimuth is measured clockwise from north.',
    rows: [
      {
        id: 'sun-elevation',
        label: 'Sun elevation',
        prov: 'noaa-solar-equations',
        register: 'modelled',
        read: (v) => degrees(v.sun.elevationDeg)
      },
      {
        id: 'sun-azimuth',
        label: 'Sun azimuth',
        prov: 'noaa-solar-equations',
        register: 'modelled',
        read: (v) => degrees(v.sun.azimuthDeg)
      },
      {
        id: 'daylight',
        label: 'Daylight',
        prov: 'noaa-solar-equations',
        register: 'modelled',
        read: (v) => (v.sun.isDaylight ? 'yes' : 'no')
      },
      {
        id: 'reference-site',
        label: 'Reference site',
        prov: 'dunwich-standard-port',
        register: 'known',
        read: (v) => coordinate(v.site.lat, v.site.lon)
      }
    ]
  },
  {
    id: 'tide',
    name: 'Tide at the standard port',
    // The note says which question was asked, in which mode, and where the reason for an absence
    // came from. A reader who cannot tell whether a panel is showing now, then or a projection
    // cannot tell whether two panels disagree, and that is the bug this whole store exists to stop.
    note: (v) => {
      const a = v.tide && v.tide.answer;
      if (!a) {
        return v.tide.reason
          || 'No resolver was supplied to the tide system, so this panel has no answer to show.';
      }
      if (a.known) {
        return 'Resolved as a ' + a.mode + ' reading, at the ' + a.rung + ' rung of the source '
          + 'ladder, from ' + a.source + '.';
      }
      return 'Asked as a ' + a.mode + ' reading. ' + a.why
        + (a.because
          ? ' The record that says so is ' + a.because + ' in data/tide.json, recorded '
            + readableDate(a.becauseRecordedAt) + '.'
          : '');
    },
    rows: [
      {
        // The citation below is the same record id the resolver names as the reason for the
        // absence, `tide-table-status`. They are declared in two files and they have to agree: if
        // the resolver ever answers from a different record, this row is citing the wrong one.
        id: 'tide-height',
        label: 'Tide height',
        prov: 'tide-table-status',
        register: 'modelled',
        marker: true,
        read: (v) => (tideAnswerKnown(v)
          ? v.tide.answer.value.toFixed(2) + ' m'
          : 'contested or unknown, as at ' + tideAnswerDate(v)),
        // The marker is an element of its own so it is visually distinct from a value, and so a
        // reader of the tree sees a marker rather than a sentence that happens to contain a word.
        parts: (v) => (tideAnswerKnown(v)
          ? [v.tide.answer.value.toFixed(2) + ' m']
          : [el('span', { class: 'marker', text: 'contested or unknown' }),
            ', as at ' + tideAnswerDate(v)])
      }
    ]
  }
];

/**
 * The accessible name of an element, computed the two ways this page uses: aria-labelledby first,
 * then aria-label. An element with neither has no accessible name, and the empty string is the
 * honest answer rather than a fallback to its text.
 */
export function accessibleName(node) {
  const by = node.getAttribute('aria-labelledby');
  if (by) {
    const parts = by.split(/\s+/)
      .map((id) => {
        const target = node.ownerDocument.getElementById(id);
        return target ? target.textContent.replace(/\s+/g, ' ').trim() : '';
      })
      .filter(Boolean);
    if (parts.length) return parts.join(' ');
  }
  const label = node.getAttribute('aria-label');
  if (label && label.trim()) return label.replace(/\s+/g, ' ').trim();
  return '';
}

/**
 * Walk the page and report what is actually on it. This is the page's self-report, and it is only
 * half of the uiprobe instrument: the other half is the accessibility tree read by an agent with a
 * browser tool. A page that lies about itself fails the comparison of the two.
 *
 * @param {Document|Element} root
 * @param {string[]} provenanceIndex ids that exist
 */
export function probePanels(root, provenanceIndex = []) {
  const known = new Set(provenanceIndex);
  const scope = root || document;
  return Array.from(scope.querySelectorAll('[data-panel]')).map((panel) => ({
    id: panel.getAttribute('data-panel'),
    role: panel.getAttribute('role') || '',
    accessibleName: accessibleName(panel),
    values: Array.from(panel.querySelectorAll('[data-value]')).map((node) => {
      const prov = node.getAttribute('data-prov') || '';
      return {
        id: node.getAttribute('data-value'),
        text: node.textContent.replace(/\s+/g, ' ').trim(),
        prov,
        register: node.getAttribute('data-register') || '',
        resolved: prov !== '' && known.has(prov)
      };
    })
  }));
}

/**
 * Build the panels into a mount point and return a handle that updates them.
 *
 * @param {Element} mount
 * @param {object} [opts]
 * @param {(minutes:number)=>void} [opts.onStep] called by the step controls
 * @returns {{update:(view:object)=>void, root:Element}}
 */
export function createPanels(mount, opts = {}) {
  if (!mount) throw new Error('createPanels needs a mount element');
  mount.textContent = '';

  const values = new Map();
  const notes = new Map();

  for (const spec of PANELS) {
    // ui-text-change: a visible label changes text and nothing else does.
    const headingText = faulty('ui-text-change') && spec.id === 'clock'
      ? 'Clock, island time'
      : spec.name;

    const headingId = 'panel-' + spec.id + '-name';
    const heading = el('h3', { id: headingId, text: headingText });

    const section = el('section', {
      class: 'panel',
      id: 'panel-' + spec.id,
      'data-panel': spec.id,
      role: 'region'
    }, [heading]);

    // ui-unlabelled: one panel loses its accessible name. The heading stays visible, which is the
    // point: the screen looks the same and the tree does not.
    if (!(faulty('ui-unlabelled') && spec.id === 'sun')) {
      section.setAttribute('aria-labelledby', headingId);
    }

    const list = el('dl', { class: 'rows' });
    for (const row of spec.rows) {
      const labelText = faulty('ui-text-change') && row.id === 'sun-elevation'
        ? 'Elevation of the sun'
        : row.label;

      // ui-dangling-prov: a number cites a record id that does not exist. The number itself is
      // unchanged, so only something that resolves the citation can tell.
      const prov = faulty('ui-dangling-prov') && row.id === 'tide-height'
        ? 'dunwich-tide-constituents'
        : row.prov;

      const value = el('span', {
        class: 'value' + (row.marker ? ' has-marker' : ''),
        id: 'value-' + row.id,
        'data-value': row.id,
        'data-prov': prov,
        'data-register': row.register
      }, ['waiting for the first frame']);

      const badge = el('span', {
        class: 'badge register-' + row.register,
        title: 'register: ' + row.register,
        text: row.register
      });

      list.appendChild(el('div', { class: 'row' }, [
        el('dt', { text: labelText }),
        el('dd', {}, [value, badge])
      ]));
      values.set(row.id, { node: value, row });
    }
    section.appendChild(list);

    const note = el('p', { class: 'note' }, [typeof spec.note === 'function' ? '' : spec.note]);
    section.appendChild(note);
    notes.set(spec.id, { node: note, spec });

    mount.appendChild(section);
  }

  // The step controls. A group rather than a region: it holds no reported value, and calling it a
  // region would put a landmark in the tree with nothing in it.
  if (typeof opts.onStep === 'function') {
    const controlsName = el('h3', { id: 'panel-controls-name', text: 'Step the simulation' });
    const controls = el('section', {
      class: 'panel controls',
      id: 'panel-controls',
      'data-panel': 'controls',
      role: 'group',
      'aria-labelledby': 'panel-controls-name'
    }, [controlsName]);
    const buttons = el('div', { class: 'buttons' });
    for (const [label, minutes] of [['1 minute', 1], ['1 hour', 60], ['6 hours', 360], ['1 day', 1440]]) {
      const button = el('button', { type: 'button', text: 'Advance ' + label });
      button.addEventListener('click', () => opts.onStep(minutes));
      buttons.appendChild(button);
    }
    controls.appendChild(buttons);
    controls.appendChild(el('p', {
      class: 'note',
      text: 'The simulation does not run by itself. It advances when it is asked to, which is what '
        + 'lets two runs be compared tick for tick.'
    }));
    mount.appendChild(controls);
  }

  return {
    root: mount,
    update(view) {
      for (const [, { node, row }] of values) {
        node.textContent = '';
        const parts = typeof row.parts === 'function' ? row.parts(view) : [row.read(view)];
        for (const part of parts) {
          node.appendChild(typeof part === 'string' ? document.createTextNode(part) : part);
        }
      }
      for (const [, { node, spec }] of notes) {
        if (typeof spec.note === 'function') node.textContent = spec.note(view);
      }
    }
  };
}
