// Where the sun is over Minjerribah, from the island's own clock.
//
// The founding prompt names the first build's solar geometry as a carry, and section 6 says light is
// measured rather than styled. What that carry actually is, once you follow it back, is NOAA's
// General Solar Position Calculations: the Fourier series for the equation of time and the solar
// declination, true solar time from the site longitude, then the hour angle into zenith and azimuth.
// The first build's src/systems/environment/daylight.js implements that document, and its sky layer
// comment names NOAA. So the constants below are copied from the document rather than from the
// first build's code, and the document is in data/_sources.json as noaa-solar-equations, retrieved
// and read on 18 August 2026.
//
// The coordinate is a separate question from the model, and the first build got it wrong quietly.
// Its daylight system hard-codes 27.4283 south, 153.4517 east, and searching that repository for
// either number returns only that file and the terrain layer: the pair has no citation anywhere,
// and it sits about 8 km north-east of the Dunwich coordinate that repository's own places pack
// carries with two agreeing sources. This build takes the cited coordinate and leaves the uncited
// one behind. Eight kilometres is worth nearly nothing to a sun angle, and that is the point:
// the reason to fix it is that a number with no source is a number nobody can check.
//
// No wall clock, no Date, no random draw. Given a tick, this file returns the same sun twice.

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

/**
 * The zenith angle NOAA sets for sunrise and sunset, which is 90 degrees plus the approximate
 * correction for atmospheric refraction and the size of the solar disc. As an elevation that is
 * -0.833 degrees, and it is the threshold this system calls daylight, so the flag and the predicted
 * times come off one number rather than two that can drift apart.
 */
export const SUNRISE_ZENITH_DEG = 90.833;
export const HORIZON_ELEVATION_DEG = 90 - SUNRISE_ZENITH_DEG;

/**
 * The island reference site. Carried from the first build's places pack, record id 'dunwich',
 * whose coordinate_source is OpenStreetMap via Nominatim queried on 6 August 2026 and whose
 * coordinate_confidence is high. The same values are in data/tide.json as the standard port record,
 * and buildIsland passes that record in so the pack is the authority. This constant exists so that
 * registerSolar(world) still runs on its own, and src/world/island.js checks the two agree.
 */
export const SITE_DUNWICH = Object.freeze({
  name: 'Dunwich, Minjerribah',
  lat: -27.4992,
  lon: 153.4025,
  utcOffsetMinutes: 600,
  source: 'first-build-places-pack',
  locator: "data/places.json, places[] id 'dunwich' at line 42"
});

/** Days in a civil year. NOAA's note: for leap years use 366 instead of 365 in the denominator. */
export function daysInYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 366 : 365;
}

/**
 * The two Fourier series, verbatim from the source document.
 * @param {number} dayOfYear 1 to 366
 * @param {number} hourOfDay 0 to 24, island civil time
 * @param {number} inYear 365 or 366
 * @returns {{gamma:number, eqTimeMin:number, declRad:number}} equation of time in minutes,
 *   declination in radians, positive to the north.
 */
export function solarBasics(dayOfYear, hourOfDay, inYear) {
  const g = ((2 * Math.PI) / inYear) * (dayOfYear - 1 + (hourOfDay - 12) / 24);
  const eqTimeMin = 229.18 * (0.000075
    + 0.001868 * Math.cos(g)
    - 0.032077 * Math.sin(g)
    - 0.014615 * Math.cos(2 * g)
    - 0.040849 * Math.sin(2 * g));
  const declRad = 0.006918
    - 0.399912 * Math.cos(g)
    + 0.070257 * Math.sin(g)
    - 0.006758 * Math.cos(2 * g)
    + 0.000907 * Math.sin(2 * g)
    - 0.002697 * Math.cos(3 * g)
    + 0.00148 * Math.sin(3 * g);
  return { gamma: g, eqTimeMin, declRad };
}

/**
 * Sun elevation and azimuth for a site at an island civil minute.
 *
 * @param {{lat:number, lon:number, utcOffsetMinutes:number}} site
 * @param {number} dayOfYear
 * @param {number} minuteOfDay 0 to 1439, island civil time
 * @param {number} inYear
 * @returns {{elevationDeg:number, azimuthDeg:number, declinationDeg:number, eqTimeMin:number}}
 *   azimuth in degrees clockwise from north, in [0, 360).
 */
export function sunAt(site, dayOfYear, minuteOfDay, inYear) {
  const { eqTimeMin, declRad } = solarBasics(dayOfYear, minuteOfDay / 60, inYear);
  const timezoneHours = site.utcOffsetMinutes / 60;
  const timeOffset = eqTimeMin + 4 * site.lon - 60 * timezoneHours;
  const trueSolarTime = minuteOfDay + timeOffset;
  const haRad = (trueSolarTime / 4 - 180) * DEG;

  const latRad = site.lat * DEG;
  const sinLat = Math.sin(latRad);
  const cosLat = Math.cos(latRad);
  let cosZenith = sinLat * Math.sin(declRad) + cosLat * Math.cos(declRad) * Math.cos(haRad);
  if (cosZenith > 1) cosZenith = 1;
  if (cosZenith < -1) cosZenith = -1;
  const elevationDeg = (Math.PI / 2 - Math.acos(cosZenith)) * RAD;

  // The document's azimuth is measured clockwise from north. The half turn puts it there.
  let azimuthDeg = Math.atan2(
    Math.sin(haRad),
    Math.cos(haRad) * sinLat - Math.tan(declRad) * cosLat
  ) * RAD + 180;
  azimuthDeg = ((azimuthDeg % 360) + 360) % 360;

  return { elevationDeg, azimuthDeg, declinationDeg: declRad * RAD, eqTimeMin };
}

/**
 * Sunrise, sunset and solar noon for a day, as island civil minutes from midnight.
 *
 * The document gives these in UTC minutes; adding the site's offset puts them in island civil time,
 * which is what a timetable and a person both use. Returns nulls with a reason where the sun does
 * not cross the horizon that day, which cannot happen at this latitude but is not this function's
 * business to assume.
 */
export function sunEvents(site, dayOfYear, inYear) {
  const { eqTimeMin, declRad } = solarBasics(dayOfYear, 12, inYear);
  const latRad = site.lat * DEG;
  const cosHa = (Math.cos(SUNRISE_ZENITH_DEG * DEG) - Math.sin(latRad) * Math.sin(declRad))
    / (Math.cos(latRad) * Math.cos(declRad));
  const solarNoonMinute = 720 - 4 * site.lon - eqTimeMin + site.utcOffsetMinutes;
  if (cosHa > 1) return { sunriseMinute: null, sunsetMinute: null, solarNoonMinute, state: 'never rises' };
  if (cosHa < -1) return { sunriseMinute: null, sunsetMinute: null, solarNoonMinute, state: 'never sets' };
  const haDeg = Math.acos(cosHa) * RAD;
  return {
    sunriseMinute: 720 - 4 * (site.lon + haDeg) - eqTimeMin + site.utcOffsetMinutes,
    sunsetMinute: 720 - 4 * (site.lon - haDeg) - eqTimeMin + site.utcOffsetMinutes,
    solarNoonMinute,
    state: 'rises and sets'
  };
}

/**
 * Register the solar system.
 *
 * @param {import('../kernel/world.js').World} world
 * @param {object} [opts]
 * @param {{lat:number, lon:number, utcOffsetMinutes:number}} [opts.site] the island reference site,
 *   normally the standard port record out of data/tide.json. Defaults to SITE_DUNWICH.
 */
export function registerSolar(world, opts = {}) {
  const given = opts.site || SITE_DUNWICH;
  if (typeof given.lat !== 'number' || typeof given.lon !== 'number') {
    throw new Error('solar needs a site with a numeric lat and lon');
  }
  const site = {
    name: given.name || SITE_DUNWICH.name,
    lat: given.lat,
    lon: given.lon,
    utcOffsetMinutes: given.utcOffsetMinutes ?? SITE_DUNWICH.utcOffsetMinutes,
    source: given.source || SITE_DUNWICH.source,
    locator: given.locator || SITE_DUNWICH.locator
  };

  const update = (self, ctx) => {
    const civil = ctx.clock.civil();
    const doy = ctx.clock.dayOfYear();
    const inYear = daysInYear(civil.year);
    const sun = sunAt(site, doy, civil.minuteOfDay, inYear);
    const events = sunEvents(site, doy, inYear);

    self.elevationDeg = sun.elevationDeg;
    self.azimuthDeg = sun.azimuthDeg;
    self.declinationDeg = sun.declinationDeg;
    self.equationOfTimeMin = sun.eqTimeMin;
    self.sunriseMinute = events.sunriseMinute;
    self.sunsetMinute = events.sunsetMinute;
    self.solarNoonMinute = events.solarNoonMinute;
    self.dayLengthMinutes = events.sunriseMinute === null ? null : events.sunsetMinute - events.sunriseMinute;
    self.dayOfYear = doy;
    return sun.elevationDeg > HORIZON_ELEVATION_DEG;
  };

  world.system({
    name: 'solar',
    order: 10,
    budgetMs: 0.5,
    emits: ['solar.sunrise', 'solar.sunset'],
    state: {
      elevationDeg: 0,
      azimuthDeg: 0,
      isDaylight: false,
      declinationDeg: 0,
      equationOfTimeMin: 0,
      sunriseMinute: null,
      sunsetMinute: null,
      solarNoonMinute: null,
      dayLengthMinutes: null,
      dayOfYear: 0,
      siteLat: site.lat,
      siteLon: site.lon,
      siteSource: site.source
    },

    // Boot establishes the sun at tick zero without emitting. A sunrise event means the sun crossed
    // the horizon while the world was running; the state at the opening moment is not a crossing.
    boot(self, ctx) {
      self.isDaylight = update(self, ctx);
    },

    tick(self, ctx) {
      const was = self.isDaylight;
      const now = update(self, ctx);
      self.isDaylight = now;
      if (now === was) return;
      ctx.emit(now ? 'solar.sunrise' : 'solar.sunset', {
        tick: ctx.tick,
        islandTime: ctx.clock.iso(),
        elevationDeg: self.elevationDeg,
        azimuthDeg: self.azimuthDeg,
        predictedMinute: now ? self.sunriseMinute : self.sunsetMinute,
        minuteOfDay: ctx.clock.civil().minuteOfDay
      });
    }
  });

  return world;
}
