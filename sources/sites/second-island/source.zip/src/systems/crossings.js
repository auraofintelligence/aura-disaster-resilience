// The crossings: three service classes, two operators, two landing points, and one rule.
//
// There is no bridge. Every person, every vehicle, every crate of milk and every ambulance patient
// crosses Quandamooka (Moreton Bay) on a boat with a published timetable, so this system is the
// throttle on everything else this world will ever model.
//
// THE LAW, AND WHY IT IS IN THE TYPE
//
// Passenger and vehicle crossings are never one figure. The first build merged them and made the
// useful question unanswerable. Writing that rule in a paragraph is what the first build did too,
// so here it is structural instead: every sailing carries `carries`, an enum with exactly two
// values, and there is no third value meaning both. A vehicle sailing also carries people, and
// that is fine. What is refused is a single field where a vehicle number and a passenger number
// could be added together. tools/gate/crossings.mjs fails the build if one appears.
//
// The state below is shaped by the same rule. `canAPersonLeaveNow` and `canAVehicleLeaveNow` are
// two booleans that are never combined, and `minutesUntilLastVehicleOffIsland` is the number that
// actually matters on this island. It has no equivalent for people on purpose: the person's day is
// five hours longer than the car's, so the two questions are not the same question asked twice.
//
// WHAT "NOW" MEANS, said here because a boolean cannot say it
//
// `canAPersonLeaveNow` is true when this minute lies inside today's off-island passenger window,
// meaning at or after the first island-to-mainland passenger departure of the day and at or before
// the last. It does not mean a boat is at the jetty this minute. `minutesUntilNextPersonOffIsland`
// answers that, and the two are kept apart because a resident at 03:00 wants the first answer and a
// resident at 12:07 wants the second.
//
// WHAT THIS SYSTEM DOES NOT KNOW
//
// Public holidays. Four Gold Cats Flyer sailings state that they do not run on one, and no source
// here says what a public holiday does to the other seventy two. There is no Queensland public
// holiday calendar in this repository, so the input is reported unfed and every answer that would
// change if today were a public holiday is flagged. Guessing a calendar would be the same class of
// mistake as guessing a tide constituent.
//
// It also knows nothing about capacity, queues, bookings, weather cancellations or the extra
// vehicle services SeaLink adds beyond its base timetable. A vehicle sailing count from this system
// is a floor and never a total, and the pack says so in its own words.
//
// No wall clock, no Date, no random draw. Given a tick, this file returns the same crossings twice.

const M2I = 'mainland-to-island';
const I2M = 'island-to-mainland';
const VEHICLES = 'vehicles';
const PASSENGERS = 'passengers';

/** The only two values `carries` may take. There is no third, and adding one is a gate failure. */
export const CARRIES_VALUES = Object.freeze([VEHICLES, PASSENGERS]);

const WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const MINUTES_PER_DAY = 1440;

/** Island civil minutes to a published-looking clock time, for a payload a person reads. */
export function hhmm(minute) {
  if (minute === null || minute === undefined) return null;
  const m = ((minute % MINUTES_PER_DAY) + MINUTES_PER_DAY) % MINUTES_PER_DAY;
  return `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
}

/**
 * Does this sailing run on this weekday, ignoring public holidays, which nothing here knows.
 * @param {object} sailing a record from data/crossings.json sailings[]
 * @param {number} weekday Sunday 0 through Saturday 6, as src/kernel/clock.js civil() gives it
 */
export function runsOnWeekday(sailing, weekday) {
  const days = sailing && sailing.days;
  if (!days || !Array.isArray(days.weekdays)) return false;
  return days.weekdays.includes(weekday);
}

/** True when this sailing's own source says it stops on a public holiday. */
export function stopsOnAPublicHoliday(sailing) {
  return Boolean(sailing && sailing.days && sailing.days.publicHolidays === 'does-not-run');
}

/**
 * The window a class of service is open off the island on a given day: first departure to last.
 * Returns nulls with no sailings, which is a real answer and not an error.
 */
export function offIslandWindow(sailings) {
  if (!sailings.length) return { firstMinute: null, lastMinute: null, minutes: null };
  const first = sailings[0].departsMinuteOfDay;
  const last = sailings[sailings.length - 1].departsMinuteOfDay;
  return { firstMinute: first, lastMinute: last, minutes: last - first };
}

/**
 * Everything about one weekday, worked out once at registration rather than every tick.
 *
 * Seven of these exist and the tick does lookups in them. That is not only speed: it means the
 * answer for a Wednesday is computed by the same code as the answer for a Friday, so a day rule
 * cannot quietly apply to one day and not another.
 */
function buildDay(pack, weekday) {
  const running = pack.sailings
    .filter((s) => runsOnWeekday(s, weekday))
    .sort((a, b) => (a.departsMinuteOfDay - b.departsMinuteOfDay) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));

  const byMinute = new Map();
  for (const s of running) {
    if (!byMinute.has(s.departsMinuteOfDay)) byMinute.set(s.departsMinuteOfDay, []);
    byMinute.get(s.departsMinuteOfDay).push(s);
  }

  const off = (carries) => running.filter((s) => s.direction === I2M && s.carries === carries);
  const vehicleOff = off(VEHICLES);
  const passengerOff = off(PASSENGERS);
  const vehicleAll = running.filter((s) => s.carries === VEHICLES);

  // Per service and per direction, sorted by minute. The keys are built in a fixed service order so
  // two runs produce the same object in the same order.
  const perService = {};
  for (const svc of pack.services) {
    perService[svc.serviceId] = {
      [M2I]: running.filter((s) => s.serviceId === svc.serviceId && s.direction === M2I),
      [I2M]: running.filter((s) => s.serviceId === svc.serviceId && s.direction === I2M)
    };
  }

  // A movement is one vessel arriving at or departing from a landing point. A sailing of a service
  // touches its island point once and its mainland point once, so it is one movement at each.
  const movementsByLandingPoint = {};
  const movementsByService = {};
  for (const p of pack.landingPoints) movementsByLandingPoint[p.id] = 0;
  for (const svc of pack.services) movementsByService[svc.serviceId] = 0;
  for (const s of running) {
    movementsByService[s.serviceId] = (movementsByService[s.serviceId] || 0) + 1;
    for (const point of [s.islandPoint, s.mainlandPoint]) {
      if (point in movementsByLandingPoint) movementsByLandingPoint[point] += 1;
    }
  }

  return {
    weekday,
    running,
    byMinute,
    vehicleOff,
    passengerOff,
    vehicleAll,
    perService,
    movementsByLandingPoint,
    movementsByService,
    firstVehicleMinute: vehicleAll.length ? vehicleAll[0].departsMinuteOfDay : null,
    lastVehicleMinute: vehicleAll.length ? vehicleAll[vehicleAll.length - 1].departsMinuteOfDay : null,
    vehicleWindow: offIslandWindow(vehicleOff),
    passengerWindow: offIslandWindow(passengerOff),
    publicHolidaySensitive: running.some(stopsOnAPublicHoliday)
  };
}

/** The next sailing at or after `fromMinute` today, then on following days, up to a week ahead. */
function nextSailing(days, weekday, fromMinute, list) {
  for (let ahead = 0; ahead <= 7; ahead++) {
    const day = days[(weekday + ahead) % 7];
    const candidates = list(day);
    for (const s of candidates) {
      if (ahead === 0 && s.departsMinuteOfDay < fromMinute) continue;
      return {
        sailingId: s.id,
        serviceId: s.serviceId,
        operator: s.operator,
        vessel: s.vessel,
        carries: s.carries,
        direction: s.direction,
        departsMinuteOfDay: s.departsMinuteOfDay,
        departsLocal: s.departsLocal,
        daysAhead: ahead,
        minutesUntil: ahead * MINUTES_PER_DAY + s.departsMinuteOfDay - fromMinute,
        stopsOnAPublicHoliday: stopsOnAPublicHoliday(s)
      };
    }
  }
  return null;
}

/**
 * Register the crossings system.
 *
 * @param {import('../kernel/world.js').World} world
 * @param {object} [opts]
 * @param {object} [opts.pack] the parsed data/crossings.json. Without it the system is unfed and
 *   says so, the same way the tide system does: an absence is an answer and a plausible timetable
 *   is not.
 */
export function registerCrossings(world, opts = {}) {
  const pack = opts.pack || null;

  const problems = [];
  if (!pack) {
    problems.push('no crossings pack was loaded');
  } else {
    if (!Array.isArray(pack.sailings) || pack.sailings.length === 0) problems.push('the pack carries no sailings');
    if (!Array.isArray(pack.services) || pack.services.length === 0) problems.push('the pack carries no services');
    if (!Array.isArray(pack.landingPoints) || pack.landingPoints.length === 0) problems.push('the pack carries no landing points');
    for (const s of pack.sailings || []) {
      if (!CARRIES_VALUES.includes(s.carries)) {
        problems.push(`sailing ${s.id} carries ${JSON.stringify(s.carries)}, which is not one of ${CARRIES_VALUES.join(' or ')}`);
        break;
      }
      if (s.direction !== M2I && s.direction !== I2M) {
        problems.push(`sailing ${s.id} has direction ${JSON.stringify(s.direction)}`);
        break;
      }
      if (!Number.isInteger(s.departsMinuteOfDay) || s.departsMinuteOfDay < 0 || s.departsMinuteOfDay >= MINUTES_PER_DAY) {
        problems.push(`sailing ${s.id} departs at minute ${JSON.stringify(s.departsMinuteOfDay)}`);
        break;
      }
    }
  }

  const fed = problems.length === 0;
  const days = fed ? [0, 1, 2, 3, 4, 5, 6].map((w) => buildDay(pack, w)) : null;
  const serviceIds = fed ? pack.services.map((s) => s.serviceId) : [];
  const landingPointIds = fed ? pack.landingPoints.map((p) => p.id) : [];
  const carriesByService = {};
  if (fed) for (const svc of pack.services) carriesByService[svc.serviceId] = svc.carries;
  const holidaySensitiveCount = fed ? pack.sailings.filter(stopsOnAPublicHoliday).length : 0;

  const blank = () => {
    const out = {};
    for (const id of serviceIds) out[id] = { [M2I]: null, [I2M]: null };
    return out;
  };

  world.system({
    name: 'crossings',
    order: 30,
    budgetMs: 0.5,
    emits: ['crossing.departed', 'crossing.last-vehicle-of-day', 'crossing.first-vehicle-of-day'],
    state: {
      fed,
      reason: fed ? '' : problems.join('; '),
      sailingCount: fed ? pack.sailings.length : 0,
      serviceIds,
      landingPointIds,
      carriesByService,

      weekday: null,
      weekdayName: null,
      minuteOfDay: null,

      // The two answers, and they are never combined into one.
      canAPersonLeaveNow: false,
      canAVehicleLeaveNow: false,

      // The number that matters on this island. There is deliberately no passenger twin of it.
      minutesUntilLastVehicleOffIsland: null,
      lastVehicleOffIslandMinuteOfDay: null,
      lastVehicleOffIslandLocal: null,
      lastVehicleOffIslandHasGone: false,

      minutesUntilNextVehicleOffIsland: null,
      minutesUntilNextPersonOffIsland: null,
      lastPersonOffIslandMinuteOfDay: null,
      lastPersonOffIslandLocal: null,

      offIslandVehicleWindow: { firstMinute: null, lastMinute: null, minutes: null, openNow: false },
      offIslandPassengerWindow: { firstMinute: null, lastMinute: null, minutes: null, openNow: false },
      windowGapMinutes: null,
      windowGapMorningMinutes: null,
      windowGapEveningMinutes: null,

      nextByService: blank(),
      passengerServicesOpenNow: [],
      movementsTodayByLandingPoint: {},
      movementsTodayByService: {},
      sailingsToday: 0,
      departedToday: 0,

      publicHolidays: {
        fed: false,
        calendar: null,
        reason: 'This repository holds no public holiday calendar and does not guess one. '
          + holidaySensitiveCount + ' sailings state that they do not run on a public holiday, and '
          + 'no source here says what a public holiday does to the others.',
        sailingsThatStopOnOne: holidaySensitiveCount,
        todayDependsOnIt: false,
        caveat: 'A sailing whose source says nothing about public holidays is recorded unknown, not '
          + 'running, so todayDependsOnIt is a floor on the uncertainty and not a bound on it.'
      }
    },

    boot(self, ctx) {
      if (!self.fed) return;
      update(self, ctx);
    },

    tick(self, ctx) {
      if (!self.fed) return;
      const civil = ctx.clock.civil();
      const day = days[civil.weekday];

      if (civil.minuteOfDay === 0) self.departedToday = 0;

      const departing = day.byMinute.get(civil.minuteOfDay);
      if (departing) {
        for (const s of departing) {
          self.departedToday += 1;
          ctx.emit('crossing.departed', {
            tick: ctx.tick,
            islandTime: ctx.clock.iso(),
            sailingId: s.id,
            serviceId: s.serviceId,
            operator: s.operator,
            vessel: s.vessel,
            carries: s.carries,
            direction: s.direction,
            mainlandPoint: s.mainlandPoint,
            islandPoint: s.islandPoint,
            departsMinuteOfDay: s.departsMinuteOfDay,
            stopsOnAPublicHoliday: stopsOnAPublicHoliday(s)
          });
        }

        // The first and the last vehicle movement of the island day. On this timetable the last one
        // is also the last vehicle off the island, which is why it is the event with a name.
        const vehicles = departing.filter((s) => s.carries === VEHICLES);
        if (vehicles.length) {
          const payload = (s) => ({
            tick: ctx.tick,
            islandTime: ctx.clock.iso(),
            sailingId: s.id,
            serviceId: s.serviceId,
            operator: s.operator,
            vessel: s.vessel,
            direction: s.direction,
            departsMinuteOfDay: s.departsMinuteOfDay,
            firstVehicleOffIslandMinuteOfDay: day.vehicleWindow.firstMinute,
            lastVehicleOffIslandMinuteOfDay: day.vehicleWindow.lastMinute,
            baseTimetableOnly: true
          });
          if (civil.minuteOfDay === day.firstVehicleMinute) {
            ctx.emit('crossing.first-vehicle-of-day', payload(vehicles[0]));
          }
          if (civil.minuteOfDay === day.lastVehicleMinute) {
            ctx.emit('crossing.last-vehicle-of-day', payload(vehicles[vehicles.length - 1]));
          }
        }
      }

      update(self, ctx);
    }
  });

  /** Recompute every answer from the clock. Pure, so boot and tick cannot drift apart. */
  function update(self, ctx) {
    const civil = ctx.clock.civil();
    const day = days[civil.weekday];
    const now = civil.minuteOfDay;

    self.weekday = civil.weekday;
    self.weekdayName = WEEKDAYS[civil.weekday];
    self.minuteOfDay = now;

    const v = day.vehicleWindow;
    const p = day.passengerWindow;
    const openNow = (w) => w.firstMinute !== null && now >= w.firstMinute && now <= w.lastMinute;

    self.offIslandVehicleWindow = { ...v, openNow: openNow(v) };
    self.offIslandPassengerWindow = { ...p, openNow: openNow(p) };

    // Two booleans, computed apart and never added, multiplied or reduced into one number.
    self.canAVehicleLeaveNow = self.offIslandVehicleWindow.openNow;
    self.canAPersonLeaveNow = self.offIslandPassengerWindow.openNow;

    // The gap between the two windows. A difference of two durations, which is the whole point of
    // this system, and not a sum of a vehicle figure with a passenger figure, which is forbidden.
    if (v.firstMinute !== null && p.firstMinute !== null) {
      self.windowGapMorningMinutes = v.firstMinute - p.firstMinute;
      self.windowGapEveningMinutes = p.lastMinute - v.lastMinute;
      self.windowGapMinutes = self.windowGapMorningMinutes + self.windowGapEveningMinutes;
    } else {
      self.windowGapMorningMinutes = null;
      self.windowGapEveningMinutes = null;
      self.windowGapMinutes = null;
    }

    self.lastVehicleOffIslandMinuteOfDay = v.lastMinute;
    self.lastVehicleOffIslandLocal = hhmm(v.lastMinute);
    self.lastVehicleOffIslandHasGone = v.lastMinute !== null && now > v.lastMinute;
    self.minutesUntilLastVehicleOffIsland = self.lastVehicleOffIslandHasGone || v.lastMinute === null
      ? null
      : v.lastMinute - now;

    self.lastPersonOffIslandMinuteOfDay = p.lastMinute;
    self.lastPersonOffIslandLocal = hhmm(p.lastMinute);

    const nextVehicleOff = nextSailing(days, civil.weekday, now, (d) => d.vehicleOff);
    const nextPersonOff = nextSailing(days, civil.weekday, now, (d) => d.passengerOff);
    self.minutesUntilNextVehicleOffIsland = nextVehicleOff ? nextVehicleOff.minutesUntil : null;
    self.minutesUntilNextPersonOffIsland = nextPersonOff ? nextPersonOff.minutesUntil : null;

    const next = {};
    const openPassengerServices = [];
    for (const id of serviceIds) {
      next[id] = {
        [M2I]: nextSailing(days, civil.weekday, now, (d) => d.perService[id][M2I]),
        [I2M]: nextSailing(days, civil.weekday, now, (d) => d.perService[id][I2M])
      };
      const off = day.perService[id][I2M];
      if (carriesByService[id] === PASSENGERS && off.length
        && now >= off[0].departsMinuteOfDay && now <= off[off.length - 1].departsMinuteOfDay) {
        openPassengerServices.push(id);
      }
    }
    self.nextByService = next;
    self.passengerServicesOpenNow = openPassengerServices;

    self.movementsTodayByLandingPoint = { ...day.movementsByLandingPoint };
    self.movementsTodayByService = { ...day.movementsByService };
    self.sailingsToday = day.running.length;

    self.publicHolidays = {
      ...self.publicHolidays,
      todayDependsOnIt: day.publicHolidaySensitive
    };
  }

  return world;
}
