// Water level at the Dunwich standard port, or an honest nothing.
//
// This system is the stage 0 demonstration of the rule that generates most of the others: where a
// real value has not been obtained, the twin says so instead of producing something that looks
// right. The tide is the most tempting place on this island to break that rule. Almost every other
// system wants a number from it, a plausible curve is five lines of trigonometry, and nobody
// looking at a rising and falling line on a screen would ever ask where it came from.
//
// So: no constituents, no curve. `heightM` is null, `fed` is false, and the reason names what is
// missing. The two events are declared and never fire, which shows up in the world report as a dead
// seam, which is correct. A dead seam that is honest about why is worth more than a live one that
// is making it up.
//
// When the official harmonic table lands in data/tide.json the sum below runs unchanged: height at
// time t is the mean level plus the sum over constituents of amplitude times the cosine of the
// constituent's angular speed times the hours since the epoch, less its phase lag. The shape is
// here so that landing the data is the whole job, and so that the empty case is visibly the same
// code path rather than a placeholder somebody has to replace.
//
// THE ANSWER AND THE SYSTEM'S OWN NUMBER ARE TWO DIFFERENT THINGS
//
// `heightM` is what THIS SYSTEM computed, which is the simulation rung of the source ladder, and it
// is null while the system is unfed. `answer` is what THE TWIN says when it is asked for
// `tide.heightM` at this tick, resolved by src/world/island.js down the ladder over the bitemporal
// store. They are kept apart on purpose. The ladder's rule is that the bottom rung never wins a
// live question, so a fed simulation and no observation still answers "not known" in live mode, and
// a system that overwrote the answer with its own number would be the exact failure the ladder
// exists to prevent.
//
// Before this was wired the null existed twice: here, and again in the panel, which built its own
// absence and its own date straight from the pack. Two nulls that agree today can disagree
// tomorrow, and the first build's time bugs were never arithmetic. They were two parts of one
// screen answering different questions with nothing saying which.

import { isUnknown } from '../world/ladder.js';

const DEG = Math.PI / 180;

/** The field name this system publishes to, and the name src/world/island.js resolves. */
export const TIDE_HEIGHT_FIELD = 'tide.heightM';

/** Hours from 1970-01-01T00:00 in the port's own civil time. The argument the harmonics take. */
export function portHours(clock) {
  return clock.minuteAt() / 60;
}

/**
 * Water level from a harmonic table.
 * @param {Array<{amplitudeM:number, speedDegPerHour:number, phaseDeg:number}>} constituents
 * @param {number} meanLevelM
 * @param {number} hours
 * @returns {number|null} metres on the table's own datum, or null when the table is empty
 */
export function heightFrom(constituents, meanLevelM, hours) {
  if (!Array.isArray(constituents) || constituents.length === 0) return null;
  if (typeof meanLevelM !== 'number') return null;
  let h = meanLevelM;
  for (const c of constituents) {
    h += c.amplitudeM * Math.cos((c.speedDegPerHour * hours - c.phaseDeg) * DEG);
  }
  return h;
}

/**
 * Register the tide system.
 *
 * @param {import('../kernel/world.js').World} world
 * @param {object} [opts]
 * @param {object} [opts.pack] the parsed data/tide.json. Without it the system is unfed, which is
 *   also what it is with the pack as the pack stands today.
 * @param {(field: string) => object} [opts.resolve] the world's field resolver, from
 *   src/world/island.js. Without it `answer` stays null and the system says so in `answerFrom`,
 *   rather than falling back to its own number, which would put the two nulls back.
 */
export function registerTide(world, opts = {}) {
  const pack = opts.pack || null;
  const askLadder = typeof opts.resolve === 'function' ? opts.resolve : null;
  // Only `constituents` is read. The pack's unverified_carry block is deliberately not consulted:
  // see data/tide.json for why those values exist and why nothing sums them.
  const constituents = pack && Array.isArray(pack.constituents) ? pack.constituents : [];
  const meanLevelM = pack && pack.datum && typeof pack.datum.value === 'number' ? pack.datum.value : null;
  const portName = pack && pack.port && pack.port.name ? pack.port.name : 'Dunwich, Minjerribah';

  const fed = constituents.length > 0 && meanLevelM !== null;
  const reason = fed
    ? ''
    : !pack
      ? 'no tide pack was loaded'
      : constituents.length === 0
        ? 'data/tide.json carries no harmonic constituents: the official table for this port has not been obtained'
        : 'data/tide.json carries constituents but no datum, so a height would have no zero';

  world.system({
    name: 'tide',
    order: 20,
    budgetMs: 0.5,
    emits: ['tide.high', 'tide.low'],
    state: {
      heightM: null,
      risingFalling: null,
      fed,
      reason,
      port: portName,
      constituentCount: constituents.length,
      lastTurnTick: null,
      lastTurnHeightM: null,
      // What the twin answers when asked for tide.heightM at this tick, through the ladder. Null
      // only when no resolver was supplied, and `answerFrom` says which of those two it is.
      answer: null,
      answerFrom: askLadder ? 'the world source ladder over the record store' : 'no resolver was supplied'
    },

    boot(self, ctx) {
      self.answer = ask();
      if (!self.fed) return;
      self.heightM = heightFrom(constituents, meanLevelM, portHours(ctx.clock));
      self.risingFalling = trend(ctx);
    },

    // An unfed system does no work and reports nothing. It does not tick towards a number, it does
    // not hold a last known value, and it does not degrade into a sine. It stays null. The answer
    // is asked for every tick either way, because the answer is a question about the island at this
    // minute and not a property of this system.
    tick(self, ctx) {
      self.answer = ask();
      if (!self.fed) return;
      const hours = portHours(ctx.clock);
      const previous = self.heightM;
      self.heightM = heightFrom(constituents, meanLevelM, hours);
      const was = self.risingFalling;
      self.risingFalling = trend(ctx);

      // A turn is the tick where the direction reverses. Reporting it on the reversal rather than
      // by searching ahead means the event is a thing that happened, at the tick it happened.
      if (was === 'rising' && self.risingFalling === 'falling') {
        self.lastTurnTick = ctx.tick;
        self.lastTurnHeightM = previous;
        ctx.emit('tide.high', { tick: ctx.tick, islandTime: ctx.clock.iso(), heightM: previous, port: portName });
      } else if (was === 'falling' && self.risingFalling === 'rising') {
        self.lastTurnTick = ctx.tick;
        self.lastTurnHeightM = previous;
        ctx.emit('tide.low', { tick: ctx.tick, islandTime: ctx.clock.iso(), heightM: previous, port: portName });
      }
    }
  });

  /**
   * Ask the twin for tide.heightM at the cursor the world is on, and flatten the ladder's two
   * shapes into one row a panel and a hash can both hold. The `why` is kept whole: it is the
   * sentence that says why there is no number, and shortening it here would be the start of the
   * absence becoming quiet again.
   */
  function ask() {
    if (!askLadder) return null;
    const r = askLadder(TIDE_HEIGHT_FIELD);
    if (isUnknown(r)) {
      return {
        field: TIDE_HEIGHT_FIELD,
        known: false,
        value: null,
        mode: r.mode,
        asAt: r.asAt,
        rung: null,
        source: null,
        because: r.becauseId || null,
        becauseRecordedAt: r.because ? r.because.recordedAt : null,
        why: r.why
      };
    }
    return {
      field: TIDE_HEIGHT_FIELD,
      known: true,
      value: r.value,
      mode: r.mode,
      asAt: r.asAt,
      rung: r.rung,
      source: r.source,
      because: null,
      becauseRecordedAt: null,
      why: null
    };
  }

  function trend(ctx) {
    const hours = portHours(ctx.clock);
    const ahead = heightFrom(constituents, meanLevelM, hours + 1 / 60);
    const behind = heightFrom(constituents, meanLevelM, hours - 1 / 60);
    if (ahead === null || behind === null) return null;
    if (ahead === behind) return 'slack';
    return ahead > behind ? 'rising' : 'falling';
  }

  return world;
}
