// The ranked source ladder, resolved per field.
//
// Founding prompt, section 3: "Live mode shows real observations; simulation only answers for
// moments that have not happened. A ranked source ladder resolved per field: island instrument,
// official observation, model, simulation. Freshness demotes per field. The bottom rung never wins
// in live mode; the honest answer to a stale feed is 'not known', dated."
//
// The four rungs, best first:
//
//     0  instrument    a sensor on this island, reporting itself
//     1  observation   an official observation from a body that publishes it
//     2  model         a published model or forecast for this place
//     3  simulation    what this twin computed, which is the bottom rung
//
// THE TWO RULES THAT MAKE IT AN INSTRUMENT RATHER THAN A PREFERENCE
//
// 1. Freshness demotes, per field. A reading older than the window declared for it drops one rung.
//    A stale official observation therefore ranks where a model would, and a stale model ranks at
//    the bottom, and a stale simulation falls off the ladder entirely. The window is declared per
//    field because the useful age of a tide reading and of a bus timetable are not the same number
//    and never will be.
//
// 2. The bottom rung never wins in live mode. If the only thing that can answer a live question is
//    this twin's own simulation, the honest answer is "not known", with the date. That is a real
//    answer and it is the one this repository exists to give: the first build filled that gap with
//    synthetic weather standing beside a free real feed, and nothing on screen said which was which.
//
// WHAT RESOLVE RETURNS, AND WHY IT IS TWO SHAPES
//
//     { value, rung, source, recordedAt, stale }   an answer, with where it came from
//     { unknown: true, asAt, why }                 no answer, dated, with the reason
//
// Two shapes on purpose. A caller cannot accidentally render "not known" as a number, and a panel
// that forgets to handle the second shape breaks visibly instead of printing undefined.
//
// `rung` is the rung the value actually came from, because that is what a panel has to show a
// person. `effectiveRung` is where it ranked after any freshness demotion, which is what decided
// the contest. Both are returned; they differ exactly when `stale` is true.

import { MODES, islandTime } from './bitemporal.js';
import { toMinute } from '../kernel/record.js';
import { faulty } from '../kernel/faults.js';

/** Best first. The index is the level, and the last entry is the bottom rung. */
export const RUNGS = Object.freeze([
  Object.freeze({ id: 'instrument', name: 'island instrument', level: 0 }),
  Object.freeze({ id: 'observation', name: 'official observation', level: 1 }),
  Object.freeze({ id: 'model', name: 'model', level: 2 }),
  Object.freeze({ id: 'simulation', name: 'simulation', level: 3 })
]);

export const RUNG_IDS = Object.freeze(RUNGS.map((r) => r.id));
export const BOTTOM_RUNG = RUNGS[RUNGS.length - 1].id;
export const BOTTOM_LEVEL = RUNGS[RUNGS.length - 1].level;

export function rungLevel(id) {
  const found = RUNGS.find((r) => r.id === id);
  return found ? found.level : null;
}

export function rungName(level) {
  const found = RUNGS.find((r) => r.level === level);
  return found ? found.name : 'below the ladder';
}

/**
 * A candidate is either a record carrying `rung` and `value` directly, or a wrapper
 * { rung, staleAfterMinutes, record }. Both shapes appear in practice: a pack can declare the rung
 * on the record, and a connector can wrap a record it did not write.
 */
function normalise(candidate) {
  if (!candidate || typeof candidate !== 'object') return null;
  const record = candidate.record && typeof candidate.record === 'object' ? candidate.record : candidate;
  const rung = candidate.rung !== undefined ? candidate.rung : record.rung;
  const stalenessRaw = candidate.staleAfterMinutes !== undefined
    ? candidate.staleAfterMinutes
    : record.staleAfterMinutes;
  return {
    id: typeof record.id === 'string' ? record.id : '(no id)',
    field: candidate.field !== undefined ? candidate.field : record.field,
    value: candidate.value !== undefined ? candidate.value : record.value,
    rung,
    staleAfterMinutes: stalenessRaw,
    source: record.source,
    recordedAt: record.recordedAt,
    validFrom: record.validFrom,
    register: record.register,
    confidence: record.confidence,
    record
  };
}

/** The ladder's own order: rung first, then freshness, then the most recently learned. */
function byLadder(a, b) {
  if (a.effectiveLevel !== b.effectiveLevel) return a.effectiveLevel - b.effectiveLevel;
  if (a.stale !== b.stale) return a.stale ? 1 : -1;
  if (a.recordedAtMinute !== b.recordedAtMinute) return b.recordedAtMinute - a.recordedAtMinute;
  if (a.validFromMinute !== b.validFromMinute) return b.validFromMinute - a.validFromMinute;
  return a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
}

/** Freshness first, then the ladder. Reached only under the 'stale-wins' fault. */
function byFreshnessFirst(a, b) {
  if (a.stale !== b.stale) return a.stale ? 1 : -1;
  return byLadder(a, b);
}

/**
 * Live mode's floor: nothing sitting at or below the bottom rung may answer. A fresh model can
 * answer a live question. A fresh simulation cannot, and neither can a stale model that has been
 * demoted onto the bottom rung.
 */
function applyLiveFloor(cursor, standing) {
  if (cursor.mode !== MODES.LIVE) return standing;
  return standing.filter((c) => c.effectiveLevel < BOTTOM_LEVEL);
}

function unknown(field, cursor, why, considered, rejected) {
  return Object.freeze({
    unknown: true,
    asAt: islandTime(cursor.validAt),
    why,
    field,
    mode: cursor.mode,
    considered,
    rejected: Object.freeze(rejected)
  });
}

/**
 * Resolve one field from a set of candidates, at a cursor position.
 *
 * @param {string} field the field being asked for, for example 'tide.heightM'
 * @param {Array} candidates records or wrappers, usually already read through a BitemporalStore so
 *   that only records valid and known at the cursor are in the list
 * @param {import('./bitemporal.js').Cursor} cursor
 * @param {object} [opts]
 * @param {number} [opts.staleAfterMinutes] the field's staleness window, when the candidates do not
 *   carry their own. A candidate with neither cannot be judged for freshness and is not eligible:
 *   treating an undated reading as fresh forever is precisely the bug this rule prevents.
 * @returns {{value: *, rung: string, source: string, recordedAt: string, stale: boolean}
 *   | {unknown: true, asAt: string, why: string}}
 */
export function resolve(field, candidates, cursor, opts = {}) {
  if (typeof field !== 'string' || field === '') throw new Error('resolve needs the name of a field');
  if (!cursor || typeof cursor.mode !== 'string' || !Number.isInteger(cursor.validAt)) {
    throw new Error('resolve needs a Cursor from src/world/bitemporal.js, got ' + typeof cursor);
  }
  const list = Array.isArray(candidates) ? candidates : [];
  const fieldWindow = opts.staleAfterMinutes;

  const judged = [];
  const rejected = [];
  let consideredForField = 0;

  for (const raw of list) {
    const c = normalise(raw);
    if (!c) {
      rejected.push({ id: '(not a record)', why: 'not an object' });
      continue;
    }
    if (c.field !== undefined && c.field !== field) continue;
    consideredForField++;

    const level = rungLevel(c.rung);
    if (level === null) {
      rejected.push({ id: c.id, why: 'rung ' + JSON.stringify(c.rung) + ' is not on the ladder. '
        + 'The rungs are ' + RUNG_IDS.join(', ') + '.' });
      continue;
    }
    if (c.value === undefined) {
      rejected.push({ id: c.id, why: 'carries no value for ' + field });
      continue;
    }
    const staleWindow = c.staleAfterMinutes !== undefined ? c.staleAfterMinutes : fieldWindow;
    if (typeof staleWindow !== 'number' || !Number.isFinite(staleWindow) || staleWindow < 0) {
      rejected.push({ id: c.id, why: 'declares no staleness window for ' + field
        + ', so its freshness cannot be judged. An undated reading treated as fresh forever is the '
        + 'bug the ladder exists to prevent.' });
      continue;
    }
    const vf = toMinute(c.validFrom);
    const ra = toMinute(c.recordedAt);
    if (vf === null || ra === null) {
      rejected.push({ id: c.id, why: 'validFrom or recordedAt is not an island time' });
      continue;
    }

    // Age is measured against the cursor's valid time: how old is this reading at the moment being
    // asked about. A reading that is not yet valid at the cursor is not old, it is early.
    const age = Math.max(0, cursor.validAt - vf);
    const stale = age > staleWindow;
    const effectiveLevel = level + (stale ? 1 : 0);

    const judgedCandidate = {
      ...c,
      level,
      stale,
      age,
      staleWindow,
      effectiveLevel,
      validFromMinute: vf,
      recordedAtMinute: ra
    };

    if (effectiveLevel > BOTTOM_LEVEL) {
      rejected.push({ id: c.id, why: 'stale by ' + (age - staleWindow) + ' minute(s) past its '
        + staleWindow + ' minute window, which drops it off the bottom of the ladder' });
      continue;
    }
    judged.push(judgedCandidate);
  }

  // Fault hook: 'stale-wins'. Healthy, live mode's floor is applied and then the ladder decides,
  // so a stale official observation still outranks a fresh simulation and the simulation cannot
  // answer a live question at all. Under the fault, freshness outranks the ladder and the floor is
  // not applied, so the simulation rung wins in live mode against a stale official observation.
  const running = faulty('stale-wins')
    ? [...judged].sort(byFreshnessFirst)
    : applyLiveFloor(cursor, judged).sort(byLadder);

  if (running.length === 0) {
    let why;
    if (consideredForField === 0) {
      why = 'no candidate was offered for ' + field + ' at ' + islandTime(cursor.validAt)
        + '. The twin has nothing to say about it, and says so.';
    } else if (judged.length === 0) {
      why = 'all ' + consideredForField + ' candidate(s) for ' + field + ' were set aside: '
        + rejected.map((r) => r.id + ' ' + r.why).join('; ');
    } else {
      const best = [...judged].sort(byLadder)[0];
      why = 'in ' + cursor.mode + ' mode the bottom rung never wins, and the best candidate for '
        + field + ' is ' + best.id + ' at the ' + rungName(best.effectiveLevel) + ' rung'
        + (best.stale ? ' after a freshness demotion' : '')
        + '. The honest answer is not known, dated.';
    }
    return unknown(field, cursor, why, consideredForField, rejected);
  }

  const w = running[0];
  return Object.freeze({
    field,
    value: w.value,
    rung: w.rung,
    effectiveRung: RUNGS[w.effectiveLevel] ? RUNGS[w.effectiveLevel].id : 'below the ladder',
    source: w.source,
    recordedAt: w.recordedAt,
    stale: w.stale,
    ageMinutes: w.age,
    staleAfterMinutes: w.staleWindow,
    validFrom: w.validFrom,
    register: w.register,
    confidence: w.confidence,
    id: w.id,
    mode: cursor.mode,
    asAt: islandTime(cursor.validAt),
    considered: consideredForField,
    rejected: Object.freeze(rejected)
  });
}

/**
 * The join between the store and the ladder: read the field's candidates at the cursor, then rank
 * them. Every record valid and known at the cursor is a candidate, so a record that has stopped
 * being true, or a belief that has been superseded, never reaches the ladder at all.
 *
 * O(n) over the store, because a field is not the store's index. When a field becomes the hot path
 * the index to add is a bucket per field in BitemporalStore, and this function does not change.
 */
export function resolveFrom(store, field, cursor, opts = {}) {
  const candidates = store.read(cursor).filter((r) => r.field === field);
  return resolve(field, candidates, cursor, opts);
}

/** True when a result is the "not known" shape. Saves every caller writing the same check. */
export function isUnknown(result) {
  return Boolean(result && result.unknown === true);
}

/**
 * One line a panel can show, for either shape. Low confidence and unknown both read as a marker
 * with a date rather than as a claim, which is contract section 3.
 */
export function describe(result) {
  if (isUnknown(result)) return 'not known as at ' + result.asAt;
  const age = result.stale ? ', stale' : '';
  return String(result.value) + '  [' + result.rung + age + ', ' + result.source
    + ', recorded ' + result.recordedAt + ']';
}
