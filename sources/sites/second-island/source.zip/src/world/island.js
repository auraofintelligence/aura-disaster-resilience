// Building the island: one function everything else in this repository calls.
//
// The instruments, the page and the gate all have to run the same world, or they are measuring
// different things and their agreement means nothing. So there is exactly one place where a World
// is constructed, packs are loaded and systems are registered, and it is here.
//
// Stage 0 registers two systems, solar and tide, because an instrument cannot be validated against
// nothing and those two are physics rather than invention. Adding a system is a line in
// `registerSystems` below, and the world's own ordering rule means adding one cannot move another
// one's numbers.
//
// THE RECORD STORE, WIRED IN
//
// Board note 018 landed the bitemporal store and said plainly what it did not do: "Nothing is
// wired. src/world/island.js builds no store, no system reads one, no number on screen goes through
// the ladder." That is what this file now does, and the three pieces are:
//
//   world.records     a BitemporalStore holding every record in every pack the world loaded, put
//                     there through the same checkRecord the gate runs, plus the store's own
//                     requirement of an id. A record that fails is refused loudly and the build
//                     stops. Nothing is skipped.
//   world.cursor()    live, history and scenario as three positions over that one store. The
//                     world's clock drives valid time in live, and belief time tracks the latest
//                     belief. Only a scenario cursor may run past every record's validFrom.
//   world.resolve()   one field, one ladder, one answer, with the record that explains an absence
//                     read at the same cursor rather than written out here as a sentence.
//
// Why the tide is the field that goes through it first: it is unfed. data/tide.json carries no
// harmonic constituents, so the honest answer is "not known" with its date and its reason, and that
// is the answer that used to exist twice, once as a null in the tide system and once as a separate
// null in the panel. Two nulls that agree today are two nulls that can disagree tomorrow, which is
// the first build's bug in miniature.

import { World, DEFAULT_EPOCH } from '../kernel/world.js';
import { faulty } from '../kernel/faults.js';
import { loadPacks, loadSourceIds, validatePacks, findRecords, SOURCES_PACK } from './data.js';
import { BitemporalStore, MODES } from './bitemporal.js';
import { resolveFrom, isUnknown } from './ladder.js';
import { registerSolar, SITE_DUNWICH } from '../systems/solar.js';
import { registerTide, TIDE_HEIGHT_FIELD } from '../systems/tide.js';

/**
 * The packs stage 0 needs. Short on purpose: real data arrives at stage 2 and arrives real.
 *
 * `_sources` is in the list, and it is not a pack of records. It is the source vocabulary, and it
 * is loaded here so that EVERY build path gets it: `buildIslandWith` is synchronous and cannot go
 * and fetch it, so a tool that builds a world from packs in hand would otherwise get a store with
 * no way to refuse a source that cannot be opened, while the page got one that could. Two build
 * paths with two different refusal rules is the shape of defect this repository exists to stop.
 * `validatePacks` already skips it by name.
 *
 * data/lore.json is deliberately NOT here. It is carried from the first build byte for byte, it
 * holds no records in the record schema, and loading it would make the pack check fail on a file
 * that was never meant to pass it. src/main.js loads it directly for the acknowledgement wording.
 */
export const STAGE_0_PACKS = ['_sources', 'tide'];

/**
 * The fields the twin publishes through the source ladder, and for each one the record that
 * explains an absence.
 *
 * `because` is a record id in the store, not a sentence. When the ladder answers "not known", the
 * reason is read out of that record at the same cursor, so the explanation carries its own source,
 * locator and date and is subject to the same two times as everything else. A reason written into
 * code here would be a claim with no provenance sitting inside the one file that is supposed to
 * stop those.
 *
 * No staleness window is declared for a field. A window is a property of the reading, and board
 * note 018 is right that real windows for real fields are a question for the data. A candidate that
 * declares none is refused by the ladder with the reason, which is the honest outcome and is
 * cheaper than a number invented here.
 *
 * A crossing figure lands here as one more entry when the crossings lane produces a record: the
 * field it publishes, and the id of the record that says why it is absent. Nothing is written for
 * it in advance, because the field names and the record ids are the lane's to decide and inventing
 * them here would be the second time this repository wrote down a figure before opening it.
 */
export const FIELDS = Object.freeze({
  [TIDE_HEIGHT_FIELD]: Object.freeze({
    what: 'water level at the Dunwich standard port, in metres on the table\'s own datum',
    because: 'tide-table-status'
  })
});

/**
 * The island reference site, read out of the tide pack's standard port record.
 *
 * The coordinate lives in a pack rather than in code so that it carries its provenance, and
 * src/systems/solar.js also holds it as a constant so that the system runs standalone. Two copies
 * of a number is a bug waiting to happen, so they are compared here and a disagreement stops the
 * build rather than quietly lighting the island from the wrong place.
 */
export function siteFrom(packs) {
  const port = packs && packs.tide && packs.tide.port;
  if (!port) return { ...SITE_DUNWICH };
  const site = {
    name: port.name,
    lat: port.lat,
    lon: port.lon,
    utcOffsetMinutes: port.utcOffsetMinutes,
    source: port.source,
    locator: port.locator
  };
  const drift = Math.max(Math.abs(site.lat - SITE_DUNWICH.lat), Math.abs(site.lon - SITE_DUNWICH.lon));
  if (!(drift <= 0)) {
    throw new Error(
      'the island site in data/tide.json and the constant in src/systems/solar.js disagree: '
      + `pack ${site.lat}, ${site.lon} against code ${SITE_DUNWICH.lat}, ${SITE_DUNWICH.lon}. `
      + 'Fix the code constant to match the pack, because the pack is the one with provenance.'
    );
  }
  return site;
}

/**
 * Load every record in every loaded pack into one BitemporalStore.
 *
 * Three things happen to a record here and each one is deliberate.
 *
 * REFUSED. A record that fails `checkRecord`, or that the store refuses for any other reason, stops
 * the build. Every problem in every pack is collected first, so the message names all of them
 * rather than the first, and nothing is added at all: a half loaded store is the worst of the three
 * outcomes because it looks like it worked.
 *
 * QUARANTINED. A record that declares `usable: false` is held out of the store and named in the
 * report with the pack's own blocking note. data/tide.json's `unverified_carry` is the case this
 * exists for: seven harmonic constituents carried from the first build whose stated source is false
 * by that build's own finding. The pack says nothing may read them, and the way to honour that is
 * to keep them out of the one place code reads from and to say so out loud. That is a labelled
 * absence, not a quiet skip, and the difference is the whole point.
 *
 * AN ID FROM ITS PATH. The store needs a string id per record, because without one there is no
 * timeline and no correction, only a heap. `checkRecord` does not ask for one, so a pack record can
 * lack it, and data/tide.json's `datum` record does. Such a record is loaded under its pack path,
 * for example `tide.datum`, and every one of them is listed in the report. The derived id is
 * machinery and not a claim: it names where the record lives, it is stable only while the record
 * stays at that path, and the pack giving the record an id of its own is the better fix.
 *
 * @param {Object<string, object>} packs
 * @param {object} [opts]
 * @param {Set<string>} [opts.sourceIds] ids from data/_sources.json. Defaults to the keys of the
 *   loaded `_sources` pack when there is one, and to null when there is not, which is the only case
 *   where a source that cannot be opened would get through.
 * @returns {{store: BitemporalStore, report: object}}
 */
export function loadRecordStore(packs, opts = {}) {
  const sourceIds = opts.sourceIds instanceof Set
    ? opts.sourceIds
    : (packs && packs[SOURCES_PACK] ? new Set(Object.keys(packs[SOURCES_PACK])) : null);

  const store = new BitemporalStore(sourceIds ? { sourceIds } : {});
  const report = {
    packs: [],
    sourceIds: sourceIds ? sourceIds.size : null,
    loaded: 0,
    quarantined: [],
    idFromPath: [],
    notLoaded: []
  };

  const ready = [];
  const problems = [];

  for (const name of Object.keys(packs).sort()) {
    if (name === SOURCES_PACK) {
      report.notLoaded.push({
        pack: name,
        why: 'the source vocabulary, not records: it becomes the set of source ids the store will accept'
      });
      continue;
    }
    const found = findRecords(packs[name]);
    let taken = 0;
    for (const { path, record } of found) {
      const where = name + '.' + path;
      if (record && record.usable === false) {
        report.quarantined.push({
          where,
          id: typeof record.id === 'string' ? record.id : null,
          why: typeof record.blocking_note === 'string'
            ? record.blocking_note
            : 'the pack declares this record usable: false'
        });
        continue;
      }
      let candidate = record;
      if (!record || typeof record.id !== 'string' || record.id.trim() === '') {
        candidate = { ...record, id: where };
        report.idFromPath.push({ where, id: where });
      }
      const found2 = store.problemsWith(candidate);
      if (found2.length) {
        for (const p of found2) problems.push(where + ': ' + p);
        continue;
      }
      ready.push(candidate);
      taken++;
    }
    report.packs.push({ pack: name, found: found.length, loaded: taken });
  }

  if (problems.length) {
    throw new Error(
      'the record store refused ' + problems.length + ' record(s) and loaded nothing:\n  '
      + problems.join('\n  ')
      + '\nA record that cannot be checked is not loaded and not skipped. Fix the pack.'
    );
  }

  store.addAll(ready);
  report.loaded = store.size;
  report.ids = store.ids();
  return { store, report };
}

/**
 * Register stage 0's systems on a world that already exists. Separated from buildIsland so a tool
 * can build a world by hand, shuffle the registration order and still get the same island.
 *
 * The tide system is handed the world's resolver rather than a store, so it asks the same question
 * through the same ladder that the page asks, and there is one answer rather than two nulls.
 */
export function registerSystems(world, packs, opts = {}) {
  const order = opts.shuffle ? ['tide', 'solar'] : ['solar', 'tide'];
  const site = siteFrom(packs);
  for (const name of order) {
    if (name === 'solar') registerSolar(world, { site });
    if (name === 'tide') {
      registerTide(world, {
        pack: packs.tide,
        resolve: typeof world.resolve === 'function' ? (field) => world.resolve(field) : null
      });
    }
  }
  return world;
}

/**
 * Attach the record store, the cursor and the field resolver to a world.
 *
 * `world.cursor(mode)` is the whole of the two time contract in one call. In live and history the
 * belief cursor tracks the latest belief and cannot be pinned; only a scenario cursor may read a
 * moment that has not happened, which is what a projection is. The store's present is moved forward
 * from the world's clock and from nowhere else: there is no wall clock in simulation, and the store
 * must not have an opinion about what time it is.
 */
function attachRecords(world, store, report) {
  world.records = store;
  world.recordsLoaded = report;
  world.fields = FIELDS;

  world.cursor = (mode = MODES.LIVE, validAt = null, knownAt = null) => {
    const minute = world.clock.minuteAt();
    const present = store.present;
    if (present === null || minute > present) store.setPresent(minute);
    return store.cursor(mode, validAt === null ? minute : validAt, knownAt);
  };

  /**
   * One field, resolved down the ladder at a cursor position.
   *
   * Returns the ladder's own two shapes and adds nothing to an answer. To an unknown it adds
   * `because`: the record this file declares as the explanation, read at the same cursor, with its
   * source, its locator and the date the twin learned it. If that record is not in the store at
   * that cursor, the why says so rather than the reason silently becoming null.
   */
  world.resolve = (field, opts = {}) => {
    const cursor = world.cursor(opts.mode || MODES.LIVE, opts.validAt ?? null, opts.knownAt ?? null);
    const spec = Object.prototype.hasOwnProperty.call(FIELDS, field) ? FIELDS[field] : null;
    const result = resolveFrom(store, field, cursor);
    if (!isUnknown(result)) return result;

    const becauseId = spec && spec.because ? spec.because : null;
    const record = becauseId ? (store.read(cursor, { id: becauseId })[0] || null) : null;
    return Object.freeze({
      ...result,
      // The cursor as two integers rather than as a sentence. islandTime() on both would be two
      // string builds per resolve, and this runs every tick: a caller that wants the words calls
      // islandTime itself, which src/world/bitemporal.js exports.
      validAtMinute: cursor.validAt,
      knownAtMinute: cursor.knownAt,
      becauseId,
      because: record
        ? Object.freeze({
          id: becauseId,
          source: record.source,
          locator: record.locator,
          recordedAt: record.recordedAt,
          validFrom: record.validFrom,
          register: record.register,
          confidence: record.confidence,
          state: record.state ?? null,
          note: record.note ?? null
        })
        : null,
      why: becauseId && !record
        ? result.why + ' The record declared to explain this absence, ' + becauseId
          + ', is not in the store at this cursor, so the absence is not explained either.'
        : result.why
    });
  };

  return world;
}

/**
 * Build the island from packs already in hand. Synchronous, which is what the determinism and
 * headless instruments want: no await inside a measured loop.
 *
 * @param {Object<string, object>} packs
 * @param {object} [opts] seed, epoch, strict, now, capacity, shuffle, boot, sourceIds
 * @returns {World} booted unless opts.boot is false
 */
export function buildIslandWith(packs, opts = {}) {
  const world = new World({
    seed: opts.seed ?? 19770614,
    epoch: opts.epoch ?? DEFAULT_EPOCH,
    strict: opts.strict ?? false,
    now: opts.now ?? null,
    capacity: opts.capacity ?? 1024
  });
  world.packs = packs;
  // The store is built before any system is registered, because a system is handed the resolver at
  // registration and the resolver reads the store.
  const { store, report } = loadRecordStore(packs, { sourceIds: opts.sourceIds });
  // Fault hook: 'store-unwired'. Healthy, the store, the cursor and the field resolver are attached
  // to the world before any system is registered, and a system that wants an answer is handed the
  // resolver. Under the fault none of that happens: the store is built and then dropped, so the
  // world has no records, no cursor and no resolve, the tide system is registered with no resolver
  // and reports `answerFrom: 'no resolver was supplied'`, and the value the page shows stops being
  // the ladder's answer. That is the state board note 018 described and board note 031 closed, made
  // injectable so it cannot come back unnoticed. tools/check-wiring.mjs is the instrument.
  if (!faulty('store-unwired')) attachRecords(world, store, report);
  registerSystems(world, packs, opts);
  if (opts.boot !== false) world.boot();
  return world;
}

/**
 * Load the packs and build the island. Async because a browser reads its packs over fetch.
 *
 * @param {object} [opts] everything buildIslandWith takes, plus:
 *   packs: pack names to load, default STAGE_0_PACKS
 *   validate: check every record against the record type before booting, default true. A pack that
 *     fails is not loaded past this point: a record without provenance is not a small problem to be
 *     logged, it is the one thing this repository exists to refuse.
 * @returns {Promise<World>}
 */
export async function buildIsland(opts = {}) {
  const names = opts.packs || STAGE_0_PACKS;
  const packs = await loadPacks(names);
  if (opts.validate !== false) {
    const sourceIds = packs[SOURCES_PACK]
      ? new Set(Object.keys(packs[SOURCES_PACK]))
      : await loadSourceIds();
    const problems = validatePacks(packs, sourceIds);
    if (problems.length) {
      throw new Error('the packs did not pass the record check:\n  ' + problems.join('\n  '));
    }
  }
  return buildIslandWith(packs, opts);
}

export { DEFAULT_EPOCH, MODES };
