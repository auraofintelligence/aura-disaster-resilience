// The bitemporal spine: one store, three cursor positions.
//
// Founding prompt, stage 3, and the largest architectural correction this build makes over the
// first one. The first build bolted live time, scrubbing and projection onto a single time model,
// and paid for it in every panel that touched time: a departure board following the projected
// clock while the figure beside it stayed frozen at the last lived tick. Two panels, two notions
// of "when", no way to make them agree.
//
// The correction is not a bug fix. It is that there is only ever ONE store, and live mode, history
// mode and scenario mode are three positions of a cursor over it:
//
//     live       what is true of the island now, according to everything we have learned
//     history    what was true of the island then, according to everything we have learned
//     scenario   what a projection says, at a moment that has not happened yet
//
// and a fourth read that is not a mode but is the reason the second time axis exists at all:
//
//     as believed   what was true of the island then, according to what we believed THEN
//
// That last one is how a past decision is audited. If a decision was made on Tuesday from a figure
// that was corrected on Thursday, the only fair question is what Tuesday could see, and a store
// that overwrites on correction can no longer answer it. So nothing here is ever overwritten. A
// correction is a new belief, and the old belief keeps its window.
//
// WHAT A RECORD IS
//
// src/kernel/record.js owns the type and its validator, and this file refuses anything that fails
// it. Two times per record, four numbers:
//
//     validFrom, validTo          when it was true of the island, half open: [validFrom, validTo)
//     recordedAt, recordedUntil   when the twin believed it, half open: [recordedAt, recordedUntil)
//
// A null validTo means still true. A null recordedUntil means this is a current belief. Half open
// intervals matter: a value that ends at midnight and its replacement that starts at midnight do
// not both answer for midnight.
//
// This store adds one requirement of its own on top of the record type: every record carries a
// string `id` naming the thing it is about. Without it there is no timeline and no correction, only
// a heap. checkRecord does not ask for an id because a record can be a standalone fact in a pack;
// a record in this store cannot.
//
// COMPLEXITY, WHICH IS WHY THERE IS AN INDEX
//
//     add             O(k) worst case, O(1) in the usual case, where k is the number of beliefs
//                     already held about that one id. The bucket is kept in order by scanning back
//                     from its end, and records normally arrive in order.
//     asOf(v, k, {id})    O(k) over that one id's bucket. This is the read a panel makes.
//     asOf(v, k)          O(n) over every record, plus O(m log m) to order the m matches. A read
//                     with no id is a question about the whole island, so it costs the whole store.
//     timeline(id)    O(k)
//     supersede       O(k)
//
// The bucket by id is the index the founding prompt's panels actually need: a panel asks about one
// thing. If the unindexed read ever becomes the hot path, the next index is a bucket per field or
// an interval tree over validFrom, and neither changes the semantics above. The four interval
// bounds are parsed to integer minutes once, at add time, and never re-parsed on a read: the naive
// version in src/kernel/record.js asOf re-parses four date strings per record per read, which is
// fine for a pack of six and is not fine for a store.

import { checkRecord, toMinute } from '../kernel/record.js';
import { civilFromDays, TICKS_PER_DAY } from '../kernel/clock.js';
import { faulty } from '../kernel/faults.js';

// ---------------------------------------------------------------------------------------------
// Island time helpers
// ---------------------------------------------------------------------------------------------

const pad = (n, w = 2) => String(n).padStart(w, '0');

/**
 * An integer island minute back to the island civil time string the records are written in.
 * Integer arithmetic only, no Date, because this file lives under src/world and the contract bans
 * a wall clock there. Checked: gate/no-wallclock.
 */
export function islandTime(minute) {
  if (!Number.isInteger(minute)) {
    throw new Error('islandTime needs a whole island minute, got ' + String(minute));
  }
  const days = Math.floor(minute / TICKS_PER_DAY);
  const minOfDay = minute - days * TICKS_PER_DAY;
  const { year, month, day } = civilFromDays(days);
  return pad(year, 4) + '-' + pad(month) + '-' + pad(day)
    + 'T' + pad(Math.floor(minOfDay / 60)) + ':' + pad(minOfDay % 60) + '+10:00';
}

/**
 * Accept either an island time string or an integer minute, and refuse anything else by name, so a
 * caller who passed the wrong argument learns which one.
 */
export function minuteOf(value, what = 'time') {
  if (typeof value === 'number') {
    if (!Number.isInteger(value)) {
      throw new Error(what + ' must be a whole island minute, got ' + String(value));
    }
    return value;
  }
  const m = toMinute(value);
  if (m === null) {
    throw new Error(what + ' is not an island time: ' + JSON.stringify(value)
      + '. Island times look like 2026-08-19T12:00+10:00, or 2026-08-19 for a whole day.');
  }
  return m;
}

// ---------------------------------------------------------------------------------------------
// The three cursor modes, as a named type
// ---------------------------------------------------------------------------------------------

/**
 * The three positions, named once so the interface cannot mix them by writing 'History' somewhere
 * and comparing it to 'history' somewhere else. The first build's time bugs were not arithmetic;
 * they were two parts of one screen disagreeing about which question they were answering.
 */
export const MODES = Object.freeze({ LIVE: 'live', HISTORY: 'history', SCENARIO: 'scenario' });

export const MODE_LIST = Object.freeze([MODES.LIVE, MODES.HISTORY, MODES.SCENARIO]);

/** The labels the two past reads carry, so a caller cannot confuse one for the other. */
export const READS = Object.freeze({
  HISTORY: 'history: true then, believed now',
  AS_BELIEVED: 'as believed: true then, believed then'
});

/**
 * A cursor is the whole of what a read needs: a mode, a point on the valid time axis, and a point
 * on the belief axis.
 *
 * The rules, which are the reason this is a class and not an object literal:
 *
 *  - In LIVE, knownAt tracks the latest belief. A live reading of a stale belief is not live, it is
 *    an audit, and BitemporalStore.cursor refuses to build one.
 *  - In HISTORY, knownAt also tracks the latest belief: history is what was true then, judged with
 *    everything we know now. Replaying an old belief is asBelieved, and it is a different read.
 *  - Only in SCENARIO may validAt run ahead of the present, which is where every record's validFrom
 *    already sits. Live mode answering for a moment that has not happened is exactly the failure
 *    the source ladder exists to prevent, so the cursor refuses it before the ladder is even asked.
 *
 * `present` is supplied by the world, not read from a clock: the store has no idea what time it is
 * and must not, because a wall clock in simulation is banned and would not be deterministic anyway.
 * A cursor built without a present cannot check the rule that needs one, and says so in
 * `presentKnown` rather than pretending it checked.
 */
export class Cursor {
  constructor({ mode, validAt, knownAt, present = null }) {
    if (!MODE_LIST.includes(mode)) {
      throw new Error('unknown cursor mode ' + JSON.stringify(mode)
        + '. The three modes are ' + MODE_LIST.join(', ') + '.');
    }
    const v = minuteOf(validAt, 'validAt');
    const k = minuteOf(knownAt, 'knownAt');
    const p = present === null ? null : minuteOf(present, 'present');

    if (p !== null && mode === MODES.LIVE && v > p) {
      throw new Error('a live cursor may not run ahead of the present: validAt ' + islandTime(v)
        + ' is after ' + islandTime(p) + '. A moment that has not happened is a '
        + MODES.SCENARIO + ', not a live reading.');
    }
    if (p !== null && mode === MODES.HISTORY && v >= p) {
      throw new Error('a history cursor reads the past: validAt ' + islandTime(v)
        + ' is not before the present ' + islandTime(p) + '. Use ' + MODES.LIVE + ' for now, or '
        + MODES.SCENARIO + ' for a moment that has not happened.');
    }

    this.mode = mode;
    this.validAt = v;
    this.knownAt = k;
    this.present = p;
    this.presentKnown = p !== null;
    this.ahead = p !== null && v > p;
    Object.freeze(this);
  }

  /** The island times, for a panel that has to show which question it answered. */
  describe() {
    return this.mode + ' cursor: valid at ' + islandTime(this.validAt)
      + ', known at ' + islandTime(this.knownAt)
      + (this.presentKnown ? ', present ' + islandTime(this.present) : ', present not supplied');
  }

  toString() {
    return this.describe();
  }
}

// ---------------------------------------------------------------------------------------------
// The store
// ---------------------------------------------------------------------------------------------

/** A stored record and its four interval bounds as integer minutes, parsed once. */
function bound(record) {
  return {
    id: record.id,
    record,
    vf: toMinute(record.validFrom),
    vt: record.validTo === null ? Infinity : toMinute(record.validTo),
    ra: toMinute(record.recordedAt),
    ru: record.recordedUntil === null ? Infinity : toMinute(record.recordedUntil)
  };
}

/**
 * A total order over stored records, so the same set of matches comes back in the same order every
 * run whether it was read through the id bucket or by scanning everything. Contract section 2:
 * iteration order is explicit, never incidental.
 */
function compareStored(a, b) {
  if (a.id !== b.id) return a.id < b.id ? -1 : 1;
  if (a.vf !== b.vf) return a.vf - b.vf;
  if (a.ra !== b.ra) return a.ra - b.ra;
  return 0;
}

function freezeReading(readAs, validAt, knownAt, records) {
  return Object.freeze({
    readAs,
    validAt: islandTime(validAt),
    knownAt: islandTime(knownAt),
    validAtMinute: validAt,
    knownAtMinute: knownAt,
    records: Object.freeze(records)
  });
}

export class BitemporalStore {
  #byId = new Map();
  #all = [];
  #latestKnown = null;
  #present = null;
  #sourceIds = null;

  /**
   * @param {object} [opts]
   * @param {Set<string>} [opts.sourceIds] ids from data/_sources.json. When given, a record whose
   *   source is not one of them is refused, because a source that is free text cannot be opened and
   *   checked. Omit it only for fixtures, which describe nothing real.
   */
  constructor(opts = {}) {
    if (opts.sourceIds !== undefined && opts.sourceIds !== null) {
      if (!(opts.sourceIds instanceof Set)) {
        throw new Error('sourceIds must be a Set of ids from data/_sources.json');
      }
      this.#sourceIds = opts.sourceIds;
    }
  }

  get size() {
    return this.#all.length;
  }

  /** Every id the store holds a belief about, in order. */
  ids() {
    return [...this.#byId.keys()].sort();
  }

  /** The latest moment the twin learned anything, or null on an empty store. */
  latestKnownAt() {
    return this.#latestKnown;
  }

  /**
   * The island's present, as an integer minute. Defaults to the latest recordedAt, because the twin
   * cannot have learned something after now. The world moves it forward with setPresent from the
   * simulation clock; nothing here reads a clock of its own.
   */
  get present() {
    return this.#present;
  }

  setPresent(value) {
    const p = minuteOf(value, 'present');
    if (this.#present !== null && p < this.#present) {
      throw new Error('the present does not run backwards: ' + islandTime(p)
        + ' is before the present already set, ' + islandTime(this.#present)
        + '. To read an earlier moment use a ' + MODES.HISTORY + ' cursor.');
    }
    if (this.#latestKnown !== null && p < this.#latestKnown) {
      throw new Error('the present may not be before the last thing the twin learned: '
        + islandTime(p) + ' is before ' + islandTime(this.#latestKnown) + '.');
    }
    this.#present = p;
    return this.#present;
  }

  // ------------------------------------------------------------------------------------- writing

  /**
   * Validate a record for this store without adding it. Returns a list of problems, empty when
   * sound, so a loader can report every bad record in a pack rather than dying on the first.
   */
  problemsWith(record) {
    const where = record && typeof record.id === 'string' && record.id ? record.id : 'record';
    const problems = checkRecord(record, { sourceIds: this.#sourceIds, where });
    if (problems.length) return problems;
    if (typeof record.id !== 'string' || record.id.trim() === '') {
      return [where + ': needs a string id naming the thing this record is about. Without one there '
        + 'is no timeline and no correction, only a heap.'];
    }
    if (record.id !== record.id.trim()) {
      return [where + ': id has leading or trailing space, which makes two ids that look the same'];
    }
    return [];
  }

  /**
   * Add one record. Refuses anything checkRecord rejects, and anything without an id.
   *
   * The stored record is a frozen shallow copy. Freezing is not decoration: this store's whole
   * claim is that nothing is ever overwritten, and a claim that depends on nobody reaching in is
   * not a claim, it is a hope.
   *
   * @returns {object} the frozen stored record
   */
  add(record) {
    const problems = this.problemsWith(record);
    if (problems.length) {
      throw new Error('BitemporalStore refused a record:\n  ' + problems.join('\n  '));
    }
    const frozen = Object.freeze({ ...record });
    const held = bound(frozen);

    let bucket = this.#byId.get(held.id);
    if (!bucket) {
      bucket = [];
      this.#byId.set(held.id, bucket);
    }
    // Scan back from the end. Records normally arrive in belief order, so this is O(1) in the
    // usual case and O(k) in the worst.
    let i = bucket.length;
    while (i > 0 && compareStored(bucket[i - 1], held) > 0) i--;
    bucket.splice(i, 0, held);

    this.#all.push(held);
    if (this.#latestKnown === null || held.ra > this.#latestKnown) this.#latestKnown = held.ra;
    if (this.#present === null || this.#latestKnown > this.#present) this.#present = this.#latestKnown;
    return frozen;
  }

  /**
   * Add many. Every record is validated BEFORE any is added, so a pack with one bad record leaves
   * the store empty rather than half loaded. A half loaded store is the worst of the three
   * outcomes: it looks like it worked.
   */
  addAll(records) {
    if (!Array.isArray(records)) throw new Error('addAll needs an array of records');
    const problems = [];
    records.forEach((rec, i) => {
      for (const p of this.problemsWith(rec)) problems.push('[' + i + '] ' + p);
    });
    if (problems.length) {
      throw new Error('BitemporalStore refused ' + problems.length + ' problem(s) and added nothing:\n  '
        + problems.join('\n  '));
    }
    return records.map((rec) => this.add(rec));
  }

  /**
   * A correction: close the old belief and open a new one. Nothing is deleted and no value is
   * rewritten. The only field that changes on the old record is recordedUntil, which is the field
   * whose whole job is to say when the twin stopped believing it, and even that is done by
   * replacing the frozen record rather than reaching into it.
   *
   * Only beliefs whose VALID interval overlaps the new record's are closed, so correcting Tuesday's
   * figure does not silently close Wednesday's.
   *
   * @returns {{closed: object[], added: object}} the records as they now stand
   */
  supersede(id, newRecord) {
    if (typeof id !== 'string' || id.trim() === '') throw new Error('supersede needs the id of the thing being corrected');
    const bucket = this.#byId.get(id);
    if (!bucket || bucket.length === 0) {
      throw new Error('supersede: the store has never held a belief about ' + JSON.stringify(id)
        + '. A first belief is add(), not supersede().');
    }
    if (!newRecord || typeof newRecord !== 'object') throw new Error('supersede needs the new record');
    if (newRecord.id !== id) {
      throw new Error('supersede: the new record is about ' + JSON.stringify(newRecord.id)
        + ' but is being used to correct ' + JSON.stringify(id));
    }
    if (newRecord.recordedUntil !== null) {
      throw new Error('supersede: a correction is opened, not pre closed. recordedUntil must be null, got '
        + JSON.stringify(newRecord.recordedUntil));
    }
    const problems = this.problemsWith(newRecord);
    if (problems.length) {
      throw new Error('BitemporalStore refused the correction:\n  ' + problems.join('\n  '));
    }

    const at = toMinute(newRecord.recordedAt);
    const nvf = toMinute(newRecord.validFrom);
    const nvt = newRecord.validTo === null ? Infinity : toMinute(newRecord.validTo);

    const open = bucket.filter((h) => h.ru === Infinity);
    for (const h of open) {
      if (at < h.ra) {
        throw new Error('supersede: the correction was recorded at ' + islandTime(at)
          + ', before the belief it corrects was recorded at ' + islandTime(h.ra)
          + '. The twin cannot learn a correction before it learned the thing.');
      }
    }

    // Fault hook: 'correction-overwrites'. Healthy, the lines below close the overlapping belief
    // and then open a new one, so both stay readable and the timeline shows a correction as two
    // rows. Under the fault the old belief is replaced in its own slot by the new one and nothing
    // is added, which is the single time model the first build carried: a correction erases what
    // the twin used to believe, and with it every audit of a decision made before it.
    if (faulty('correction-overwrites')) {
      let overwritten = null;
      for (const h of open) {
        if (!(h.vf < nvt && nvf < h.vt)) continue;
        overwritten = Object.freeze({ ...newRecord });
        h.record = overwritten;
        h.vf = nvf;
        h.vt = nvt;
        h.ra = at;
      }
      return { closed: [], added: overwritten };
    }

    const closed = [];
    for (const h of open) {
      const overlaps = h.vf < nvt && nvf < h.vt;
      if (!overlaps) continue;
      const replacement = Object.freeze({ ...h.record, recordedUntil: islandTime(at) });
      h.record = replacement;
      h.ru = at;
      closed.push(replacement);
    }

    const added = this.add(newRecord);
    return { closed, added };
  }

  // ------------------------------------------------------------------------------------- reading

  /**
   * The two cursor read. Everything true of the island at validAt, according to what the twin
   * believed at knownAt.
   *
   * @param {number|string} validAt
   * @param {number|string} knownAt
   * @param {object} [opts]
   * @param {string} [opts.id] narrow to one thing. O(k) instead of O(n), same answer.
   */
  asOf(validAt, knownAt, opts = {}) {
    const v = minuteOf(validAt, 'validAt');
    const k = minuteOf(knownAt, 'knownAt');

    // Fault hook: 'frozen-clock'. Healthy, the read uses the cursor's validAt exactly as given.
    // Under the fault it ignores validAt and reads at the last lived minute instead, which is the
    // first build's exact bug: one panel followed the projected clock while the panel beside it
    // stayed at the last lived tick, and neither of them was wrong on its own terms.
    const at = faulty('frozen-clock') ? this.#present : v;

    const pool = opts.id === undefined ? this.#all : (this.#byId.get(opts.id) || []);
    const hits = [];
    for (const h of pool) {
      if (h.vf <= at && at < h.vt && h.ra <= k && k < h.ru) hits.push(h);
    }
    hits.sort(compareStored);
    return hits.map((h) => h.record);
  }

  /**
   * Live mode's read: what is true at validAt according to the latest belief. The knownAt cursor
   * tracks the newest thing the twin has learned, always, which is what makes live live.
   */
  current(validAt, opts = {}) {
    const k = this.#requireBelief('current');
    return this.asOf(validAt, k, opts);
  }

  /**
   * History mode's read. The same two cursor positions as current, and a different question, so it
   * comes back labelled: what was true THEN, judged with everything we know NOW. A caller that
   * wanted the other question wanted asBelieved, and the label is there so the two cannot be
   * swapped by accident in a panel.
   */
  history(validAt, opts = {}) {
    const k = this.#requireBelief('history');
    const v = minuteOf(validAt, 'validAt');
    return freezeReading(READS.HISTORY, v, k, this.asOf(v, k, opts));
  }

  /**
   * Replaying a past belief, which is how a decision made at the time is audited: what was true
   * then, according to what the twin believed then. This is the read that a single time store
   * cannot answer at all, and the reason the second axis exists.
   */
  asBelieved(validAt, knownAt, opts = {}) {
    const v = minuteOf(validAt, 'validAt');
    const k = minuteOf(knownAt, 'knownAt');
    return freezeReading(READS.AS_BELIEVED, v, k, this.asOf(v, k, opts));
  }

  /** Read through a Cursor, which is the shape live, history and scenario mode all share. */
  read(cursor, opts = {}) {
    if (!(cursor instanceof Cursor)) {
      throw new Error('read needs a Cursor. Build one with store.cursor(MODES.LIVE, validAt).');
    }
    return this.asOf(cursor.validAt, cursor.knownAt, opts);
  }

  /**
   * Every belief the twin has held about one thing, oldest belief first. A correction shows here as
   * two rows, not as one row that changed.
   */
  timeline(id) {
    const bucket = this.#byId.get(id);
    if (!bucket) return [];
    return [...bucket]
      .sort((a, b) => (a.ra !== b.ra ? a.ra - b.ra : a.vf - b.vf))
      .map((h) => h.record);
  }

  /**
   * Build a cursor against this store, with the mode rules enforced rather than documented.
   *
   * @param {string} mode one of MODES
   * @param {number|string} validAt
   * @param {number|string} [knownAt] scenario only. LIVE and HISTORY always track the latest belief
   *   and refuse an explicit knownAt that is not it, because a live panel showing a stale belief is
   *   the failure this whole file exists to prevent.
   */
  cursor(mode, validAt, knownAt = null) {
    if (!MODE_LIST.includes(mode)) {
      throw new Error('unknown cursor mode ' + JSON.stringify(mode)
        + '. The three modes are ' + MODE_LIST.join(', ') + '.');
    }
    const latest = this.#requireBelief('cursor');
    let k = latest;
    if (mode === MODES.SCENARIO) {
      k = knownAt === null ? latest : minuteOf(knownAt, 'knownAt');
    } else if (knownAt !== null) {
      const asked = minuteOf(knownAt, 'knownAt');
      if (asked !== latest) {
        throw new Error('a ' + mode + ' cursor tracks the latest belief, ' + islandTime(latest)
          + ', and cannot be pinned to ' + islandTime(asked)
          + '. To replay a past belief use asBelieved, which is an audit rather than a mode.');
      }
    }
    return new Cursor({ mode, validAt, knownAt: k, present: this.#present });
  }

  #requireBelief(what) {
    if (this.#latestKnown === null) {
      throw new Error(what + ': the store holds no record, so there is no belief for a cursor to track');
    }
    return this.#latestKnown;
  }
}
