// The tunnel network, and the spoil, which is the same thing counted twice.
//
// The owner's framing, and the reason this file computes spoil rather than treating it as waste:
// "the spoil is the building, so the two largest numbers, digging and materials, are set against
// each other instead of added" (sandworm-subterranean-systems, building pages). A tunnel is not a
// hole that produces a disposal problem. It is how you get the material for the bus shelters, the
// artificial reefs, the community buildings, the sand courts and the sand batteries.
//
// Parameters are his, from Sandworm, and are not to be replaced with remembered figures:
//   bore diameter   0.6 m to 5 m, default 1.5 m
//   advance rate    up to 1,250 m per week
//   forming factor  1.15
//
// The forming factor is why bored volume and spoil volume are different numbers. Sand in the ground
// is packed; sand out of the ground is not. 1.15 is his figure and it is applied once, here, so no
// other file has to remember to apply it.

export const SANDWORM = {
  boreDefaultM: 1.5,
  boreMinM: 0.6,
  boreMaxM: 5,
  advanceMetresPerWeek: 1250,
  formingFactor: 1.15,
  source: 'sandworm-subterranean-systems, reefs and calculator pages, read 19 August 2026'
};

// Bore, and what a bore is actually for.
//
// The owner's correction, 19 August 2026: "a 5m bore is what idiot humans do now. there is no reason
// why a 5m bore should be done unless for transporting massive machinery. if you can sit 1-2 people
// abreast comfortably that is ideal and that is 2m-3m bore like boring company or smaller."
//
// This file previously invited a 5 m bore for people, which is conventional metro practice and is
// the wrong unit here. A pod carrying one or two people seated does not need the clearance a train
// needs. His declared default of 1.5 m was the people figure all along.
//
// The consequence is the important part, and it runs opposite to intuition. Spoil goes as the square
// of the bore, so for a fixed quantity of material a smaller bore buys network by the square of the
// ratio. The same sand that yields 45 km of 5 m tunnel yields 182 km at 2.5 m and 505 km at 1.5 m,
// against an island with 591 km of road. Small bore does not reduce the ambition. It multiplies the
// number of places the network reaches.
//
// So the material is a by-product and never a reason to bore wider. Boring wide to harvest sand is
// the megaproject move: most concrete, most contract, fewest destinations.
export const BORE_BANDS = [
  { m: 1.5, seats: 'one person, single file', note: 'the declared default' },
  { m: 2.0, seats: 'one to two abreast' },
  { m: 2.5, seats: 'two abreast' },
  { m: 3.0, seats: 'two abreast, comfortably', note: 'the top of the useful range for people' },
  { m: 5.0, seats: 'machinery, not people', note: 'only where large plant has to pass' }
];

/** For a fixed spoil budget, how much network does a given bore buy? */
export function networkForSpoil(spoilM3, boreM) {
  const area = Math.PI * (boreM / 2) ** 2;
  return spoilM3 / (area * SANDWORM.formingFactor);
}

// Real coordinates, OpenStreetMap place nodes for this island, fetched 19 August 2026.
// These are positions, not alignments. A tunnel between two of them is longer than the line
// between them, and the model says so rather than pretending otherwise.
export const PLACES = {
  dunwich: { name: 'Dunwich', lat: -27.4948714, lon: 153.4083282, osm: 'node place=village' },
  amityPoint: { name: 'Amity Point', lat: -27.4013942, lon: 153.4411291, osm: 'node place=village' },
  pointLookout: { name: 'Point Lookout', lat: -27.4313049, lon: 153.5332366, osm: 'node place=town' }
};

const R = 6371008.8; // metres, IUGG mean Earth radius
const rad = (d) => (d * Math.PI) / 180;

/** Great-circle distance in metres. */
export function distanceM(a, b) {
  const dLat = rad(b.lat - a.lat);
  const dLon = rad(b.lon - a.lon);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/**
 * A segment of the network. `lengthM` is the bored length, which is the alignment and not the
 * straight line. `sinuosity` records how much longer the alignment is than the line between its
 * ends, so a straight-line estimate is never mistaken for a route.
 */
export function segment({ id, from, to, boreM = SANDWORM.boreDefaultM, sinuosity = 1, purpose = 'transport', lengthM = null }) {
  if (boreM < SANDWORM.boreMinM || boreM > SANDWORM.boreMaxM) {
    throw new Error(`bore ${boreM} m is outside the declared range ${SANDWORM.boreMinM} to ${SANDWORM.boreMaxM} m`);
  }
  const straightM = from && to ? distanceM(from, to) : null;
  const bored = lengthM !== null ? lengthM : straightM === null ? null : straightM * sinuosity;
  if (bored === null) throw new Error(`segment ${id} needs either two ends or an explicit lengthM`);
  const area = Math.PI * (boreM / 2) ** 2;
  const boredVolumeM3 = area * bored;
  return {
    id, purpose, boreM, sinuosity,
    fromName: from ? from.name : null,
    toName: to ? to.name : null,
    straightLineM: straightM,
    lengthM: bored,
    crossSectionM2: area,
    boredVolumeM3,
    spoilVolumeM3: boredVolumeM3 * SANDWORM.formingFactor,
    boringWeeks: bored / SANDWORM.advanceMetresPerWeek
  };
}

/** Sum a set of segments. Machines bore in sequence unless told otherwise, so weeks add. */
export function network(segments, { machines = 1 } = {}) {
  const lengthM = segments.reduce((a, s) => a + s.lengthM, 0);
  const spoilVolumeM3 = segments.reduce((a, s) => a + s.spoilVolumeM3, 0);
  const boringWeeks = segments.reduce((a, s) => a + s.boringWeeks, 0) / machines;
  return {
    segments,
    machines,
    lengthM,
    lengthKm: lengthM / 1000,
    boredVolumeM3: segments.reduce((a, s) => a + s.boredVolumeM3, 0),
    spoilVolumeM3,
    boringWeeks,
    boringYears: boringWeeks / 52
  };
}

// Mind's eye. The owner's house rule for public copy: every macro number gets something a person
// can picture. These are conversions, not claims about what the spoil becomes.
export const PICTURE = {
  olympicPoolM3: 2500,        // 50 x 25 x 2 m, the standard comparison
  shippingContainer40ftM3: 67,
  concreteTruckM3: 8,
  standardTipperTruckM3: 10
};

export function picture(volumeM3) {
  return {
    olympicPools: volumeM3 / PICTURE.olympicPoolM3,
    shippingContainers: volumeM3 / PICTURE.shippingContainer40ftM3,
    tipperTruckLoads: volumeM3 / PICTURE.standardTipperTruckM3
  };
}
