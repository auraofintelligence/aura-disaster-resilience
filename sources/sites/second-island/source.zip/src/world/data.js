// Loading the packs, in Node and in the browser, from the same code.
//
// The whole island has to run headless in Node, because that is what makes determinism testable at
// all, and it has to run in a page, because that is where a person looks at it. So the loader has
// one job with two backends: node:fs when there is a process, fetch when there is not. Everything
// above this line sees one async function and never learns which backend answered.
//
// Paths resolve from `import.meta.url`, not from a working directory and not from the page's path.
// A tool run from tools/, a tool run from the repository root and a page served at any depth all
// have to find the same data/ directory, and the module's own URL is the only thing all three agree
// on.
//
// Nothing here touches the network beyond the origin the module was loaded from. A pack is a
// committed file, checked in and reviewable. If a pack ever needs a live feed, that is a different
// lane with a different honesty rule, and it does not arrive by widening this function.

import { checkRecord, REQUIRED_FIELDS } from '../kernel/record.js';

/** true in Node, false in a browser. `globalThis.process` alone is claimed by some page shims. */
export const IS_NODE = !!(globalThis.process && globalThis.process.versions && globalThis.process.versions.node);

/** The data directory, as a URL, resolved from this module. */
export const DATA_URL = new URL('../../data/', import.meta.url);

export const SOURCES_PACK = '_sources';

/**
 * Fields whose presence means "this object is meant to be a record". Deliberately not `source`:
 * a record that forgot its source is exactly the record the gate has to catch, so the marker set
 * has to be things a non-record is unlikely to carry and a broken record still will.
 */
const RECORD_MARKERS = ['register', 'recordedAt', 'recordedUntil', 'validFrom', 'validTo'];

async function readText(url) {
  if (IS_NODE) {
    const { readFileSync } = await import('node:fs');
    return readFileSync(url, 'utf8');
  }
  const res = await fetch(url);
  if (!res.ok) throw new Error(`pack fetch failed: ${url} returned ${res.status}`);
  return res.text();
}

/**
 * Load one pack by name. `tide` reads data/tide.json.
 * A missing or malformed pack throws with the path in the message: a pack that silently becomes an
 * empty object is a system that silently becomes wrong.
 */
export async function loadPack(name) {
  const url = new URL(name + '.json', DATA_URL);
  let text;
  try {
    text = await readText(url);
  } catch (err) {
    throw new Error(`could not read pack ${name} at ${url.href}: ${err.message}`);
  }
  try {
    return JSON.parse(text);
  } catch (err) {
    throw new Error(`pack ${name} at ${url.href} is not valid JSON: ${err.message}`);
  }
}

/**
 * Load several packs at once.
 * @param {string[]} names
 * @returns {Promise<Object<string, object>>} pack name to parsed JSON
 */
export async function loadPacks(names) {
  if (!Array.isArray(names)) throw new Error('loadPacks takes an array of pack names');
  const out = {};
  // Sorted, so two runs load in the same order and a failure reports the same pack first.
  const sorted = [...names].sort();
  for (const name of sorted) out[name] = await loadPack(name);
  return out;
}

/**
 * The source vocabulary: data/_sources.json is a flat map of source id to a description of the
 * source. Every record's `source` field is one of these ids and never free text, because an id
 * resolves to something a critic can open and a sentence does not.
 */
export async function loadSources() {
  const sources = await loadPack(SOURCES_PACK);
  if (!sources || typeof sources !== 'object' || Array.isArray(sources)) {
    throw new Error('data/_sources.json must be an object of source id to source description');
  }
  return sources;
}

export async function loadSourceIds() {
  return new Set(Object.keys(await loadSources()));
}

/** Every object in a pack that is meant to be a record, with the path that found it. */
export function findRecords(pack, path = '') {
  const found = [];
  const walk = (node, at) => {
    if (Array.isArray(node)) {
      node.forEach((item, i) => walk(item, `${at}[${i}]`));
      return;
    }
    if (!node || typeof node !== 'object') return;
    if (RECORD_MARKERS.some((f) => f in node)) {
      found.push({ path: at || '(root)', record: node });
    }
    for (const key of Object.keys(node).sort()) walk(node[key], at ? `${at}.${key}` : key);
  };
  walk(pack, path);
  return found;
}

/**
 * Check every record in a pack against the record type in src/kernel/record.js.
 *
 * @param {object} pack parsed pack JSON
 * @param {object} [opts]
 * @param {Set<string>} [opts.sourceIds] from loadSourceIds(). When given, a record whose source is
 *   not a known id is a problem, which is the check that stops `source` drifting back to free text.
 * @param {string} [opts.name] pack name, for the message
 * @returns {string[]} problems, empty when the pack is sound
 */
export function validateRecords(pack, opts = {}) {
  const label = opts.name ? opts.name : 'pack';
  const problems = [];
  const records = findRecords(pack);
  if (records.length === 0) problems.push(`${label}: no records found, so nothing was checked`);
  for (const { path, record } of records) {
    problems.push(...checkRecord(record, { sourceIds: opts.sourceIds, where: `${label}.${path}` }));
  }
  return problems;
}

/** Check a whole set of loaded packs. Returns problems across all of them, in pack name order. */
export function validatePacks(packs, sourceIds) {
  const problems = [];
  for (const name of Object.keys(packs).sort()) {
    if (name === SOURCES_PACK) continue;
    problems.push(...validateRecords(packs[name], { sourceIds, name }));
  }
  return problems;
}

export { REQUIRED_FIELDS };
