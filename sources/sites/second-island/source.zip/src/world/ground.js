// Holding wet sand open long enough to cast a wall in it.
//
// The owner's correction, 19 August 2026: "speed of tunnelling doesnt matter to me. the tunnelling
// is arbitrary. the wall casting and energy to freeze the wet sand or hold the sand in place when
// all it wants to do is collapse is the objective function."
//
// So this file replaces the wrong objective. src/world/tunnels.js was built around advance rate and
// weeks to completion, which is the metric for boring rock. In saturated sand the machine is not the
// constraint. The ground is. It wants to close, and every metre has to be supported while it is open
// and lined before the support comes off.
//
// The three things that scale differently, which is why the earlier spoil-budget comparison was
// measuring the wrong side of the problem:
//
//   spoil            goes as D squared     a by-product
//   wall area        goes as D             the objective function
//   ground to hold   goes as D, roughly    the other half of the objective function
//
// For a fixed length of network, halving the bore quarters the spoil and only halves the wall. For a
// fixed quantity of spoil, a smaller bore buys more network and therefore MORE wall, not less. The
// two framings point opposite ways and this one is the one the owner named.
//
// Nothing here decides between freezing and pressure support. Both are modelled because he named
// both, and the inputs that separate them are site facts this repository does not hold.

// Physics. These are properties of water and quartz, not of this island, and they are not estimates.
export const PHYSICS = {
  latentHeatFusionWater_kJ_per_kg: 334,
  specificHeatWater_kJ_per_kgK: 4.18,
  specificHeatIce_kJ_per_kgK: 2.09,
  specificHeatQuartz_kJ_per_kgK: 0.83,
  densityWater_kg_per_m3: 1000,
  densityQuartzSolid_kg_per_m3: 2650
};

// Site facts this repository does not have. Every one of them changes the answer, and the first
// three change it by more than any engineering choice does. They are listed here rather than given
// placeholder values, because a placeholder in this file would be a fabricated foundation for every
// number downstream of it.
export const UNKNOWN_SITE_INPUTS = [
  { id: 'porosity', what: 'void fraction of the sand, which sets how much water there is to freeze',
    typicalRangeForDuneSand: [0.30, 0.45], note: 'NOT measured for this island' },
  { id: 'saturation', what: 'how much of that void is water rather than air, which depends on depth below the water table' },
  { id: 'waterTableDepth', what: 'above it the sand is damp and stands up; below it, it does not' },
  { id: 'groundTemperature', what: 'the sensible heat to remove before any ice forms' },
  { id: 'hydraulicConductivity', what: 'the number the freeze question turns on. With 42 m of head over about 5,500 m the gradient is 0.0076, which gives seepage from 0.02 m a day in very fine sand to 2.18 in gravel. A freeze is straightforward below about 1 m a day, so conductivity decides it and nothing else does' },
  { id: 'grading', what: 'grain size distribution, which decides whether the ground can be grouted at all' }
];

/**
 * Wall area and lining volume per metre of tunnel. This is the objective function's first half and
 * it is pure geometry, so it has no unknowns in it.
 */
export function wallPerMetre(boreM, liningThicknessM) {
  const circumference = Math.PI * boreM;
  return {
    boreM,
    liningThicknessM,
    wallAreaM2PerM: circumference,
    liningVolumeM3PerM: Math.PI * ((boreM / 2 + liningThicknessM) ** 2 - (boreM / 2) ** 2),
    spoilM3PerM: Math.PI * (boreM / 2) ** 2 * 1.15
  };
}

/**
 * Energy to freeze an annulus of saturated sand around the bore, per metre of tunnel.
 *
 * @param boreM              bore diameter
 * @param freezeThicknessM   radial thickness of the frozen ring
 * @param porosity           void fraction, 0 to 1. NOT known for this island.
 * @param saturation         fraction of void that is water, 0 to 1
 * @param groundTempC        starting ground temperature
 * @param targetTempC        temperature the frozen ring is taken to
 * @param copRefrigeration   coefficient of performance of the plant. Thermodynamic work is the heat
 *                           removed divided by this, and at these temperatures it is well below 1
 *                           for a single stage, so it is an input rather than an assumption.
 */
export function freezeEnergyPerMetre({
  boreM, freezeThicknessM, porosity, saturation = 1,
  groundTempC, targetTempC, copRefrigeration
}) {
  const rOuter = boreM / 2 + freezeThicknessM;
  const rInner = boreM / 2;
  const annulusM3PerM = Math.PI * (rOuter ** 2 - rInner ** 2);

  const waterM3 = annulusM3PerM * porosity * saturation;
  const waterKg = waterM3 * PHYSICS.densityWater_kg_per_m3;
  const solidM3 = annulusM3PerM * (1 - porosity);
  const solidKg = solidM3 * PHYSICS.densityQuartzSolid_kg_per_m3;

  const coolWater = waterKg * PHYSICS.specificHeatWater_kJ_per_kgK * Math.max(0, groundTempC - 0);
  const freeze = waterKg * PHYSICS.latentHeatFusionWater_kJ_per_kg;
  const coolIce = waterKg * PHYSICS.specificHeatIce_kJ_per_kgK * Math.max(0, 0 - targetTempC);
  const coolSolid = solidKg * PHYSICS.specificHeatQuartz_kJ_per_kgK * Math.max(0, groundTempC - targetTempC);

  const heatRemoved_kJ = coolWater + freeze + coolIce + coolSolid;
  const work_kJ = copRefrigeration ? heatRemoved_kJ / copRefrigeration : null;

  return {
    annulusM3PerM,
    waterKgPerM: waterKg,
    breakdown_kJ_per_m: {
      coolingWaterToZero: coolWater,
      latentHeatOfFusion: freeze,
      coolingIceToTarget: coolIce,
      coolingTheSandItself: coolSolid
    },
    latentShareOfHeat: freeze / heatRemoved_kJ,
    heatRemoved_kJ_per_m: heatRemoved_kJ,
    heatRemoved_kWh_per_m: heatRemoved_kJ / 3600,
    plantWork_kWh_per_m: work_kJ === null ? null : work_kJ / 3600,
    holdingLoadNote: 'This is the energy to form the ring once. Holding it costs again, continuously, '
      + 'against heat conducted in from the surrounding ground and carried in by any groundwater '
      + 'movement, until the lining is cast and cured and the ring can be let go. Hold time and '
      + 'groundwater velocity are not in this repository and the holding load cannot be computed '
      + 'without them.'
  };
}

/**
 * The other way he named: hold the sand in place rather than freeze it. Face and radial support by
 * pressure, which is what a closed-face machine does, is a pumping problem rather than a
 * refrigeration one. The support pressure has to at least balance the water pressure at depth plus
 * the earth pressure, so it is set by how deep the tunnel is below the water table.
 */
export function supportPressurePerMetre({ boreM, depthBelowWaterTableM, earthPressureCoefficient }) {
  const waterPressure_kPa = PHYSICS.densityWater_kg_per_m3 * 9.80665 * depthBelowWaterTableM / 1000;
  const faceAreaM2 = Math.PI * (boreM / 2) ** 2;
  return {
    boreM,
    depthBelowWaterTableM,
    waterPressure_kPa,
    earthPressureCoefficient,
    minimumFacePressure_kPa: earthPressureCoefficient === undefined ? null
      : waterPressure_kPa * (1 + earthPressureCoefficient),
    faceAreaM2,
    faceForce_kN: earthPressureCoefficient === undefined ? null
      : waterPressure_kPa * (1 + earthPressureCoefficient) * faceAreaM2,
    note: 'Pressure support has no phase change in it, so its energy is compression and pumping and '
      + 'is orders below a freeze for the same ground. What it costs instead is that the pressure '
      + 'must never lapse, and the earth pressure coefficient for this island sand is not known here.'
  };
}

/**
 * Advance rate, which in sand is not a cutting rate.
 *
 * The owner, 19 August 2026: "you can technically tunnel at the pace a vacuum pump can suck the
 * sand out, or a conveyor can remove it."
 *
 * There is nothing to grind. Advance is spoil removal throughput divided by cross-section, so the
 * same pump drives a small bore far faster than a large one, by the square of the ratio. And that
 * is exactly why the wall is the objective function: removal is cheap enough to outrun the ability
 * to line what has been opened. The binding rate is whichever of the two is slower, and in sand it
 * is the lining.
 *
 * @param boreM
 * @param removalRateM3PerHour   what the vacuum or conveyor moves
 * @param liningRateM2PerHour    what the wall casting achieves, in square metres of wall
 * @param hoursPerWeek
 */
export function advance({ boreM, removalRateM3PerHour, liningRateM2PerHour, hoursPerWeek = 168 }) {
  const areaM2 = Math.PI * (boreM / 2) ** 2;
  const wallM2PerM = Math.PI * boreM;
  const loose = areaM2 * 1.15; // spoil bulks, and the pump moves loose sand not packed sand

  const removalLimitedMPerHour = removalRateM3PerHour === undefined ? null : removalRateM3PerHour / loose;
  const liningLimitedMPerHour = liningRateM2PerHour === undefined ? null : liningRateM2PerHour / wallM2PerM;
  const rates = [removalLimitedMPerHour, liningLimitedMPerHour].filter((r) => r !== null);
  const bindingMPerHour = rates.length ? Math.min(...rates) : null;

  return {
    boreM,
    faceAreaM2: areaM2,
    wallAreaM2PerM: wallM2PerM,
    removalLimitedMPerHour,
    liningLimitedMPerHour,
    bindingMPerHour,
    bindingConstraint: bindingMPerHour === null ? 'not enough inputs'
      : removalLimitedMPerHour === bindingMPerHour ? 'removal' : 'lining',
    metresPerWeek: bindingMPerHour === null ? null : bindingMPerHour * hoursPerWeek,
    hoursPerWeek
  };
}

/** What removal throughput a stated advance implies, which is the question in reverse. */
export function removalImpliedBy({ boreM, metresPerWeek, hoursPerWeek = 168 }) {
  const loose = Math.PI * (boreM / 2) ** 2 * 1.15;
  const mPerHour = metresPerWeek / hoursPerWeek;
  return { boreM, metresPerWeek, hoursPerWeek, m3PerHour: mPerHour * loose, m3PerWeek: metresPerWeek * loose };
}

/**
 * Buoyancy, which is what "it's all wet sand" actually implies for the structure.
 *
 * The owner, 19 August 2026: "the island is an aquifer lens on the great artesian basin edge. its
 * all wet sand."
 *
 * So saturation is not an unknown to be ranged over. Below the lens surface it is one, everywhere.
 * That removes a variable and introduces a larger one: a sealed tube below a water table displaces
 * water, and the pore pressure pushes up on it. If the lining plus its contents weigh less than the
 * water they displace, the tunnel wants to rise, and it wants to rise hardest where the cover is
 * thinnest.
 *
 * Uplift goes as the outer diameter squared. The lining that resists it is an annulus and goes
 * roughly as the diameter. So the ratio of uplift to the lining's own weight WORSENS with size:
 * 1.36 at a 1.5 m bore and 3.79 at 5 m, on a 0.15 m lining. The small bore wins here too, and it
 * wins hard, because 679 kg a metre of ballast is a track slab and 16 tonnes a metre is not.
 */
export function buoyancyPerMetre({ boreM, liningThicknessM, liningDensity_kg_per_m3, contentsMass_kg_per_m = 0 }) {
  const g = 9.80665;
  const rOuter = boreM / 2 + liningThicknessM;
  const rInner = boreM / 2;
  const displacedM3PerM = Math.PI * rOuter ** 2;
  const liningAreaM2 = Math.PI * (rOuter ** 2 - rInner ** 2);

  const upliftMass = displacedM3PerM * PHYSICS.densityWater_kg_per_m3;
  const liningMass = liningAreaM2 * liningDensity_kg_per_m3;
  const netMass = upliftMass - liningMass - contentsMass_kg_per_m;

  return {
    boreM, liningThicknessM,
    outerDiameterM: rOuter * 2,
    displacedM3PerM,
    upliftForce_kN_per_m: upliftMass * g / 1000,
    liningWeight_kN_per_m: liningMass * g / 1000,
    contentsWeight_kN_per_m: contentsMass_kg_per_m * g / 1000,
    netUplift_kN_per_m: netMass * g / 1000,
    floats: netMass > 0,
    // The mass a metre of tunnel would need to carry, or the friction and cover it would need to
    // mobilise, to stop rising. Sand cover above the crown resists through its submerged weight and
    // through friction on the failure surfaces, neither of which is computed here.
    ballastNeeded_kg_per_m: Math.max(0, netMass),
    note: 'Resisting uplift is done with cover, with ballast, or with anchors. Cover is free and the '
      + 'other two are not, so buoyancy is an argument for depth. How much cover is enough is a '
      + 'geotechnical question and depends on the submerged unit weight and friction angle of this '
      + 'island sand, neither of which is in this repository.'
  };
}

/**
 * What holds it down.
 *
 * The owner, 19 August 2026: "what holds it down is artificial roots/anchors and traffic and
 * resonance and sensors and real time evolution to actual data."
 *
 * That is not a conventional load case and this function does not pretend it is one. Conventional
 * practice sizes a dead structure against a worst case, builds it, and inspects it on a cycle. What
 * he describes is a live structure: distributed root anchorage rather than point piles, the traffic
 * itself as downforce, resonance working the surrounding sand, and a sensor field that keeps the
 * belief about all three current.
 *
 * So the four contributions are not design constants. Each is a value with a source and an age, and
 * this repository already has the machinery for that: src/world/ladder.js resolves a field from
 * island instrument, then official observation, then model, then simulation, demotes on staleness,
 * and refuses to let the bottom rung win in live mode. Anchor capacity resolved from a strain gauge
 * outranks anchor capacity resolved from a model, and when the gauge goes stale the answer degrades
 * to "not known" with a date rather than silently falling back to the design figure.
 *
 * This function therefore reports a BUDGET and a MARGIN, and takes every contribution as an input
 * with its rung. It invents no capacity. What a root anchor holds in this island's sand is a
 * measurement nobody has taken.
 */
export function holdDown({ netUplift_kN_per_m, contributions = [] }) {
  const named = contributions.map((c) => ({
    id: c.id,
    kN_per_m: c.kN_per_m,
    rung: c.rung || 'unknown',
    asAt: c.asAt || null,
    known: typeof c.kN_per_m === 'number'
  }));
  const known = named.filter((c) => c.known);
  const unknown = named.filter((c) => !c.known);
  const supplied = known.reduce((a, c) => a + c.kN_per_m, 0);
  return {
    netUplift_kN_per_m,
    contributions: named,
    supplied_kN_per_m: supplied,
    shortfall_kN_per_m: netUplift_kN_per_m - supplied,
    margin: supplied / netUplift_kN_per_m,
    holds: supplied >= netUplift_kN_per_m,
    unknownContributions: unknown.map((c) => c.id),
    // The honest state when a contribution has no current measurement behind it. A live structure
    // that cannot say how old its belief is has stopped being live.
    answer: unknown.length
      ? 'not known: ' + unknown.map((c) => c.id).join(', ') + ' have no current value'
      : supplied >= netUplift_kN_per_m ? 'holds' : 'short by ' + (netUplift_kN_per_m - supplied).toFixed(2) + ' kN/m'
  };
}

/** The four he named, as a budget rather than an allocation. */
export const HOLD_DOWN_CONTRIBUTIONS = [
  { id: 'artificial-roots', what: 'distributed anchorage into the surrounding sand rather than point piles, so load spreads through a volume the way a root plate does', measurable: 'pull-out capacity per metre, by test' },
  { id: 'traffic', what: 'the pods themselves as live downforce, which varies through the day and is zero at the quietest hour', measurable: 'occupancy and mass, continuously, which the twin already tracks for transport' },
  { id: 'resonance', what: 'working the surrounding sand, which densifies granular ground and raises both friction and unit weight', measurable: 'density and shear response around the bore, by instrument' },
  { id: 'cover', what: 'submerged weight and friction of the sand above the crown, the free one', measurable: 'depth, plus the island geotechnics that are not in this repository' },
  { id: 'building-more', what: 'the owner added this one after the other four, and it is the one that changes the shape of the model rather than adding a term to it: every new segment, anchor and structure adds dead load and lateral restraint, and a branching network is stiffer than a line', measurable: 'the rate of accretion, which is a project fact rather than a site fact' }
];

// Accretion, and why there is no completion date in this model.
//
// The owner, 19 August 2026, listing what holds the tunnel down: "artificial roots/anchors and
// traffic and resonance and sensors and real time evolution to actual data" and then, separately,
// "and building more."
//
// That last one is not a fifth force of the same kind. It says the structure is stabilised by
// continuing rather than by being completed, which inverts the usual shape of infrastructure. A
// conventional asset is finished and then degrades from its best day. This one is held by growth,
// so the failure mode is stopping.
//
// Three things follow for the model, and the first is why tools/tunnel.mjs reports weeks and should
// not have led with them:
//
//   1. There is no scope and no critical path to a completion date, so there is no order to get
//      right. His answer when asked what order to build the legs in was that it is a game engine.
//      That follows from this rather than from indifference.
//   2. The right measure is a rate of accretion and the state at a moment, not a percentage of a
//      fixed total. A twin of a thing that is never finished reports where it is, not how far along.
//   3. The loop closes on itself: boring yields spoil, spoil becomes structures, structures anchor
//      and stiffen the network, and an anchored network can be extended. The material for the next
//      segment comes out of the last one.
export const ACCRETION_NOTE = 'The network is stabilised by continuing, not by completion. Report '
  + 'state at a moment and rate of growth. There is no percentage complete, because there is no '
  + 'total to be a percentage of.';

// The island's actual geology, found 19 August 2026 after the owner said he did not know where the
// bedrock was. It is published, because the island's freshwater lens is among the most studied on
// the continent and the sand miners drilled it for decades.
//
//   depth to bedrock   a maximum of 89 metres below mean sea level
//   water table        a north-south mound, up to 42 m AHD near Mt Hargrave at the island's centre,
//                      falling to sea level in the coastal lowlands
//   groundwater        one regional interconnected system holding almost all the fresh water, plus
//                      localised perched systems disconnected from it
//
// Source: hydrology and 3D hydrology literature on northern Stradbroke Island, retrieved 19 August
// 2026. Recorded at confidence medium: these are secondary summaries and the primary bore logs have
// not been opened here.
export const ISLAND_GROUND = {
  bedrockMaxDepthBelowMSL_m: 89,
  waterTableMax_mAHD: 42,
  waterTableAtCoast_mAHD: 0,
  waterTableForm: 'a north-south mound, highest near Mt Hargrave at the centre',
  confidence: 'medium',
  note: 'secondary sources, primary bore logs not opened'
};

/**
 * How much sand cover holds a floating tunnel down.
 *
 * The correction this makes to the buoyancy result above: uplift on a sealed tube is the weight of
 * the water it displaces, and that does not change with depth. What changes with depth is the cover
 * available to resist it. So buoyancy is a shallow problem, not a deep one, and there is a depth
 * below which the ground holds the tunnel down for nothing.
 *
 * The resisting prism taken here is the simplest one: the submerged weight of a vertical column of
 * sand the width of the tunnel's outer diameter. It ignores friction on the sides of that column,
 * which is real and adds resistance, so this is conservative.
 *
 * submergedUnitWeight_kN_per_m3 is a property of this island's sand and is NOT in this repository.
 * Saturated sands commonly sit near 10 kN/m3 submerged, and that is the figure to argue with, not a
 * measurement of Minjerribah.
 */
export function coverToHoldDown({ netUplift_kN_per_m, outerDiameterM, submergedUnitWeight_kN_per_m3 }) {
  const resistancePerMetreOfCover = submergedUnitWeight_kN_per_m3 * outerDiameterM;
  return {
    netUplift_kN_per_m,
    outerDiameterM,
    submergedUnitWeight_kN_per_m3,
    resistance_kN_per_m_per_m_of_cover: resistancePerMetreOfCover,
    coverNeededM: netUplift_kN_per_m / resistancePerMetreOfCover,
    note: 'Vertical prism only, no side friction, so conservative. Uplift is depth-independent and '
      + 'cover is not, which makes buoyancy a portal and shallow-loop problem rather than a deep '
      + 'tunnel problem.'
  };
}

// Annealing the sand rather than lining against it.
//
// The owner, 19 August 2026: "theres no reason why we cant use algae or mycelium or calcium to self
// aneal the sand around tunnels into fractals, or ionise the water and introduce other elements."
//
// Recorded as a design space, not a decision, and not costed. Each entry names what would have to be
// measured for it to become a number, because none of them have rates in this repository. The shared
// idea is that the ground becomes the structure instead of being resisted by one, and that the
// resulting form is fractal and branching rather than a uniform annulus, which is the same shape as
// the artificial roots in the hold-down list.
//
// Note what the geology above does to this list: at a 1.5 m bore, 0.37 m of cover already holds the
// tunnel down. So annealing is not needed for buoyancy. Its work is sealing, stiffening, and making
// the ground stand up while the bore is open, which is the objective function he named.
export const ANNEALING_FAMILY = [
  { id: 'calcium', what: 'precipitate calcium carbonate through the pore space so the grains cement to each other',
    measurable: 'strength gain against treatment volume and time; how much of the pore space closes, since a fully sealed lens is a different hydrological island' },
  { id: 'mycelium', what: 'grow a fungal network through the sand and let it bind and later mineralise',
    measurable: 'growth rate and reach in saturated sand at ground temperature, and whether it survives below the water table at all' },
  { id: 'algae', what: 'biological precipitation and binding, with the organism itself as the delivery mechanism',
    measurable: 'the same, plus what it does to water chemistry in an aquifer people drink from' },
  { id: 'ionisation', what: 'ionise the pore water and move elements through it, so treatment reaches where injection cannot',
    measurable: 'energy per cubic metre treated, and where the ions end up' }
];

// The lens as infrastructure, not as a constraint.
//
// The owner, 19 August 2026, on changing the lens: "the change to the lens matters not, at most it
// just changes where the water is harvested from and moved to and that is what a city does."
//
// Taken as stated. What the published geology adds to it is that the change is a resource. The water
// table is a mound reaching 42 m AHD at the centre and sea level at the coast, so there is 42 m of
// head across the island. Tap high and it gravity-feeds. And the tunnel network at depth is already
// the conduit, so the same bore that moves people moves water and does it downhill for nothing. That
// is the same shape as the spoil: one thing doing several jobs, the second paid for by the first.
//
// The reason the twin models the lens is therefore not risk. It is that the water table position is
// an input to the ground conditions on every metre of the network. Move where the water is harvested
// and the table moves, and the cover, support and buoyancy conditions near it move with it. That is
// a coupling inside the design.
//
// Boundary already set by the owner in Sandworm and not to be reopened here: perched lakes are
// excluded as storage. "A perched lake can be a teacher without being the battery."
export const LENS_AS_INFRASTRUCTURE = {
  headAcrossIsland_m: ISLAND_GROUND.waterTableMax_mAHD - ISLAND_GROUND.waterTableAtCoast_mAHD,
  gravityFedFromCentre: true,
  conduit: 'the tunnel network at depth, already bored for transport',
  coupling: 'water table position sets cover, support and buoyancy conditions along the network',
  perchedLakes: 'excluded as storage by the owner: a teacher, not a battery'
};

// The drive does not stop.
//
// The owner, 19 August 2026: "the artesian basin is not going to stop pushing the water out."
//
// The operative fact for every calculation in this file is that the water is driven and continuous,
// and it is the same fact whether the drive is deep basin pressure or rainfall recharging through a
// hundred metres of sand. The design does not need that question resolved. What it needs is that the
// water moves, always, and is not a stock that can be drawn down.
//
// Two consequences, and they point in opposite directions from the same cause.
//
// AGAINST FREEZING, AND THIS PARAGRAPH WAS WRONG. It said a permanently driven system rules out
// refrigeration, because moving groundwater carries heat in faster than a plant removes it. That is
// a real effect and it was applied here without computing how fast this water actually moves, which
// is the same error this repository has made all day: reaching for the general caution instead of
// the number.
//
// The owner's reply, 19 August 2026: "I can't imagine an aquifer lense having so much water pressure
// that it can stop a freezing apparatus from holding a 1.5m-3m bore stable long enough to reinforce
// is with pre-cast quick fit interlocks."
//
// He is right, and the arithmetic is in out/velocity.mjs. 42 m of head over about 5,500 m to the
// coast is a hydraulic gradient near 0.0076. At that gradient, seepage velocity is 0.02 m a day in
// very fine sand, 0.22 in fine to medium clean sand, 0.65 in medium to coarse. Freezing is generally
// straightforward below about 1 m a day and difficult above about 2, so the lens only troubles a
// freeze at the coarse end of the range, and dune sand is not usually at that end.
//
// The hold time is the other half and it is also his. A freeze that must stand while concrete is
// cast in place and cures is a weeks-long refrigeration load. Pre-cast quick-fit interlocking
// segments erected behind a shield need the ground to stand for the shield length and the time to
// place a ring, minutes to hours, advancing continuously. Nothing is held statically, so the freeze
// is a short local operation rather than a standing wall.
//
// Freezing is therefore viable here on both counts, and hydraulic conductivity is the one number the
// whole table turns on. It is not measured for this island and it is in the same bore log as
// everything else this model is missing.
//
// FOR THE RESOURCE. It does not deplete. Most cities manage a stock and this one would route a flow
// that keeps arriving under its own pressure, with 42 m of head already in it. Permanent supply and
// permanent head, without pumping.
//
// And the lining therefore never does a static job. It holds a head that does not relent, for the
// life of the structure, rather than waiting out a construction phase.
export const DRIVE = {
  continuous: true,
  ownerStatement: 'the artesian basin is not going to stop pushing the water out',
  sameEitherWay: 'deep basin pressure or rainfall recharge through the sand column: the tunnel sees continuous driven inflow either way, so the design does not wait on that question',
  rulesOut: 'nothing on its own. See the corrected note above: at this lens gradient the seepage velocity is well inside what a freeze tolerates across most of the plausible conductivity range.',
  methods: 'freezing and pressure support are both open. Freezing is short and local when the ring is pre-cast quick-fit rather than cast in place. A permanent seal is needed either way, because the head does not relent.',
  resource: 'a flow that does not deplete, already carrying 42 m of head'
};
