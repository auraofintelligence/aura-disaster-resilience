// One boot for two pages, and the API the instruments drive.
//
// index.html is the page for a person arriving: the acknowledgement of Country and the everyday
// crossings view, nothing else. lab.html is the instrument bench: the calibration scene, the stage
// 0 panels, the step controls. Both load this module. Which page this is is decided by what the
// markup provides, not by a flag: a page with a #stage canvas gets the renderer and the bench
// panels, a page with an #everyday mount gets the crossings view. Both run the same world, built
// from the same packs, so a number on either page is computed by the simulation and never pasted.
//
// Everything an instrument needs from a running page arrives through `window.ISLAND`:
//
//   ISLAND.ready      a promise that resolves after the first frame, so a tool never measures a
//                     page that has not drawn yet.
//   ISLAND.info()     which render path is live (null on the front page, which draws no scene),
//                     which fault is switched on, and where the world is.
//   ISLAND.step(n)    advance the simulation and redraw. Nothing here runs by itself: a world that
//                     advances on a wall clock cannot be compared with another run of itself.
//   ISLAND.probe(name) walk the DOM and POST what is actually on the page to out/probes/<name>.json.
//                     Lives on both pages, so the interface probe can audit the front page too.
//                     The default name is 'calibration' on the lab and 'front' on the front page,
//                     so a probe of one page cannot quietly overwrite a probe of the other.
//   ISLAND.shot(name) render the calibration scene offscreen, encode a PNG in the page, and POST
//                     it to the server. Lab only: the front page draws no scene, and a shot of it
//                     would be a picture of nothing. On the front page it answers with a refusal.
//   ISLAND.bench(n)   render n frames and POST the per frame milliseconds. Lab only, same reason.
//
// The POST sinks exist only under tools/serve.mjs. On a static host such as GitHub Pages the
// fetch comes back as an error body, post() returns { ok: false } and nothing on either page
// depends on it having worked. That is deliberate and must stay true.
//
// The provenance index. Every number on either page cites the id of the thing it came from, and
// the probe reports whether that id resolves. The index is built at load from three honest kinds
// of id and nothing else:
//
//   1. source ids from data/_sources.json,
//   2. record ids from the packs the world loaded, meaning objects that carry an id and all eight
//      provenance fields,
//   3. two ids this page declares, listed in PAGE_DECLARED below with the file and the field they
//      point at. They exist because the tick and the acknowledgement did not come out of a pack,
//      and citing a pack record that did not produce a number would be worse than naming the real
//      source of it.
//
// ISLAND.provenance() returns all three kinds with their locators, so a critic can check the index
// rather than take it.

import { buildIsland, STAGE_0_PACKS } from './world/island.js';
import { loadPack, loadSources } from './world/data.js';
import { REQUIRED_FIELDS } from './kernel/record.js';
import { ACTIVE_FAULT, faultBanner } from './kernel/faults.js';
import { createRenderer, loadScene } from './render/calibration.js';
import { createPanels, probePanels } from './ui/panel.js';
import { createCrossingsView } from './ui/crossings-view.js';
import { registerCrossings } from './systems/crossings.js';

/**
 * The packs both pages load: stage 0's two plus the two the everyday view reads.
 *
 * data/crossings.json is the two operators' published timetables and the owner's ground truth of
 * 19 August 2026. data/transport-gtfs.json is TransLink's island bus feed. The lab page loads them
 * too, even though it shows no crossings view, so that the two pages run one world rather than two
 * near-copies whose numbers could drift apart.
 */
const PAGE_PACKS = [...new Set([...STAGE_0_PACKS, 'crossings', 'transport-gtfs'])];

/** Ids this page declares, each with the file and field it points at. */
const PAGE_DECLARED = [
  {
    id: 'kernel-clock-epoch',
    kind: 'kernel constant',
    locator: 'src/kernel/world.js, DEFAULT_EPOCH, with the arithmetic in src/kernel/clock.js',
    what: 'The island civil time of tick zero. The tick and the island time are counted from it, so '
      + 'it is where those two numbers come from. It is a decision this build made and not a '
      + 'published record, and it is named here rather than dressed up as one.'
  },
  {
    id: 'lore-acknowledgement',
    kind: 'pack wording',
    locator: 'data/lore.json, acknowledgement.game_wording.long.text',
    what: 'The acknowledgement of Country shown at load. data/lore.json is carried from the first '
      + 'build byte for byte and is not in the record schema, so its wording is cited by field path '
      + 'rather than by record id.'
  }
];

let world = null;
let scene = null;
let renderer = null;
let panels = null;
let everyday = null;
let shotRen = null;
let shotCanvas = null;
let index = [];
let registry = [];

const byId = (id) => document.getElementById(id);

function showBanner(id, text) {
  const node = byId(id);
  if (!node) return;
  node.textContent = text;
  node.hidden = !text;
}

/** Every object in a loaded pack that is a record: an id, and all eight provenance fields. */
function packRecordIds(packs) {
  const out = new Set();
  const walk = (node) => {
    if (Array.isArray(node)) {
      node.forEach(walk);
      return;
    }
    if (!node || typeof node !== 'object') return;
    if (typeof node.id === 'string' && REQUIRED_FIELDS.every((f) => f in node)) out.add(node.id);
    for (const key of Object.keys(node)) walk(node[key]);
  };
  walk(packs);
  return out;
}

function buildProvenance(packs, sources) {
  const rows = [];
  for (const id of Object.keys(sources).sort()) {
    rows.push({
      id,
      kind: 'source',
      locator: 'data/_sources.json, key ' + id,
      what: sources[id] && sources[id].title ? sources[id].title : ''
    });
  }
  for (const id of [...packRecordIds(packs)].sort()) {
    rows.push({ id, kind: 'record', locator: 'a record in a loaded pack under data/', what: '' });
  }
  for (const row of PAGE_DECLARED) rows.push(row);
  return rows;
}

/**
 * The frame's worth of state the bench panels read. The renderer never sees this and never writes
 * it.
 *
 * The tide row carries `answer`, which is what the twin says when it is asked for `tide.heightM`
 * at this tick: resolved by src/world/island.js down the source ladder over the bitemporal store,
 * at a cursor whose mode and moment come back with it. This page used to build the tide's absence
 * itself, out of the tide system's null and a date read straight from the pack, which was a second
 * answer to the same question with nothing saying which one a reader was looking at.
 */
function view() {
  const solar = world.state.solar;
  const tide = world.state.tide;
  return {
    tick: world.clock.tick,
    islandTime: world.clock.iso(),
    civil: world.clock.civil(),
    sun: {
      elevationDeg: solar.elevationDeg,
      azimuthDeg: solar.azimuthDeg,
      isDaylight: solar.isDaylight
    },
    site: { lat: solar.siteLat, lon: solar.siteLon },
    tide: {
      fed: tide.fed,
      heightM: tide.heightM,
      reason: tide.reason,
      port: tide.port,
      answer: tide.answer
    }
  };
}

/**
 * The frame's worth of state the everyday crossings view reads. Kept apart from `view()` above so
 * that the bench panels and the crossings panels cannot start reading each other's shapes by
 * accident, and so a reader can see exactly what the crossings view is allowed to see: the clock,
 * the crossings system's own answers, and the tide answer that already came down the source ladder.
 */
function crossingsView() {
  // The minute the systems actually answered for, which is not always the minute the clock reads.
  // A tick runs every system and then advances the clock by one, so after a step the crossings
  // system holds the answer for the minute that just finished while the clock has moved on to the
  // next one. Before the first step there has been no advance, so boot's answer is for tick zero.
  // The crossings view shows this minute rather than the clock's, and says which minute it is,
  // because one minute is the difference between "in one minute" and "it is going now".
  const tick = world.clock.tick;
  const answeredTick = tick === 0 ? 0 : tick - 1;
  return {
    tick,
    answeredTick,
    civil: world.clock.civil(),
    answeredAt: world.clock.civil(answeredTick),
    crossings: world.state.crossings,
    tide: { answer: world.state.tide.answer }
  };
}

function drawNow() {
  if (renderer) renderer.draw({ tick: world.clock.tick });
  if (panels) panels.update(view());
  if (everyday) everyday.update(crossingsView());
}

/** The offscreen target, built once. It prefers the visible page's path and still falls back. */
async function shotRenderer() {
  if (shotRen) return shotRen;
  if (typeof OffscreenCanvas === 'function') {
    shotCanvas = new OffscreenCanvas(scene.width, scene.height);
  } else {
    shotCanvas = document.createElement('canvas');
  }
  shotRen = await createRenderer({ canvas: shotCanvas, scene, prefer: renderer.path });
  return shotRen;
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error || new Error('the blob could not be read'));
    reader.readAsDataURL(blob);
  });
}

async function toPngDataUrl(canvas) {
  if (typeof canvas.convertToBlob === 'function') {
    const blob = await canvas.convertToBlob({ type: 'image/png' });
    return blobToDataUrl(blob);
  }
  return canvas.toDataURL('image/png');
}

async function post(path, body) {
  const res = await fetch(path, { method: 'POST', body });
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    return { ok: false, status: res.status, body: text };
  }
}

/**
 * Compare the acknowledgement on the page with the wording in the pack, and say which it is. The
 * gate checks the same thing from outside; this is the page checking itself, so a drift is visible
 * to whoever is looking at the page rather than only to whoever runs the gate. The check line
 * exists on the lab page only: the check still protects the front page through the gate, and the
 * front page does not narrate its own checks.
 */
async function checkAcknowledgement() {
  const node = byId('value-acknowledgement');
  const line = byId('acknowledgement-check');
  if (!node || !line) return;
  try {
    const lore = await loadPack('lore');
    const wording = lore.acknowledgement.game_wording.long.text;
    const same = node.textContent === wording;
    line.textContent = same
      ? 'This wording is the long acknowledgement in data/lore.json, at '
        + 'acknowledgement.game_wording.long.text, checked against the pack when this page loaded.'
      : 'This wording does NOT match data/lore.json at acknowledgement.game_wording.long.text. The '
        + 'pack is the authority and the page is wrong.';
  } catch (err) {
    line.textContent = 'The acknowledgement could not be checked against data/lore.json: '
      + String((err && err.message) || err);
  }
}

/**
 * Where the crossings system is registered, and why it is registered here rather than in
 * src/world/island.js where it belongs.
 *
 * It belongs in `registerSystems` in src/world/island.js, so that the page, the headless instrument
 * and the gate all run one island. Board note 032 recorded that wiring as owed and said why it was
 * not done: another agent held that file open. This function is the interim, and it is written so
 * that it does nothing at all the moment the proper wiring lands, because it asks the world whether
 * the system is already there before registering it.
 *
 * Until that day, one thing is true and is said out loud rather than left to be discovered: these
 * pages run a system that `node tools/headless.mjs` and `node tools/determinism.mjs` do not, because
 * those build the island from STAGE_0_PACKS. `node tools/check-crossings.mjs` is the instrument that
 * covers the system in the meantime.
 */
function registerCrossingsIfMissing(built) {
  if (built.byName && built.byName.has('crossings')) return false;
  registerCrossings(built, { pack: built.packs.crossings });
  return true;
}

async function boot() {
  showBanner('fault-banner', faultBanner());

  world = await buildIsland({ packs: PAGE_PACKS, boot: false });
  registerCrossingsIfMissing(world);
  world.boot();
  const sources = await loadSources();
  registry = buildProvenance(world.packs, sources);
  index = [...new Set(registry.map((r) => r.id))].sort();

  // The bench, on the page that carries a stage. The calibration scene and its panels are stage 0
  // instruments: tools/shot.mjs checks the scene's pixels against tools/scenes/calibration.json,
  // and the shot is taken from an offscreen canvas of its own.
  const stage = byId('stage');
  if (stage) {
    scene = await loadScene();
    renderer = await createRenderer({ canvas: stage, scene });
    panels = createPanels(byId('panels'), {
      onStep: (minutes) => {
        world.step(minutes);
        drawNow();
      }
    });
  }

  // The everyday view, on the page that carries a mount for it.
  const mount = byId('everyday');
  if (mount) {
    everyday = createCrossingsView(mount, {
      packs: { crossings: world.packs.crossings, transport: world.packs['transport-gtfs'] }
    });
  }

  drawNow();
  if (renderer) await renderer.flush();

  const path = byId('render-path');
  if (path && renderer) {
    const refused = renderer.notes.filter((n) => !n.ok)
      .map((n) => n.path + ' was not used: ' + n.why);
    path.textContent = 'Render path: ' + renderer.path + '. ' + renderer.detail + '.'
      + (refused.length ? ' ' + refused.join(' ') : '');
  }

  checkAcknowledgement();
  return ISLAND.info();
}

/** Assigned below, once the object it belongs to exists. Every method waits on it. */
let ready = null;

/** The default probe name for this page, so one page's probe cannot overwrite the other's. */
function defaultProbeName() {
  return renderer ? 'calibration' : 'front';
}

const ISLAND = {
  /** Resolves after the first frame has been drawn. Replaced with the real promise below. */
  ready: null,

  /** The five facts an instrument needs before it measures anything. */
  info() {
    return {
      renderPath: renderer ? renderer.path : null,
      fault: ACTIVE_FAULT || null,
      tick: world ? world.clock.tick : null,
      seed: world ? world.seed : null,
      epoch: world ? world.clock.epochISO : null
    };
  },

  /** How the render path was chosen, including what the paths that were not used said. */
  renderNotes() {
    return {
      page: renderer ? { path: renderer.path, detail: renderer.detail, notes: renderer.notes } : null,
      shot: shotRen ? { path: shotRen.path, detail: shotRen.detail, notes: shotRen.notes } : null
    };
  },

  /** The provenance index with its locators, so the index itself can be checked. */
  provenance() {
    return registry.map((r) => ({ ...r }));
  },

  /** Advance the simulation by n island minutes and redraw. Returns the new tick. */
  step(n = 1) {
    const count = Math.max(0, Math.floor(Number(n) || 0));
    if (count > 0) world.step(count);
    drawNow();
    return world.clock.tick;
  },

  /** Render offscreen, encode a PNG here, and POST it to the server. Resolves with the reply. */
  async shot(name = 'calibration') {
    await ready;
    if (!renderer) {
      return {
        ok: false,
        why: 'this page draws no calibration scene, so there is nothing honest to photograph. '
          + 'The scene and its shot live at lab.html.'
      };
    }
    const target = await shotRenderer();
    target.draw({ tick: world.clock.tick });
    await target.flush();
    const dataUrl = await toPngDataUrl(shotCanvas);
    return post('/__shot/' + encodeURIComponent(name), dataUrl);
  },

  /** Walk the DOM and POST what is on the page. Resolves with the reply. */
  async probe(name = null) {
    await ready;
    const chosen = name || defaultProbeName();
    const report = {
      name: chosen,
      tick: world.clock.tick,
      renderPath: renderer ? renderer.path : null,
      fault: ACTIVE_FAULT || null,
      panels: probePanels(document, index),
      provenanceIndex: index
    };
    return post('/__probe/' + encodeURIComponent(chosen), JSON.stringify(report, null, 2));
  },

  /**
   * Render n frames and POST the per frame milliseconds. Lab only, because it measures the
   * calibration renderer and the front page does not have one.
   *
   * What a sample is, said plainly rather than left for someone to assume: the cost of building and
   * submitting one frame from this page, measured around the draw call. On the two GPU paths the
   * GPU's own time is not in it, because waiting for the GPU on every frame would measure a
   * different thing again. The instrument computes the percentiles; no average is computed
   * anywhere here.
   *
   * The frames are drawn back to back rather than one per animation frame, and that is not a
   * shortcut. The browser pane in this environment does not composite, which is the same fact that
   * makes the page post its own screenshots, and a page that is not compositing gets no animation
   * frame callbacks at all. A bench that waited for one would hang instead of measuring, which is
   * what the first version of this method did.
   */
  async bench(frames = 600) {
    await ready;
    if (!renderer) {
      return {
        ok: false,
        why: 'this page draws no calibration scene, so a frame time here would measure nothing. '
          + 'The bench lives at lab.html.'
      };
    }
    const n = Math.max(1, Math.floor(Number(frames) || 0));
    const samples = [];
    for (let i = 0; i < n; i++) {
      const t0 = performance.now();
      renderer.draw({ tick: world.clock.tick });
      samples.push(Number((performance.now() - t0).toFixed(3)));
    }
    return post('/__probe/bench', JSON.stringify({ frames: n, samples }));
  },

  /** The world itself, for a person at a console. Nothing in the instruments depends on it. */
  get world() {
    return world;
  }
};

ready = boot().catch((err) => {
  showBanner('boot-error', 'The page did not boot: ' + String((err && err.message) || err));
  throw err;
});
ISLAND.ready = ready;

window.ISLAND = ISLAND;
