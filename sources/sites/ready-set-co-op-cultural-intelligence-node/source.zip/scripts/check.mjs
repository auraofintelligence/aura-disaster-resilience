import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.cwd();
const pages = ['index.html', 'node.html', 'dunwich.html', 'culture.html', 'uses.html', 'projects.html', 'digital-twin.html', 'process.html', 'cooperative.html', 'network.html', 'sitemap.html'];
const heroPages = [...pages, '404.html'];
const errors = [];
const textExtensions = new Set(['.html', '.md', '.js', '.mjs', '.css', '.json', '.xml', '.txt', '.webmanifest']);
const allFiles = [];

function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (entry.name === '.git' || entry.name === 'node_modules') continue;
    const location = path.join(directory, entry.name);
    entry.isDirectory() ? walk(location) : allFiles.push(location);
  }
}

walk(root);

for (const file of allFiles) {
  const vectorWord = ['s', 'v', 'g'].join('');
  if (path.extname(file).toLowerCase() === `.${vectorWord}`) errors.push(`${path.relative(root, file)}: prohibited vector-image file`);
  if (!textExtensions.has(path.extname(file).toLowerCase()) && path.basename(file) !== 'LICENSE') continue;
  const relative = path.relative(root, file);
  const source = fs.readFileSync(file, 'utf8');
  const vectorReference = new RegExp(`<${vectorWord}\\b|image\\/${vectorWord}|\\.${vectorWord}(?:\\b|[?#])`, 'i');
  if (vectorReference.test(source)) errors.push(`${relative}: prohibited vector-image reference`);
  if (new RegExp(`[\\u2013\\u2014]`).test(source)) errors.push(`${relative}: contains an en dash or em dash`);
}

const heroHashes = new Map();
const expectedNav = pages.map(file => `href="${file}"`);

for (const page of heroPages) {
  const location = path.join(root, page);
  if (!fs.existsSync(location)) {
    errors.push(`${page}: missing`);
    continue;
  }
  const html = fs.readFileSync(location, 'utf8');
  const hero = html.match(/<img class="hero-image" src="([^"]+)"[^>]*>/);
  if (!hero) {
    errors.push(`${page}: missing full-width hero image`);
  } else {
    const source = hero[1];
    if (/^https?:/i.test(source)) errors.push(`${page}: hero is remotely hosted`);
    if (!/\.(webp|png|jpe?g)$/i.test(source)) errors.push(`${page}: hero is not raster`);
    const heroFile = path.resolve(root, source);
    if (!fs.existsSync(heroFile)) {
      errors.push(`${page}: missing hero asset ${source}`);
    } else {
      const hash = crypto.createHash('sha256').update(fs.readFileSync(heroFile)).digest('hex');
      if (heroHashes.has(hash)) errors.push(`${page}: hero duplicates ${heroHashes.get(hash)}`);
      heroHashes.set(hash, page);
    }
  }
  if (!/<button class="to-top"/.test(html)) errors.push(`${page}: missing floating return-to-top button`);
  if (!/<div class="wrap route-nav">/.test(html)) errors.push(`${page}: missing previous and next navigation`);
  if (/<p class="eyebrow"|class="eyebrow"/.test(html)) errors.push(`${page}: contains a decorative eyebrow label`);
  if (/\b(?:can|should|must)\b/i.test(stripMarkup(html))) errors.push(`${page}: contains directive or permission language`);
  if (/\b(?:small|smaller|smallest|safe|safer|safest|modest|narrow|minimal|least|timid)\b/i.test(stripMarkup(html))) errors.push(`${page}: contains timid or self-diminishing language`);
  for (const expected of expectedNav) {
    if (!html.includes(expected)) errors.push(`${page}: header omits ${expected.slice(6, -1)}`);
  }
  for (const match of html.matchAll(/<a\b([^>]*?)href="(https?:\/\/[^"]+)"([^>]*)>/g)) {
    const attributes = `${match[1]}${match[3]}`;
    if (!/target="_blank"/.test(attributes) || !/rel="noopener noreferrer"/.test(attributes)) errors.push(`${page}: unsafe external link ${match[2]}`);
  }
  for (const match of html.matchAll(/<img\b[^>]*src="([^"]+)"/g)) {
    if (/^https?:/i.test(match[1])) errors.push(`${page}: remote image ${match[1]}`);
  }
  for (const match of html.matchAll(/href="([^"]+)"/g)) {
    const href = match[1];
    if (/^(?:https?:|mailto:|tel:|#)/i.test(href)) continue;
    const clean = href.split('#')[0].split('?')[0];
    if (!clean) continue;
    const target = path.resolve(root, path.dirname(page), clean);
    if (!fs.existsSync(target)) errors.push(`${page}: broken internal link ${href}`);
  }
}

for (const icon of ['assets/favicon-32.png', 'assets/favicon-192.png', 'assets/apple-touch-icon.png', 'assets/favicon.png']) {
  if (!fs.existsSync(path.join(root, icon))) errors.push(`missing raster icon ${icon}`);
}

const sitemap = fs.readFileSync(path.join(root, 'sitemap.xml'), 'utf8');
const stylesheet = fs.readFileSync(path.join(root, 'assets', 'styles.css'), 'utf8');
const siteScript = fs.readFileSync(path.join(root, 'assets', 'site.js'), 'utf8');
if (/\.reveal\s*\{[^}]*opacity\s*:\s*0(?:\D|$)/i.test(stylesheet)) errors.push('styles.css: meaningful content is hidden until JavaScript runs');
const arrivalRule = stylesheet.match(/\.reveal\.visible \.colour-card[^}]+}/i)?.[0] ?? '';
if (!/animation-iteration-count\s*:\s*1/i.test(arrivalRule)) errors.push('styles.css: card entrance animation is not locked to one pass');
if (/animation(?:-iteration-count)?\s*:[^;}]*infinite/i.test(stylesheet)) errors.push('styles.css: contains a repeating animation');
for (const removedEffect of ['data-twin-canvas', 'data-network-canvas', 'data-ambient-canvas']) {
  if (heroPages.some(page => fs.readFileSync(path.join(root, page), 'utf8').includes(removedEffect))) errors.push(`generated pages: obsolete decorative effect ${removedEffect}`);
  if (siteScript.includes(removedEffect)) errors.push(`site.js: obsolete decorative effect ${removedEffect}`);
}
for (const image of fs.readdirSync(path.join(root, 'assets', 'projects'))) {
  if (!/\.(?:webp|png|jpe?g)$/i.test(image)) errors.push(`assets/projects/${image}: project image is not raster`);
}
for (const feature of [
  ['index.html', 'class="record-spine"'],
  ['dunwich.html', 'data-place-explorer'],
  ['culture.html', 'class="operation-field"'],
  ['uses.html', 'class="operating-comparison"'],
  ['digital-twin.html', 'data-workbench'],
  ['process.html', 'data-node-plan-builder'],
  ['cooperative.html', 'data-role-wheel']
]) {
  const [page, marker] = feature;
  if (!fs.readFileSync(path.join(root, page), 'utf8').includes(marker)) errors.push(`${page}: missing ${marker}`);
}
const projectsHtml = fs.readFileSync(path.join(root, 'projects.html'), 'utf8');
const projectCardCount = [...projectsHtml.matchAll(/class="local-project-card/g)].length;
if (projectCardCount !== 18) errors.push(`projects.html: expected 18 project cards, found ${projectCardCount}`);
if (!projectsHtml.includes('community-club-builder-sandy-sports')) errors.push('projects.html: missing Sandy Sports');
if (!projectsHtml.includes('ballow-road-sand-screen-hub')) errors.push('projects.html: missing Ballow Road Sand and Screen Hub');
for (const image of fs.readdirSync(path.join(root, 'assets', 'projects'))) {
  if (!projectsHtml.includes(`assets/projects/${image}`)) errors.push(`projects.html: missing project image ${image}`);
}
for (const page of pages.filter(page => page !== 'projects.html')) {
  const html = fs.readFileSync(path.join(root, page), 'utf8');
  if (/class="local-project-card/.test(html)) errors.push(`${page}: repeats the dedicated project catalogue`);
  if (/class="adventure-project/.test(html)) errors.push(`${page}: repeats the wider project gateway`);
}
for (const page of pages) {
  const route = page === 'index.html' ? 'ready-set-co-op-cultural-intelligence-node/' : `ready-set-co-op-cultural-intelligence-node/${page}`;
  if (!sitemap.includes(route)) errors.push(`sitemap.xml: missing ${page}`);
}

function stripMarkup(html) {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&[a-z#0-9]+;/gi, ' ');
}

if (heroHashes.size !== heroPages.length) errors.push(`unique hero count ${heroHashes.size} does not match ${heroPages.length} hero pages`);

if (errors.length) {
  console.error(errors.join('\n'));
  process.exit(1);
}

console.log(`Checked ${pages.length} main pages, 404.html, ${allFiles.length} repository files and ${heroHashes.size} unique local raster heroes.`);
console.log('Confirmed: complete navigation, one dedicated project catalogue, secure external links, unique raster heroes, raster project imagery, distinct interaction patterns, single-pass motion, no decorative canvas effects, no remote images, no vector references, no decorative eyebrows, no directive or permission language, no timid framing, and no en dashes or em dashes.');
