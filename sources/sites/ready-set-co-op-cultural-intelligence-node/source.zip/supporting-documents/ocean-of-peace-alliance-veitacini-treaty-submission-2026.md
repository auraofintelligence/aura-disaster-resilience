<!-- Public Markdown edition generated from the supplied DOCX. Wording and document order are preserved; page layout and Word-only formatting are normalised. -->

SUBMISSION TO THE JOINT STANDING COMMITTEE ON TREATIES

Ocean of Peace Alliance

The Veitacini Treaty: a Protopian Gambit for Joyful Responsible Abundance

| Submitter | Luke Nathan Hayes |
| --- | --- |
| Location | Minjerribah / North Stradbroke Island, Queensland |
| Date | 27 August 2026 |
| Inquiry | Ocean of Peace Alliance (The Veitacini Treaty) |

| Central proposition<br>This submission supports the stated objective of an Ocean of Peace. The treaty already names a civic foundation: a culture of peace, the Pacific Way, talanoa, consensus, sovereignty, democratic institutions, peaceful settlement, free, healthy and productive lives, and a desire to live in peace with all peoples and governments. Together, we can grow these words into practical civic, scientific, cultural, economic and people-to-people cooperation guided by the Protopian Gambit and Joyful Responsible Abundance. |
| --- |

## EXECUTIVE SUMMARY

## An Ocean of Peace we build together

The Veitacini Treaty is broad, but its civic words are clear. The preamble commits to a culture of peace grounded in the Pacific Way. It describes the Pacific Way as peaceful settlement through talanoa and consensus, with respect for sovereignty and rejection of coercion. It recognises the 2050 Strategy vision of free, healthy and productive lives and expresses a desire to live in peace with all peoples and governments. Article 2 names democratic institutions. Article 3 names peaceful settlement. Article 11 returns treaty disputes to consultation, good-faith negotiation and the Pacific Way. [2] [4] [5]

The companion Fiji-Australia Vuvale Union gives these ideas practical fields. It names prosperity and resilience, cultural and people connections, climate action, a culture of peace, inclusive development, human dignity, the digital economy, resilient infrastructure, education, healthcare, First Nations heritage, mobility, trust, consultation and consensus. It also opens its forum to traditional, religious, community and business leaders. [3]

The Protopian Gambit offers a simple way to work within that open field. Begin with something useful now, then design it to leave more capability, trust, knowledge and choices for the next step. Joyful Responsible Abundance adds direction. Joyful asks whether life becomes more worth living. Responsible asks how we care for consequences, consent and stewardship. Abundance asks whether capability, knowledge, time, care and opportunity spread rather than concentrate. [6] [13]

The ideas below are already connected across public work: P4A and P4A Oceania, the B.E.L.A.U. Protopian Gambit, GAJRA Earth Global Association for Joyful Responsible Abundance on Earth, the C-Hour and local government submission, the AUKUS Public Inquiry submission lodged on 25 August 2026, and the Senate AI and data centres bundle lodged on 27 August 2026 with A Fair Go for the AI Age and the 44,000-place world cities dataset. Together they offer civic ways to give an Ocean of Peace visible daily meaning. [7] [8] [9] [10] [11] [12] [15]

## 1. THE CIVIC WORDS ARE ALREADY THERE

## Culture of peace, Pacific Way and lives worth living

The strongest opening is not hidden between lines. It is already stated in the words culture of peace, talanoa, consensus, sovereignty, democracy, peaceful settlement and free, healthy and productive lives. These words invite civic practice, not only institutional language.

Read beside the Vuvale Union, the field becomes wider and more concrete: dignity, prosperity, climate, people connections, education, health, digital systems, infrastructure, First Nations heritage, mobility and community leadership. We can treat these as connected parts of peace rather than separate policy boxes. [2] [3]

Article 12 also creates a pathway for other Pacific states to join the Alliance. Any wider participation could carry locally chosen civic contributions as well as national commitments. Each place could bring its own language, law, culture, priorities and methods of working together. [2]

| A clear civic reading<br>Peace is practised through how we talk, learn, care, build, share knowledge, move between places, protect culture and solve problems together. |
| --- |

## 2. THE PROTOPIAN GAMBIT

## Useful now, stronger together later

A Protopian Gambit is an opening move that improves something real while deliberately increasing future options. It avoids the promise of a perfect final system. We try, measure, learn, correct and carry forward what proves useful and appropriate. [6]

That pattern suits a Pacific built from distinct sovereign peoples and places. A united region does not require one model. P4A Oceania describes a Minjerribah seed, an Australian ripple, a Pacific listening layer, self-similar local nodes and a federated Oceania commons. Every place keeps its own centre and decides what to adopt, adapt, share, fork or refuse. [7]

Joyful Responsible Abundance keeps the direction human. Joy without responsibility can become indulgence. Responsibility without joy can become grim control. Abundance without responsibility can become extraction and inequality. Held together, the three words invite lives, systems and technologies that people can help author. [13]

| Start useful | Improve a real local issues now. |
| --- | --- |
| Stay sovereign | Each person and place keeps its centre, language, law, keys, protocols and right to refuse. |
| Learn openly | Document what happened, translate it, teach the next cohort and preserve correction trails. |
| Compound deliberately | Design local gains so they can connect with wider cooperation later. |

## 3. CIVIC PEACE INFRASTRUCTURE

## Six practical strands already connected to the treaty language

| Open civic field | Positive invitation |
| --- | --- |
| Democratic institutions, talanoa and consensus | P4A, Gamify Democracy and Australian Law 2012 could support treaty literacy, public source trails, local deliberation and civic simulation in plain language. [14] [15] |
| Human dignity, prosperity and community | The C-Hour and Braided Economy could recognise freely chosen volunteering as care, mentoring, translation, environmental restoration, disaster preparation and community technology while paid work remains paid. [8] |
| Digital economy and resilient infrastructure | The Senate AI and Data center bundle proposes a federated compute continuum from personal devices to community-scale nodes and larger systems. Locally sovereign AI models, digital twins, XR learning and public science could sit within that shared infrastructure. [10] [11] [12] |
| Climate, ocean and shared science | The Global Sensorium could link more locally governed sensors, open provenance, digital twins and comparative models for oceans, reefs, weather, ecosystems and long-term change. [16] |
| Cultural and people connections | Language, art, film, music, sport, education, mobility, diaspora, family, friendship, sister-city and chosen-family inter-marriage relationships carry knowledge and trust between places. [3] |
| Culture of peace and intelligent systems | GAJRA Earth invites people and AI systems to explore what alignment might become through Joyful Responsible Abundance, while each culture and community keeps its own voice. [13] |

The public record already contains the same pattern at three scales. The local government funding and fiscal sustainability submission places the C-Hour, sovereign digital twins and First Nations data sovereignty at community scale. The AUKUS submission places positive-sum civic capability beside very large national investment and explores the philosophy of what is considerable as national security investment. The Senate AI bundle places distributed sovereign compute, public learning and a 44,000-place global thought experiment into the national AI debate. [8] [9] [10] [11] [12]

## 4. LOVE LINKS INTELLIGENCE

## Family, friendship and inter-cultural marriage connections

Vuvale means family. That language matters because peace travels through relationships as well as formal institutions. Family, friendship, diaspora, study, work, sport, art and shared projects carry language, memory, care, context and early warning across borders. [3]

One study across sub-Saharan Africa found less ethnic conflict where interethnic marriage was more common. Global Group Marriages adds one voluntary adult path to this wider field. Its value rests on equality, clear consent, revocable participation, safe exits and relationships that carry care, knowledge and loyalty across cultures and countries. It sits beside ordinary marriage, friendship, diaspora, education, sport, art and sister-city ties, not above them. [17]

## 5. GAJRA EARTH AND AI ALIGNMENT

## A garland, not a single mould

GAJRA Earth stands for the Global Association for Joyful Responsible Abundance on Earth. Its image is a flower garland: many distinct flowers connected by a shared thread. At planetary scale, the aurora becomes the garland. This is a useful picture of global peace and AI alignment because connection does not require sameness. [13]

AI is entering public administration, education, science, media, infrastructure and daily life. A plural alignment process could invite people to describe the values, virtues, lessons and hopes they associate with the past, present and future, and what Joyful Responsible Abundance means at the scales of self, family, community, Country, nation, region and planet.

Local models and sovereign data make that plurality practical. Models could visit data more often than data leaves its community. Pacific countries and Native Nations could retain authority over language, culture, data, model permissions and what is shared. An open treaty knowledge layer could connect the treaty text, National Interest Analysis, parliamentary reports, work plans and implementation records in plain Australian English and Pacific languages. [14] [16]

## RECOMMENDATIONS

## Positive invitations for the Committee's consideration

> **Recommendation:** 1. A civic implementation frame. Public explanations and future work plans could lead with the treaty's stated culture of peace, Pacific Way, talanoa, consensus, sovereignty, democratic institutions, peaceful settlement and free, healthy and productive lives.

> **Recommendation:** 2. A joined-up reading of the two treaties. The Ocean of Peace Alliance and Vuvale Union could be presented together so people can see the connected fields of dignity, prosperity, climate, culture, people, education, health, infrastructure and digital systems.

> **Recommendation:** 3. A small network of locally governed civic pilots. Willing Pacific communities could test different combinations of C-Hours, local compute, digital twins, ocean and climate sensing, language tools, public science, arts, film and youth exchange. Each pilot could keep its own name, governance, data rules and right to adapt or refuse.

> **Recommendation:** 4. A public treaty knowledge layer. Treaty text, analyses, parliamentary reports, work plans, decisions, sources and progress could be linked, versioned, machine-readable and translated.

> **Recommendation:** 5. Plural AI alignment through GAJRA Earth. Voluntary multilingual reflection on Joyful Responsible Abundance, including values of the past, present and future, could inform locally governed and regional AI work without flattening difference.

> **Recommendation:** 6. People-to-people peace. Family, friendship, diaspora, education, sport, art, sister-city and chosen-family inter-marriage relationships could receive visible support as living channels of trust and shared intelligence.

> **Recommendation:** 7. A civic peace dividend. An annual public account could track wellbeing, participation, skills, local capability, climate and ocean knowledge, cultural and language vitality, community contribution and cooperation across borders.

## CONCLUSION

## Build peace together, grain by grain

An Ocean of Peace becomes visible in what we build together every day. The treaty already gives us a clear civic vocabulary. The Vuvale Union adds practical fields. The Protopian Gambit keeps the first step useful. Joyful Responsible Abundance gives it direction. P4A helps us understand choices. The C-Hour recognises contribution. Sovereign compute and shared science spread capability while communities keep their centre. GAJRA Earth invites plural alignment. Love carries intelligence between people and places.

This submission offers one invitation: start useful, stay sovereign, learn openly, compound deliberately and build peace together, grain by grain.

## SELECTED SOURCES AND RELATED SUBMISSIONS

| [1] JSCOT, Ocean of Peace Alliance inquiry. [Inquiry page](https://www.aph.gov.au/Parliamentary_Business/Committees/Joint/Treaties/OceanofPeaceAlliance)<br>[2] DFAT, Ocean of Peace Alliance, full Veitacini Treaty text. [Official text](https://www.dfat.gov.au/countries/fiji/ocean-peace-alliance-veitacini-treaty)<br>[3] DFAT, Fiji-Australia Vuvale Union. [Official text](https://www.dfat.gov.au/countries/fiji/fiji-australia-vuvale-union)<br>[4] Pacific Islands Forum, Blue Pacific Ocean of Peace Declaration, Annex 3 of the 2025 Leaders Communique. [Official PDF](https://forumsec.org/sites/default/files/2025-09/54th%20Pacific%20Islands%20Forum%20Leaders%20Communique_final.pdf)<br>[5] Pacific Islands Forum, 2050 Strategy for the Blue Pacific Continent. [Official page](https://forumsec.org/2050)<br>[6] Hayes, The B.E.L.A.U. Protopian Gambit, Pacific-facing discussion paper, 21 August 2026.<br>[7] P4A Oceania Cinema, public civic prototype. [Public site](https://auraofintelligence.github.io/p4a-oceania-cinema/)<br>[8] House inquiry into Local Government Funding and Fiscal Sustainability, Submission 2, Mr Luke Nathan Hayes. [Official submissions](https://www.aph.gov.au/Parliamentary_Business/Committees/House/Regional_Development_Infrastructure_and_Transport/LocalGovernmentFunding/Submissions)<br>[9] Hayes, AUKUS Public Inquiry submission, lodged 25 August 2026. | [10] Hayes, Senate AI and data centres submission, lodged 27 August 2026. [Inquiry page](https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Environment_and_Communications/AIdatacentres48P)<br>[11] Hayes, A Fair Go for the AI Age, companion paper lodged 27 August 2026.<br>[12] World Cities, 44,000 Records with Population, March 2023 SimpleMaps-derived snapshot, lodged 27 August 2026.<br>[13] GAJRA Earth, Global Association for Joyful Responsible Abundance on Earth. [Public site](https://auraofintelligence.github.io/gajra-earth-claude-build/)<br>[14] Australian Law 2012: Luke's Relevance. [Public site](https://auraofintelligence.github.io/australian-law-2012-lukes-relevance/)<br>[15] P4A civic workbench. [Public site](https://p4a.xyz)<br>[16] Hayes, Strategic Plan for a Decentralised Global Sensorium, working paper.<br>[17] Demarest and Haer, A perfect match? The dampening effect of interethnic marriage on armed conflict in Africa. [DOI](https://doi.org/10.1177/07388942211050875) |
| --- | --- |
