<!-- Public Markdown edition generated from the supplied DOCX. Wording and document order are preserved; page layout and Word-only formatting are normalised. -->

SUBMISSION TO THE JOINT STANDING COMMITTEE ON TREATIES

Fiji-Australia Vuvale Union

Building Economies: Life, Action and Unity through Joyful Responsible Abundance

| Submitter | Luke Nathan Hayes |
| --- | --- |
| Location | Minjerribah / North Stradbroke Island, Queensland |
| Date | 29 August 2026 |
| Inquiry | Fiji-Australia Vuvale Union |

| Central proposition<br>I support the Fiji-Australia Vuvale Union and its language of family, trust, respect, responsibility, prosperity, resilience and people-to-people connection. My invitation to the Committee is a practical civic on-ramp that gives those words daily meaning within Joyful Responsible Abundance, while leaving both countries free to choose. Fiji and Australia could test a diverse family of locally chosen projects linking community-scale AI, food waste reduction, civic health research, disaster resilience, co-operative ownership and recognition of voluntary contribution. Each part can stand alone. Together they form a Braided Economy in which money, contribution and public value work side by side, while individuals, communities and nations keep their own sovereign centre. |
| --- |

## EXECUTIVE SUMMARY

## Committee members, here is the possibility I ask you to consider

The Vuvale Work Plan offers room for a connected family of practical experiments that Fiji and Australia shape together. Living on an Australian island, I see the everyday links between food, health, local government, technology, culture, family and disaster resilience. Government departments separate these subjects. Ordinary life braids them back together.

My preference is to keep authority close to the people and places affected, while useful public institutions provide support, shared standards and capability. Self-sovereignty means the practical ability of a person, community or country to say yes, no, not yet, show me the evidence, let me leave, and let me take my information with me. Cooperation matters because no household, island or country can build everything alone. Vuvale holds both ideas together: family without assimilation, unity without sameness, and shared capability without permanent dependency.

The treaty already opens the door. It describes Vuvale as family grounded in trust, loyalty, duty, respect, understanding and responsibility. It proposes progressive steps, prosperity and resilience, cultural and people connections, human dignity, a digital economy, resilient infrastructure, education, healthcare and a culture of peace. It creates a Vuvale Forum that may invite traditional, religious, community and business leaders, and a Vuvale Bukmak that will maintain a long-term Work Plan. Later arrangements can give particular ideas practical form. [2] [3]

The organising frame I offer is B.E.L.A.U., Building Economies: Life, Action, Unity. Life asks what helps people, culture and Country flourish. Action asks how values become useful capability. Unity asks how distinct people and places can cooperate while keeping their own centre. A Protopian Gambit is a first move that improves something real, produces evidence and leaves more choices for the next move. Joyful Responsible Abundance gives it a compass: life worth living, consequences cared for, and useful capability spreading rather than concentrating. [17] [20] [22]

A practical on-ramp could be an indicative AUD100 million Civic Empowerment pilot. Five to ten community-scale AI racks at the AUD6 million planning figure used in my Senate AI and data centres submission would cost AUD30 million to AUD60 million. The remaining AUD40 million to AUD70 million could fund the people, local models, food tools, digital twins, co-operative finance, health research, disaster functions and independent evaluation that make the hardware useful. [19]

A rack without local purpose, skills and trust is just an expensive cupboard of computers. The pilot would therefore compare deliberately different settings, communities and ownership models rather than copy one design everywhere. It would start the on-ramp, learn in public, repay debt early when value appears, and leave every participant free to adapt, connect, pause or refuse.

## 1. VUVALE AS A WORKING PRINCIPLE

## Family without sameness

Vuvale means family in every sense, including the generous expression 'my home is your home'. The earlier partnership connects that idea to respect, reciprocity, shared responsibility, careful listening, common wellbeing and helping each other grow as individual sovereign states and as partners. The 2026 treaty carries those ideas forward. [2] [3]

A family can share a table without eating the same meal. That is how I read the most useful civic promise in Vuvale. Fiji and Australia can share capability, knowledge, finance and lessons while each keeps its own laws, culture, priorities and right to choose.

| Vuvale principle | What it means in this submission |
| --- | --- |
| Family and reciprocity | The relationship aims to create mutual care, mutual benefit and growing capability on both sides. |
| Trust and careful listening | We explain unusual ideas plainly, publish what happened, admit what failed and correct course. |
| Sovereignty and connection | A person, community, First Nation, institution and country can each keep authority over what belongs at their layer while connecting what they choose. |
| Human dignity | People remain participants, decision-makers and possible owners, with paid work and voluntary contribution kept clearly distinct. |
| Prosperity and resilience | Useful systems help during ordinary life and remain useful when food, power, communications or supply chains are disrupted. |
| Progressive evolution | We can begin with a bounded pilot and grow only what earns evidence, trust and local support. |

This reading fits the treaty's practical machinery. The Vuvale Forum can bring different voices into the conversation. The Vuvale Bukmak can develop a phased Work Plan. Subsidiary agreements or implementing arrangements can follow later if a particular function proves useful. Each function can sit within an existing or locally chosen institution, keeping the field plural and connected. [2]

## 2. THE TERMS IN PLAIN AUSTRALIAN ENGLISH

## Committee members, here is the machinery in plain language

Several of these ideas have unusual names, so the short definitions below explain exactly how they are used throughout this submission.

| When I say... | I mean... |
| --- | --- |
| Self-sovereignty | The practical ability to understand the rules, say yes or no, change your mind, leave a system and take your own data or assets with you. It can exist at individual, community and national levels. |
| Braided Economy | Ordinary money keeps doing money's job. A second record recognises freely chosen community contribution. A third record tracks results such as savings, skills and resilience. The strands inform each other without pretending to be the same thing. |
| C-Hour | A receipt for one verified hour of voluntary contribution. One hour equals one hour. It is earned through real human activity, radical equality everyone’s hour is exactly 1 C-hour, is untaxable, has no allowance for financial speculation, and is kept clearly separate from wages. Each community chooses eligible actions, verification, privacy and rewards. |
| Co-operative | A business owned by its members. One member, one vote is a common form. Members can share an asset, elect the people who manage it and decide whether surplus reduces prices, repays debt, builds reserves or returns to members as a patronage rebate. |
| Local AI rack | A cabinet of high-powered computers that can run useful AI and simulation close to the people it serves. It fills the missing middle between a personal laptop and a giant corporate data centre. |
| Sovereign AI model | An AI system run under rules chosen by the people, institution or country using it. Practical sovereignty includes control over data, permissions, keys, model choice, location, portability and the ability to change provider. |
| Digital twin | A practical digital model of something real, such as a person, home, farm, town, reef, road, clinic or food system. It combines agreed information so people can see conditions, test options and learn before changing the physical world. |
| Federated model | An awkward technical name for a simple idea: let the model travel to the data instead of dragging all the data away. A local system can return an agreed result or model improvement while the raw records remain where they are. |
| Disaster mode | The same equipment does useful work every day, then sheds power-hungry tasks during an outage and keeps essential maps, messages, directories and local coordination running. |
| De-Slop and civic health | My deliberately blunt shorthand for reducing avoidable burdens on body, mind and information. The practical starting points are ordinary: better food, sleep, movement, clean environments, clear information and access to good care. More experimental health tools belong in properly approved research. |
| GAJRA Earth | The Global Association for Joyful Responsible Abundance on Earth. Its image is a flower garland: many distinct flowers connected by a shared thread, with each flower keeping its own form. It offers one voluntary way for people and AI systems to explore values while each culture keeps its own voice. |

Fiji already has a substantial co-operative movement rooted in the Fijian principle of solesolevaki, or collective effort. The Fiji Government reported about 715 registered co-operatives across 15 sectors, around 40,000 members and FJD151 million in assets in 2025. This proposal builds from that existing strength and asks whether it could connect to new shared assets and new forms of public value. [7]

## 3. ONE COMMUNITY, ONE CONNECTED EXAMPLE

## Here is what the whole proposal could look like in ordinary life

The example below leaves the location and institutional choice with Fiji. Its purpose is to show the connections as one working loop rather than a pile of project names.

### 1. Choose the purpose before the technology

A willing community begins with a problem it already recognises. It might be food waste, a lack of local digital skills, expensive cloud services, unreliable communications, better disaster information, or stronger local health and education. The first question is: 'What useful local result are we trying to create?'

### 2. Choose who holds the asset

The community and Fiji could choose a co-operative, university, municipality, provincial or customary body, health provider, trust, business partnership or another locally suitable holder. What matters most is that ownership, duties and exit are understood. A co-operative is one useful option because people who use and support the asset can also own and govern it.

### 3. Install the missing middle and train local people

A shared rack is installed with power, connectivity, maintenance and clear local responsibilities. Local technicians, students and community helpers learn to operate it. In this submission, trusted local people who explain the tools, help elders and beginners, and keep practical knowledge in the community are called Digital Custodians.

### 4. Give people a daily reason to use it

The rack can host local language tools, education, small business support, creative work and a practical food system. A Kitchen Mate can scan receipts, track pantry items and dates, and suggest meals using food already available. A Garden Mate can help plan and record household or community growing. A Fermentation Mate can guide safe preservation of surplus. An Event Mate can coordinate shared meals, dietary needs, tasks and shopping. These names describe functions, not a required brand. [24]

### 5. Recognise contribution without stealing wages

People might voluntarily help with food audits, community gardens, translation, mentoring, cultural work, environmental care, digital mapping or disaster preparation. One verified hour can be recorded as one C-Hour. The community chooses what a C-Hour can unlock, such as training, transport, local food, events, shared equipment or approved wellbeing services. The boundary is simple: C-Hours recognise genuinely voluntary contribution, while paid work remains paid. [13] [14] [18] [21]

### 6. Keep information close and share lessons by consent

Personal information stays with the person. Collective cultural or environmental knowledge stays under the authority of its custodians. A digital twin can show agreed patterns in the food system, infrastructure or environment without exposing every household record. Federated models can send approved lessons or model improvements outward while raw data stays local. [25]

### 7. Let ordinary infrastructure become disaster infrastructure

During normal weeks, the node supports learning, local services and planning. When a cyclone, cable break or grid failure arrives, it can move into disaster mode. High-power tasks stop. Low-power maps, directories, local messages and mesh communications continue. Equipment that people use and maintain every week is more likely to work when it is genuinely needed. [25]

### 8. Spread the cost and keep the end of the loan visible

The public contribution can carry the benefits that are hard to sell, such as open knowledge, disaster readiness, equitable access and evaluation. A 1 to 5 year co-operative or institutional loan can carry assets expected to earn cash or measurable savings. Early repayment carries no penalty, so success shortens debt at no extra cost. At the end of the term, the community can own a debt-free asset, refinance it, transfer it under agreed rules, or close the project if the value did not appear. [23]

Seen together, the eight steps form one loop: choose a local purpose, share an asset, build local skill, create daily value, recognise contribution, protect data, prepare for disruption, measure results and decide what deserves to grow.

## 4. A SERIOUS BUT BOUNDED AUD100 MILLION ON-RAMP

## Start large enough to matter and small enough to learn

AUD100 million is an indicative scale for a family of projects rather than one cheque or one procurement. It is large enough to test infrastructure, ownership, food, health, data and resilience together, while remaining bounded enough for the parties to compare approaches and stop what does not work.

Using the AUD6 million planning figure from my Senate submission, five racks cost AUD30 million and ten cost AUD60 million. The difference matters because the people, purposes and services around each rack turn hardware into civic capability.

| Illustrative path | Rack allocation | What the rest of the envelope could carry |
| --- | --- | --- |
| Five-rack path | AUD30 million | About AUD70 million remains for local models, food and household tools, digital twins, training, co-operative finance, C-Hour trials, health research, disaster functions, maintenance and evaluation. |
| Ten-rack path | AUD60 million | About AUD40 million remains for the same surrounding functions, while more locations and ownership models can be compared. |

The placements would be deliberately different. One might be urban. One might serve a regional or maritime community. One could sit with a university or skills hub. One could connect health and education. One could be owned through a co-operative or another local arrangement. The point is to learn from difference rather than hide it.

The Fiji Bureau of Statistics currently projects a 2026 population of 902,623. The wider rule of thumb of one rack-equivalent per 10,000 people therefore points to roughly 90 rack-equivalents over time. That is a horizon rather than the pilot. Fiji's geography adds another guide: a smaller island may justify an independent smaller node because distance, cable risk, transport and disaster needs matter. [8]

AUD100 million is serious bilateral money. Australia's 2026-27 bilateral allocation for Fiji is AUD64 million and total Australian aid benefiting Fiji is estimated at AUD124.2 million. Fiji is also receiving a FJD300 million Chinese grant for the Vanua Levu road project, roughly AUD189 million at the Reserve Bank of Fiji's 27 August 2026 exchange rate. These comparisons show the scale of existing relationships. Civic empowerment that carries infrastructure responsibilities can be discussed at infrastructure scale. [4] [5] [6]

## 5. HOW THE MONEY, C-HOURS AND VALUE COULD BRAID

## Share the cost, share the value, keep the exit visible

The financing becomes clearer when each form of value keeps its own account. A public grant, a loan, a C-Hour and a social benefit carry different responsibilities. They can support one another while remaining honestly separate.

| Layer | What it can carry | How it is treated |
| --- | --- | --- |
| Public grant or guarantee | Open knowledge, training, equitable access, disaster readiness, cultural capability, research and independent evaluation. | A grant carries agreed public value without repayment. A guarantee responds only if the agreed borrower cannot meet the loan. |
| Co-operative or institutional loan | Racks, shared equipment and other assets expected to produce service income or cashable savings. | One to five years, with clear repayments and no penalty for paying the principal early. |
| Member or institutional contribution | Member shares, prepaid use, service contracts, sponsorship, land, buildings or in-kind support. | Handled under the rules chosen for the local entity. |
| C-Hour | Recognition and access for verified voluntary contribution. | Bank debt is repaid in money. C-Hours can reduce the amount of cash a participant needs for locally agreed benefits. |
| Outcome account | Food saved, costs avoided, services delivered, uptime, skills, health findings, participation and resilience. | It tells everyone whether the opening value case was real and whether the next stage deserves support. |

Each project could publish an opening value case before borrowing: its best honest estimate of expected income, savings and wider public value. Annual reports then replace expectation with evidence. Debt can stay inside the conservative cash case. A project expecting AUD2 million a year in cash and savings carries a much smaller loan than one expecting AUD10 million. If AUD40 million is financed over five years, principal recovery alone is AUD8 million a year before interest. The grant and loan proportions can move to suit the expected value and useful life of each asset.

Co-operative surplus can also shorten the term. A patronage rebate is the plain idea that some surplus can be returned to members according to their use or contribution. Members may choose to apply it to fees or loan principal. Penalty-free early repayment keeps the finance aligned with shared ownership and capability. [23]

Legalising the C-Hour can also begin modestly. Early trials could use a limited community record rather than declare a new national currency. The C-Hour could be earned, not purchased; used only within an agreed program; kept non-speculative; and separated clearly from employment. Where an employment relationship exists, the worker is paid. If a digital reward becomes a general payment tool, financial and payment laws may apply. Australia and Fiji already have regulators and innovation pathways that could examine those boundaries before wider use, including ASIC, the Fair Work Ombudsman, the Reserve Bank of Fiji's National Payment System and the Fiji Innovation Hub. [11] [12] [13] [14]

If later evidence supports a special legal category, both countries could explore a plain form of community contribution receipt or regenerative asset. The name matters less than the boundaries: voluntary, verifiable, non-speculative, transparent, portable where agreed and easy to leave.

## 6. FIRST USES THAT PEOPLE CAN FEEL

## Food, intelligence, resilience, health and relationships

### Food and household savings can provide the first visible dividend

Food is a practical starting point because people can feel the result in a fridge, a garden, a shopping bill and a rubbish bin. The Kitchen, Garden, Fermentation and Event functions can connect what is grown, bought, stored, cooked, preserved and shared. Households can save money. Farmers and markets can see demand. Hotels, schools and hospitals can reduce avoidable waste. Local authorities can reduce collection and landfill pressure. Community groups can redirect safe surplus and build food reserves for disruption. [24]

Australia estimates that food waste costs its economy about AUD36.6 billion each year. A 20 per cent reduction would equal about AUD7.3 billion. Fiji can establish its own household, hospitality, market and municipal baseline, then measure the result of each pilot on Fijian terms. The first dividend is evidence, followed by whatever real savings the evidence shows. [9] [10]

C-Hours fit here without replacing employment. A person might voluntarily help map a community garden, teach preservation, translate food guidance, check an emergency pantry or coordinate a shared meal. Local rules decide what counts and what access follows.

### Local AI can help without turning every person into a product

The missing middle gives communities computing power of their own. A local model can support language, education, public information, farming, health administration, creative work, small business and legal or policy research. It can be adapted to local vocabulary and priorities. It can also compare commercial and open models rather than tying the whole partnership to one company.

The layers matter. Personal information belongs with the person. Family or collective knowledge can carry family or collective rules. Cultural and environmental knowledge can remain under the authority of its custodians. Institutions and governments can receive the summaries and services they are authorised to receive. Federated models and digital twins make cooperation possible without one central database of everyone and everything. [25]

The same infrastructure can support skills. Fiji's existing education institutions, Innovation Hub, co-operatives, businesses and community organisations could train local technicians, model builders, translators, artists, data stewards and Digital Custodians. Mobility between Fiji and Australia can then leave a skills dividend in both places rather than only move labour from one shortage to another. [3] [11]

### Disaster resilience can be designed into equipment used every day

Pacific resilience belongs in the everyday design. A local node can cache maps, emergency guidance, local contacts and public records. It can connect to low-power mesh radios, solar and batteries. When links return, it can synchronise. During ordinary life it remains useful for education, food, culture and business, which gives people a reason to know it, maintain it and notice when it fails. [25]

### Civic health can begin with research rather than promises

I use De-Slop as blunt shorthand because our bodies and information environments carry accumulated rubbish. The sensible beginning is ordinary: better food, movement, sleep, cleaner environments, accessible health information and individual control of health data. A further research stream could examine shared preventive and restorative facilities, including sauna and properly regulated hyperbaric oxygen therapy, where professionals, ethics and evidence support it. [15] [16] [25]

My wider Oceania working papers sketch a long-horizon thought experiment of 600,000 HBOT chambers and 600,000 saunas. At target manufacturing figures of AUD35,000 and AUD5,000, the bare equipment total is AUD24 billion inside a broader AUD42.35 billion placeholder plan for deployment, people and systems. The immediate invitation is a much smaller research path. The Committee can treat the larger horizon as a direction of travel rather than a funding request or a proven health claim. Advanced health infrastructure could become a shared community asset, and smaller pilots could earn the right to grow through evidence. [23] [25]

Co-operative loans are relevant because an expensive device can be shared across many members and services. Public funding can support research and equitable access. Service income can repay the asset. C-Hours can recognise genuine community contribution and widen access. Health savings stay outside the base financial case until research demonstrates them.

### Love links intelligence

Vuvale becomes real through people. Education, family, friendship, diaspora, faith, art, film, music, sport, work and shared projects move language, memory, skills, care and early understanding between countries. These relationships are part of the intelligence of the partnership and carry economic, civic and cultural value. [3]

Global Group Marriages appears as one voluntary adult thought experiment within that wider field. It asks whether freely chosen family links across cultures and countries can carry care and understanding over generations. It sits beside ordinary marriage, friendship, diaspora, sister-city ties, education, art and sport. [26]

GAJRA Earth offers a related AI alignment idea. People in different cultures could describe the values, virtues, lessons and hopes they associate with the past, present and future, and what Joyful Responsible Abundance means at the scales of self, family, community, Country, nation, region and Earth. Local models could keep those voices distinct while federated systems share agreed lessons. The garland becomes a useful image: connection without one mould. [22]

## 7. WHAT WE WOULD LEARN

## Three honest accounts, each answering a different question

The pilot would be easier to trust if it kept three accounts visible from the start.

| Account | The honest question it answers |
| --- | --- |
| Money account | What was spent, borrowed, earned, saved, repaid and retained locally. This is the account that services loans and pays wages, suppliers and tax. |
| Contribution account | Which voluntary actions earned C-Hours, who verified them, who used the resulting benefits, and whether participation remained genuinely free. |
| Public value account | Food saved, landfill reduced, services delivered, data kept local, disaster uptime, skills created, research findings, health access, cultural activity and lessons shared. |

An annual public account could compare the different pilots without pretending they are identical. It could show which ownership forms worked, which models were useful, what people refused, whether loans were repaid early, whether data stayed where promised, and whether any claimed savings reached households or public budgets.

A Protopian pilot publishes failure as well as success. If a tool does not help, we change it or stop. If one community creates a better version, others can learn from it while keeping their own choice. Success means more capability, more informed choice and less dependency at the end than at the beginning.

## RECOMMENDATIONS

## Positive invitations for the Committee's consideration

Committee members, I care more that the useful function exists than which logo sits above the door. These recommendations are therefore deliberately open about the final vehicle. They could be explored through the Vuvale Forum, the Vuvale Bukmak and Work Plan, existing development programs, Fiji's Innovation Hub, universities, municipalities, provincial and customary bodies, co-operatives, community organisations, businesses, finance partners or later implementing arrangements chosen by Fiji and Australia.

> **Recommendation:** 1. Keep a civic possibility stream open in the Vuvale Work Plan. The Committee could invite the parties to reserve visible space for locally chosen experiments in human dignity, prosperity, digital capability, food, health, culture and resilience. This connects to Vuvale's principles of family, listening and progressive evolution.

> **Recommendation:** 2. Explore an indicative AUD100 million Civic Empowerment on-ramp. Five to ten AUD6 million community-scale AI racks could be placed with deliberately different groups and settings, while the remaining envelope supports local models, people, food tools, digital twins, disaster functions, health research, co-operative finance and evaluation. This connects to prosperity, resilient infrastructure and the digital economy.

> **Recommendation:** 3. Make food and household savings the first visible value test. Willing households, farmers, markets, tourism operators, schools, health services, local bodies and community groups could test inventory, growing, preservation, sharing and waste measurement. Fiji's own baseline would guide any savings claim. This connects to life, climate, resilience and human dignity.

> **Recommendation:** 4. Trial the C-Hour carefully and plainly. One verified hour of genuine voluntary contribution could be recorded as one C-Hour within limited local programs. Paid work would remain paid. Communities could choose eligible activities, verification, privacy, rewards, transfer and exit, while Australian and Fijian regulators examine employment, tax, consumer and payment boundaries. This connects to reciprocity, trust and responsibility.

> **Recommendation:** 5. Spread asset costs through fair shared finance. Co-operatives and other locally chosen holders could combine grants, guarantees, member shares, service contracts and 1 to 5 year loans with no penalty for early repayment. Opening value cases and annual results could guide repayment, patronage rebates, refinancing, transfer or closure. This connects to shared responsibility, prosperity and freedom from permanent dependency.

> **Recommendation:** 6. Keep intelligence close while learning together. Participating groups could run local and sovereign AI models, build useful digital twins, keep personal and collective data under the authority of its owners and custodians, and share only agreed results or model improvements. This connects to sovereignty, trust, safe digital systems and First Nations heritage.

> **Recommendation:** 7. Build daily usefulness and disaster readiness into the same assets. Local racks, kiosks, solar, batteries, cached information and low-power communications could support ordinary education, food, business and culture, then move into maps, messages and local coordination during disruption. Carefully governed health research could use the same local skills and data protections. This connects to resilience, climate, health and care.

> **Recommendation:** 8. Treat people, culture and plural alignment as infrastructure. Education, mobility, local skills, family, friendship, diaspora, faith, art, film, music, sport and voluntary intercultural relationships could remain visible parts of the Vuvale Work Plan. GAJRA Earth's Joyful Responsible Abundance process could offer one voluntary way to connect many cultural voices to local and regional AI systems. An annual public account could show what we learned together. This connects to cultural and people connections, family and a culture of peace.

## CONCLUSION

## A practical on-ramp that earns its next step

Committee members, Vuvale already gives Fiji and Australia the relationship: family, trust, respect, responsibility and a commitment to grow together. The open question is what useful capability we place inside that relationship.

The connected possibility offered here lets a Braided Economy keep money, voluntary contribution and public value distinct while they support each other. Local AI racks fill a missing middle. Sovereign models, digital twins and federated learning let places cooperate while keeping authority over their own information. Food gives the first everyday value loop. Disaster mode gives the infrastructure a second life when normal systems fail. Co-operative finance spreads cost and ownership through 1 to 5 year terms, with no penalty for early repayment. Health research, culture and people-to-people links keep the technology connected to life.

The Committee can treat the long-horizon ideas as possibilities to test rather than promises to believe. The treaty's words are wide enough for us to explore them together. Start useful. Stay sovereign. Learn openly. Repay early when success allows. Compound what earns trust. That is the Protopian Gambit I offer for building economies of life, action and unity through Joyful Responsible Abundance.

## SELECTED SOURCES AND RELATED WORK

Official sources establish the treaty, current public funding and regulatory settings. My lodged submissions, public prototypes and working papers describe the proposal. The working papers are design sources rather than independent proof. Health claims remain subject to research, ethics and regulation.

| [1] Joint Standing Committee on Treaties, Fiji-Australia Vuvale Union inquiry. [Inquiry page](https://www.aph.gov.au/Parliamentary_Business/Committees/Joint/Treaties/FijiAUVuvale)<br>[2] Department of Foreign Affairs and Trade, Fiji-Australia Vuvale Union, signed 6 July 2026. [Official treaty text](https://www.dfat.gov.au/countries/fiji/fiji-australia-vuvale-union)<br>[3] Department of Foreign Affairs and Trade, Fiji-Australia Vuvale Partnership, 18 October 2023. [Official partnership](https://www.dfat.gov.au/geo/fiji/fiji-australia-vuvale-partnership)<br>[4] Department of Foreign Affairs and Trade, Australia's development partnership with Fiji. [Official page](https://www.dfat.gov.au/geo/fiji/development-assistance/development-partnership-with-fiji)<br>[5] Department of Foreign Affairs and Trade, Australia's Official Development Assistance Budget Summary 2026-27. [Budget summary](https://www.dfat.gov.au/about-us/corporate/portfolio-budget-statements/australias-official-development-assistance-budget-summary-2026-27)<br>[6] Office of the Prime Minister of Fiji, China Aid Vanua Levu Road Upgrading Project, FJD300 million grant. [Official release](https://www.pmoffice.gov.fj/keynote-address-for-the-approval-ceremony-of-the-external-review-of-the-preliminary-design-china-aid-fiji-vanua-levu-road-upgrading-project/)<br>[7] Office of the Prime Minister of Fiji, solesolevaki and the International Year of Co-operatives 2025. [Official release](https://www.pmoffice.gov.fj/pm-rabuka-emphasises-community-empowerment-through-solesolevaki-at-the-launch-of-the-international-year-of-co-operatives-2025-27-03-2025/)<br>[8] Fiji Bureau of Statistics, 2026 population projection and Population Grid 2026. [Official statistics](https://www.statsfiji.gov.fj/fiji-population-grid-2026/)<br>[9] Australian Government, Reducing Australia's food waste. [Official page](https://www.dcceew.gov.au/environment/protection/waste/food-waste)<br>[10] Fiji Bureau of Statistics, Fiji's Experimental Environmental Account for Solid Waste 2025. [Official release](https://www.statsfiji.gov.fj/fijis-experimental-environmental-account-for-solid-waste-2025/)<br>[11] Reserve Bank of Fiji, Fiji Innovation Hub. [Official release](https://www.rbf.gov.fj/joint-media-release-fiji-launches-innovation-hub-with-european-union-australia-and-new-zealand-support/)<br>[12] Reserve Bank of Fiji, National Payment System Act and Regulations. [Official page](https://www.rbf.gov.fj/core-functions/financial-system-development/national-payment-system/)<br>[13] Australian Securities and Investments Commission, Digital assets: financial products and services. [Official guidance](https://www.asic.gov.au/regulatory-resources/digital-transformation/digital-assets-financial-products-and-services) | [14] Fair Work Ombudsman, unpaid work and volunteering. [Official guidance](https://www.fairwork.gov.au/starting-employment/unpaid-work)<br>[15] Therapeutic Goods Administration, risk of fire during use of hyperbaric chambers. [Official safety advice](https://www.tga.gov.au/safety/safety-monitoring-and-information/safety-alerts/risk-fire-during-use-hyperbaric-chambers)<br>[16] National Health and Medical Research Council, Human Research Ethics Committees. [Official ethics guidance](https://www.nhmrc.gov.au/research-policy/ethics/human-research-ethics-committees)<br>[17] Hayes, Ocean of Peace Alliance submission, lodged 27 August 2026.<br>[18] House inquiry into Local Government Funding and Fiscal Sustainability, Submission 2, Mr Luke Nathan Hayes. [Official submissions](https://www.aph.gov.au/Parliamentary_Business/Committees/House/Regional_Development_Infrastructure_and_Transport/LocalGovernmentFunding/Submissions)<br>[19] Hayes, Senate AI and data centres bundle, including A Fair Go for the AI Age and the 44,000-place world cities dataset, lodged 27 August 2026. [Inquiry page](https://www.aph.gov.au/Parliamentary_Business/Committees/Senate/Environment_and_Communications/AIdatacentres48P)<br>[20] Hayes, The B.E.L.A.U. Protopian Gambit, Pacific-facing discussion paper, 21 August 2026.<br>[21] P4A Oceania and Native Nations C-Hour pages, with Grain by Grain threats and resilience. [P4A Oceania C-Hours](https://auraofintelligence.github.io/p4a-oceania-cinema/pages/c-hours.html)<br>[22] GAJRA Earth and P4A Oceania Cinema public prototypes. [GAJRA Earth](https://auraofintelligence.github.io/gajra-earth-claude-build/)<br>[23] Hayes, Health-Tech Co-operative Business Plan, including group finance, shared assets and patronage rebates.<br>[24] Hayes, Integrated Food System AI Expansion and Full Spectrum Consumption work, including Kitchen, Garden, Fermentation and Event functions.<br>[25] Hayes, Architectural Blueprint for Oceania and related sovereign compute, disaster resilience, digital twin and De-Slop working papers.<br>[26] Demarest and Haer, A perfect match? The dampening effect of interethnic marriage on armed conflict in Africa. [DOI](https://doi.org/10.1177/0022343317727894) |
| --- | --- |
