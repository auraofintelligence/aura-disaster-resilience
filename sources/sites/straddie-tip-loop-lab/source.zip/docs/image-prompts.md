# Image Prompt Notes

Built-in image generation was used for the project hero assets. The final PNG outputs were copied into this repo and converted to WebP for page use.

## Shared Direction

All hero images were requested as wide 16:9 editorial-documentary scenes, with useful negative space on the left for code-native webpage text. Prompts asked for no readable text, no logos, no watermarks, no dump scavenging scene and no identifiable people.

## Page Assets

- `home-reuse-depot.webp` - lawful pre-tip reuse depot beside coastal bushland, with lockable containers and sorted useful objects.
- `material-streams.webp` - clean material streams on workshop benches: plastic flakes, metals, cardboard, glass, copper wire and electronic components.
- `lawful-loop-design.webp` - covered intake bay, donation table, scale, repair triage bench and lockable storage.
- `microfactory-tools.webp` - compact container microfactory with robot arm, 3D printers, recycled filament and electronics trays.
- `governance-evidence.webp` - community workshop evidence table with material samples, model depot, abstract ledger blocks and public-policy mood.
- `ecosystem-links.webp` - physical model table connecting maker-space, tip loop, energy, ferry terminal, sand systems and civic prototypes.
- `field-records.webp` - Markdown record desk with clipboards, material samples, camera, scale and review workflow.
- `sources-trail.webp` - source-trail desk with documents, island map, material samples and coastal light.
