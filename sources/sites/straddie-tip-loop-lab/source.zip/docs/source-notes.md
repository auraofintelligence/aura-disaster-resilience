# Source Notes For Straddie Tip Loop Lab

This note keeps the public source trail readable and easy to revisit.

## Main Public Framing

The site is a question-led sister repo to Straddie Maker-Space Lab. It explores lawful pre-tip diversion, repair, reuse, material recovery, battery and data sovereignty literacy, AI-assisted sorting, robotics, 3D printing, electronics benches and local microfactory capability.

## Public Sources Linked

- Parliament of Australia submissions page for the Inquiry into Local Government Funding and Fiscal Sustainability
- Redland City Council waste-centre locations page
- Redland City Council RecycleWorld page
- Redland City Council accepted-items and e-waste pages
- Precious Plastic machine overview
- How to Use Markdown with AI public guide and builder
- Existing Straddie Maker-Space Lab public tip-loop page
- Moreton Bay Community Wealth and Mutuals index
- Mineral Moonshots Super-Computers of North Straddie brief
- Brisbane City Council sister cities page for the Kaohsiung relationship
