# Straddie Tip Loop Lab

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 15 June 2026.
- GitHub repository: [straddie-tip-loop-lab](https://github.com/auraofintelligence/straddie-tip-loop-lab).
- Public site: [visit the public site](https://auraofintelligence.github.io/straddie-tip-loop-lab/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 7 relevant public connections.

### Circular making and local infrastructure

- [civilisation-of-sand](https://github.com/auraofintelligence/civilisation-of-sand) - [public page](https://auraofintelligence.github.io/civilisation-of-sand/) - shared community programme.
- [grain-by-grain](https://github.com/auraofintelligence/grain-by-grain) - [public page](https://auraofintelligence.github.io/grain-by-grain/) - shared community programme.
- [Sandworm-subterranean-systems](https://github.com/auraofintelligence/sandworm-subterranean-systems) - [public page](https://auraofintelligence.github.io/sandworm-subterranean-systems/) - shared community programme.
- [shared-table-initiative](https://github.com/auraofintelligence/shared-table-initiative) - [public page](https://auraofintelligence.github.io/shared-table-initiative/) - shared community programme.
- [straddie-clean-energy-superpower](https://github.com/auraofintelligence/straddie-clean-energy-superpower) - [public page](https://auraofintelligence.github.io/straddie-clean-energy-superpower/) - explicit cross-reference, shared community programme.
- [straddie-makerspace-lab](https://github.com/auraofintelligence/straddie-makerspace-lab) - [public page](https://auraofintelligence.github.io/straddie-makerspace-lab/) - explicit cross-reference, shared community programme.

### Direct and other supported connections

- [straddie-noticeboard-network](https://github.com/auraofintelligence/straddie-noticeboard-network) - [public page](https://auraofintelligence.github.io/straddie-noticeboard-network/) - explicit cross-reference.

<!-- github-organisation:end -->

A public, question-led static site exploring a lawful tip-loop and local recycling sister site for Straddie Maker-Space Lab.

The site asks how Minjerribah / North Stradbroke Island might recover more useful material locally, build practical skills, and keep more value on-island before everything gets shipped away.

## Page Map

- `index.html` - Home
- `streams.html` - Material streams
- `loop.html` - Lawful loop design
- `microfactory.html` - AI, robotics and microfactory tools
- `governance.html` - Pilot governance and rule-change pathway
- `ecosystem.html` - Links to the wider Straddie / Aura ecosystem
- `forms.html` - Markdown AI-context builder
- `sources.html` - Public source trail

## How It Works

The source of truth is `tools/build_site.py`.

In simple terms:

1. The Python file stores the page list and public copy.
2. Running it writes the public HTML files.
3. The forms page lets a visitor draft a portable AI-context Markdown file.
4. Hero images live in `assets/img/heroes/`.

## Local Build

```powershell
python tools\build_site.py
```

Then preview:

```powershell
python -m http.server 4188 --bind 127.0.0.1
```

Open:

```text
http://127.0.0.1:4188/
```

## Public Posture

This is a proposal and learning workbench. It is not an approval claim, legal advice, engineering design, handling manual, waste-operation authority, cultural authority statement, funding commitment or Council project page.

## Public page and related work

- [Open Straddie Tip Loop Lab](https://auraofintelligence.github.io/straddie-tip-loop-lab/)
- [Browse the source repository](https://github.com/auraofintelligence/straddie-tip-loop-lab)
- [Straddie Maker-Space Lab](https://auraofintelligence.github.io/straddie-makerspace-lab/)
- [Straddie Clean Energy Superpower](https://auraofintelligence.github.io/straddie-clean-energy-superpower/)
- [Straddie Noticeboard Network](https://auraofintelligence.github.io/straddie-noticeboard-network/)
