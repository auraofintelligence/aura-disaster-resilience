from pathlib import Path
import json


ROOT = Path(__file__).resolve().parents[1]
SITE_URL = "https://auraofintelligence.github.io/straddie-tip-loop-lab/"


def p(text):
    return f'<p class="body-copy">{text}</p>'


def button_row(buttons):
    return '<div class="button-row">' + "".join(
        f'<a class="button {kind}" href="{href}">{label}</a>'
        for label, href, kind in buttons
    ) + "</div>"


def card(title, text, href=None, link=None, icon=None, image=None, image_alt="", kind="route-card"):
    tag = "a" if href else "article"
    href_attr = f' href="{href}"' if href else ""
    icon_html = f'<span data-icon="{icon}"></span>' if icon else ""
    image_html = (
        f'<figure class="card-preview"><img src="{image}" alt="{image_alt}" loading="lazy" width="180" height="180"></figure>'
        if image else ""
    )
    link_html = f'<span class="card-link">{link}</span>' if link else ""
    return (
        f'<{tag} class="{kind}"{href_attr}>'
        f"{icon_html}<h3>{title}</h3><p>{text}</p>{link_html}{image_html}"
        f"</{tag}>"
    )


def grid(items, columns="three", kind="route-card"):
    return (
        f'<div class="grid {columns}">'
        + "\n".join(card(**item, kind=kind) for item in items)
        + "</div>"
    )


def section(title, intro, inner="", band=None, classes=""):
    band_open = f'<div class="{band}">' if band else ""
    band_close = "</div>" if band else ""
    section_class = f"section {classes}".strip()
    return f"""
{band_open}
<section class="{section_class}" aria-labelledby="{slug(title)}">
  <div class="section-head">
    <h2 id="{slug(title)}">{title}</h2>
    {p(intro)}
  </div>
  {inner}
</section>
{band_close}
"""


def slug(text):
    clean = "".join(ch.lower() if ch.isalnum() else "-" for ch in text)
    while "--" in clean:
        clean = clean.replace("--", "-")
    return clean.strip("-") or "section"


def split(title, body, aside_title, aside_body, band="band", reverse=False):
    return f"""
<div class="{band}">
  <section class="section split {'reverse' if reverse else ''}" aria-labelledby="{slug(title)}">
    <div>
      <h2 id="{slug(title)}">{title}</h2>
      {''.join(p(item) for item in body)}
    </div>
    <div class="callout">
      <h3>{aside_title}</h3>
      <p>{aside_body}</p>
    </div>
  </section>
</div>
"""


def flow(items):
    return '<div class="flow">' + "".join(
        f'<div class="flow-step"><strong>{index}</strong><p><b>{title}</b> {text}</p></div>'
        for index, (title, text) in enumerate(items, start=1)
    ) + "</div>"


HOME_BODY = f"""
{section(
    "A sister site for practical recovery.",
    "The maker-space asks what the island could make, fix and learn. This sister site asks what could be intercepted, sorted, repaired, disassembled, documented, remade or sent to the right recycler before value disappears from local view.",
    grid([
        {"title": "Material Streams", "text": "Which plastic, metal, cardboard, cans, glass and e-waste streams could become teachable local stock?", "href": "streams.html", "link": "Open the stream map", "icon": "streams"},
        {"title": "Lawful Loop Design", "text": "What would need to be true for pre-tip offers, supervised handover and clear storage to feel trustworthy?", "href": "loop.html", "link": "Explore the loop", "icon": "loop"},
        {"title": "Microfactory Tools", "text": "How might AI sorting, robotics, 3D printers and compact machines build skills instead of exporting every question?", "href": "microfactory.html", "link": "See the tool stack", "icon": "robot"},
        {"title": "Pilot Governance", "text": "What kind of evidence, rules and local-government pilot framing could remove avoidable caution from the path?", "href": "governance.html", "link": "Read the pilot path", "icon": "ledger"},
        {"title": "Ecosystem Links", "text": "Where does this connect to Sandworm, Civilisation of Sand, clean energy, grants, legal memory and civic contribution?", "href": "ecosystem.html", "link": "Follow the links", "icon": "network"},
        {"title": "Field Records", "text": "Could residents and partners draft public-review Markdown records before anything is promised or published?", "href": "forms.html", "link": "Open the builder", "icon": "clipboard"},
    ])
)}

{split(
    "The useful what-if.",
    [
        "The first version does not need to pretend the island can recycle every material tomorrow. It could start by making the invisible visible: what arrives, what still works, what has parts, what has clean material value, what needs deeper literacy, and what pathway people choose after understanding the trade-offs.",
        "That turns the dump from a final stop into a learning boundary. The question becomes: what local capacity can be built before an item leaves the island?"
    ],
    "Public boundary",
    "This site does not suggest unauthorised taking from any waste centre. It explores lawful offer, donation, supervised diversion, approved recovery and partner-led recycling pathways."
)}

{section(
    "A calm island loop.",
    "A clear public loop can let people participate without needing to understand every policy, machine or material detail at once.",
    flow([
        ("Offer.", "A resident, business or event steward notes something before it becomes waste."),
        ("Read.", "A trained person and the owner read the object together: usefulness, access, stored data, chemistry, energy, tools, value and permission."),
        ("Choose.", "The pathway can be repair, parts, local material stock, deeper bench learning, partner processing or an explicit pause while people learn more."),
        ("Teach.", "The process becomes a small learning moment: how to identify, dismantle, clean, test, repair, recover or make."),
        ("Prove.", "Weights, photos, repair notes and outcomes show what changed, what failed and what could be funded next.")
    ]),
    band="band-sand"
)}

{section(
    "First streams to notice.",
    "The lab can begin with ordinary, visible streams that are easier to explain, clearer to sort, and useful for workshops.",
    grid([
        {"title": "Plastics", "text": "Precious Plastic-style sorting, shredding, sheet pressing and 3D-print filament experiments could start with clean, known polymers."},
        {"title": "Metals and cans", "text": "Aluminium, steel, copper and useful brackets can become repair stock, teaching samples and future fabrication questions."},
        {"title": "Cardboard and paper", "text": "Clean fibre streams can support packaging, pulp tests, signage, compost-adjacent trials and low-cost prototyping."},
        {"title": "Glass", "text": "Bottles and cullet can connect to glass art, aggregate, sand questions, geopolymer tests and careful crushing protocols."},
        {"title": "E-waste components", "text": "Repairable devices, boards, motors, sensors, cables and chips can become a right-to-repair and component-literacy pathway before any downstream decision."},
        {"title": "Useful objects", "text": "Bikes, furniture, tubs, tools, garden frames and event gear can often be repaired before they become material streams."},
    ], kind="question-card")
)}
"""


STREAMS_BODY = f"""
{section(
    "Waste streams as local literacy.",
    "Every material has a different story: how it is identified, cleaned, stored, repaired, remade, studied, sold, donated, shipped, paused or kept for a future learning pathway. The practical win is not just diversion. It is shared material literacy.",
    grid([
        {"title": "Precious Plastic pathway", "text": "Clean plastic can move from type check to wash, dry, shred, flake library, mould test, sheet press or filament trial.", "icon": "plastic"},
        {"title": "Metals and cans", "text": "Aluminium cans, clean scrap, copper wire, brackets and frames can become weighing, sorting, fastener and fabrication lessons.", "icon": "metal"},
        {"title": "Cardboard and fibre", "text": "Cardboard can become moving boxes, event packaging, pulp tests, compost-adjacent carbon, templates or prototype panels.", "icon": "cardboard"},
        {"title": "Glass and ceramics", "text": "Bottle glass, cullet and broken ceramics can connect to art, aggregate, terrazzo, geopolymer and sand-stack questions.", "icon": "glass"},
        {"title": "E-waste and components", "text": "Devices can be read as repairable objects, component libraries, data-sovereign devices, battery-chemistry lessons or future chip-learning stock.", "icon": "circuit"},
        {"title": "Timber and furniture", "text": "Clean timber, shelves, chairs and frames can teach repair, sanding, finishing, jigs, signage and community event furniture.", "icon": "timber"},
    ])
)}

{split(
    "A material passport could keep the work honest.",
    [
        "A simple material passport can record what the item is, where it came from, what people noticed, what is still unknown, who has consented, what skills are needed, and where it went next.",
        "That record could stay small at first: a Markdown file, a photo, a weight, a stream, a learning note, an outcome and a human reviewer. The deeper digital-twin version can come later."
    ],
    "Small first",
    "A good first passport might only ask: what is it, who offered it, what do people need to understand before touching it, who controls the data, and what pathway did the owner choose?"
)}

{section(
    "Stream questions.",
    "These are not orders. They are useful questions for a self-sovereign public conversation.",
    grid([
        {"title": "Plastic", "text": "Which polymer types are common enough on-island to justify washing, shredding, storage and product trials?"},
        {"title": "Aluminium", "text": "Could cans and clean offcuts become a quantified local stream before any melting or fabrication pathway is considered?"},
        {"title": "Glass", "text": "Where could glass stay art, where could it become aggregate, and where could a specialist pathway teach the island something useful?"},
        {"title": "Cardboard", "text": "Could clean cardboard become a local packaging and prototyping material before it leaves the island?"},
        {"title": "Circuit boards", "text": "Which boards help people learn repair, signals, chips, sensors, heat, power and value before any export pathway is chosen?"},
        {"title": "Batteries", "text": "How could lithium, swollen cells and unknown packs become a chemistry, fire-behaviour and stewardship learning pathway rather than a fear label?"},
        {"title": "Motors and sensors", "text": "Could small motors, fans, switches and sensors become a repair-learning library for schools and workshops?"},
        {"title": "Furniture", "text": "Which repairs suit public sessions, which invite mentoring, and which ask for a more skilled pathway?"},
    ], columns="four", kind="info-card")
)}
"""


LOOP_BODY = f"""
{section(
    "Before the gate, before the loss.",
    "The strongest first model is a lawful pre-tip or partner-approved handover loop where people can offer useful items before disposal, then explore what belongs in repair, parts, material stock, bench learning, specialist processing or a later decision.",
    grid([
        {"title": "Offer point", "text": "A public form, collection day, business pickup or supervised drop-off could capture items before they enter the waste stream.", "icon": "handover"},
        {"title": "Triage bench", "text": "The first check could ask what the item is, what it can teach, who owns the data, what energy or chemistry it holds, and what skills are needed.", "icon": "bench"},
        {"title": "Secure storage", "text": "Lockable containers, cages and sign-out rules can turn curiosity into consentful access instead of chaotic rummaging.", "icon": "lock"},
        {"title": "Outcome log", "text": "Every item can leave a small record: repaired, reused, studied, parts recovered, material tested, returned, processed or paused for deeper review.", "icon": "ledger"},
    ], columns="four")
)}

{split(
    "Trust comes from understanding.",
    [
        "A good loop can be generous without being vague. It can welcome useful offers while giving people the reasons: chemistry, heat, stored energy, personal data, access rights, contamination, road movement, tool skill and local authority.",
        "That turns caution into literacy. People can make better sovereign choices when they can see the reason behind the pause, the pathway or the invitation."
    ],
    "Working boundary",
    "The exploration starts from consentful handover, clear stewardship, owner-controlled data choices, battery chemistry literacy and a public record of what people chose to do."
)}

{section(
    "A first operating sketch.",
    "This page keeps the operating model plain. Each piece can be tested separately before anyone tries to scale it.",
    flow([
        ("Public offer.", "A person records an item, stream or repair candidate through the builder or a stewarded intake day."),
        ("Human read.", "A reviewer and owner look at permission, location, handling, data sovereignty, stored energy, chemistry and available space."),
        ("Pathway choice.", "The item is marked repair, reuse, parts, material stock, battery learning, chip learning, partner processing, normal disposal or pause-for-research."),
        ("Local work.", "Suitable items become workshops, repair nights, student projects, microfactory tests or community-use gear."),
        ("Evidence return.", "The outcome returns to the public record so the next funding or Council conversation has proof.")
    ]),
    band="band-sand"
)}

{section(
    "Questions that could remove friction.",
    "The point of careful questioning is not to shrink the idea. It is to make the first yes easier for people who carry responsibility and for people who want to learn why the risk exists.",
    grid([
        {"title": "Site and traffic", "text": "Where could vehicles stop, unload and turn around without mixing public curiosity with waste-centre traffic?"},
        {"title": "Insurance", "text": "What inductions, supervision, age ranges, tool boundaries, prevention work and mutual-care models would make the risk legible?", "href": "https://auraofintelligence.github.io/moreton-bay-community-wealth-and-mutuals/", "link": "Open mutual care index"},
        {"title": "Waste operator role", "text": "Could the operator flag recoverable items only inside an authorised process, not through informal taking?"},
        {"title": "Council role", "text": "Could Council support a small evidence pilot without promising a permanent service?"},
        {"title": "Data sovereignty", "text": "How can owners choose repair, wipe, harvest, archive or destroy pathways without surrendering right-to-repair value?"},
        {"title": "Battery literacy", "text": "How can lithium, swollen, unknown and damaged packs teach chemistry, fire behaviour, energy storage and careful stewardship?"},
        {"title": "First Nations protocol", "text": "What local protocol, place naming, cultural respect and land-use care needs to shape the conversation?"},
        {"title": "Public messaging", "text": "How can signs and posts invite lawful offers, explain the reasons, and keep curiosity inside consentful pathways?"},
    ], columns="four", kind="info-card")
)}
"""


MICROFACTORY_BODY = f"""
{section(
    "Small machines, serious capability.",
    "The local goal is not to beat industrial recycling at every scale. It is to build enough island capability that more people can identify, repair, remake, inspect, recover and understand the material world around them.",
    grid([
        {"title": "AI sorting aide", "text": "A camera bench could help classify common items, compare possibilities, surface uncertainty and invite a human learning conversation.", "icon": "ai"},
        {"title": "Plastic micro-workspace", "text": "Shredder, injector, sheet press or extruder experiments could begin with clean known plastics and shared tool literacy.", "icon": "plastic"},
        {"title": "3D printer loop", "text": "Recycled filament and part-replacement workflows could make small repair clips, knobs, brackets, jigs and learning objects.", "icon": "printer"},
        {"title": "Electronics bench", "text": "A consent-led bench can recover switches, motors, screws, heat sinks, fans, speakers, sensors, chips and boards while owners choose the data pathway.", "icon": "circuit"},
        {"title": "Glass and mineral tests", "text": "Glass cullet and sand-adjacent research can connect to geopolymers, terrazzo, art, aggregate and Civilisation of Sand pathways.", "icon": "glass"},
        {"title": "Cardboard fabrication", "text": "Cutting, pulping, pressing and packaging tests can turn a boring stream into cheap prototypes and event infrastructure.", "icon": "cardboard"},
    ])
)}

{split(
    "Keep value and learning on-island.",
    [
        "Some streams might still travel to Brisbane, Redlands or specialist processors. The self-sovereign question is what can be learned, repaired, measured, harvested, documented or prototyped locally before that choice is made.",
        "A local microfactory can turn waste handling into workforce learning: sorting, risk literacy, logistics, CAD, electronics, small manufacturing, maintenance, public records, human-in-the-loop AI and right-to-repair judgement."
    ],
    "Infinity lens",
    "I See Infinity. I Choose Infinity. AI and robotics can widen the explorer's lens while consent, repair rights, material literacy and local skill-building stay alive."
)}

{section(
    "From dump bench to compute bench.",
    "The Mineral Moonshots supercomputer brief gives the deeper horizon: maze theory, pathfinding, quartz-to-silicon maps, FPGA benches, EDA simulation, lithography, etching, deposition and small-batch rapid evolution. The tip-loop lab can become the humble front door where people first learn to read parts, boards, heat, signals, power and value.",
    grid([
        {"title": "Maze theory", "text": "Could repair sorting teach graphs, nodes, edges, dead ends, path cost and AI planning before anyone says chip design?"},
        {"title": "Board literacy", "text": "Could circuit boards become maps of power, signal, memory, heat and component relationships instead of anonymous e-waste?"},
        {"title": "FPGA bridge", "text": "Could recovered components and ordinary PCs lead into visual FPGA demos for logic, timing, memory and signal flow?"},
        {"title": "Silicon process map", "text": "Could the island maintain an honest map from quartz and e-waste through purification, crystal growth, doping, lithography and packaging?"},
        {"title": "Kaohsiung bridge", "text": "Could Brisbane's Kaohsiung sister-city relationship become a respectful doorway into older lithography knowledge and Taiwanese manufacturing literacy?"},
        {"title": "Radiation-hard horizon", "text": "Could maze theory, AI layout search and small-batch chip learning point toward space-radiation-hardened experiments over time?"},
    ], kind="info-card"),
    band="band-sand"
)}

{section(
    "Tool lanes to test.",
    "Each lane can begin as a one-bench demonstration before becoming a larger claim.",
    grid([
        {"title": "Repair-first prints", "text": "Could printers make simple replacement parts that keep appliances, bikes, furniture and workshop tools in use?"},
        {"title": "Plastic sheet objects", "text": "Could cleaned plastic become durable sheet for signs, shelves, jigs, clipboards, planter labels or public furniture details?"},
        {"title": "Can and metal literacy", "text": "Could local sorting and weighing reveal enough about aluminium, steel and copper flows before any thermal process is imagined?"},
        {"title": "E-waste harvest", "text": "Could motors, sensors, fasteners, chips and boards become school kits, repair stock and a bridge into local electronics capability?"},
        {"title": "Battery learning bench", "text": "Could battery packs become a supervised pathway for chemistry, pack design, balancing, failure modes, fire behaviour and storage literacy?"},
        {"title": "Robot demos", "text": "Could a small robot arm teach repeatability, sorting, vision, tool paths and the human judgement that keeps a lab sovereign?"},
        {"title": "Silicon horizon", "text": "Could e-waste, sand literacy and older lithography access become a long runway toward small-batch silicon and radiation-hardened chip experiments?"},
        {"title": "Material dashboards", "text": "Could a public dashboard show kilograms diverted, repairs attempted, skills learned, parts recovered and questions still open, then publish updates through Straddie Noticeboards?"},
    ], kind="question-card")
)}
"""


GOVERNANCE_BODY = f"""
{section(
    "Going slow can become a design input.",
    "Waste, stored energy, land, insurance, culture, public money and data all deserve literacy. The useful move is to turn those concerns into a pilot design so care becomes a learning pathway, not a wall.",
    grid([
        {"title": "Pilot scope", "text": "A small pre-tip diversion and documentation pilot could start with a few legible streams, then expand as local skill and confidence grow.", "icon": "loop"},
        {"title": "Evidence", "text": "Photos, weights, stream labels, outcomes, repair hours, parts recovered and open questions can show what the island actually handles.", "icon": "ledger"},
        {"title": "C-Hour fit", "text": "Verified public-good work such as repair, mentoring, sorting and ecological stewardship could later connect to a Community-Hour receipt model.", "href": "https://auraofintelligence.github.io/p4a_xyz/pages/c-hour-receipt-builder.html", "link": "Open C-Hour page", "icon": "hour"},
        {"title": "Regulatory sandbox", "text": "A test pilot could ask for clear rules around non-speculative regenerative contribution, public records and local value creation.", "icon": "shield"},
        {"title": "Federal inquiry submissions", "text": "The Parliament of Australia submissions page lists Luke Nathan Hayes as submission 2 for the Local Government Funding and Fiscal Sustainability inquiry.", "href": "https://www.aph.gov.au/Parliamentary_Business/Committees/House/Regional_Development_Infrastructure_and_Transport/LocalGovernmentFunding/Submissions", "link": "Open submissions page", "icon": "source"},
        {"title": "Actual submission PDF", "text": "Submission 2 sets out the incomplete ledger, C-Hour, Community Sovereign Wealth Fund and regenerative-asset carve-out argument.", "href": "https://www.aph.gov.au/DocumentStore.ashx?id=b0bb44ad-3515-4c22-bdb7-d5db605f6e0a&subId=780115", "link": "Open PDF", "icon": "source"},
    ], columns="four")
)}

{split(
    "The January submission gives the bigger policy door.",
    [
        "Luke's Local Government Funding and Fiscal Sustainability submission appears as submission 2 on the Parliament of Australia inquiry page, with the actual PDF available through APH's document store. The site can point to that public proof without pretending the proposal has already been accepted.",
        "For this repo, the connection is practical: local government often carries the cost of waste, community care, ecology and public assets while normal ledgers barely count that work. A tip-loop pilot could become one visible way to measure repair, learning, stewardship and local capability."
    ],
    "Policy question",
    "What would a lawful Minjerribah pilot need so repair, sorting, training, component recovery, battery literacy, data sovereignty and material stewardship can be counted without becoming speculation, surveillance or charity theatre?"
)}

{section(
    "A pilot could ask these questions.",
    "These asks are framed as discussion points, not demands.",
    flow([
        ("Consentful intake.", "How can owners, Council, operators and local partners shape a handover that keeps choice visible?"),
        ("Data-sovereign records.", "How can the lab record what is useful while leaving owner data, private histories and repair choices under human control?"),
        ("Human judgement.", "How can AI tools draft, classify or suggest while accountable people keep the final call?"),
        ("Local skills.", "How can value be measured in repairs, training, material literacy, recovered parts, avoided waste and local confidence?"),
        ("Rule-change evidence.", "If the pilot works, what evidence could support a broader regenerative-asset or civic-contribution sandbox conversation?")
    ]),
    band="band-sand"
)}

{section(
    "Literacy points to keep visible.",
    "These are the places where a serious project can stay expansive without becoming careless.",
    grid([
        {"title": "Cultural respect", "text": "Minjerribah is Quandamooka Country. Place-based work needs respect, protocol and local legitimacy."},
        {"title": "Waste law", "text": "The lab can explore diversion, but waste-centre rules, operator contracts and Council authority still matter."},
        {"title": "Bench literacy", "text": "Machines, dust, sharp metal, glass, mould, heat and batteries become teachable systems when procedures explain the reasons."},
        {"title": "Data sovereignty", "text": "Phones, laptops, drives and smart devices carry owner-controlled data as well as right-to-repair value."},
        {"title": "Insurance", "text": "Public workshops, lending, repair and transport can link to prevention, mutual-care reserves and community wealth thinking.", "href": "https://auraofintelligence.github.io/moreton-bay-community-wealth-and-mutuals/", "link": "Open mutual care index"},
        {"title": "Finance", "text": "Any C-Hour or regenerative-asset idea needs legal review before real-world issuance or redemption."},
    ], kind="info-card")
)}
"""


ECOSYSTEM_BODY = f"""
{section(
    "One island system, many useful doors.",
    "This repo is deliberately narrow: the dump, local material loops and recycling capability. It becomes stronger when it can hand off to the wider Straddie ecosystem instead of trying to hold every idea at once.",
    grid([
        {"title": "Straddie Maker-Space Lab", "text": "The repair, learning and light-industrial sister room.", "href": "https://auraofintelligence.github.io/straddie-makerspace-lab/", "link": "Open site", "image": "assets/img/previews/cubes/maker-space.webp", "image_alt": "Preview of the Straddie Maker-Space Lab site."},
        {"title": "Sandworm Subterranean Systems", "text": "Careful tunnel, spoil, geopolymer, transport and future infrastructure questions.", "href": "https://auraofintelligence.github.io/sandworm-subterranean-systems/", "link": "Open site", "image": "assets/img/previews/cubes/sandworm.webp", "image_alt": "Preview of the Sandworm Subterranean Systems site."},
        {"title": "Civilisation of Sand", "text": "The larger material stack, AI, robotics, in-situ resources and capability simulation.", "href": "https://auraofintelligence.github.io/civilisation-of-sand/", "link": "Open site", "image": "assets/img/previews/cubes/civilisation-sand.webp", "image_alt": "Preview of the Civilisation of Sand site."},
        {"title": "Straddie Clean Energy Superpower", "text": "Energy, sand batteries, wave/tidal questions and resilient local power pathways.", "href": "https://auraofintelligence.github.io/straddie-clean-energy-superpower/", "link": "Open site", "image": "assets/img/previews/cubes/clean-energy.webp", "image_alt": "Preview of the Straddie Clean Energy Superpower site."},
        {"title": "Ferry Terminal Open Data Lab", "text": "Open data, public-source trails, 360 evidence and community simulation practice.", "href": "https://auraofintelligence.github.io/dunwich-gumpi-ferry-terminal-open-data-lab/", "link": "Open site", "image": "assets/img/previews/cubes/ferry-terminal.webp", "image_alt": "Preview of the Ferry Terminal Open Data Lab site."},
        {"title": "Straddie Noticeboard Network", "text": "A public update layer for material dashboards, repair calls, learning nights and open questions.", "href": "https://auraofintelligence.github.io/straddie-noticeboard-network/", "link": "Open noticeboards", "image": "assets/img/previews/cubes/noticeboards.webp", "image_alt": "Preview of the Straddie Noticeboard Network site."},
        {"title": "Ready S.E.T. Trust Hub", "text": "Trust, co-working, training, asset-sharing and handover pathways.", "href": "https://auraofintelligence.github.io/ready-set-co-op-trust-hub/", "link": "Open site", "image": "assets/img/previews/cubes/trust-hub.webp", "image_alt": "Preview of the Ready S.E.T. Trust Hub site."},
        {"title": "Ballow Road Sand Screen Hub", "text": "Ballow precinct evidence, photos, 360 viewing and grounded local infrastructure context.", "href": "https://auraofintelligence.github.io/ballow-road-sand-screen-hub/", "link": "Open site", "image": "assets/img/previews/cubes/ballow-road.webp", "image_alt": "Preview of the Ballow Road Sand Screen Hub site."},
        {"title": "Stradbroke Grants Lab", "text": "A place to turn evidence, partners and small wins into fundable public notes.", "href": "https://auraofintelligence.github.io/stradbroke-grants-lab/", "link": "Open site", "image": "assets/img/previews/cubes/grants-lab.webp", "image_alt": "Preview of the Stradbroke Grants Lab site."},
        {"title": "Legal Memory Workbench", "text": "A legal/source reasoning layer for rules, documents and public memory.", "href": "https://auraofintelligence.github.io/legal-memory-workbench/", "link": "Open site", "image": "assets/img/previews/cubes/legal-memory.webp", "image_alt": "Preview of the Legal Memory Workbench site."},
        {"title": "P4A Civic Architecture", "text": "C-Hours, public ledgers, local government and regenerative contribution questions.", "href": "https://auraofintelligence.github.io/p4a_xyz/pages/architecture.html", "link": "Open page", "image": "assets/img/previews/cubes/p4a-architecture.webp", "image_alt": "Preview of the P4A Civic Architecture page."},
        {"title": "Mineral Moonshots: Super-Computers", "text": "Maze theory, sovereign compute, quartz-to-silicon maps, FPGAs and small-batch chip imagination.", "href": "https://auraofintelligence.github.io/mineral-moonshots/briefs/supercomputers.html", "link": "Open brief", "image": "assets/img/previews/cubes/mineral-supercomputers.webp", "image_alt": "Preview of the Mineral Moonshots supercomputers brief."},
    ], columns="two", kind="preview-card")
)}

{split(
    "This repo removes a bottleneck.",
    [
        "The maker-space can become crowded if every recycling question sits inside it. A dedicated tip-loop repo lets the deeper material, policy and operating questions breathe.",
        "The stronger pattern is a network: maker-space for tools and repair, tip loop for materials, grants lab for evidence, legal memory for rules, open data for proof, trust hub for people, clean energy or Sandworm where waste streams touch infrastructure, and Mineral Moonshots where materials open into sovereign compute."
    ],
    "Useful handoff",
    "When an idea gets too deep for this repo, it can move sideways to the right sister site instead of becoming noise."
)}
"""


FORMS_BODY = f"""
<div class="band">
  <section class="section" aria-labelledby="builder-note">
    <div class="section-head">
      <h2 id="builder-note">Create an AI-ready material context packet.</h2>
      <p class="body-copy">This builder turns a local material idea into a portable Markdown file: what it is, why it matters, who chooses, what evidence travels with it, what stays private, and what a chosen AI could help develop next. Each answer has one job.</p>
      <div class="button-row">
        <a class="button primary" href="https://auraofintelligence.github.io/how-to-use-md-with-ai/">How Markdown works with AI</a>
        <a class="button secondary" href="https://auraofintelligence.github.io/how-to-use-md-with-ai/pages/builder.html">Open the general MD builder</a>
      </div>
    </div>

    <div class="builder-primer">
      <article>
        <h3>Personal choice AI</h3>
        <p>A useful record can travel into ChatGPT, Claude, Gemini, a local model, a coding agent, a trusted human reviewer or a future island knowledge tool.</p>
      </article>
      <article>
        <h3>High-context, low-control</h3>
        <p>The file gives an AI enough structure to be useful while leaving the person in charge of what is public, private, uncertain, refused or ready for review.</p>
      </article>
      <article>
        <h3>Reusable local data</h3>
        <p>Each record can become better evidence for repairs, grants, dashboards, noticeboards, skill-building, right-to-repair work and future microfactory experiments.</p>
      </article>
    </div>

    <div class="builder-layout">
      <form class="builder-form" data-tiploop-builder>
        <fieldset>
          <legend>Frame the record</legend>
          <label>Record type
            <select name="record_type">
              <option value="material-offer">Material offer</option>
              <option value="repair-candidate">Repair candidate</option>
              <option value="stream-note">Material stream note</option>
              <option value="partner-pathway">Partner pathway</option>
              <option value="pilot-question">Pilot question</option>
              <option value="learning-boundary">Learning boundary note</option>
              <option value="other">Other</option>
            </select>
          </label>
          <label>Visibility lane
            <select name="visibility">
              <option value="private_owner_context">Private owner context</option>
              <option value="trusted_review">Trusted review circle</option>
              <option value="public_draft">Public draft</option>
              <option value="public_after_review">Public after review</option>
              <option value="ledger_or_dashboard_reference">Ledger or dashboard reference</option>
            </select>
          </label>
          <label>Short title
            <input name="title" placeholder="Clean HDPE buckets, bike parts, cardboard stream, e-waste question">
          </label>
          <label>Material stream
            <input name="stream" placeholder="Plastic, metal, cans, glass, cardboard, e-waste, timber, mixed">
          </label>
          <label>Place or reach
            <input name="place" placeholder="Dunwich, Amity, Point Lookout, business pickup, event leftovers">
          </label>
        </fieldset>

        <fieldset>
          <legend>Describe the material once</legend>
          <label data-detail-label>What is the thing, in ordinary words?
            <textarea name="details"></textarea>
          </label>
          <label>What facts are already known?
            <textarea name="quantity"></textarea>
          </label>
          <label>Why could this matter locally?
            <textarea name="local_use"></textarea>
          </label>
          <label>Skills, tools or helpers that might be needed
            <textarea name="needs"></textarea>
          </label>
          <label>Source links, filenames, photos, measurements or people to ask
            <textarea name="sources"></textarea>
          </label>
        </fieldset>

        <fieldset>
          <legend>Choice, care and AI use</legend>
          <label>What changes the pathway?
            <textarea name="handling"></textarea>
          </label>
          <label>Who gets to choose what happens?
            <textarea name="permission"></textarea>
          </label>
          <label>What would be useful for your chosen AI to produce?
            <textarea name="ai_output" placeholder="Example: repair pathway, material passport, public notice, grant angle, parts list, workshop outline, dashboard note or experiment map."></textarea>
          </label>
          <label>What is still unresolved?
            <textarea name="questions"></textarea>
          </label>
          <label>What stays out of public or AI copies?
            <textarea name="private_notes"></textarea>
          </label>
        </fieldset>

        <fieldset>
          <legend>Review</legend>
          <label>Who could review or steward this record?
            <input name="reviewer">
          </label>
        </fieldset>

        <div class="builder-actions">
          <button class="button primary" type="submit">Update Markdown</button>
          <button class="button secondary" type="button" data-copy-markdown>Copy Markdown</button>
          <button class="button secondary" type="button" data-download-markdown>Download .md</button>
          <button class="button secondary" type="button" data-clear-form>Clear</button>
        </div>
        <p class="status" data-status></p>
      </form>

      <div class="output-panel">
        <label for="markdown-output">Markdown preview</label>
        <textarea class="markdown-output" id="markdown-output" data-markdown-output readonly></textarea>
      </div>
    </div>
  </section>
</div>
<script src="tip-loop-builder.js"></script>
"""


SOURCES_BODY = f"""
{section(
    "Public source trail.",
    "This page keeps the public trail easy to inspect, question and extend.",
    grid([
        {"title": "Federal funding inquiry submissions", "text": "The Parliament of Australia submissions page lists Mr Luke Nathan Hayes as submission 2 for the Local Government Funding and Fiscal Sustainability inquiry.", "href": "https://www.aph.gov.au/Parliamentary_Business/Committees/House/Regional_Development_Infrastructure_and_Transport/LocalGovernmentFunding/Submissions", "link": "Open APH submissions", "icon": "source"},
        {"title": "Actual submission 2 PDF", "text": "The APH document store PDF contains the incomplete ledger, C-Hour, Community Sovereign Wealth Fund and regenerative-asset carve-out argument.", "href": "https://www.aph.gov.au/DocumentStore.ashx?id=b0bb44ad-3515-4c22-bdb7-d5db605f6e0a&subId=780115", "link": "Open PDF", "icon": "source"},
        {"title": "North Stradbroke Island waste centre", "text": "Redland City Council lists the North Stradbroke Island Recycling and Waste Centre at 100 East Coast Road, with current opening and payment details on its site.", "href": "https://www.redland.qld.gov.au/Waste-and-recycling/Recycling-and-waste-centres/Recycling-and-Waste-Centres-opening-hours-and-locations", "link": "Open Council page", "icon": "source"},
        {"title": "RecycleWorld precedent", "text": "Council describes RecycleWorld as a trash and treasure facility at Redland Bay where unwanted good-condition items can be donated and reused.", "href": "https://www.redland.qld.gov.au/Waste-and-recycling/Recycling-and-waste-centres/RecycleWorld", "link": "Open RecycleWorld", "icon": "source"},
        {"title": "Items accepted", "text": "Council's accepted-items and e-waste pages help frame what already has a regulated pathway and what needs care.", "href": "https://www.redland.qld.gov.au/Waste-and-recycling/Recycling-and-waste-centres/Items-accepted-at-Recycling-and-Waste-Centres", "link": "Open accepted items", "icon": "source"},
        {"title": "Precious Plastic machines", "text": "Precious Plastic publishes open-source machine pathways for local plastic recycling workspaces.", "href": "https://www.preciousplastic.com/solutions/machines/overview", "link": "Open machines", "icon": "source"},
        {"title": "How to Use Markdown with AI", "text": "The linked guide explains why form-generated Markdown can help people create portable context for their own choice of AI, with purpose, boundaries, sources, requests and review notes.", "href": "https://auraofintelligence.github.io/how-to-use-md-with-ai/", "link": "Open MD guide", "icon": "source"},
        {"title": "Maker-space sister page", "text": "The existing tip-loop page in Straddie Maker-Space Lab is the seed this deeper repo grows from.", "href": "https://auraofintelligence.github.io/straddie-makerspace-lab/tip-loop.html", "link": "Open seed page", "icon": "source"},
        {"title": "Community wealth and mutuals", "text": "The Moreton Bay mutual-care index gives the insurance and community-wealth doorway for prevention, lawful pooling and local resilience funds.", "href": "https://auraofintelligence.github.io/moreton-bay-community-wealth-and-mutuals/", "link": "Open mutual care index", "icon": "source"},
        {"title": "Mineral Moonshots supercomputers", "text": "The deeper compute reference covers maze theory, quartz-to-silicon, FPGAs, lithography, cleanroom constraints and small-batch rapid evolution.", "href": "https://auraofintelligence.github.io/mineral-moonshots/briefs/supercomputers.html", "link": "Open supercomputer brief", "icon": "source"},
        {"title": "Brisbane and Kaohsiung", "text": "Brisbane City Council identifies Kaohsiung, Taiwan, as a sister city relationship formalised in 1997.", "href": "https://www.brisbane.qld.gov.au/things-to-see-and-do/council-venues-and-precincts/brisbane-city-hall/sister-cities", "link": "Open sister cities page", "icon": "source"},
    ], columns="two")
)}

"""


PAGES = [
    {
        "id": "home",
        "label": "Home",
        "file": "index.html",
        "title": "Straddie Tip Loop Lab",
        "description": "A public question-led site for a lawful tip-loop and local recycling sister site to Straddie Maker-Space Lab.",
        "hero": "assets/img/heroes/home-reuse-depot.webp",
        "alt": "A clean lockable reuse depot made from shipping containers beside coastal bushland, with sorted repair and recycling materials.",
        "heading": "Straddie Tip Loop Lab",
        "lede": "Could the island treat the dump as a capability question before useful things become waste?",
        "buttons": [
            ("Map the streams", "streams.html", "primary"),
            ("Explore the loop", "loop.html", "secondary"),
            ("Open field records", "forms.html", "secondary"),
        ],
        "body": HOME_BODY,
    },
    {
        "id": "streams",
        "label": "Streams",
        "file": "streams.html",
        "title": "Material Streams | Straddie Tip Loop Lab",
        "description": "Plastic, metal, cardboard, cans, glass, e-waste and useful-object streams for a local island resource recovery lab.",
        "hero": "assets/img/heroes/material-streams.webp",
        "alt": "Clean recycled material streams sorted across workshop benches, including plastic flakes, metal, cardboard, glass and electronic components.",
        "heading": "What could materials teach?",
        "lede": "Plastic, metals, cans, cardboard, glass and e-waste can become more than a disposal problem when the island can see and sort them.",
        "buttons": [("Try the record builder", "forms.html", "primary"), ("See microfactory tools", "microfactory.html", "secondary")],
        "body": STREAMS_BODY,
    },
    {
        "id": "loop",
        "label": "Loop",
        "file": "loop.html",
        "title": "Lawful Loop Design | Straddie Tip Loop Lab",
        "description": "A lawful pre-tip diversion workflow for repair, reuse, parts, material stock and approved recycling pathways.",
        "hero": "assets/img/heroes/lawful-loop-design.webp",
        "alt": "A clean covered pre-tip intake bay with a weighing scale, repair bench, lockable storage and consentful handover area.",
        "heading": "Could value move before waste?",
        "lede": "The loop starts with permission, supervision and clear choice paths, not with scavenging by default.",
        "buttons": [("Draft an offer", "forms.html", "primary"), ("Read governance", "governance.html", "secondary")],
        "body": LOOP_BODY,
    },
    {
        "id": "microfactory",
        "label": "Microfactory",
        "file": "microfactory.html",
        "title": "Microfactory Tools | Straddie Tip Loop Lab",
        "description": "AI, robotics, 3D printers and compact machines for local recycling, repair and material literacy.",
        "hero": "assets/img/heroes/microfactory-tools.webp",
        "alt": "A compact island microfactory with a robot arm, 3D printers, recycled plastic filament, sorted components and daylight through a container workshop.",
        "heading": "Could small machines build skills?",
        "lede": "AI, robotics and 3D printers can help more when they leave skills behind instead of hiding the work somewhere else.",
        "buttons": [("See material streams", "streams.html", "primary"), ("Follow ecosystem links", "ecosystem.html", "secondary")],
        "body": MICROFACTORY_BODY,
    },
    {
        "id": "governance",
        "label": "Governance",
        "file": "governance.html",
        "title": "Pilot Governance | Straddie Tip Loop Lab",
        "description": "Evidence, public records, C-Hour links and lawful pilot framing for a regenerative local recycling trial.",
        "hero": "assets/img/heroes/governance-evidence.webp",
        "alt": "A civic evidence table with material samples, a small reuse-depot model, abstract ledger blocks and coastal bushland beyond.",
        "heading": "What makes a pilot easy to trust?",
        "lede": "Caution can become a clear test design when the evidence, permissions, risks and public benefit are visible.",
        "buttons": [("Open sources", "sources.html", "primary"), ("See ecosystem", "ecosystem.html", "secondary")],
        "body": GOVERNANCE_BODY,
    },
    {
        "id": "ecosystem",
        "label": "Ecosystem",
        "file": "ecosystem.html",
        "title": "Ecosystem Links | Straddie Tip Loop Lab",
        "description": "How the tip-loop repo connects to maker-space, Sandworm, Civilisation of Sand, clean energy, open data, grants, legal memory and P4A.",
        "hero": "assets/img/heroes/ecosystem-links.webp",
        "alt": "A workshop table with connected physical models of Straddie projects, including maker-space, recycling depot, energy, ferry terminal and sand systems.",
        "heading": "How does the loop connect?",
        "lede": "The dump question touches energy, tools, grants, law, public data, material science, trust and civic contribution.",
        "buttons": [("Visit sources", "sources.html", "primary"), ("Open builder", "forms.html", "secondary")],
        "body": ECOSYSTEM_BODY,
    },
    {
        "id": "forms",
        "label": "Forms",
        "file": "forms.html",
        "title": "AI Context Builder | Straddie Tip Loop Lab",
        "description": "A browser-local Markdown builder for portable, self-sovereign tip-loop context packets that people can use with their own choice of AI.",
        "hero": "assets/img/heroes/field-records.webp",
        "alt": "A tidy workshop desk with blank clipboards, material samples, scale, camera and laptop for public-review field records.",
        "heading": "Could one file help an idea travel?",
        "lede": "A Markdown context packet can help a person bring material facts, choices, sources and open questions into the AI tool they choose.",
        "buttons": [("Start the builder", "#builder-note", "primary"), ("Read the MD guide", "https://auraofintelligence.github.io/how-to-use-md-with-ai/", "secondary")],
        "body": FORMS_BODY,
    },
    {
        "id": "sources",
        "label": "Sources",
        "file": "sources.html",
        "title": "Sources | Straddie Tip Loop Lab",
        "description": "Public source links for the Straddie Tip Loop Lab site.",
        "hero": "assets/img/heroes/sources-trail.webp",
        "alt": "A clean source-trail desk with blank documents, island map, material samples and coastal light through a window.",
        "heading": "What supports the idea?",
        "lede": "Source links help the project stay easy to inspect, question and improve.",
        "buttons": [("Open field records", "forms.html", "primary"), ("Back home", "index.html", "secondary")],
        "body": SOURCES_BODY,
    },
]


def render_page(page):
    pages_for_js = [
        {"id": item["id"], "label": item["label"], "href": item["file"]}
        for item in PAGES
    ]
    page_url = SITE_URL + ("" if page["file"] == "index.html" else page["file"])
    return f"""<!doctype html>
<html lang="en-AU">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="{page['description']}">
    <meta property="og:title" content="{page['title']}">
    <meta property="og:description" content="{page['description']}">
    <meta property="og:image" content="{page['hero']}">
    <meta property="og:url" content="{page_url}">
    <title>{page['title']}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Atkinson+Hyperlegible:wght@400;700&family=Nunito+Sans:wght@700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
    <link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
    <link rel="shortcut icon" href="assets/favicon.ico" type="image/x-icon">
  </head>
  <body data-page="{page['id']}">
    <header data-site-header></header>
    <main id="main">
      <section class="page-hero" aria-labelledby="page-title">
        <figure class="page-hero-media" aria-hidden="true">
          <img src="{page['hero']}" alt="">
        </figure>
        <div class="page-hero-inner">
          <div class="page-hero-copy">
            <h1 class="page-title" id="page-title">{page['heading']}</h1>
            <p class="lede">{page['lede']}</p>
            {button_row(page['buttons'])}
          </div>
        </div>
      </section>
{page['body']}
    </main>
    <footer data-site-footer></footer>
    <script>window.StraddieTipLoopPages = {json.dumps(pages_for_js)};</script>
    <script src="script.js"></script>
  </body>
</html>
"""


def write_docs():
    source_notes = """# Source Notes For Straddie Tip Loop Lab

This note keeps the public source trail readable and easy to revisit.

## Main Public Framing

The site is a question-led sister repo to Straddie Maker-Space Lab. It explores lawful pre-tip diversion, repair, reuse, material recovery, battery and data sovereignty literacy, AI-assisted sorting, robotics, 3D printing, electronics benches and local microfactory capability.

## Public Sources Linked

- Parliament of Australia submissions page for the Inquiry into Local Government Funding and Fiscal Sustainability
- Redland City Council waste-centre locations page
- Redland City Council RecycleWorld page
- Redland City Council accepted-items and e-waste pages
- Precious Plastic machine overview
- How to Use Markdown with AI public guide and builder
- Existing Straddie Maker-Space Lab public tip-loop page
- Moreton Bay Community Wealth and Mutuals index
- Mineral Moonshots Super-Computers of North Straddie brief
- Brisbane City Council sister cities page for the Kaohsiung relationship
"""
    (ROOT / "docs" / "source-notes.md").write_text(source_notes, encoding="utf-8")

    image_prompts = """# Image Prompt Notes

Built-in image generation was used for the project hero assets. The final PNG outputs were copied into this repo and converted to WebP for page use.

## Shared Direction

All hero images were requested as wide 16:9 editorial-documentary scenes, with useful negative space on the left for code-native webpage text. Prompts asked for no readable text, no logos, no watermarks, no dump scavenging scene and no identifiable people.

## Page Assets

- `home-reuse-depot.webp` - lawful pre-tip reuse depot beside coastal bushland, with lockable containers and sorted useful objects.
- `material-streams.webp` - clean material streams on workshop benches: plastic flakes, metals, cardboard, glass, copper wire and electronic components.
- `lawful-loop-design.webp` - covered intake bay, donation table, scale, repair triage bench and lockable storage.
- `microfactory-tools.webp` - compact container microfactory with robot arm, 3D printers, recycled filament and electronics trays.
- `governance-evidence.webp` - community workshop evidence table with material samples, model depot, abstract ledger blocks and public-policy mood.
- `ecosystem-links.webp` - physical model table connecting maker-space, tip loop, energy, ferry terminal, sand systems and civic prototypes.
- `field-records.webp` - Markdown record desk with clipboards, material samples, camera, scale and review workflow.
- `sources-trail.webp` - source-trail desk with documents, island map, material samples and coastal light.
"""
    (ROOT / "docs" / "image-prompts.md").write_text(image_prompts, encoding="utf-8")


def main():
    for page in PAGES:
        (ROOT / page["file"]).write_text(render_page(page), encoding="utf-8")
    write_docs()
    print(f"Built {len(PAGES)} pages.")


if __name__ == "__main__":
    main()
