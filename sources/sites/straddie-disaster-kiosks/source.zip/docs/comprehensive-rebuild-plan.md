# Straddie Disaster Kiosks comprehensive rebuild plan

**Planning draft | 20 October 2026 | Minjerribah and Redlands**

The proposed disaster kiosk network would provide useful everyday island information and a hardened service through storms, cyclones, fires and prolonged disruption. The rebuild must join software, physical equipment, communications, qualified people and continuing operations. High fidelity means keeping the location, time, source, authority, availability and delivery state of information accurate enough to support decisions under demanding conditions.

**The integrated service is a plan. It is unimplemented, is not operating and has not yet been properly pitched to the community.** The existing [disaster kiosk repository](https://github.com/auraofintelligence/straddie-disaster-kiosks) is a seven-page concept site. Related repositories contain proposals and code demonstrations; these provide foundations for a new build.

**Ready S.E.T. Co-op**, fully **Ready Sustainable Employment and Training Cooperative**, is the proposed intermediary that would run the disaster kiosks, Cultural Intelligence Node and Minjerribah Screen and Media Network. Community mandate, formation, hosts, staffing and funding remain development work. **Aura of Intelligence is the personal AI operating system Luke is designing, from light to ultra high definition**, including navigation of this disaster network and just-in-time learning.

**GAJRA Earth**, the **Global Association for Joyful Responsible Abundance on Earth**, is the defining values starting point. The kiosk design should carry those values into personal agency, meaningful choice, accountable consequences, consent and correction, fair access to shared capability, ecological care and learning that people can sustain. Evaluate whether the service improves lived experience, accounts for consequences and spreads useful capability, drawing on the [UNGA81 contribution and library](https://auraofintelligence.github.io/UNGA81-Luke-Hayes/library.html). Public assistance remains available without enrolment in an Aura or an association. [Values and personal AI sources](supporting-research.md#aura-personal-operating-system-and-gajra-values)

The immediate scope is the kiosk and the network it must manage. Wider projects appear as short references in section 12; their source details and deeper documents are retained in the [supporting research](supporting-research.md). The next build should make the kiosk proposal and its demanding operating requirements concrete enough for community discussion and review before a field pilot.

## 1 Local purpose and design basis

Luke developed the idea after Cyclone Alfred in March 2025. In his firsthand account, parts of the island lost grid power for five to nine days. Generators were already present but were unconnected, with qualified people unavailable locally while barges were down. The lesson is to test a usable service with available people, connections, consumables and access. Owning equipment does not establish readiness.

Council's [Alfred recovery plan](https://www.redland.qld.gov.au/files/assets/public/v/1/business-and-investment/documents/tropical_cyclone_alfred_redland_local_recovery_plan__a12342961_.pdf) identifies independent island facilities, stronger fuel, food and medical supply chains, and emergency barge access as recovery objectives. [Queensland Parks](https://parks.des.qld.gov.au/__data/assets/pdf_file/0030/305688/Bp2005-SEQ-planned-burn-guidelines.pdf), Appendix 1, describes the 2014 wildfire as impacting almost 80% of the island and threatening all three main townships. Storms, cyclones and fires are the initial exercise priorities.

Design for cascading failures: lost grid power, unavailable fuel, closed ferries, damaged routes, absent qualified staff, failed communications and delayed repair supplies. Run a nine-day disruption exercise derived from Luke's Alfred experience, including changes and recovery across that period. Longer scenarios ask what can be maintained, replenished or repaired when outside support remains unavailable.

Future readiness means building the ability to adapt before change is imposed on the community. Climate-related disruption, conflict, superintelligence and rare wider events belong in the scenario horizon. Their common service demands are continuity, trusted evidence, retained skills, human agency and cooperation. Particular extraordinary-event hypotheses remain distinct from established information; the public pitch can stay grounded in familiar local needs.

## 2 Everyday service and hardened operation

The same familiar public doorway should work throughout the year. Residents and visitors should find the ongoing island calendar, local notices, service and transport information, accessible place information and approved local media without an account. Everyday use should exercise the publishing, checking, maintenance and handover routines that disaster operation needs.

The proposed Straddie Noticeboard Network would provide a shared publishing layer, with disaster kiosks and media screens as parts of it. One approved item could produce portrait, wide-screen, phone and text versions, retaining the same identity, source, revision and expiry. The Quandamooka Country Events Engine would supply reviewed public calendar records. [Source review](supporting-research.md#connected-repositories-and-deeper-sources)

| State | Public experience | Required operating behaviour |
| --- | --- | --- |
| Everyday | Calendar, notices, services, transport sources and media | Check sources, publish accessible versions, expire content and practise maintenance |
| Preparedness or exercise | Checked readiness information or visibly labelled practice | Confirm people, equipment, installed content, power transitions and communication paths |
| Hardened with connections | Priority warnings, closures, assistance and service updates | Apply authorised priorities; preserve source meaning, privacy and accountable requests |
| Partitioned or local only | Locally available essentials and local assistance routes | Show who can be reached, what is queued and the age of saved information |
| Minimum power | Essential text, directories, maps and bounded messages where available | Shed agreed optional loads; show remaining capability and preserve recoverable records |
| Recovery | Corrected services, outstanding requests and restored everyday content | Reconcile changes, revalidate affected information and authorise the return to normal |

Public mode, connection state and power state must be separate. A kiosk can be in hardened mode while isolated; a connected kiosk can still have stale information or low energy. Every transition must preserve permitted records and explain the services available. A changed screen theme alone does not demonstrate hardening.

A calendar occurrence needs its own identity, zoned start/end times, recurrence exceptions, current status, organiser/source, per-item check time, approval, revision and linked notices. Cancellations and postponements must supersede promotion across releases. The existing calendar's fixed 9 October 2026 ageing anchor and unstructured recurrence are unsuitable for a current service without replacement. An event venue must never become an activated shelter by inference.

### Personal AI navigation and learning

Aura of Intelligence would help a person understand the network, find relevant services, inspect evidence, choose a next action and learn what that action requires. A person could use their own Aura or choose an assisted private session at a kiosk. Their private context and permissions would remain distinct from public network records.

The light to ultra high definition direction allows the personal system to grow in depth and capability with the person's choices and available resources. A light configuration could offer simple source-linked guidance and selected context; richer configurations could connect more detailed personal models, memory, tools, spatial views and simulations. The precise profiles remain design work. Personal-model depth, presentation, compute location and emergency power mode are separate choices or operating states. An ultra high definition personal twin remains a chosen research and development path; everyday Aura use and kiosk assistance do not require one. Across configurations, preserve record identities, permission boundaries, evidence age and unresolved requests. Greater detail must not imply greater certainty about the real situation.

Just-in-time learning would follow a real task through explanation, rehearsal, application, feedback and a related next task. Identify the person's role and prerequisites, retrieve an approved learning item, explain the next useful step in their chosen accessible form, check understanding and offer a human handover. Each item needs an owner, source, version, applicable conditions, review date and stop/escalation points. Record demonstrated outcomes or teach-back with the person's permission. A short lesson does not confer a qualification or permission to perform restricted work.

For example, a relief kiosk steward could use Aura to find the current handover, open the approved offline checklist for verifying a content release, practise the procedure and record the result. Electrical faults would go to the qualified cover identified in the readiness record. An unavailable model or connection would lead to the installed source material and remaining assistance routes, with limitations visible.

Package essential learning locally alongside the approved information release. Personalisation, voice or spatial presentation can adapt to available power, connectivity and accessibility needs; the underlying source and authority must remain inspectable. Civic or legal retrieval needs the relevant jurisdiction, operative dates and exact source passage, with escalation when current applicability cannot be established. Source documents and retrieved text cannot grant an agent authority to publish, disclose private data or operate equipment. [Source review](supporting-research.md#aura-personal-operating-system-and-gajra-values)

## 3 Information people can act on

Official instructions retain the issuing body's authority and meaning. The kiosk should relay authorised information in accordance with the [local disaster arrangements](https://www.redland.qld.gov.au/files/assets/public/v/3/community-safety-and-health/documents/20251219-local-disaster-management-plan-control-copy.pdf) and preserve the warning details specified by the [Queensland warning framework](https://www.disaster.qld.gov.au/watch-for-the-warnings). Local assistance coordination does not confer emergency command.

Keep official instructions, published schedules, observations, forecasts, community reports, proposals and simulations visibly distinct. A timetable does not establish that a ferry is sailing; a mapped building does not establish shelter activation; a modelled weather value is not an island instrument reading. An unknown or contested state must remain available.

Every actionable item should carry:

- Stable identity, type, revision and the item it corrects or supersedes.
- Source owner and locator, issuing authority where applicable, and permission to relay.
- Issue or observation time, effective period, recording time, last source check and expiry.
- Relevant place or area, coordinate uncertainty where relevant, audience and affected services.
- Reviewer, approval scope, permitted channels, rights and correction or withdrawal route.
- Current evidence state, including stale, unknown, disputed or awaiting verification.

Generated, source-checked, human-reviewed, approved, published and delivered are separate events. A site-wide check date cannot substitute for an item's check. Derived summaries and translations must retain their source and approval trail; an AI suggestion must not become a public instruction automatically.

Time handling is part of safety. Record source times and the device's clock confidence. If time cannot be trusted after a restart, avoid claiming freshness or extending validity. Preserve the issuer's validity and cancellation semantics, including instructions that remain in force until further notice. An overdue check or lost connection must never imply cancellation or an all-clear. Show the last received warning with its age and unresolved status where appropriate; handle expired routine notices separately. The screen should state when the current situation cannot be verified and offer the remaining contact routes.

Choose feeds and manual source-check arrangements with actual information owners. [Council's dashboard](https://disaster.redland.qld.gov.au/), [BOM warnings](https://www.bom.gov.au/weather-and-climate/warnings-and-alerts) and national alert systems are source leads, not evidence that a kiosk API, licence or integration is available. For each source, define access, permitted use, check cadence, outage fallback, responsible operator and failed-check escalation.

## 4 Requests resources and usable readiness

Requests should use stable IDs and show meaningful states: saved on this device, queued, received by a service, acknowledged by a person, assigned, completed, cancelled or expired. Record who owns the next action, its deadline or review time and the handover. A network receipt must never imply help is coming. If no staffed receiving service is available, explain that before accepting a request as actionable.

The public interface must separate immediate danger from ordinary assistance requests, show [Triple Zero 000 for emergencies](https://www.qld.gov.au/emergency/emergencies-services/assistance/triple-000), and explain how to reach a working phone or agreed local assistance point when the kiosk cannot connect. Any offered calling function must be tested; a queued kiosk request is not an emergency call. If a receiving person becomes unavailable after acknowledgement, flag the broken handover, seek reassignment through the agreed escalation route and show the requester that responsibility is unresolved. Acknowledgement cannot remain a permanent assurance when nobody owns the next action.

Keep a public information route separate from private assistance. Welfare details, household needs, contact information, precise stock locations and delivery rosters require scoped access. Give the person a way to retain a reference without exposing their request on a public screen. Define retention and closure with the receiving service.

| Record | Minimum operational distinctions |
| --- | --- |
| Service or facility | Open, limited, closed or unknown; verified activation where needed; hours, accessible approach, capacity limits, check time and responsible contact |
| Resource | Quantity and units; present, usable, allocated, in transit, unavailable or unknown; condition, location access, owner and replenishment dependencies |
| Critical equipment | Owned, stored, installed, connected, commissioned, tested and ready with qualified cover; compatible interfaces, consumables and last demonstrated test |
| People and cover | Role, permission, demonstrated competence or required qualification, availability, relief, contact permission and access arrangements |
| Route or transport | Operator-confirmed status, operating limits, disruptions, relevant time, accessible collection point and fallback |
| Device | Canonical device ID, host, release, last contact, power and link state, faults, maintenance due and recovery procedure |

Stock must not be double-allocated by disconnected nodes. The first design should use a named stock custodian or bounded local allocation authority; conflicting allocations enter review. A merge algorithm cannot decide whether two claims concern the same remaining water, fuel or vehicle.

Food and water availability need condition and assessment states. A date label alone cannot establish food safety after lost refrigeration. Public material should relay applicable [emergency food guidance](https://www.foodstandards.gov.au/consumer/prevention-of-foodborne-illness/food-safety-in-an-emergency) and [water guidance](https://www.health.qld.gov.au/public-health/disaster/public-health-advice/water-safety); inventories may be marked unknown or awaiting assessment. The kiosk would support information and human handover.

## 5 Software and network architecture

Build independently testable components around versioned records and portable exports. The essential local service must continue when optional AI, 3D, media rendering, community compute or outside hosting becomes unavailable.

| Component | Responsibility |
| --- | --- |
| Kiosk player and local store | Cold-start into a complete approved local release, enforce display states and recover after interruption |
| Nearby phone access | Offer permitted local content over a tested local connection, with clear discovery instructions and privacy boundaries |
| Publishing and release service | Draft, check, approve, package, distribute, expire, correct and withdraw content |
| Request coordination | Queue permitted records, deduplicate, acknowledge, assign and close with an accountable human handover |
| Network gateways | Exchange only supported traffic through measured links; expose availability, delay and delivery limits |
| Operator console | Source review, role-based actions, unresolved work, device health, handover and incident records |
| Personal AI interface | Let Aura navigate permitted service records, retrieve approved learning and prepare chosen actions with scoped authority and explicit handover |
| Recovery tools | Verify packages, restore backups, replace nodes and retain the audit trail |
| Optional adapters | Exchange approved calendar, media, twin, mobility or resource records through explicit contracts |

Separate the low-energy continuity unit from demanding community-node workloads. A large GPU job, model update or media render must not exhaust the storage, bandwidth or energy needed for essential notices. Choose frameworks, storage and cryptographic mechanisms after the failure and recovery requirements have been demonstrated.

A locally governed community node could provide the missing middle between personal or neighbourhood devices and larger external compute. Place each workload where its purpose, permissions and resources fit, preserving choice and a locally usable essential service. [Missing-middle source](supporting-research.md#unga81-contribution-and-reference-library)

Each release needs a manifest, schema version, content/map versions, dependencies, integrity checks, approval and validity records, and a known-good rollback. Installation must be atomic: a power cut cannot leave a half-installed essential release. Keep permitted base maps, fonts, scripts and text alternatives local; online map tiles, fonts or CDNs must not be hidden startup requirements.

Signatures and checksums support origin and integrity; they do not establish the truth of a claim. Device trust, publisher permissions and the handling of expired credentials require their own operational design.

## 6 Communication loss load and reconciliation

Map which parts of the network can still communicate under each failure. Local Wi-Fi does not provide internet, and a radio mesh does not by itself deliver SMS or email. External messages need a working gateway and an actual receiving service. Compare wired, mobile, local Wi-Fi, low-bandwidth radio, optional satellite and controlled physical transfer by coverage, capacity, latency, energy, cost and failure behaviour. Radio configurations need review against the applicable [ACMA requirements](https://www.acma.gov.au/licences/low-interference-potential-devices-lipd-class-licence).

Use high-capacity links or controlled transfer for maps, images, models and media. Carry compact priority messages and status over low-bandwidth links within measured limits. Document which functions disappear or become delayed on each path, including when the local network also fails.

Give urgent authorised corrections, current essential information and urgent requests protected capacity, with deadlines and fair scheduling so one class cannot starve another. Routine records, bulk media and optional compute receive lower priority. Set limits per queue and sender so one faulty device or burst of uploads cannot displace essential traffic. Authenticate priority actions and test flooding, retry storms, storage exhaustion and a damaged peer. Reserve storage for essential records and report what is delayed, rejected or dropped.

During a partition, preserve authorship, source time, recording time, local changes and their history. Deduplicate retries with stable IDs. On reconnection, apply explicit supersession rules for corrections and cancellations; retain conflicting real-world observations for review. Never silently overwrite an unresolved request or revive cancelled content from an older release. Track delivery to each intended device separately from publication.

Track package receipt, verification, installation, player health and display health separately. An online device may have a frozen player, blank screen or failed panel. The console must show the evidence and age of each health check; a received package cannot be reported as successfully displayed without suitable confirmation. Missing contact means visibility is lost, with failure cause still unknown.

A disconnected device cannot learn a new cancellation or key revocation instantly. Bound that risk through validity periods, pre-agreed local authority, reduced functions and visible age. The plan must state the residual limitation and test it. Physical transfer needs package verification, authorisation and reconciliation too.

Before implementation, select a declared test envelope: node count and topology, concurrent users and nearby phones, notice/request rates, burst sizes, link capacity/loss/delay, storage limits, retention and recovery times. Record pass limits for essential display startup, priority update age, request acknowledgement and recovery. Numerical targets should follow the pilot's geography, people and measured links; attractive demonstrations cannot substitute for them.

## 7 Power hardware and siting

Use device roles suited to the task: venue display, interactive public kiosk, low-energy continuity unit, optional community node, and portable exercise or gap-coverage unit. Each needs its own essential load, failure behaviour and accountable maintenance owner.

Measure watts and daily energy under actual screen brightness, processing, local Wi-Fi, radio, storage and charging loads. Calculate usable energy after reserve, conversion losses, temperature, ageing and degradation. The original pitch's 24 V 200 Ah example is 4.8 kWh nominal; it does not establish runtime. Model seasonal generation and poor-weather days, with a no-generation case and explicit replenishment assumptions.

Design load shedding in advance: optional compute and bulk media can stop before essential information. Test grid loss, depleted battery, restart, failed charger and return of supply under load. Independent power means the required equipment is connected, commissioned, accessible and supportable by available qualified people. Qualified electrical work and generator arrangements should follow applicable [generator safety guidance](https://www.energex.com.au/__data/assets/pdf_file/0004/1013368/Electrical-safety-while-using-generators.pdf).

The nine-day exercise must account for energy, operator shifts, information checks, fuel, repairs and supplies across time. A 24-hour disconnected software bench is an early milestone; neither a time-compressed simulation nor nominal battery arithmetic proves nine-day field endurance. Record separately what was simulated, measured on a bench and demonstrated at a site.

Assess potential sites for host agreement, everyday usefulness, physical accessibility, safe approach, shade, glare, heat, salt, wind, water, fire exposure, enclosure, mounting, battery protection, maintenance access and communication paths. Keep kiosks distributed so failure of one hub does not disable all locations. Site and configuration evidence must support any environmental rating or survival claim.

Provide spares, replaceable components, offline maintenance instructions, verified backups and a tested method to commission a replacement. Include safe shutdown, secure storage, physical tampering and loss of the usual maintainer in the operating design.

## 8 Authority privacy accessibility and staffing

Ready S.E.T. Co-op would coordinate the proposed service agreements, publishing operations, equipment stewardship, paid work, learning, maintenance and accountability. Assign named duties for source checking, content approval, local assistance, devices, power, communications, privacy, cultural permissions, shift cover and recovery. A technical administrator's access does not confer cultural authority or authority to issue public emergency instructions.

Before a pilot, define ownership or lease, host responsibilities, access, membership and representation, budgets, maintenance reserves, insurance, conflicts, complaints and handover if an arrangement ends. Cooperative ideas from the health and Oceania sources may inform shared ownership, procurement, training and mutual support; the kiosk requires its own practical agreements and budget. [Cooperative source review](supporting-research.md#additional-cooperative-model-originals)

Publishing permissions, approval of an item, authority to interrupt screens, device administration and private assistance need separate access scopes. Include offline operator authentication, short-lived permissions where appropriate, lost credentials, compromised nodes, emergency delegation and recovery of trusted access. Test a compromised publishing account and a malicious update. Restricted actions should narrow when the system cannot establish permission.

Public use must not require a personal Aura, Genesis participation, biometrics or agreement with an AI. End shared sessions safely after sign-out, timeout or interrupted power. Test history, caches, downloads, clipboard, local storage and browser recovery so the next user cannot recover the previous person's material. Durable assistance records require separate protected storage and an authorised receiver.

For cultural material, establish the relevant custodians' conditions for access, copying, interpretation, AI use and release. Derived summaries or translations must follow those conditions. [QYAC's cultural heritage role](https://qyac.net.au/cultural-heritage/) identifies an engagement pathway; it does not establish project endorsement.

Target [WCAG 2.2 AA](https://www.w3.org/TR/2024/REC-WCAG22-20241212/) for the web experience, alongside physical access assessment. Provide large text, keyboard and touch use, captions, plain language and supported participation. Essential directions need text and locally available map alternatives when 3D, AI or audio is absent. Maintain dated paper fallback and assistance for people without a phone.

Shift handovers should show current state, unresolved requests, faults, remaining energy, last source checks, contacts and escalation. Relief people must be able to use the offline runbook. Paid work, supervised learning and voluntary activity retain distinct conditions; qualification-dependent tasks need actual qualified cover.

One C-Hour recognises one verified hour of voluntary human contribution. Each community decides its reciprocal rewards and opportunities. C-Hours have no monetary equivalent and cannot be sold or transferred. Count each person's elapsed contribution once across linked projects; keep paid work, money, machine time and outcomes separate. This governs any later contribution interface.

## 9 High fidelity exercises and acceptance

High fidelity concerns service behaviour and evidence as well as visual detail. Use time-varying scenario inputs with source, units, location, uncertainty and assumptions. Calibrate components against measurements where possible. Make runs repeatable and compare predicted behaviour with observations and human experience. Clearly label simulation on screens, messages and exports, and isolate exercise distribution from public operational channels.

Voluntary branching exercises can let people choose actions, propose alternatives and review consequences. They should practise coordination and judgement without treating fictional events, model outputs or AI confidence as authority.

| Exercise | Required result |
| --- | --- |
| Cold-start with internet absent | Essential installed content, local navigation and service-state explanation work without remote assets |
| Warning or service information ages | Issuer validity and cancellation meaning remain intact; an unresolved warning shows age/uncertainty without an implied all-clear; routine notices follow their own expiry policy |
| Event cancelled during disconnection | Stable occurrence and revision survive reboot; cancellation supersedes promotion after contact; no accidental recurrence rollover |
| Grid internet and radio fail together | Complete local release remains usable; eligible changes queue honestly; measured power reduction follows policy |
| Network splits and reconnects | Retries do not duplicate work; delivery history, corrections and requests reconcile; conflicts remain inspectable |
| Several nodes compete for stock | Allocation limits prevent unreviewed double use; discrepancies reach a named custodian |
| Demand exceeds normal load | Essential traffic stays within the agreed envelope; overflow/backpressure is visible and recoverable |
| Clock signature or update is invalid | Unsuitable updates are rejected or quarantined; a usable known-good release remains; freshness is not invented |
| Publisher account or node is compromised | Scope limits, isolation, revocation limitations and recovery are demonstrated |
| Package arrives but screen freezes | Console distinguishes receipt, installation and display evidence; a working network connection cannot conceal a failed public display |
| Receiver disappears after acknowledgement | Escalation and reassignment are attempted; outstanding responsibility and the requester's status remain explicit |
| Public user leaves or power cuts | The next user cannot recover private session material; authorised durable requests remain protected |
| AI inference or richer interfaces become unavailable | Available functions reduce while essential navigation and approved local material remain usable; the person's profile and consent are not rewritten; record identities, permissions and outstanding work remain intact |
| Just-in-time learning supports a real task | Approved source/version and prerequisites are checked; understanding and human escalation are available; generated advice cannot create a qualification or authority |
| Ferry fuel route or qualified staff becomes unavailable | Readiness and service availability change; dependencies and unresolved work have accountable handovers |
| Node or host is lost | Remaining locations retain their designed functions; a relief person restores a replacement from verified local resources |
| Nine-day disruption and recovery | Track changing power, connections, staffing, information and supplies; reconcile outstanding work and revalidate normal content |

Each run needs its configuration, source/release versions, operators, fault sequence, pass conditions, observations and unresolved issues. Measure startup and recovery time, priority-update age, queue depth, loss/duplication, acknowledgement time, actual energy, usable runtime, accessibility barriers and staff burden. Report simulated endurance separately from measured endurance.

## 10 Next build and delivery stages

The next public site should explain the local origin, everyday use, hardened modes, network failures, equipment readiness, Ready S.E.T. Co-op's proposed role, costs and evidence. Keep deeper project histories in linked sources. People should also enter directly by task: find information, request assistance, publish, or maintain the service.

Use visibly labelled sample records for reviewable demonstrations. The foundation should include a public player, operator console, source-labelled notices and calendar changes, atomic local releases, expiry, disconnected requests, resource/readiness states, device status and recovery. Demonstrate transitions and failed paths on several nodes. Include Aura navigation and just-in-time learning using sample personal context, with locally installed source material available when inference or richer views are unavailable.

| Stage | Concrete work and gate |
| --- | --- |
| Complete the build brief | Choose initial tasks, roles, record contracts, test envelope, boundaries and prototype allowance |
| Build reviewable demonstrations | Show everyday to hardened to isolated to recovery operation; pass source, request, cancellation and invalid-update cases |
| Bench and network exercises | Run a candidate 24-hour disconnected software test, partitions, load limits, power transitions and relief handover; record failures |
| Community discussion | Present the proposal to potential users, custodians and hosts; record concerns, changes and any explicitly agreed next step |
| Prepare a supervised field pilot | Establish host/site and information agreements, qualified work, hardware, permissions, support, operating budget and acceptance limits |
| Exercise and review | Test daily usefulness and demanding disruption; compare results, cost and burden with the agreed service envelope |
| Grow demonstrated capability | Add locations and interfaces when maintained evidence, trained people and continuing resources support them |

A field release needs its own readiness review. The community discussion cannot be replaced by a software demonstration, and a successful bench cannot establish physical installation fitness. Dates should follow the actual team, site and evidence rather than historical roadmap promises.

## 11 Cost funding and measures

Build a dated priced inventory: displays, enclosures/mounts, site work, power and batteries, communications, software/hosting, content rights, wages and on-costs, cultural work, accessibility, training, insurance, spares, security maintenance, recovery and contingency. Separate one-off setup, continuing operation and replacement reserves. Include donated equipment's condition and support burden.

Potential cooperative support could share procurement, technical help and recovery practice through future agreements. Member choices about assets, any surplus and service income require their own governance. Historical treasury, yield, subsidy or serious-compute-node figures are not kiosk funds or quotes.

The [Stradbroke Grants Lab](https://github.com/auraofintelligence/stradbroke-grants-lab) is a funding research aid. Current leads checked on **20 October 2026** include Redland Community Support, FRRR Prepare and Recover, Stronger Communities round 10 and Mayor/Councillors support. Their dated deadlines, amounts, eligibility and equipment restrictions are in the [funding register](supporting-research.md#funding-leads). No eligible applicant, auspice, nomination or funding commitment has been established. Capital support must include a credible continuing service plan.

Judge the service by tasks completed, information understood, current sources, requests acknowledged and resolved, usable offline capability, successful handovers, skills transferred and barriers removed. Show failures and continuing cost. Keep financial costs, voluntary contribution and actual benefits/harms as separate evidence; participation alone does not prove public benefit.

## 12 Brief wider connections

These are future interfaces and capability pathways. Their fuller research belongs in the [companion](supporting-research.md), keeping the kiosk deliverable focused.

| Connection | Limited relevance to this kiosk plan |
| --- | --- |
| Noticeboard media and events | One reviewed publishing flow for everyday information, urgent changes and device-specific accessible versions |
| Straddie twins | Dated place evidence, dependency views and exercises; historical/current/scenario modes stay distinct |
| Aura of Intelligence GAJRA Earth Verse Box and Aura Genesis | Personal AI navigation and just-in-time learning grounded in the values starting point, with explicit permissions and locally usable essential information |
| Shared Table and revised Dig for Australia | Approved food/supply summaries and practical growing, kitchen and mutual-help pathways; the original Dig chat remains unlocated |
| Clean energy makerspace and tip loop | Future power, repair, spares, material recovery and supervised skill development |
| Gumpi terminal mobility and Ballow Road | Potential transport information, accessible collection points, essential deliveries and host/training links; actual availability and charging remain dependencies |
| Sandworm and related materials research | Possible later fortification, material reuse, energy and skills work, subject to its own evidence; no assumed shelter or electrical backup capability |
| Try Everything Once and Brisbane 2032 | Paid supervised learning and later volunteering pathways; official selection and qualification requirements remain with the relevant programme |
| Web3 Sensorium and P4A | Intended grassroots growth from integrated local installations, evidence and useful cooperation into wider state/national platforms |

The wider civic direction is [Redlands discovers Luke Hayes](https://github.com/auraofintelligence/Redlands_discovers_Luke_Hayes) and [Purple Party for Australia (P4A)](https://p4a.xyz). P4A is an aspiration, including Luke's intended Cyber Republic referendum during or before 2031 and hoped-for Brisbane 2032 showcase. Aura of Intelligence's wider purpose includes retaining agency for people, communities, middle powers and small nations during the emergence of superintelligence. The kiosk is a practical local starting point for that direction.

The proposed [Moreton Bay Autonomous Mobility](https://github.com/auraofintelligence/moreton-bay-autonomous-mobility) interface would support later assisted transport requests and operator-confirmed service updates, including unavailable vehicles, routes, communications or charging. Broader infrastructure and future-scenario references remain in the companion.

## 13 Decisions before implementation

1. Choose the first three everyday tasks and the essential disaster tasks, including Aura navigation, the learning needed at each step and the human receiving service for any requests.
2. Define pilot geography, candidate hosts, device roles, information owners and who has authority to publish or change modes.
3. Set the test envelope and measurable limits for freshness, load, delivery, recovery and offline service.
4. Agree the nine-day exercise basis, measured essential load and the engineering work needed to test real autonomy.
5. Develop the proposed Ready S.E.T. Co-op operating model, cultural engagement, qualified cover, relief and continuing budget.
6. Set the prototype allowance and build brief; then choose the new repository's name and implementation tools.

The [supporting research](supporting-research.md) retains source editions, repository revisions, original-document distinctions and conditional funding leads for that next discussion.
