(function () {
  document.documentElement.classList.add("js-ready");

  const year = document.querySelector("[data-year]");
  const toTop = document.querySelector(".to-top");

  if (year) {
    year.textContent = new Date().getFullYear();
  }

  function updateTopButton() {
    if (!toTop) {
      return;
    }

    toTop.classList.toggle("is-visible", window.scrollY > 420);
  }

  updateTopButton();
  window.addEventListener("scroll", updateTopButton, { passive: true });
})();
