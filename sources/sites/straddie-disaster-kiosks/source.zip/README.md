# Straddie Disaster Kiosks

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 1 May 2026.
- GitHub repository: [straddie-disaster-kiosks](https://github.com/auraofintelligence/straddie-disaster-kiosks).
- Public site: [visit the public site](https://auraofintelligence.github.io/straddie-disaster-kiosks/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 16 relevant public connections.

### Capsule, habitat and resilience simulation

- [Minjerribah-Resilience](https://github.com/auraofintelligence/Minjerribah-Resilience) - [public page](https://auraofintelligence.github.io/Minjerribah-Resilience/) - shared technical architecture.
- [SSB](https://github.com/auraofintelligence/SSB) - [public page](https://auraofintelligence.github.io/SSB/) - shared technical architecture.
- [straddie-capsule-surge-lab](https://github.com/auraofintelligence/straddie-capsule-surge-lab) - [public page](https://auraofintelligence.github.io/straddie-capsule-surge-lab/) - explicit cross-reference, shared technical architecture.
- [straddie-digital-twin-builders](https://github.com/auraofintelligence/straddie-digital-twin-builders) - [public page](https://auraofintelligence.github.io/straddie-digital-twin-builders/) - shared technical architecture.
- [straddie-space-station-simulator](https://github.com/auraofintelligence/straddie-space-station-simulator) - [public page](https://auraofintelligence.github.io/straddie-space-station-simulator/) - shared technical architecture.
- [straddie-vitality-network-builders](https://github.com/auraofintelligence/straddie-vitality-network-builders) - [public page](https://auraofintelligence.github.io/straddie-vitality-network-builders/) - shared technical architecture.

### Island publication and community operations

- [ballow-road-sand-screen-hub](https://github.com/auraofintelligence/ballow-road-sand-screen-hub) - [public page](https://auraofintelligence.github.io/ballow-road-sand-screen-hub/) - shared community programme.
- [community-club-builder-sandy-sports](https://github.com/auraofintelligence/community-club-builder-sandy-sports) - [public page](https://auraofintelligence.github.io/community-club-builder-sandy-sports/) - shared community programme.
- [ready-set-co-op-hyperlocal-media](https://github.com/auraofintelligence/ready-set-co-op-hyperlocal-media) - [public page](https://auraofintelligence.github.io/ready-set-co-op-hyperlocal-media/) - explicit cross-reference, shared community programme.
- [ready-set-co-op-trust-hub](https://github.com/auraofintelligence/ready-set-co-op-trust-hub) - [public page](https://auraofintelligence.github.io/ready-set-co-op-trust-hub/) - shared community programme.
- [shared-table-initiative](https://github.com/auraofintelligence/shared-table-initiative) - [public page](https://auraofintelligence.github.io/shared-table-initiative/) - shared community programme.
- [stradbroke-grants-lab](https://github.com/auraofintelligence/stradbroke-grants-lab) - [public page](https://auraofintelligence.github.io/stradbroke-grants-lab/) - shared community programme.
- [straddie-content-assets-kit](https://github.com/auraofintelligence/straddie-content-assets-kit) - [public page](https://auraofintelligence.github.io/straddie-content-assets-kit/) - explicit cross-reference, shared community programme.
- [straddie-news](https://github.com/auraofintelligence/straddie-news) - [public page](https://auraofintelligence.github.io/straddie-news/) - shared community programme.
- [straddie-night-market-lab](https://github.com/auraofintelligence/straddie-night-market-lab) - [public page](https://auraofintelligence.github.io/straddie-night-market-lab/) - shared community programme.
- [straddie-noticeboard-network](https://github.com/auraofintelligence/straddie-noticeboard-network) - [public page](https://auraofintelligence.github.io/straddie-noticeboard-network/) - explicit cross-reference, shared community programme.

<!-- github-organisation:end -->

A public, multi-page concept site for useful everyday island screens that can also support local
information and resilience during disruptions. It connects rugged noticeboards, venue publishing,
beach-camera questions, media tools and Ready S.E.T. Co-op pathways.

The project is a planning and communication layer. It is not an emergency-warning service,
approved disaster plan, operational camera network or claim of venue participation.

## Comprehensive rebuild planning

The [comprehensive rebuild plan](docs/comprehensive-rebuild-plan.md) focuses on everyday kiosk use and demanding disaster operation across the network: trusted information, local releases, communications failures, power, requests, staffing and recovery. Aura of Intelligence would provide personal AI navigation and just-in-time learning, with GAJRA Earth as the values starting point. The [supporting research](docs/supporting-research.md) retains the original documents, related project references and conditional funding leads. The integrated service remains proposed and unimplemented, with Ready S.E.T. Co-op as the proposed intermediary.

## Existing pages

- `index.html` introduces the public-layer concept.
- `kiosks.html` explores kiosk roles and practical requirements.
- `noticeboards.html` connects device publishing to the noticeboard network.
- `venues.html` maps venue questions without implying agreement.
- `cameras.html` explores bounded public-camera uses and privacy questions.
- `ready-set.html` connects the concept to the Ready S.E.T. Co-op media pathway.
- `roadmap.html` separates useful early steps from later infrastructure.
- `docs/` holds source and planning notes.

## Use locally

Open `index.html` directly, or run `python -m http.server 8000` from this folder.

Any real deployment would still need community and cultural review, venue consent, current
emergency information, privacy and camera governance, accessibility, maintenance ownership,
connectivity and power planning.

## Links

- [Public project site](https://auraofintelligence.github.io/straddie-disaster-kiosks/)
- [Source repository](https://github.com/auraofintelligence/straddie-disaster-kiosks)
- [Ready S.E.T. Co-op and Hyperlocal Media](https://auraofintelligence.github.io/ready-set-co-op-hyperlocal-media/)
- [Straddie Noticeboard Network](https://auraofintelligence.github.io/straddie-noticeboard-network/)
- [Straddie Content Assets Kit](https://auraofintelligence.github.io/straddie-content-assets-kit/)
