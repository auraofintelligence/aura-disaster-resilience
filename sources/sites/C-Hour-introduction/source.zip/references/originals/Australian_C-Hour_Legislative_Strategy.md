## The Reciprocity Guidance: A Strategic Framework for Integrating Regenerative Assets into Australian Law

The Reciprocity Guidance: A Strategic Framework for Integrating Regenerative Assets into Australian Law

Executive Summary

Part I: The Australian Legislative and Political Landscape

Section 1.1: From Inquiry to Legislation: A Deliberate and Consultative Path

Section 1.2: Core Architecture of the Draft Digital Asset Platforms Bill 2025

Section 1.3: The Political Environment: An Alignment of Values and Ambition

Part II: The Policy Case for a 'Regenerative Asset' Carve-Out

Section 2.1: Deconstructing the 'Braided Economy' for Australian Policymakers

Section 2.2: The Community-Hour as a Non-Financial Product

Table 1: Comparative Analysis of Digital Asset Classifications (Australian Context)

Section 2.3: The 'Fundamental Incompatibility' Hook

Part III: A Strategic Framework for Legislative Integration

Section 3.1: Strategic Entry Points

Section 3.2: Crafting the 'Regenerative Asset' Amendment

Table 2: Proposed Amendments to Australian Legislation

Section 3.3: Proposed Regulatory Framework

Part IV: A Multi-Pronged Advocacy and Engagement Strategy

Section 4.1: Navigating the Parliamentary Process

Section 4.2: Targeted Parliamentary Outreach

Table 3: Key Stakeholder Matrix and Messaging Framework

Section 4.3: Building a Coalition of Support

Conclusion and Prioritised Recommendations Works cited

## Executive Summary

The Australian Government is on the cusp of implementing a landmark regulatory framework for digital assets. The exposure draft of the Treasury Laws Amendment (Regulating Digital Asset, And Tokenised Custody, Platforms) Bill 2025 represents a considered, principles-based approach to mitigating consumer harm and providing market certainty by bringing custodial intermediaries under the established Australian Financial Services Licence (AFSL) regime. 1 While this platform-centric model is a pragmatic and necessary step, its focus on financial intermediaries and custodial risk creates a strategic blind spot. It fails to adequately provide for a new generation of digital assets designed not for financial speculation, but for social and ecological regeneration. This omission risks stifling a uniquely powerful form of pro-social innovation that aligns directly with Australia's national interests.

This report presents a comprehensive legal and political strategy to address this gap by establishing a legislative 'carve-out' for a novel asset class: the 'Regenerative Asset'. The archetype for this class is the Community-Hour (C-hour), a non-speculative digital receipt for one hour of verified contribution to community well-being, ecological stewardship, or the care economy. 3 The C-hour is the cornerstone of a 'Braided Economy' model, designed to formally measure, value, and reward the foundational, non-market work that underpins a resilient society and a healthy environment.

The central recommendation of this report is to amend the forthcoming Digital Asset Platforms Bill 2025 and the Corporations Act 2001 to create a distinct and appropriate regulatory pathway for Regenerative Assets. This strategy does not oppose the Government's current direction but seeks to enhance it. The policy justification for this carve-out is derived directly from the Australian Treasury's own 'Token Mapping' exercise, which concluded that certain non-intermediated, community-governed token systems may be "fundamentally incompatible" with the existing financial services framework. 4 The C-hour system is a quintessential example of such a system.

By creating this clear legal lane, Australia can position itself as a global leader in fostering technology that generates tangible social dividends. This initiative strengthens the proposed Bill by promoting genuine, non-speculative innovation, enhancing consumer protection through an asset class that is pro-social by design, and providing a powerful, market-based tool to achieve the Albanese Government's stated ambition for a more inclusive, purposeful, and "values-based economy". 5 This report provides the specific legislative language, the detailed political engagement plan, and the compelling policy narrative required to turn this vision into a legal reality, securing profound benefits for the Australian community and environment.

## Part I: The Australian Legislative and Political Landscape

## Section 1.1: From Inquiry to Legislation: A Deliberate and Consultative Path

Australia's approach to regulating digital assets has been characterised by a deliberate, consultative, and evidence-led methodology. Unlike jurisdictions that have pursued reactive or enforcement-centric strategies, the Australian policy trajectory reveals a commitment to understanding the underlying technology and its economic functions before prescribing regulation. This methodical process, from parliamentary inquiry to detailed policy consultation, has created a sophisticated and well-reasoned foundation for the current legislative reforms. It is this very process that provides the important entry points for a nuanced proposal to recognise Regenerative Assets. The government has demonstrated a clear willingness to engage with complex arguments and adapt its approach based on evidence, creating a favourable environment for a proposal that builds upon, rather than contradicts, its existing work.

The genesis of the current reform agenda can be traced to the landmark Final Report of the Senate Select Committee on Australia as a Technology and Financial Centre, tabled in October 2021. 7 Chaired by then-Senator Andrew Bragg, this comprehensive inquiry engaged deeply with industry, academia, and regulators to map the opportunities and risks of the burgeoning digital asset sector. 10 The Committee's report was pivotal, moving the policy debate beyond simplistic narratives and toward a sophisticated understanding of the technology's potential. It made twelve key recommendations, forming a coherent roadmap for reform. Central among these were proposals to establish a market licensing regime for digital currency exchanges, introduce minimum standards for the custody of digital assets, and, most critically for this strategy, a recommendation that the Australian Government, through Treasury, conduct a 'token mapping' exercise to determine the best way to characterise the various types of digital assets in Australia. 8

The then-Coalition Government's response in December 2021, titled "Transforming Australia's Payment System," signalled a broad, bipartisan consensus on the need for action by agreeing in principle to the core recommendations, including the token mapping exercise. 14 This commitment was subsequently carried forward by the incoming Albanese Labour Government, demonstrating a shared understanding across the political spectrum that regulatory clarity was helpful for both consumer protection and innovation.

This commitment culminated in the release of Treasury's 'Token Mapping Consultation Paper' in February 2023, a foundational document in Australia's digital asset policy development. 4

This paper was not a simple taxonomy but a sophisticated attempt to apply Australia's established regulatory principles to the novel crypto ecosystem. Its methodology was explicitly guided by two long-standing pillars of Australian financial regulation: technology neutrality and a 'functional approach'. 17 Rather than creating bespoke rules for specific technologies, the paper sought to identify the economic 'function' of a given crypto asset or service and assess whether that function fell within the existing regulatory 'perimeter' of a 'financial product' as defined in the Corporations Act 2001 . 4

To achieve this, the paper proposed a framework for classifying crypto arrangements into three components: the 'token' (the digital record-keeping unit), the 'token system' (the protocol or arrangement governing the token), and the 'function' (the product or benefit provided). 4 It is this analytical framework that produced the most significant conclusion for the purposes of this strategy. The paper drew a clear distinction between two types of token systems:

1. Intermediated Token Systems: Where an intermediary (such as an exchange or a custodian) makes promises and provides services to a consumer. A large portion of the crypto ecosystem falls into this category, and the risks are analogous to traditional financial services. 4
2. Public Token Systems: Where users form transactional relationships directly on a public network, often governed by smart contracts, in the absence of a traditional intermediary.

The paper's important finding, which forms the lynchpin of the policy case for a Regenerative Asset carve-out, was its conclusion regarding this second category. Treasury acknowledged that products in this category, which operate without the intermediaries that financial services law is designed to regulate, "may be fundamentally incompatible with the existing financial services regulatory framework". 4 This official recognition of a potential regulatory mismatch is not a flaw in the government's analysis but a sophisticated observation that provides the explicit policy justification for creating a new, more appropriate regulatory pathway for assets that fit this description.

## Section 1.2: Core Architecture of the Draft Digital Asset Platforms Bill 2025

The intellectual work of the Token Mapping exercise directly informs the architecture of the Government's proposed legislative solution: the exposure draft of the Treasury Laws Amendment (Regulating Digital Asset, And Tokenised Custody, Platforms) Bill 2025 , released for consultation in September 2025. 1 The Bill is a direct and logical consequence of the token mapping findings. Having identified that the primary source of unmitigated consumer risk resides in 'intermediated' platforms that take custody of client assets, the Bill is precisely tailored to address this specific harm. 20 Its core logic is to regulate the activity of providing a custodial digital asset facility, rather than attempting to define the legal nature of every underlying asset itself.

This is achieved through a significant amendment to the Corporations Act 2001 , which introduces two new categories of 'financial product'. 1 The creation of these new product categories brings the providers of these facilities squarely within the existing and well-understood AFSL regime. The two new products are:

- Digital Asset Platform (DAP): Defined as a facility where an operator holds digital tokens on behalf of clients. This definition is broad, intended to capture a wide range of business models, including cryptocurrency exchanges, custodial wallet providers, and staking services where the provider takes control of the client's tokens. 20
- Tokenised Custody Platform (TCP): Defined as a facility where an operator holds an underlying asset (which can be physical, like gold, or intangible, like shares) and creates a unique digital token that represents the client's right to redeem or direct that underlying asset. This covers services that 'tokenise' real-world assets. 20

Under the proposed legislation, any entity providing these DAP or TCP facilities, or providing financial services such as advice in relation to them, will be required to hold an AFSL issued by the Australian Securities and Investments Commission (ASIC). 1 This triggers a comprehensive suite of regulatory obligations designed to protect consumers and ensure market integrity. These obligations include meeting standards for capital adequacy, having robust risk management systems, ensuring key personnel are competent, providing adequate disclosure to clients via a new 'Platform Guide', and having internal and external dispute resolution mechanisms. 2

A key feature of the Bill's architecture is its deliberate technology-neutral language. The draft legislation avoids using specific, and potentially transient, technological terms like 'blockchain', 'cryptocurrency', or 'distributed ledger technology'. 1 Instead, it uses broader concepts like 'digital token' and 'digital object'. This approach is designed for longevity, ensuring the framework can adapt to future technological developments without requiring constant legislative amendment. This principle of technology neutrality is a strategic advantage that can be leveraged, as it allows for a focus on the economic substance and purpose of an asset, rather than its underlying technical implementation.

The Bill also includes a low-value exemption. Platforms that hold less than $5,000 per customer and facilitate less than $10 million in total transactions per year will be exempt from the AFSL requirement. 1 While this may provide a pathway for small-scale or early-stage projects, it is fundamentally unsuitable for the C-hour protocol, which is designed for national and global scale and would quickly exceed these thresholds. Therefore, relying on this exemption is not a viable long-term strategy. The C-hour requires a dedicated, purpose-built regulatory classification that recognises its unique nature, rather than an exemption based on its scale.

## Section 1.3: The Political Environment: An Alignment of Values and Ambition

The success of any legislative reform strategy depends critically on its alignment with the prevailing political environment and the priorities of key decision-makers. In the context of the C-hour proposal, the current Australian political landscape presents a uniquely receptive and favourable climate. The Albanese Labour Government's core economic and social narrative, the specific policy interests of the ministers responsible for the legislation, and the backgrounds and public statements of influential committee members and crossbenchers all indicate a powerful alignment of values and ambition with the foundational principles of the Regenerative Asset class. This proposal does not could create a new political conversation; it can join and amplify an existing one about how to build a more purposeful, inclusive, and sustainable Australian economy.

## Government Leadership:

At the apex of economic policymaking, The Hon Dr Jim Chalmers MP , the Treasurer, has embarked on a significant public intellectual project to redefine the goals of economic policy in Australia. 24 In a widely discussed essay and numerous speeches, he has called for a move towards a "values-based capitalism" or a "social purpose economy". 5 He argues that economic policy could look beyond traditional metrics like GDP to measure well-being and social cohesion, and that markets should be designed to deliver a "social dividend". 6 He has explicitly championed the expansion of social impact investing and the option to find new models to fund solutions in areas like aged care and disability services, where markets have traditionally failed. 6 This overarching philosophy provides the premier political and intellectual anchor for the C-hour proposal. The C-hour is a tangible, scalable mechanism to build the very "social purpose economy" the Treasurer has described.

Directly responsible for the legislation is The Hon Dr Daniel Mulino MP , the Assistant Treasurer and Minister for Financial Services. 30 As the minister steering the digital asset reforms, his public framing is crucial. He has consistently described the Bill's purpose as "legitimising the good actors and shutting out the bad," and providing "certainty for business and confidence for consumers". 20 This framing creates a clear strategic imperative: to position the C-hour not as a fringe crypto-asset seeking to evade regulation, but as the archetypal "good actor" asset-one that is non-speculative, transparent, and pro-social by its very design. The advocacy strategy could present the proposal as an enhancement that helps the Minister achieve his stated goals.

Supporting this is The Hon Ed Husic MP , the Minister for Industry and Science. 36 His portfolio focus on building sovereign capability, backing Australian-led innovation, and creating a "Future Made in Australia" provides a powerful industrial policy lens. 38 The Regenerative Civilisation Protocol, as a homegrown, globally significant innovation, can be framed as a key contributor to this agenda, positioning Australia at the forefront of a new, more ethical model of technological and social development.

## Key Parliamentary Committees:

The legislative journey of the Bill will be critically shaped by parliamentary committees, particularly in the Senate. The Senate Economics Legislation Committee is the primary body responsible for scrutinising Treasury legislation. Its current Chair is Senator Lisa Darmanin (ALP, VIC) . 42 Senator Darmanin's career prior to entering parliament was with the Australian Services Union, where she was a lifelong advocate for workers in the community and care sectors, leading landmark campaigns for equal pay and the recognition of undervalued work. 44 Her public statements and career history demonstrate a deep, personal understanding of the very issues the C-hour is designed to address. Her position as chair of the key committee represents an extraordinary alignment, making her a pivotal and potentially highly receptive audience for this proposal.

In the House of Representatives, the Standing Committee on Economics , chaired by Minister Husic, plays a vital role in shaping economic debate. Its membership includes influential voices such as the independent Member for Wentworth, Ms Allegra Spender MP . 36 A former business leader, Ms Spender is deeply focused on Australia's productivity challenges, intergenerational fairness, and the need for ambitious economic reform. 47 The C-hour's potential to unlock the productivity of the non-market economy and create new forms of value for community contribution speaks directly to her stated policy concerns.

## Opposition and Crossbench:

Building bipartisan support is helpful for the long-term success and stability of any legislative reform. Senator the Hon Andrew Bragg (Liberal, NSW) is a key figure in this regard. 51 As the architect of the 2021 Senate inquiry, he has a deep understanding of the issues and is a vocal advocate for a clear, pro-innovation regulatory framework. 10 His frustration with the current government's pace of reform led him to introduce his own Private Senator's Bill, the Digital Assets (Market Regulation) Bill 2023 , demonstrating his willingness to lead on the issue. 11 Engaging him constructively and positioning the Regenerative Asset carve-out as a logical extension of his own committee's work will be important.

Similarly, Senator the Hon Jane Hume (Liberal, VIC) , a former Minister for Superannuation, Financial Services and the Digital Economy, is a highly experienced and respected voice on financial technology and innovation. 42 Her support would lend significant credibility to the proposal within the Coalition.

Finally, The Australian Greens are natural allies for this initiative. Their core platform is built on principles of ecological sustainability, social justice, and challenging economic models that externalise costs onto the community and the environment. 59 The C-hour's function of rewarding environmental regeneration and community work aligns perfectly with their policy objectives, making them strong potential champions for the amendment in the Senate, where they frequently hold the balance of power. 61

## Part II: The Policy Case for a 'Regenerative Asset' Carve-Out

## Section 2.1: Deconstructing the 'Braided Economy' for Australian Policymakers

To secure a legislative carve-out, the conceptual framework of the 'Braided Economy' and the Community-Hour could be translated from a global protocol into the specific language and context of Australian public policy. The core argument-that modern capitalism operates on an "incomplete ledger" by failing to value foundational work-could be grounded in tangible Australian challenges and data. 3 By doing so, the C-hour is no longer presented as an abstract technological novelty, but as a pragmatic, market-based tool designed to solve well-documented, pressing national problems.

The concept of the "incomplete ledger" resonates powerfully with Australia's widely discussed "productivity puzzle." While productivity in traditional sectors is a constant focus of economic debate, the vast and growing 'foundational economy'-comprising care, community services, and environmental stewardship-is often overlooked in these discussions. Yet, this sector is important to national well-being and economic resilience. The C-hour offers a mechanism to make the value of this work visible on a national scale. For instance, volunteering in Australia contributes an estimated $290 billion to the economy annually-a staggering figure that remains largely invisible in conventional economic accounts. Similarly, the work of over 2.65 million informal caregivers, who provide useful support to the elderly and people with disabilities, represents an enormous economic subsidy to the formal healthcare and social services systems. The C-hour system, through mechanisms like a 'Caregiver's Dividend', would provide a formal, non-welfare-based recognition and reward for this useful labour, directly addressing the Treasurer's call for new models that create a measurable "social dividend". 3

Furthermore, the C-hour can be framed as a powerful tool for achieving specific government policy objectives. In the environmental sphere, it can create direct incentives for participation in regeneration and conservation activities, supporting the work of community groups like Landcare and local conservation volunteers. In social policy, it can foster community cohesion and combat loneliness by rewarding mentorship, neighbourhood support, and civic engagement. This reframes the C-hour from a 'cryptocurrency' into a versatile public policy instrument. It is a market-based, non-bureaucratic mechanism for directing human capital towards areas of national priority that are currently underserved by the traditional financial economy. This narrative aligns with the principles of both major parties: it offers a market-oriented solution that empowers individuals and communities, consistent with conservative principles, while also achieving progressive goals of valuing care work and strengthening the social safety net.

## Section 2.2: The Community-Hour as a Non-Financial Product

The legal cornerstone of the strategy is to establish that the Community-Hour (C-hour) system, as designed, falls outside the existing regulatory perimeter of the Corporations Act 2001 . It is not a 'financial product' and the protocol governing it is not a 'Digital Asset Platform' (DAP) or a 'Tokenised Custody Platform' (TCP) as defined in the proposed 2025 Bill. This argument is not based on a technical loophole, but on the fundamental purpose and structure of the asset, which is intentionally designed to be non-financial.

A systematic analysis against the definitions in Chapter 7 of the Corporations Act and ASIC's guidance demonstrates this distinction. 62 The C-hour is not:

- A Security: The C-hour fails the established legal test for an investment contract (known in the US as the Howey Test and applied similarly in Australian jurisprudence). There is no "investment of money" with an "expectation of profits arising from the efforts of a third party". 3 Users earn C-hours through their own personal contributions of time and effort. The value they receive is a direct result of their own work, not the managerial efforts of a promoter or a centralised entity seeking to generate a financial return for investors. 3
- An Interest in a Managed Investment Scheme (MIS): An MIS involves people contributing money or assets to a common pool, which is then used by a 'responsible entity' to generate financial benefits that are distributed back to the members. 62 The C-hour system operates differently. There is no common pool of invested capital. The governing body, a Decentralised Autonomous Organisation (DAO), is not a responsible entity managing investments for profit; it is a community-governed protocol for verifying
- and recording contributions. The benefits are earned individually and directly by participants for their own work. 3
- A Derivative or a Non-Cash Payment Facility: The C-hour's value is not derived from another financial instrument, nor is it designed as a general-purpose facility for making payments across the economy. Its utility is primarily within the 'Reciprocity Economy' for redeeming specific community-backed goods and services. 3

Crucially, the C-hour protocol is also not a DAP or a TCP under the proposed 2025 Bill. The defining characteristic of both a DAP and a TCP is the presence of a custodial 'operator'-an intermediary that holds assets on behalf of clients. 20 This custodial relationship is the specific risk the Bill is designed to regulate. The C-hour system is architected to eliminate this risk. C-hours are earned directly into a user's self-custodied digital wallet. The user has exclusive control of their private keys and, therefore, their assets. The protocol's software and the governing DAO facilitate the verification and issuance of C-hours, but they do not take custody of them. The 'operator' is the decentralised community itself, not a corporate intermediary. This fundamental structural difference means the C-hour system does not create the custodial risks that the AFSL regime for DAPs and TCPs is designed to mitigate, making that regulatory framework both unnecessary and inappropriate.

## Table 1: Comparative Analysis of Digital Asset Classifications (Australian Context)

| Feature          | Financial Product ( Corporations Act 2001 )                                 | Digital Asset Facility (Proposed Bill)                                                           | Proposed: Regenerative Asset                                                                      |
|------------------|-----------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|
| Primary Purpose  | Financial investment; capital formation; risk management; non-cash payment. | To provide a custodial platform for holding and transacting digital assets on behalf of clients. | To measure, value, and reward non-financial contributions to community and ecological well-being. |
| Value Derivation | Expectation of future financial profit from the efforts of others;          | Market value of the underlying digital assets held in custody; platform                          | Verified off-chain human work (e.g., one hour of caregiving,                                      |

|                            | underlying financial instruments.                                                       | utility.                                                                                              | volunteering, or environmental restoration).                                                               |
|----------------------------|-----------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------|
| Issuance / Creation Method | Issued by a promoter or company via an investment contract (e.g., a PDS or prospectus). | A facility is 'issued' or provided by a platform operator to a client who opens an account.           | Earned directly by individuals through verified personal contributions to the community.                   |
| Key Risks                  | Investor fraud; lack of disclosure; market volatility; insolvency of the issuer.        | Platform insolvency; commingling of assets; fraud; cyber theft; operational failure of the custodian. | Integrity of the contribution verification process; failure of DAO governance; lack of redemption utility. |
| Appropriate Regulator      | ASIC (under a full AFSL and/or market licence regime).                                  | ASIC (under the proposed AFSL regime for DAPs and TCPs).                                              | ASIC (under a proposed new, light-touch registration and disclosure framework).                            |

## Section 2.3: The 'Fundamental Incompatibility' Hook

The most compelling policy argument for a bespoke legislative carve-out for Regenerative Assets is not one that needs to be invented from whole cloth. It is an argument that the Australian Treasury has already made itself. The strategic approach is to leverage the government's own sophisticated analysis from the Token Mapping Consultation Paper, positioning the proposed amendment as the logical and necessary policy response to its own findings. 4 This transforms the advocacy from a request for special treatment into a collaborative effort to complete the government's own policy architecture.

The argument can be constructed in a clear, linear progression that is easy for policymakers

## to follow:

1. Acknowledge and Endorse Treasury's Analysis: The first step is to commend Treasury for its nuanced and insightful analysis in the Token Mapping paper. Specifically, its distinction between 'intermediated token systems' and 'public token systems' is a crucial and accurate observation of the crypto ecosystem's structure. 4
2. Affirm the Appropriateness of the Draft Bill for Intermediated Systems: The second step is to affirm that the Digital Asset Platforms Bill 2025 is an excellent, well-designed, and appropriate regulatory framework for the risks associated with 'intermediated' systems. By focusing on custodial platforms, the Bill correctly targets the primary source of consumer harm seen in recent market failures, such as platform insolvency and the misuse of client funds. 20 This demonstrates that the proposal is not anti-regulation, but proappropriate -regulation.
3. Classify the C-hour as a 'Public Token System': The third step is to clearly demonstrate that the C-hour and the Regenerative Civilisation Protocol are a quintessential example of a 'public token system'. It is a system designed to enable a community to form transactional relationships (the earning and redemption of C-hours) directly, governed by a transparent protocol and a DAO, specifically without the need for a traditional, custodial intermediary. 3
4. Invoke Treasury's Own Conclusion: The final and most powerful step is to directly quote or paraphrase Treasury's own conclusion from the Token Mapping paper: that such public, non-intermediated systems "may be fundamentally incompatible with the existing financial services regulatory framework". 4

This line of reasoning leads to an unavoidable conclusion. If the government's own expert analysis has identified a class of systems that do not fit the existing regulatory model, and the C-hour is a prime example of such a system, then attempting to force it into the legislative framework designed for 'intermediated' systems would be a policy error. It would create a regulatory mismatch, imposing inappropriate and burdensome obligations designed for risks that do not exist in the C-hour model, while failing to address the unique risks that do (such as governance and verification integrity). Therefore, the creation of a separate, bespoke 'carve-out' is not a special favour or an exemption from the rules. It is the direct, logical, and responsible policy action required to address the "fundamental incompatibility" that Treasury itself has identified. This approach allows advocates to present themselves as helpful partners in the policy-making process, assisting the government in completing the important work it has already started.

## Part III: A Strategic Framework for Legislative Integration

## Section 3.1: Strategic Entry Points

A coherent policy case could be matched with a precise and actionable legislative strategy. The primary and most immediate legislative vehicle for creating a legal carve-out for Regenerative Assets is the Treasury Laws Amendment (Regulating Digital Asset, And Tokenised Custody, Platforms) Bill 2025 . 1 The strategy is to propose amendments directly to this Bill as it moves through the policy development and parliamentary process. This is the most efficient pathway, as it leverages the existing political momentum and legislative timetable for digital asset reform.

The secondary but useful legislative target is the parent act, the Corporations Act 2001 , specifically Chapter 7, which contains the foundational definitions of 'financial product' and 'financial service'. 21 Any amendment to the new Bill to create a carve-out requirement be supported by a corresponding definitional amendment to the principal Act to ensure legal consistency and clarity. The proposed amendments are designed to work in tandem: one creates the positive legal definition of a 'Regenerative Asset', and the other explicitly excludes it from the new custodial platform regime.

The timing of this intervention is important. The most effective entry point is the current public consultation phase on the exposure draft of the Bill. By lodging a comprehensive submission with Treasury that includes the detailed legal arguments from Part II and the specific draft legislative text from Section 3.2, the proposal can be considered by departmental officials and the Minister's office before the Bill is finalised and introduced to Parliament. This provides the greatest opportunity for the amendments to be adopted into the government's own version of the Bill, which is a far more effective strategy than attempting to force amendments later in the parliamentary process. Should this initial approach be unsuccessful, the secondary strategy would be to work with supportive parliamentarians to move the amendments during the committee stage of the Bill's review in the Senate.

## Section 3.2: Crafting the 'Regenerative Asset' Amendment

To move from a policy concept to a legal reality, it is helpful to provide policymakers with concrete, professionally drafted legislative language. This significantly lowers the barrier to adoption and demonstrates a high level of sophistication and seriousness. The proposed amendment package consists of two core components designed to be inserted into the relevant legislation.

## Part 1: New Definition in the Corporations Act 2001

The first component is the creation of a positive legal definition for the new asset class. This would involve proposing a new definition for insertion into the primary definitions section of the Corporations Act 2001 (section 9 or 761A). The proposed wording is:

regenerative asset means a digital representation of value that:

- (a) serves as a digital receipt for a verified, non-financial contribution of time, effort, or resources to community, ecological, or social well-being; and
- (b) is earned by a person through such a verified contribution and is not offered to the public primarily for the purpose of a passive financial investment or with the expectation of profit derived from the managerial efforts of a promoter or third party; and
- (c) is not a non-cash payment facility within the meaning of section 763D.

This definition is carefully crafted to be both precise and principles-based. It anchors the asset in its pro-social purpose (subsection a), distinguishes its issuance method from that of a security or investment product (subsection b), and explicitly separates it from payment systems (subsection c).

## Part 2: Exclusionary Clause in the Draft Digital Asset Platforms Bill 2025

The second component is an exclusionary clause to be inserted into the section of the new Bill that defines a 'digital asset platform'. This ensures that while Regenerative Assets are legally recognised, the protocols that facilitate them are not captured by the custodial AFSL regime. The proposed wording is:

A facility is not a digital asset platform to the extent that it is a facility for holding, or facilitating the use of, a regenerative asset.

This dual-pronged approach is legally robust. It first establishes 'Regenerative Asset' as a distinct legal concept within the foundational law of Australian financial services. It then uses that new definition to explicitly and cleanly carve it out from the specific custodial regime being created by the new Bill. This creates the necessary legal space for a separate, more appropriate regulatory framework to be developed for this unique asset class.

## Table 2: Proposed Amendments to Australian Legislation

| Act / Bill                                                                                     | Section for Amendment                                                                     | Proposed New / Amended Language                                                                                                                                                                                                                                                                                                                             | Strategic Rationale                                                                                                                                                                                                                               |
|------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Corporations Act 2001                                                                          | Section 761A (Definitions)                                                                | Insert a new definition: " regenerative asset means a digital representation of value that: (a) serves as a digital receipt for a verified, non-financial contribution...; and (b) is earned by a person... and is not offered to the public primarily for the purpose of a passive financial investment...; and (c) is not a non-cash payment facility..." | Creates a clear, positive legal definition for the C-hour and similar assets within the principal Act. This anchors their legal status in their pro-social purpose and non-financial nature, providing a durable foundation for their regulation. |
| Treasury Laws Amendment (Regulating Digital Asset, And Tokenised Custody, Platforms) Bill 2025 | Section defining 'digital asset platform' (e.g., proposed s763F of the Corporations Act ) | Insert a new exclusionary sub-clause: "A facility is not a digital asset platform to the extent that it is a facility for holding, or facilitating the use of, a regenerative asset."                                                                                                                                                                       | Legally separates Regenerative Asset protocols from the AFSL regime designed for custodial, speculative platforms. This prevents the application of an inappropriate and burdensome regulatory                                                    |

|                       |                      |                                                                                                                                                                | framework and creates the clear policy need for a new, 'fit-for-purpose' alternative.                                                                                                                                                                           |
|-----------------------|----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Corporations Act 2001 | Chapter 7 (New Part) | Add a new Part: " Part 7.XX- Registration of Regenerative Asset Protocols ". This Part would establish a light-touch registration regime administered by ASIC. | Proactively establishes a bespoke, appropriate regulatory framework. This counters any argument that the carve-out is an attempt to avoid all oversight, positioning the proposal as responsible and committed to consumer protection and governance integrity. |

## Section 3.3: Proposed Regulatory Framework

A legislative strategy that merely creates a carve-out without proposing an alternative form of oversight is politically vulnerable. It can be portrayed as an attempt to create an unregulated 'wild west', which runs counter to the government's clear focus on consumer protection. 20 To pre-empt this criticism and demonstrate a commitment to responsible innovation, the carve-out could be paired with a proposal for an alternative, 'fit-for-purpose' regulatory framework. This framework should be designed to address the unique risks of Regenerative Assets, which are related to governance and verification integrity rather than custodial or market risk.

The proposed framework would be a 'light-touch' registration regime, not a full AFSL regime. Protocols that issue or facilitate Regenerative Assets, such as the C-hour protocol, would be required to register with ASIC. This would provide regulators with visibility over the sector without imposing the costly and inappropriate compliance burdens of the AFSL framework.

Upon registration, the protocol's operators (i.e., the governing DAO or its legal wrapper) would be required to comply with a set of tailored standards focused on transparency and integrity. These standards would include:

- Integrity of Contribution Verification: The protocol could have clear, publicly disclosed, and auditable rules and processes for how contributions are verified and how Regenerative Assets are earned. This addresses the core risk of the system's integrity and ensures that assets are genuinely linked to pro-social work.
- Governance Transparency: The protocol could publicly disclose its governance framework. This includes the rules of the governing DAO, how proposals are made and voted upon, how the protocol's treasury is managed, and the rights of asset holders within the governance system. This provides participants with a clear understanding of how the system is controlled and can be changed.
- Consumer Information and Disclosure: The protocol could provide users with a clear, concise, and easy-to-understand 'Protocol Statement'. This document, analogous to the Bill's 'Platform Guide', would not be a financial product disclosure statement (PDS). Instead, it would outline the protocol's purpose, the nature of the Regenerative Asset, the specific goods, services, or benefits for which it can be redeemed, the risks associated with participation (e.g., governance failure, smart contract risk), and the dispute resolution process.

This proposed framework achieves the ideal balance. It removes Regenerative Assets from a regulatory regime designed for speculative financial products while establishing a new regime that is precisely tailored to their unique characteristics and risks. It ensures accountability and protects participants while fostering the growth of this powerful new model for social and ecological innovation.

## Part IV: A Multi-Pronged Advocacy and Engagement Strategy

## Section 4.1: Navigating the Parliamentary Process

A sophisticated legislative proposal requires an equally sophisticated and strategically timed advocacy campaign. The objective is to guide the 'Regenerative Asset' amendment through the key inflection points of the Australian parliamentary process, building a broad coalition of support at each stage. The strategy could be proactive, engaging with the policy development process before the Bill is finalised, and adaptable, preparing for engagement throughout the legislative journey.

The advocacy campaign will be sequenced according to the following timeline-based strategy:

1. Immediate (Consultation Phase): The highest leverage opportunity exists now, during the public consultation period for the exposure draft of the Digital Asset Platforms Bill 2025 . The immediate priority is to finalise and lodge a comprehensive submission with the Australian Treasury. This submission will be the formal vehicle for the arguments and draft legislative text detailed in Parts II and III of this report. It will be framed as a constructive contribution aimed at enhancing and future-proofing the government's proposed framework.
2. Short-Term (Pre-Introduction Phase): Following the submission, the focus will shift to direct engagement. The goal is to secure briefings with the senior ministerial advisors in the offices of the Treasurer (Dr Chalmers) and the Assistant Treasurer (Dr Mulino). The purpose of these meetings is to present the proposal directly, answer technical questions, and make the political case for why adopting this amendment strengthens their legislation and aligns with their core policy objectives.
3. Medium-Term (Parliamentary Phase): Once the Bill is finalised by the government and introduced into Parliament, the primary focus of advocacy will shift to the Senate, specifically the Senate Economics Legislation Committee, which will conduct an inquiry into the Bill. This phase will involve preparing a supplementary submission for the committee, seeking to appear and provide testimony at public hearings, and engaging directly with the offices of all committee members, with a particular focus on the Chair, Senator Darmanin.
4. Contingency (Amendment Phase): If the government does not adopt the proposed amendments in its own version of the Bill, the strategy will shift to having the amendments moved in the Senate. This will involve working closely with identified parliamentary champions-such as Senator Bragg from the Coalition and Senators from The Australian Greens-to have our proposed legislative text formally moved as amendments during the committee stage of the debate in the Senate chamber. This requires building the cross-party support necessary to ensure the amendments have a realistic chance of passage.

This phased approach ensures that influence is applied at every important juncture, from the initial policy formulation within the executive to the final legislative debate in the parliament.

## Section 4.2: Targeted Parliamentary Outreach

Effective advocacy requires tailored messaging that resonates with the specific political priorities, ideological frameworks, and constituencies of different decision-makers. A one-size-fits-all approach is ineffective. The engagement strategy will deploy distinct but complementary narratives for each key political group, leveraging the detailed analysis from Part I of this report.

- For the Australian Labour Party (Government):
- Target Audience: Treasurer Jim Chalmers, Assistant Treasurer Daniel Mulino, Industry Minister Ed Husic, and Senate Economics Legislation Committee Chair Lisa Darmanin.
- Core Message: "The Regenerative Asset is the Treasurer's 'values-based economy' in action."
- Key Messaging Hooks: The C-hour will be presented as a tangible policy tool to achieve Labour's core objectives. The narrative will focus on its ability to formally value the work done in the care economy, a sector dominated by women, thereby advancing women's economic security-a key priority for Senator Darmanin. 44 It will be framed as a mechanism for building community resilience, strengthening civil society, and providing a market-based pathway to a more inclusive economy, directly aligning with Dr Chalmers' vision. 5 For Minister Husic, it will be positioned as a world-leading, sovereign Australian innovation that builds a "Future Made in Australia" based on social and technological leadership. 38
- For the Liberal-National Coalition (Opposition):
- Target Audience: Senator Andrew Bragg, Senator Jane Hume, and Shadow Treasurer Angus Taylor.
- Core Message: "A pro-innovation, market-based solution that strengthens civil society without growing government."
- Key Messaging Hooks: The narrative for the Coalition will de-emphasise government intervention and highlight individual and community empowerment. The C-hour will be framed as a mechanism that encourages self-reliance and rewards the foundational work of families and community volunteers-themes that align with conservative principles. For Senators Bragg and Hume, the emphasis will be on providing regulatory certainty for a new wave of non-speculative digital innovation, positioning Australia as a global leader, and enhancing consumer protection through pro-social design rather than heavy-handed regulation. 10
- For the Crossbench:
- Target Audience: Ms Allegra Spender MP and The Australian Greens.
- Core Message (Spender): "A new engine for productivity and intergenerational fairness."
- Key Messaging Hooks (Spender): Engagement with Ms Spender will focus on the C-hour's potential to address Australia's productivity slowdown by making the vast, unmeasured foundational economy visible and efficient. 47 It will be presented as a tool to create new forms of assets and opportunities for younger generations, addressing the intergenerational equity concerns she has frequently raised. 48
- Core Message (The Greens): "A practical tool to fund the regeneration of our environment and communities."
- Key Messaging Hooks (The Greens): The narrative for The Greens will focus on the tangible outcomes. The C-hour will be presented as a way to directly fund and incentivise environmental restoration work, such as reforestation and waterway cleanup, and to challenge the extractive logic of the current economic system by rewarding regenerative activities. 59

This tailored messaging ensures that the proposal is always presented in the most compelling and politically resonant manner for each specific audience, maximising the potential for building a broad, multi-partisan coalition of support.

## Table 3: Key Stakeholder Matrix and Messaging Framework

| Stakeholder / Target       | Role / Relevance                  | Primary Engagement Goal                                                                                  | Key Messaging Hooks & Framing                                                                                                                                                                                             |
|----------------------------|-----------------------------------|----------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| The Hon Dr Jim Chalmers MP | Treasurer, Australian Labour Party | Secure top-level government endorsement for the 'Regenerative Asset' concept as a key policy innovation. | "The C-hour is a tangible mechanism to build the 'values-based' and 'social purpose economy' you described in The Monthly ." Frame as a tool for measuring well-being beyond GDP and promoting social impact investing. 5 |

![Image]([IMAGE_DATA_REMOVED_FOR_AI_EFFICIENCY])

| The Hon Dr Daniel Mulino MP   | Assistant Treasurer & Minister for Financial Services, ALP          | Persuade the Minister to incorporate the proposed amendments into the final version of the Digital Asset Platforms Bill .             | "This amendment strengthens your Bill by 'legitimising the good actors' and creating a safe harbour for pro-social, non-speculative innovation, enhancing consumer confidence.". 20                                 |
|-------------------------------|---------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Senator Lisa Darmanin         | Chair, Senate Economics Legislation Committee, ALP                  | Secure a powerful champion within the key parliamentary committee who understands the value of uncompensated care and community work. | "This legislation formally recognises and rewards the very work you have spent your career fighting for-in the care and community sectors. It is a modern tool for achieving pay equity and economic security.". 44 |
| Senator the Hon Andrew Bragg  | Deputy Chair, Senate Economics Legislation Committee, Liberal Party | Gain bipartisan support and a potential champion to move amendments if the government does not adopt them.                            | "This proposal completes the work of your landmark Senate inquiry by creating the regulatory certainty needed for non-financial digital assets, positioning Australia as a global leader.". 10                      |
| Ms Allegra Spender MP         | Member, House Economics                                             | Build crossbench support by linking                                                                                                   | "The C-hour addresses                                                                                                                                                                                               |

![Image]([IMAGE_DATA_REMOVED_FOR_AI_EFFICIENCY])

|                                           | Committee, Independent                               | the proposal to mainstream economic reform priorities.                                                                               | Australia's productivity puzzle by unlocking the value of the foundational economy. It's a tool for intergenerational fairness and a more dynamic economic model.". 47                              |
|-------------------------------------------|------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| The Australian Greens                     | Key crossbench party in the Senate                   | Secure a bloc of votes in the Senate and vocal public advocates for the environmental and social benefits.                           | "This is a direct challenge to the extractive economy. The C-hour provides a mechanism to fund ecological regeneration and reward the community stewardship that our current system ignores.". 59   |
| Australian Treasury                       | Department responsible for drafting the legislation. | Ensure departmental officials understand the legal and economic rationale and view the proposal as a constructive policy refinement. | Frame the proposal using Treasury's own language from the Token Mapping paper, arguing it is the logical response to the "fundamental incompatibility" of public token systems with existing law. 4 |
| Social Traders & Social Enterprise Sector | Peak bodies representing businesses with a           | Build a powerful coalition of third-party                                                                                            | "The C-hour provides the infrastructure to                                                                                                                                                          |

| social mission.   | validators who can speak to the practical benefits of the model.   | scale the social enterprise model nationally, aligning with your advocacy for social procurement and a national social enterprise strategy.". 63   |
|-------------------|--------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|

## Section 4.3: Building a Coalition of Support

While direct parliamentary engagement is useful, the long-term success of this initiative will be significantly amplified by building a broad and diverse coalition of support outside of Parliament House. A groundswell of endorsement from respected government agencies, regulatory bodies, and civil society organisations can create an environment where the proposed legislative change is seen not just as viable, but as necessary and desirable. This strategy transforms the proposal from a niche "tech" issue into a mainstream economic, social, and environmental policy imperative.

## Engagement with Government and Regulators:

The advocacy could extend beyond ministerial offices into the senior ranks of the public service. A parallel track of engagement should be opened with senior officials at the Australian Treasury , the Department of Social Services (DSS) , and the Australian Securities and Investments Commission (ASIC) . The goal is to build bureaucratic understanding and support for the proposal. These departments will be provided with the detailed legal and economic analysis from this report, framed as a contribution to their ongoing policy work. For Treasury, it helps solve the "incompatibility" puzzle from their Token Mapping exercise. For DSS, it offers a novel, non-welfare tool to support caregivers and volunteers. For ASIC, it provides a clear and manageable framework for a new class of asset, reducing regulatory ambiguity. The support, or at least neutral understanding, of these bodies is crucial, as ministers rely heavily on their advice.

## Alliance with Civil Society:

The most persuasive public advocates for the C-hour may not be its creators, but the very communities it is designed to serve. Building a strong coalition with civil society is therefore the central pillar of the public-facing campaign. This involves forming strategic alliances with:

- The Social Enterprise Sector: Peak bodies like Social Traders are already advocating
- for the federal government to adopt social procurement frameworks and a national social enterprise strategy. 63 The C-hour provides a powerful piece of infrastructure to help achieve their goals. A joint submission or public statement with these groups would provide powerful validation.
- The Environmental Movement: Organisations such as the Australian Conservation Foundation (ACF), The Wilderness Society, and Landcare Australia are natural partners. 60 The C-hour can be presented to them as a new, scalable funding and incentive mechanism for on-the-ground conservation and regeneration efforts, empowering their volunteer networks and creating a direct economic case for environmental stewardship.
- The Care Sector: Engaging with unions representing community and care workers (such as the Australian Services Union), as well as peak bodies for caregivers (e.g., Carers Australia), is vital. These groups can speak with immense moral authority on the importance of valuing the work the C-hour measures. Their endorsement would powerfully resonate with the government and key parliamentarians like Senator Darmanin.

## Engagement with Industry:

Finally, support should be cultivated within the innovative segments of the business and finance community. This includes engaging with impact investors , who are philosophically aligned with the goal of generating a social dividend alongside financial returns, and forward-thinking fintech companies that can appreciate the technological elegance and potential of the protocol. Their support will demonstrate that the proposal is not anti-business, but represents the future of a more responsible and innovative economy. This diverse coalition provides a powerful political buffer, demonstrating that support for the Regenerative Asset class transcends traditional ideological divides and is rooted in a shared desire for a more prosperous, equitable, and sustainable Australia.

## Conclusion and Prioritised Recommendations

Australia stands at an important juncture in the development of its digital economy. The Digital Asset Platforms Bill 2025 is a testament to a thoughtful, evidence-based approach to regulation that rightly prioritises consumer protection and market integrity. However, in its current form, it is an incomplete architecture. By focusing exclusively on the risks of financialised, custodial platforms, it overlooks the immense opportunity presented by a new class of digital assets designed for social and ecological regeneration. This omission, if uncorrected, would inadvertently stifle a powerful form of Australian innovation that aligns directly with the government's highest aspirations for a more purposeful and inclusive economy.

The analysis in this report has demonstrated that a clear and compelling strategic pathway exists to correct this. The proposal to create a legislative 'carve-out' for 'Regenerative Assets' is not a radical departure from the government's agenda but a logical and necessary refinement. It leverages the Treasury's own expert findings from the Token Mapping exercise, which acknowledged the "fundamental incompatibility" of non-intermediated systems with the existing financial services framework. The Community-Hour is the archetype of such a system-one that is earned through contribution, governed by its community, and dedicated to making the foundational work of our society visible and valued.

Integrating this concept into law is both politically feasible and strategically advantageous. It strengthens the bipartisan consensus for digital asset reform by appealing to the core principles of both major parties. For the government, it provides a powerful tool to build its envisioned "values-based economy." For the opposition, it offers a market-based, pro-innovation solution that empowers civil society. The path forward requires a disciplined, multi-faceted effort that combines precise legal drafting with targeted political advocacy and the construction of a broad coalition of support. By embracing this opportunity, Australia can move beyond simply regulating the digital economy as it is, and begin to actively shape it into what it ought to be: an engine for shared prosperity and national well-being.

The following prioritised recommendations provide an actionable roadmap for achieving this strategic objective over the next 6-12 months:

1. Finalise and Lodge Treasury Submission: The immediate priority is to prepare and lodge a formal submission with the Australian Treasury in response to the exposure draft of the Digital Asset Platforms Bill 2025 . This submission could incorporate the detailed legal arguments, policy rationale, and specific draft legislative amendments contained in Parts II and III of this report. This is the single most effective action for influencing the final shape of the legislation.
2. Secure Ministerial and Departmental Briefings: Immediately following the submission, formally request meetings with the senior advisors in the offices of the Assistant Treasurer (Dr Mulino) and the Treasurer (Dr Chalmers). Concurrently, seek technical briefings with senior officials in the relevant divisions of Treasury and ASIC to present the proposal as a constructive and well-reasoned enhancement to their Bill.
3. Initiate Coalition Building with Civil Society: Commence a targeted outreach campaign to the leadership of key civil society stakeholders identified in Section 4.3. The initial focus should be on securing the endorsement of Social Traders, Carers Australia, and a leading national environmental organisation (e.g., the Australian Conservation Foundation). The goal is to establish a powerful group of third-party validators who can advocate for the proposal from a non-tech perspective.
4. Prepare a Senate Committee Engagement Package: In anticipation of the Bill's introduction to Parliament, compile a tailored package of materials for the members of the Senate Economics Legislation Committee. This package should include a concise one-page summary of the proposal, the detailed legal analysis, the draft amendments, and letters of support from coalition partners. This ensures the committee is fully briefed

and prepared to consider the amendments during its inquiry.

## Works cited

- 1.
- Treasury: Regulating digital asset platforms - exposure draft ..., accessed October 7, 2025,

https://www.regulationtomorrow.com/au/treasury-regulating-digital-asset-platfor ms-exposure-draft-legislation/

- More than meets the eye: navigating Australia's proposed regime for ..., accessed October 7, 2025,
- 2.

https://www.kwm.com/au/en/insights/latest-thinking/more-than-meets-the-eye-n avigating-australias-proposed-regime-for-digital-asset-and-tokenised-custodyplatforms.html

3. The Braided Economy Guidance\_ Integrating Regenerative Principles into U.S. Digital Asset Legislation.pdf
4. Token mapping | Treasury.gov.au, accessed October 7, 2025, https://treasury.gov.au/consultation/c2023-341659
3. 5.
4. Our position | A social purpose economy - now there's an idea, accessed October 7, 2025, https://www.socialtraders.com.au/news/our-position-a-social-purpose-economy -now-theres-an-idea/
6. Capitalism after the crises - FPIP, accessed October 7, 2025, https://www.fpinvest.com.au/blog-article/capitalism-after-the-crises
7. Senate Select Committee on Australia as a Technology and Financial Centre | APO, accessed October 7, 2025, https://apo.org.au/organisation/314356
8. Final report - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/Parliamentary\_Business/Committees/Senate/Financial\_Te

chnology\_and\_Regulatory\_Technology/AusTechFinCentre/Final\_report

9. Select Committee on Australia as a Technology and Financial Centre, accessed October 7, 2025,
2. https://www.aph.gov.au/Parliamentary\_Business/Committees/Senate/Financial\_Te chnology\_and\_Regulatory\_Technology
10. Cryptocurrency Is Here To Stay! - Senator Andrew Bragg, accessed October 7, 2025, https://www.andrewbragg.com/policy/the-new-economy
11. Senator Bragg proposes Digital Assets Bill to parliament - SW Accountants &amp; Advisors, accessed October 7, 2025, https://www.sw-au.com/insights/article/senator-bragg-proposes-digital-assets-b ill-to-parliament/
12. Senate report on Australia as a technology and financial centre - Lander &amp; Rogers, accessed October 7, 2025, https://www.landers.com.au/legal-insights-news/senate-report-on-australia-as-t

echnology-and-financial-centre

13. Australia as a Technology and Financial Centre: Report - Dwyer Harris business lawyers, accessed October 7, 2025, https://www.dwyerharris.com/blog/australia-as-a-technology-and-financial-centr

## e-report

- 14.
- Australia as a Technology and Financial Centre - PwC Australia, accessed October 7, 2025,

https://www.pwc.com.au/banking-capital-markets/pwc-perspectives-australia-as -a-technology-and-financial-centre.pdf

- 15.
- Overview of digital assets markets and regulation - Parliament of Australia, accessed October 7, 2025,

https://www.aph.gov.au/Parliamentary\_Business/Committees/Senate/Financial\_Te chnology\_and\_Regulatory\_Technology/AusTechFinCentre/Final\_report/Section?id =committees%2Freportsen%2F024747%2F78067

16. Crypto consultation: The Australian token mapping exercise | Russell Kennedy, accessed October 7, 2025, https://www.russellkennedy.com.au/insights-events/insights/crypto-consultationthe-australian-token-mapping-exercise
17. Not by the same token - Treasury releases its Token Mapping consultation KWM, accessed October 7, 2025, https://www.kwm.com/au/en/insights/latest-thinking/not-by-the-same-token-trea sury-releases-its-token-mapping-consultation.html
18. Navigating the Australian Token Mapping Consultation - Bits of Blocks, accessed October 7, 2025, https://www.bitsofblocks.io/post/navigating-the-australian-token-mapping-cons ultation
19. Token Mapping in Australia - Ally Law, accessed October 7, 2025, https://ally-law.com/crypto-consultation-the-australian-token-mapping-exercise/
20. Australia tightens crypto rules to protect investors - Information Age | ACS, accessed October 7, 2025, https://ia.acs.org.au/article/2025/australia-tightens-crypto-rules-to-protect-inves tors.html
21. Australian Treasury consults on AFSL obligations for crypto-asset platforms, accessed October 7, 2025, https://www.claytonutz.com/insights/2023/october/australian-treasury-consults-o n-afsl-obligations-for-crypto-asset-platforms
22. Practically unpacking Treasury's proposed digital assets legislation | Financial Services, accessed October 7, 2025, https://www.tglaw.com.au/insights/practically-unpacking-treasurys-proposed-dig ital-assets-legislation
23. Australia: Australian Government moves to regulate digital asset and ..., accessed October 7, 2025, https://insightplus.bakermckenzie.com/bm/banking-finance\_1/australia-australian -government-moves-to-regulate-digital-asset-and-tokenised-custody-platform s
24. Ministers | Treasury.gov.au, accessed October 7, 2025, https://treasury.gov.au/the-department/about-treasury/our-ministers
25. Jim Chalmers | Member for Rankin - Australian Labor Party, accessed October 7, 2025, https://www.alp.org.au/our-people/our-people/jim-chalmers/
26. Biography | Treasury Ministers, accessed October 7, 2025, https://ministers.treasury.gov.au/ministers/jim-chalmers-2022/biography
27. Your Ministry | Prime Minister of Australia, accessed October 7, 2025, https://www.pm.gov.au/your-ministry
28. Treasurer Jim Chalmers evokes Hawke-era consensus as 'political footballs' are tossed around his economic roundtable - Startup Daily, accessed October 7, 2025,

https://www.startupdaily.net/topic/politics-news-analysis/treasurer-jim-chalmers -evokes-hawke-era-consensus-as-political-footballs-are-tossed-around-his-ec onomic-roundtable/

29. Keynote address to the Economic and Social Outlook Conference, Melbourne | Treasury Ministers, accessed October 7, 2025, https://ministers.treasury.gov.au/ministers/jim-chalmers-2022/speeches/keynoteaddress-economic-and-social-outlook-conference
30. The Hon Dr Daniel Mulino MP | Treasury Ministers, accessed October 7, 2025, https://ministers.treasury.gov.au/ministers/daniel-mulino-2025
31. Minister for Financial Services - Wikipedia, accessed October 7, 2025, https://en.wikipedia.org/wiki/Minister\_for\_Financial\_Services
32. Hon Dr Daniel Mulino MP - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/Senators\_and\_Members/Parliamentarian?MPID=132880
33. Australian Government Address - Assistant Treasurer Dr Daniel Mulino - YouTube, accessed October 7, 2025, https://www.youtube.com/watch?v=j80e\_8rbdI0
6. 34.
7. Australia Proposes Digital Asset Platform Regulations | Phemex News, accessed October 7, 2025, https://phemex.com/news/article/australia-proposes-regulatory-framework-for-d igital-asset-platforms-21077
8. 35.
9. Australia Drafts Law to Tighten Oversight of Digital Asset Platforms - Decrypt, accessed October 7, 2025, https://decrypt.co/341217/australia-drafts-law-tighten-oversight-digital-asset-pla tforms
36. Committee Membership - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/Parliamentary\_Business/Committees/House/Economics/ Committee\_Membership
37. Hon Ed Husic MP - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/e\_husic\_mp
12. 38.
13. Industry, science and technology powering a Future Made in Australia, accessed October 7, 2025, https://www.minister.industry.gov.au/ministers/husic/media-releases/industry-scie nce-and-technology-powering-future-made-australia
39. Unlocking the potential of AI for Australian industry, accessed October 7, 2025, https://www.minister.industry.gov.au/ministers/husic/speeches/unlocking-potentia l-ai-australian-industry
40. Industry and Science Minister Ed Husic's National Press Club address - Science Meets Parliament 2023, accessed October 7, 2025, https://scienceandtechnologyaustralia.org.au/industry-and-science-minister-ed-

husics-press-club-2023/

41. Industry Minister Ed Husic flags crackdown on 'risky' artificial intelligence - The Nightly, accessed October 7, 2025,

https://thenightly.com.au/society/technology/industry-minister-ed-husic-flags-cr ackdown-on-risky-artificial-intelligence-c-15944970

42. Legislation Committee Membership - Parliament of Australia, accessed October 7, 2025,

https://www.aph.gov.au/Parliamentary\_Business/Committees/Senate/Economics/ Legislation\_Committee\_Membership

43. Economics Legislation Committee, accessed October 7, 2025, http://navigatesenatecommittees.senate.gov.au/committees/c028--economics
44. Lisa Darmanin | Senator for Victoria - Australian Labor Party, accessed October 7, 2025, https://www.alp.org.au/our-people/our-people/lisa-darmanin/
45. Lisa Darmanin: Home, accessed October 7, 2025, https://lisadarmanin.com.au/
46. Senator Lisa Darmanin's first speech, accessed October 7, 2025,
5. https://lisadarmanin.client.trfg.au/media/senator-lisa-darmanins-first-speech/
47. Economic reform - Allegra Spender, accessed October 7, 2025, https://www.allegraspender.com.au/4821/economic\_reform
48. 834b productivity roundtable, tax, housing, intergenerational wealth + more with Allegra Spender - YouTube, accessed October 7, 2025, https://www.youtube.com/watch?v=dsw-wj-0zSU
49. Allegra Spender MP urges reform to address skills shortage and boost Australian economy, accessed October 7, 2025, https://activateaustralia.org.au/allegra-spender-mp-urges-reform-to-address-skil ls-shortage-and-boost-australian-economy/
50. Additional Comments from Ms Allegra Spender MP - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/Parliamentary\_Business/Committees/House/Economics/E conomicdynamism/Report/Additional\_Comments\_from\_Ms\_Allegra\_Spender\_MP
51. Advocacy | Digital Economy Council of Australia, accessed October 7, 2025, https://deca.org.au/advocacy/
52. Crypto advocate Senator Andrew Bragg has launched his own digital assets legislation to Parliament - Startup Daily, accessed October 7, 2025, https://www.startupdaily.net/topic/cryptocurrency/crypto-senator-andrew-bragg -digital-assets-legislation/
53. Senator Bragg releases draft bill on Digital Assets regulation - Bits of Blocks, accessed October 7, 2025, https://www.bitsofblocks.io/post/senator-bragg-releases-draft-bill-on-digital-ass ets-regulation
54. Senator the Hon Jane Hume - Parliament of Australia, accessed October 7, 2025, https://www.aph.gov.au/Senators\_and\_Members/Parliamentarian?MPID=266499
55. Supporting Australia's FinTech sector | Minister for Trade and Tourism, accessed October 7, 2025,

https://www.trademinister.gov.au/minister/dan-tehan/media-release/supporting-a ustralias-fintech-sector

56. Senator The Hon Jane Hume | Treasury Ministers, accessed October 7, 2025, https://ministers.treasury.gov.au/ministers/jane-hume-2019
57. Senator the Hon Jane Hume | Minister for Superannuation, Financial Services and the Digital Economy, Australian Government - Innovate Finance, accessed October 7, 2025,

https://www.innovatefinance.com/profiles/senator-the-hon-jane-hume/

58. Jane Hume | Money Management, accessed October 7, 2025, https://www.moneymanagement.com.au/topics/jane-hume?page=4
59. Environment | Policy Portfolio - The Australian Greens, accessed October 7, 2025, https://greens.org.au/portfolios/environment
60. Revealed: The 10 Most Influential Sustainability Voices in Australia | Ecobin Australia, accessed October 7, 2025, https://www.ecobin.com.au/blogs/blog/revealed-10-influential-sustainability-voic es-australia
61. Removing the Fossil Fuel Industry's Influence on Politics and Parliament | Senator Larissa Waters - The Australia Institute, accessed October 7, 2025, https://australiainstitute.org.au/post/removing-the-fossil-fuel-industrys-influence -on-politics-and-parliament-senator-larissa-waters/
62. Crypto-assets | ASIC, accessed October 7, 2025, https://www.asic.gov.au/regulatory-resources/digital-transformation/crypto-asset s/
63. Social Traders advocates for social enterprise to be part of the productivity agenda | Unlocking business for good, accessed October 7, 2025, https://www.socialtraders.com.au/news/social-traders-advocates-for-economicreform-through-social-enterprise/
64. Australian Government backing social enterprise to deliver multiple policy agendas, accessed October 7, 2025, https://www.socialtraders.com.au/news/australian-government-backing-social-e nterprise-to-deliver-multiple-policy-agendas/
