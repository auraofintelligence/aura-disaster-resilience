# Minjerribah Screen & Media Network

A cinematic, multi-page public invitation connecting existing film, local-media,
training, noticeboard, Ballow Road, sand-sport and long-horizon transport
workbenches.

The site is deliberately source-honest:

- active public prototypes stay separate from official projects;
- proposals are labelled as proposals;
- the Quandamooka Festival, QUAMPI and cultural authority are not claimed;
- Ready S.E.T. Co-op is not presented as an already formed entity;
- community screens do not replace emergency authorities; and
- tunnels, park-and-ride and spoil reuse remain future questions, not engineering
  plans.

<!-- github-organisation:start -->

## Project links and history

- First substantive build: 24 July 2026.
- GitHub repository: [minjerribah-screen-media-network](https://github.com/auraofintelligence/minjerribah-screen-media-network).
- Public site: [visit the public site](https://auraofintelligence.github.io/minjerribah-screen-media-network/).

## Related public projects

Each link below reflects an evidenced family, lineage or direct connection. This project has 10 relevant public connections.

### Direct and other supported connections

- [Sandworm-subterranean-systems](https://github.com/auraofintelligence/sandworm-subterranean-systems) - [public page](https://auraofintelligence.github.io/sandworm-subterranean-systems/) - explicit cross-reference.

### Ready SET and Minjerribah media network

- [explorer-music-video-lab](https://github.com/auraofintelligence/explorer-music-video-lab) - [public page](https://auraofintelligence.github.io/explorer-music-video-lab/) - shared community programme.
- [film-club-documentary-builders](https://github.com/auraofintelligence/film-club-documentary-builders) - [public page](https://auraofintelligence.github.io/film-club-documentary-builders/) - shared community programme.
- [grain-by-grain-documentary](https://github.com/auraofintelligence/grain-by-grain-documentary) - [public page](https://auraofintelligence.github.io/grain-by-grain-documentary/) - shared community programme.
- [quandamooka-country-events-engine](https://github.com/auraofintelligence/quandamooka-country-events-engine) - [public page](https://auraofintelligence.github.io/quandamooka-country-events-engine/) - shared community programme.
- [quandamooka-film-festival](https://github.com/auraofintelligence/quandamooka-film-festival) - [public page](https://auraofintelligence.github.io/quandamooka-film-festival/) - explicit cross-reference, shared community programme.
- [ready-set-co-op-hyperlocal-media](https://github.com/auraofintelligence/ready-set-co-op-hyperlocal-media) - [public page](https://auraofintelligence.github.io/ready-set-co-op-hyperlocal-media/) - explicit cross-reference, shared community programme.
- [ready-set-co-op-trust-hub](https://github.com/auraofintelligence/ready-set-co-op-trust-hub) - [public page](https://auraofintelligence.github.io/ready-set-co-op-trust-hub/) - explicit cross-reference, shared community programme.
- [straddie-content-assets-kit](https://github.com/auraofintelligence/straddie-content-assets-kit) - [public page](https://auraofintelligence.github.io/straddie-content-assets-kit/) - shared community programme.
- [straddie-news](https://github.com/auraofintelligence/straddie-news) - [public page](https://auraofintelligence.github.io/straddie-news/) - explicit cross-reference, shared community programme.

<!-- github-organisation:end -->

## Public pages

- Opening night
- Media network
- Ballow Road
- Fund the layers
- Join the build
- Receipts

## Edit the content

Most shared lists, links and editable planning allowances live in
`data/site-content.ts`. Page copy lives in `components/`.

## Run locally on Windows

```powershell
npm.cmd install
npm.cmd run dev
```

Open the local address shown in the terminal.

## Check both publishing builds

```powershell
npm.cmd test
```

The project produces:

- a vinext build for private preview and Sites hosting; and
- a separate static multi-page build in `pages-dist/` for GitHub Pages.

## Public participation

The GitHub collaboration form is a public issue form. Do not place sensitive
cultural, personal, youth, health, legal or commercial information in it.

## Status

First super-site build: 24 July 2026, Brisbane / AEST.
